package com.exam.config.kaptcha;

import com.exam.config.redis.RedisService;
import com.exam.config.security.exception.CustomerAuthenticationException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.ObjectUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;


/**
 * @author dyy
 */
public class MyAuthenticationProvider extends DaoAuthenticationProvider {

    @Resource
    private RedisService redisService;

    @Override
    protected void additionalAuthenticationChecks(UserDetails userDetails,
                                                  UsernamePasswordAuthenticationToken authentication) {
        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String code = req.getParameter("code");
        System.out.println("请求参数中验证码："+code);
//        String verify_code = (String) req.getSession().getAttribute("captcha");
        String verify_code = redisService.get("captcha");

        if (ObjectUtils.isEmpty(code)) {
            throw new CustomerAuthenticationException("请输入验证码");
        }
        //如果redis里面没有captcha,说明该captcha失效
        if (ObjectUtils.isEmpty(verify_code)) {
            throw new CustomerAuthenticationException("验证码已过期");
        }
        //如果code和Redis中的verify_code不一致，则验证失败
        if (!code.equals(verify_code)) {
            throw new CustomerAuthenticationException("验证码错误");
        }
        System.out.println("验证码："+verify_code);
        super.additionalAuthenticationChecks(userDetails, authentication);
    }
}
