package org.dfzt.controller;


import io.minio.MinioClient;
import io.minio.PutObjectOptions;
import io.minio.errors.*;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
//import jdk.nashorn.internal.runtime.regexp.joni.exception.InternalException;
import org.apache.commons.math3.exception.InsufficientDataException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;

/**
 * @ClassName BucketExistsController
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/7/13 9:09
 */
@Api(tags = "上传文件至存储桶")
@RestController
@RequestMapping("/bucketExists")
public class BucketExistsController {

    @ApiOperation(value = "蒙东文件存储",response = String.class)
    @PostMapping(value = "/bucket/import",headers = "content-type=multipart/form-data")
    public String bucketExistsImport(@RequestPart("file") MultipartFile file,
                                @RequestParam(required = false) String bucketName) {

        String objectName=null;
        try {
            // 使用MinIO服务的URL，端口，Access key和Secret key创建一个MinioClient对象
            MinioClient minioClient = new MinioClient(
                    "http://10.168.1.101:9000",
                    "minioadmin", "minioadmin");

           // 检查存储桶是否已经存在
            String filename = file.getOriginalFilename();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            // 设置存储对象名称
             objectName = filename;
            // 使用 putObject 上传一个文件到存储桶中。
            minioClient.putObject("mengdong",objectName,file.getInputStream(),new PutObjectOptions(file.getInputStream().available(), -1));
            System.out.println("D:\\'"+"文件上传"+"'+is successfully" +
                    " uploaded as images.zip to `files` bucket.");
        } catch(Exception e) {
            e.printStackTrace();
        }
       return objectName;
    }

    @GetMapping("/getFileLink")
    public String getFileLink(String fileName) throws InvalidPortException, InvalidEndpointException, InvalidBucketNameException, InsufficientDataException, ErrorResponseException, InvalidExpiresRangeException, IOException, NoSuchAlgorithmException, InvalidKeyException, InvalidResponseException, XmlParserException, InternalException, io.minio.errors.InsufficientDataException, io.minio.errors.InternalException {
        MinioClient minioClient = new MinioClient(
                "http://10.168.1.101:9000",
                "minioadmin", "minioadmin");
        String path = minioClient.presignedGetObject("mengdong",fileName,10000);
        return path;
    }

}
