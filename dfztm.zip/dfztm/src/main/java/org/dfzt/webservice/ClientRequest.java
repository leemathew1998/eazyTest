package org.dfzt.webservice;

import org.apache.cxf.Bus;
import org.apache.cxf.endpoint.*;
import org.apache.cxf.endpoint.dynamic.DynamicClientFactory;
import org.apache.cxf.interceptor.Interceptor;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.service.model.BindingOperationInfo;
import org.apache.cxf.transport.Conduit;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.xml.namespace.QName;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;

@Configuration
public class ClientRequest {
    private static final String WSDLURL = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";

    @Bean
    public Client wsdlClient(){
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
//        Client client = dcf.createClient(WSDLURL);
        Client client = new Client() {
            @Override
            public void onMessage(Message message) {

            }

            @Override
            public List<Interceptor<? extends Message>> getInInterceptors() {
                return null;
            }

            @Override
            public List<Interceptor<? extends Message>> getOutInterceptors() {
                return null;
            }

            @Override
            public List<Interceptor<? extends Message>> getInFaultInterceptors() {
                return null;
            }

            @Override
            public List<Interceptor<? extends Message>> getOutFaultInterceptors() {
                return null;
            }

            @Override
            public Object[] invoke(String s, Object... objects) throws Exception {
                return new Object[0];
            }

            @Override
            public Object[] invoke(QName qName, Object... objects) throws Exception {
                return new Object[0];
            }

            @Override
            public Object[] invokeWrapped(String s, Object... objects) throws Exception {
                return new Object[0];
            }

            @Override
            public Object[] invokeWrapped(QName qName, Object... objects) throws Exception {
                return new Object[0];
            }

            @Override
            public Object[] invoke(BindingOperationInfo bindingOperationInfo, Object... objects) throws Exception {
                return new Object[0];
            }

            @Override
            public Object[] invoke(BindingOperationInfo bindingOperationInfo, Object[] objects, Map<String, Object> map) throws Exception {
                return new Object[0];
            }

            @Override
            public Object[] invoke(BindingOperationInfo bindingOperationInfo, Object[] objects, Map<String, Object> map, Exchange exchange) throws Exception {
                return new Object[0];
            }

            @Override
            public void invoke(ClientCallback clientCallback, String s, Object... objects) throws Exception {

            }

            @Override
            public void invoke(ClientCallback clientCallback, QName qName, Object... objects) throws Exception {

            }

            @Override
            public void invokeWrapped(ClientCallback clientCallback, String s, Object... objects) throws Exception {

            }

            @Override
            public void invokeWrapped(ClientCallback clientCallback, QName qName, Object... objects) throws Exception {

            }

            @Override
            public void invoke(ClientCallback clientCallback, BindingOperationInfo bindingOperationInfo, Object... objects) throws Exception {

            }

            @Override
            public void invoke(ClientCallback clientCallback, BindingOperationInfo bindingOperationInfo, Object[] objects, Map<String, Object> map) throws Exception {

            }

            @Override
            public void invoke(ClientCallback clientCallback, BindingOperationInfo bindingOperationInfo, Object[] objects, Exchange exchange) throws Exception {

            }

            @Override
            public void invoke(ClientCallback clientCallback, BindingOperationInfo bindingOperationInfo, Object[] objects, Map<String, Object> map, Exchange exchange) throws Exception {

            }

            @Override
            public Map<String, Object> getRequestContext() {
                return null;
            }

            @Override
            public Map<String, Object> getResponseContext() {
                return null;
            }

            @Override
            public void setThreadLocalRequestContext(boolean b) {

            }

            @Override
            public boolean isThreadLocalRequestContext() {
                return false;
            }

            @Override
            public Endpoint getEndpoint() {
                return null;
            }

            @Override
            public Conduit getConduit() {
                return null;
            }

            @Override
            public ConduitSelector getConduitSelector() {
                return null;
            }

            @Override
            public void setConduitSelector(ConduitSelector conduitSelector) {

            }

            @Override
            public void destroy() {

            }

            @Override
            public void setExecutor(Executor executor) {

            }

            @Override
            public Bus getBus() {
                return null;
            }
        };

        return client;
    }
}
