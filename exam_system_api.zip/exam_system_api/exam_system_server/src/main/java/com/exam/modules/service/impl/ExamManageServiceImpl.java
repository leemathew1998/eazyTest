package com.exam.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.exam.modules.entity.vo.ExamManageVo;
import com.exam.modules.mapper.ExamManageMapper;
import com.exam.modules.entity.ExamManage;
import com.exam.modules.service.ExamManageService;
import org.springframework.stereotype.Service;

/**
 * 考试管理(ExamManage)表服务实现类
 *
 * @author makejava
 * @since 2022-11-08 17:16:07
 */
@Service("examManageService")
public class ExamManageServiceImpl extends ServiceImpl<ExamManageMapper, ExamManage> implements ExamManageService {

    /**
     *分页查询考试列表
     * @param page
     * @param examManageVo
     * @return
     */
    @Override
    public IPage<ExamManage> findExamManageList(IPage<ExamManage> page, ExamManageVo examManageVo) {
        //创建条件构造器
        QueryWrapper<ExamManage> queryWrapper = new QueryWrapper<>();
        return baseMapper.selectPage(page,queryWrapper);
    }


//    @Override
//    public IPage<ExamManage> select(IPage<ExamManage> page, ExamManageVo manageVo) {
//        QueryWrapper<ExamManage> queryWrapper = new QueryWrapper<>();
//        return baseMapper.selectPage(page,queryWrapper);
//    }
}
