package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@ApiModel(value="s_power_violate_steal")
@Data
@TableName(value = "s_power_violate_steal")
public class SPowerViolateSteal {
    /**
     * 违约窃电编号
     */
    @TableId(value = "violate_no", type = IdType.INPUT)
    @ApiModelProperty(value="违约窃电编号")
    private Long violateNo;

    /**
     * 违约用电窃电性质
     */
    @TableField(value = "attr_code")
    @ApiModelProperty(value="违约用电窃电性质")
    private String attrCode;

    /**
     * 现场调_取证编号
     */
    @TableField(value = "s_s_id")
    @ApiModelProperty(value="现场调_取证编号")
    private Long sSId;

    /**
     * 现场描述
     */
    @TableField(value = "alarm_desc")
    @ApiModelProperty(value="现场描述")
    private String alarmDesc;

    /**
     * 备用字段8
     */
    @TableField(value = "extend_field_8")
    @ApiModelProperty(value="备用字段8")
    private String extendField8;

    /**
     * 有效标识
     */
    @TableField(value = "extend_field_valid_flag")
    @ApiModelProperty(value="有效标识")
    private String extendFieldValidFlag;

    /**
     * 追补电量
     */
    @TableField(value = "add_pq")
    @ApiModelProperty(value="追补电量")
    private Long addPq;

    /**
     * 备用字段6
     */
    @TableField(value = "extend_field_6")
    @ApiModelProperty(value="备用字段6")
    private String extendField6;

    /**
     * 违约用电窃电类别
     */
    @TableField(value = "type_code")
    @ApiModelProperty(value="违约用电窃电类别")
    private String typeCode;

    /**
     * 省公司标识代码
     */
    @TableField(value = "extend_field_org_code")
    @ApiModelProperty(value="省公司标识代码")
    private String extendFieldOrgCode;

    /**
     * 发生时间
     */
    @TableField(value = "occur_time")
    @ApiModelProperty(value="发生时间")
    private String occurTime;

    /**
     * 备用字段2
     */
    @TableField(value = "extend_field_2")
    @ApiModelProperty(value="备用字段2")
    private String extendField2;

    /**
     * 备用字段1
     */
    @TableField(value = "extend_field_1")
    @ApiModelProperty(value="备用字段1")
    private String extendField1;

    /**
     * 备用字段4
     */
    @TableField(value = "extend_field_4")
    @ApiModelProperty(value="备用字段4")
    private String extendField4;

    /**
     * 复电信_复电编号
     */
    @TableField(value = "s_p_id")
    @ApiModelProperty(value="复电信_复电编号")
    private Long sPId;

    /**
     * 现场取证记录
     */
    @TableField(value = "evidence_content")
    @ApiModelProperty(value="现场取证记录")
    private String evidenceContent;

    /**
     * 来源系统
     */
    @TableField(value = "extend_field_src_system")
    @ApiModelProperty(value="来源系统")
    private String extendFieldSrcSystem;

    /**
     * 备用字段7
     */
    @TableField(value = "extend_field_7")
    @ApiModelProperty(value="备用字段7")
    private String extendField7;

    /**
     * 检查结果标识
     */
    @TableField(value = "id")
    @ApiModelProperty(value="检查结果标识")
    private Long id;

    /**
     * DS
     */
    @TableField(value = "ds")
    @ApiModelProperty(value="DS")
    private String ds;

    /**
     * 备用字段9
     */
    @TableField(value = "extend_field_9")
    @ApiModelProperty(value="备用字段9")
    private Date extendField9;

    /**
     * 增量标识
     */
    @TableField(value = "extend_field_update_flag")
    @ApiModelProperty(value="增量标识")
    private String extendFieldUpdateFlag;

    /**
     * 立案标志
     */
    @TableField(value = "case_flag")
    @ApiModelProperty(value="立案标志")
    private String caseFlag;

    /**
     * 数据修改时间
     */
    @TableField(value = "extend_field_update_time")
    @ApiModelProperty(value="数据修改时间")
    private Date extendFieldUpdateTime;

    /**
     * 数据生成时间戳
     */
    @TableField(value = "extend_field_time_stamp")
    @ApiModelProperty(value="数据生成时间戳")
    private Date extendFieldTimeStamp;

    /**
     * 备用字段5
     */
    @TableField(value = "extend_field_5")
    @ApiModelProperty(value="备用字段5")
    private Date extendField5;

    /**
     * 是否停电
     */
    @TableField(value = "poweroff_flag")
    @ApiModelProperty(value="是否停电")
    private String poweroffFlag;

    /**
     * 违约使用电费
     */
    @TableField(value = "amt")
    @ApiModelProperty(value="违约使用电费")
    private Long amt;

    /**
     * 备用字段10
     */
    @TableField(value = "extend_field_10")
    @ApiModelProperty(value="备用字段10")
    private Date extendField10;

    /**
     * 备用字段3
     */
    @TableField(value = "extend_field_3")
    @ApiModelProperty(value="备用字段3")
    private Date extendField3;

    /**
     * 追补电费
     */
    @TableField(value = "add_amt")
    @ApiModelProperty(value="追补电费")
    private Long addAmt;

    /**
     * 缴费确认编号
     */
    @TableField(value = "id2")
    @ApiModelProperty(value="缴费确认编号")
    private Date id2;
}