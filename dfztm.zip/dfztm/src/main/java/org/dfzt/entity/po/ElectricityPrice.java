package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "ElectricityPrice对象", description = "")
public class ElectricityPrice implements Serializable {


    private Integer id;
    @ApiModelProperty(value = "主键")
    @TableId(value = "key_id", type = IdType.AUTO)
    private String keyId;

    @ApiModelProperty(value = "定价策略")
    @TableField("price_strategy")
    private String priceStrategy;

    @ApiModelProperty(value = "基本电费计算方式")
    @TableField("basic_cal_method")
    private String basicCalMethod;

    @ApiModelProperty(value = "需量核定值")
    @TableField("de_value")
    private String deValue;

    @ApiModelProperty(value = "功率因数考核方式")
    @TableField("ass_method")
    private String assMethod;

    @ApiModelProperty(value = "用户编号")
    private String consNo;

}
