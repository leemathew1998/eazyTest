package com.exam.modules.utils;

import com.exam.modules.entity.SysMenu;
import com.exam.modules.entity.vo.RouterVo;
import org.springframework.beans.BeanUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * @Author dyy
 * @Date 2022/10/31 19:45
 * @PackageName:com.exam.modules.utils
 * @ClassName: MenuTree
 * @Description: TODO 生成菜单树
 * @Version 1.0
 */
public class MenuTree {
    /**
     * 生成路由
     *
     * @param meuList 菜单列表
     * @param pid 父级菜单
     * @return
     */
    public static List<RouterVo> makeRouter(List<SysMenu> meuList, Long pid) {
        //创建集合保存路由列表
        List<RouterVo> routerList = new ArrayList<RouterVo>();
        //如果menuList菜单列表不为空，则使用菜单列表，否则创建集合对象
        Optional.ofNullable(meuList).orElse(new ArrayList<SysMenu>())
                //筛选不为空的菜单及菜单父id相同的数据
                .stream().filter(item -> item != null && item.getPid() == pid)
                .forEach(item -> {
                    RouterVo router = new RouterVo();
                    router.setName(item.getName());//路由名称
                    router.setPath(item.getUrl());//路由地址
                    //判断是否是一级菜单
                    if (item.getPid() == 0L) {
                        router.setComponent("Layout");//一级菜单组件
                        router.setAlwaysShow(true);//显示路由
                    } else {
                        router.setComponent(item.getUrl());//具体的组件
                        router.setAlwaysShow(false);//折叠路由
                    }

                    //设置meta信息
                    router.setMeta(router.new Meta(
                            item.getName(),
                            item.getIcon(),
                            item.getPerms().split(",")));
                    //递归生成路由
                    List<RouterVo> children = makeRouter(meuList, item.getMenuId());
                    router.setChildren(children);//设置子路由到路由对象中
                    //将路由信息添加到集合中
                    routerList.add(router);
                });
        return routerList;
    }
    /**
     * 生成菜单树
     *
     * @param meuList
     * @param pid
     * @return
     */
    public static List<SysMenu> makeMenuTree(List<SysMenu> meuList, Long pid) {
        //创建集合保存菜单
        List<SysMenu> permissionList = new ArrayList<SysMenu>();
        //如果menuList菜单列表不为空，则使用菜单列表，否则创建集合对象
        Optional.ofNullable(meuList).orElse(new ArrayList<SysMenu>())
                .stream().filter(item -> item != null && Objects.equals(item.getPid(), pid))
                .forEach(item -> {
                    //创建菜单权限对象
                    SysMenu sysMenu = new SysMenu();
                    //复制属性
                    BeanUtils.copyProperties(item, sysMenu);
                    //获取每一个item的下级菜单,递归生成菜单树
                    List<SysMenu> children = makeMenuTree(meuList, item.getMenuId());
                    //设置子菜单
                    sysMenu.setChildren(children);
                    //将菜单对象添加到集合
                    permissionList.add(sysMenu);
                });
        return permissionList;
    }
}
