package org.dfzt.response;

import io.swagger.models.auth.In;

/**
 * @Author dyy
 * @Date 2022/7/11 14:51
 * @PackageName:org.dfzt.response
 * @ClassName: ResultCode
 * @Description: TODO 公共返回类
 * @Version 1.0
 */
public enum ResultCode implements CustomizeResultCode{
    /**
     * 20000:"成功"
     */
    SUCCESS(20000,  "成功"),
    /**
     * 20001:”失败”
     */
    ERROR(20001,"失败"),
    /**
     * 404:没有找到对应的请求路径
     */
    PAGE_NOT_FOUND(404,"你请求的页面暂时飘走了。。。"),
    /**
     * 500:服务端异常
     */
    INTERNAL_SERVER_ERROR(500,"服务器冒烟了。。。要不等他降降温再来访问"),
    /**
     * 2001:未知异常
     */
    UNKNOW_SERVER_ERROR(2001,"未知异常请联系管理员！"),

    /**
     * 3006:算术异常
     */
    ARITHMETIC_EXCEPTION(3006,"算术异常"),

    /**
     * 3007:用户不存在
     */
    USER_NOT_FOUND_EXCEPTION(3007,"用户不存在")
   ;

    private Integer code;
    private String message;

    ResultCode(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
