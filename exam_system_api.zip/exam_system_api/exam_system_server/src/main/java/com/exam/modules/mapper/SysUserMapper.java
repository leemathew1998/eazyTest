package com.exam.modules.mapper;

import com.exam.modules.entity.ExamInfo;
import com.exam.modules.entity.SysUser;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.security.core.userdetails.User;

import java.util.List;


/**
 * <p>
 * 用户表 Mapper 接口
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface SysUserMapper extends BaseMapper<SysUser> {
    /**
     * 删除用户角色关系
     * @param userId
     * @return
     */
    @Delete("DELETE FROM EXAM.SYS_USER_ROLE WHERE USER_ID=#{userId}")
    int deleteUserRole(Long userId);

    /**
     * 保存用户角色关系
     * @param userId
     * @param roleIds
     * @return
     */
    int saveUserRole(Long userId, List<Long> roleIds);

    /**
     * 根据id查询用户考试信息
     * @param userId
     * @return
     */
    @Select("SELECT * FROM (\n" +
                    "SELECT row_.*, rownum rn FROM (\n" +
                            "SELECT EI.*,EM.EXAM_LONG_TIME examLongTime,EM.EXAM_BEGIN_TIME examBeginTime,\n" +
                            "EM.EXAM_END_TIME examEndTime,EM.EXAM_TYPE examType,\n" +
                            "EPI.EXAM_PAPER_ID paperId,EPI.TIDS tids\n" +
                            "FROM EXAM.EXAM_INFO EI\n" +
                            "LEFT JOIN EXAM.EXAM_MANAGE EM ON EI.EXAM_ID = EM.EXAM_ID\n" +
                            "LEFT JOIN EXAM.EXAM_PAPER_INFO EPI ON EM.EXAM_PAPER_ID = EPI.EXAM_PAPER_ID\n" +
                            "WHERE USER_ID = #{userId}\n" +
                    ") row_ WHERE rownum <= #{pageEnd}\n" +
            ") WHERE rn>=  #{pageStart}")
    List<ExamInfo> selectExamInfo(Long userId,Integer pageStart,Integer pageEnd);


}
