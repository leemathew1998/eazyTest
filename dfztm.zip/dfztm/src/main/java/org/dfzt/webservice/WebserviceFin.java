package org.dfzt.webservice;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.apache.cxf.service.model.BindingInfo;
import org.apache.cxf.service.model.BindingOperationInfo;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.dfzt.entity.dto.ExecuteLog;
import org.dfzt.entity.dto.ExecuteLogDetail;
import org.dfzt.entity.po.CollectFailure;
import org.dfzt.entity.po.CollectNotcon;
import org.dfzt.entity.xmlDemoReal.Demo1;
import org.dfzt.entity.xmlDemoReal.DemoConverter;
import org.dfzt.entity.xmlDemoReal.General;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.mapper.ExecuteLogDetailMapper;
import org.dfzt.mapper.ExecuteLogMapper;
import org.dfzt.mapper.LinelossWorkOrderMapper;
import org.dfzt.service.CollectWorkOrderService;
import org.dfzt.util.TimeUtil;
import org.dfzt.util.XStreamUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.xml.namespace.QName;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/3/11
 * @Version: 1.00 采集工单归档研判定时任务
 */
@RestController
@RequestMapping("/webservicefin")
@Slf4j
@Component
@CrossOrigin
public class WebserviceFin {
    @Resource
    CollectWorkOrderMapper collwoMapper;
    @Resource
    CollectWorkOrderService collwoService;
    @Resource
    LinelossWorkOrderMapper linelossWorkOrderMapper;
    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;
    @Resource
    ExecuteLogDetailMapper executeLogDetailMapper;
    @Resource
    ExecuteLogMapper executeLogMapper;

    //采集失败判断归档数据
    //@Scheduled(cron = "0 0/30 * * * ? ")
    @Scheduled(cron = "0 0 16 * * ? ")
    @Async
    @RequestMapping("collfailfin")
    public void getCollfailfin(){
        List<General> generals = Lists.newArrayList();
        //入参mr_date字符串 （2022-12-15）
        String startTime = TimeUtil.getTodayTime();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        /*创建动态客户端*/
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        /*创建本地客户端连接*/
        System.out.println("获取客户端连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalFailData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisticalFailData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> lists = collwoMapper.selectOrgList();
            List<String> selectfailfin = collwoMapper.selectfailfin(TimeUtil.getTodayTime());//待归档工单电能表资产号列表
            List<String> failfins = new ArrayList<>();//仍采集失败的电能表资产号
            for (String orgNo :lists) {
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"ORG_NO\">" + orgNo + "</C>\n" +
                        "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";
                Object[] objects = client.invoke(opName, sendXml);
                if (objects == null || objects.length == 0) {
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String resultxml = (String) objects[0];
                System.out.println("字符串长度:" + resultxml.length()+"获取返回的xml数据" + resultxml);
                if (resultxml.length() > 150) {
                    /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                    for (List<General> demo3 : demo3s) {
                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());
                        if (generals.size() != 0) {
                            failfins.add(generals.get(8).getValue());//收集目前仍然失败的电能表资产号
                        }
                    }
                }
            }
            System.out.println("failfins长度"+failfins.size());
            int i = 0;
            for (String assetNo : selectfailfin) {
                if(!failfins.contains(assetNo)){
                    System.out.println(assetNo);
                    i += collwoMapper.UpdatefinStatus(assetNo, TimeUtil.getTodayTime());
                }
            }
            System.out.println("采集失败归档状态更改数量为:"+i+"条");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @RequestMapping("test2")
    //@Scheduled(cron = "0 5/15 * * * ? ")
    @Scheduled(cron = "0 0 16 * * ? ")
    @Async
    public void getCollncon(){
        String startTime = TimeUtil.getTodayTime();
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        System.out.println("webservice执行");
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取客户端连接前");
        Client client = dcf.createClient(wsdlUrl);
        System.out.println("获取客户端连接后");
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "unCoverageData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("unCoverageData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> lists = collwoMapper.selectOrgList();
            List<String> selectnotcfin = collwoMapper.selectnotcfin();//查找表中采集未接入的表
            List<String> notcfins = new ArrayList<>();//归档后的工单表数量
            for (String orgNo : lists) {
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"ORG_NO\">" + orgNo + "</C>\n" +
                        "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";
                Object[] objects = client.invoke(opName, sendXml);
                if(objects == null || objects.length==0){
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String  resultxml = (String) objects[0];
                System.out.println("获取返回的xml数据"+resultxml);
                System.out.println("字符串长度:"+resultxml.length());

                if(resultxml.length()>155) {
                    List<CollectNotcon> collnots = new ArrayList<>();
                    /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                    for (List<General> demo3 : demo3s) {
                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());
                        if (generals.size() != 0) {
                            notcfins.add(generals.get(9).getValue());
                        }
                    }
                    int i = 0;
                    for (String s : selectnotcfin) {
                        if(notcfins.contains(s)){
                            System.out.println(s);

                            i += collwoMapper.UpdatefinStatus(s, TimeUtil.getTodayTime());
                        }
                    }
                    System.out.println("采集未接入归档状态更改数量为:"+i+"条");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}