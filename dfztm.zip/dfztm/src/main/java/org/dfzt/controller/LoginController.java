package org.dfzt.controller;

import com.sgcc.isc.core.orm.identity.User;
import com.sgcc.isc.framework.common.constant.Constants;
import com.sgcc.isc.framework.common.entity.Paging;
import com.sgcc.isc.service.adapter.factory.AdapterFactory;
import com.sgcc.isc.service.adapter.helper.IDomainService;
import com.sgcc.isc.service.adapter.helper.IIdentityService;
import com.sgcc.isc.ualogin.client.IscServiceTicketValidator;
import com.sgcc.isc.ualogin.client.util.IscSSOResourceUtil;
import com.sgcc.isc.ualogin.client.vo.IscSSOUserBean;
import lombok.extern.slf4j.Slf4j;

import org.dfzt.entity.po.UserRole;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.mapper.SysUserMapper;
import org.dfzt.util.TimeUtil;
import org.dfzt.util.jwt.JwtUtil;
import org.springframework.scheduling.annotation.Async;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.xml.sax.SAXException;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.dfzt.util.jwt.respUtil.responseAppJSON;

/**
 * @Author dyy
 * @Date 2022/7/21 13:29
 * @PackageName:org.dfzt.modules.dfzt.controller
 * @ClassName: loginController
 * @Description: TODO 登录
 * @Version 1.0
 */

@Slf4j
@RestController
@CrossOrigin
@RequestMapping("/SysUser")
public class LoginController {

    @Resource
    private SysUserMapper sysUserMapper;
    @Resource
    private CollectWorkOrderMapper collectWorkOrderMapper;

    @ResponseBody
    @RequestMapping("/login1")
    public void login(HttpServletRequest request, HttpServletResponse response) throws IOException {
        //@RequestBody SysUser user,HttpServletRequest request, HttpServletResponse resp
        System.out.println("URL地址:"+request.getRequestURL());
        System.out.println("获取ticket的地址:"+request.getParameter("ticket"));
        if(null == request.getParameter("ticket") || "".equals(request.getParameter("ticket"))){
            /*重定向到统一认证服务端，service参数是业务系统LoginModule请求地址*/
            System.out.println("重定向操作");
            response.sendRedirect("http://10.1.118.88:8090/isc_sso/login?service=http://25.73.1.171/api/SysUser/login1");
            return;
        }
        String user = null;
//        String xmlResponse = null;
        String errorCode = null;
        String errorMessage = null;
        Cookie cookie = new Cookie("ticket",request.getParameter("ticket"));
        cookie.setPath("/");
        cookie.setMaxAge(-1);
        response.addCookie(cookie);
        /* ticket校验器 */
        IscServiceTicketValidator sv = new IscServiceTicketValidator();
        System.out.println("创建IscServiceTicketValidator实例");
        /*统一认证服务端校验器地址*/
        System.out.println("统一认证服务端校验器地址");
        sv.setCasValidateUrl("http://10.1.118.88:8090/isc_sso/serviceValidate");
        /*业务系统LoginModule访问地址  http://10.173.78.138:17001/isc_mp/framework/desktop/index.jsp*/
        System.out.println("业务系统LoginModule访问地址");
        sv.setService("http://25.73.1.171:80");
        /*设置Ticket*/
        System.out.println("设置Ticket");
        sv.setServiceTicket(request.getParameter("ticket"));
        System.out.println("校验");
        /*校验*/
        try {
            sv.validate();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (sv.isAuthenticationSuccesful()) {
            user = sv.getUser();
        } else {
            errorCode = sv.getErrorCode();
            errorMessage = sv.getErrorMessage();
            /* handle the error */
            System.out.println("errorInfo -----------> " + errorCode + "\r\n" + errorMessage);
        }
        System.out.println("userinfo >>>>>>>>>>>> " + user);
        IscSSOUserBean iscSSOUserBean = null;
        try {
            /*获取当前用户登录信息*/
            iscSSOUserBean = IscSSOResourceUtil.transferIscUserBean(user);
            /*当前登录用户ID*/
            String userid = iscSSOUserBean.getIscUserId();
            System.out.println("userid" + userid);
            String baseOrgName = iscSSOUserBean.getBaseOrgName();
            System.out.println("baseOrgName"+baseOrgName);
//            String loginNameByfro = collectWorkOrderMapper.selectTgManager(userid);
//            System.out.println("登录人用户名为1"+loginNameByfro);
            //Cookie cookie1 = new Cookie("loName",loginNameByfro);
            //cookie1.setPath("/");
            //cookie1.setMaxAge(3600);
            //response.addCookie(cookie1);
            System.out.println("iscSSOUserBean"+iscSSOUserBean);
            /*当前登录用户账号*/
            String loginName = iscSSOUserBean.getIscUserSourceId();

            Cookie cookie3 = new Cookie("userName",loginName);
            cookie3.setPath("/");
            cookie3.setMaxAge(-1);
            response.addCookie(cookie3);

            System.out.println("loName" + loginName);
            String loginNameByfro2 = collectWorkOrderMapper.selectTgManagerByLoginName(loginName);
            String orgNo = collectWorkOrderMapper.selectOrgNoByuName(loginName).get(0);
            System.out.println("登录人用户名为2"+loginNameByfro2);
            System.out.println("当前时间"+ TimeUtil.getTodayTimes());
            Cookie cookie2 = new Cookie("loName2",loginNameByfro2);
            cookie2.setPath("/");
            cookie2.setMaxAge(-1);
            response.addCookie(cookie2);
            Cookie cookie4 = new Cookie("orgNo",orgNo);
            cookie4.setPath("/");
            cookie4.setMaxAge(-1);
            response.addCookie(cookie4);

            response.sendRedirect("http://25.73.1.171");
            return;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
//        String loginName = user.getLoginName();
//        String passWord = user.getPassWord();
//        SysUser userForBase=sysUserMapper.findByLoginNameAndPassWord(loginName,passWord);
//        System.out.println("------------------------------"+userForBase);
//        if(userForBase == null){
//            return "error";
//        }
//        SysUser user1 = new SysUser();
//        user1.setLoginName(loginName);
//        user1.setPassWord(passWord);
//        String token = JwtUtil.generateToken(user1);
//        Map<String,Object> map = new HashMap<>();
//        map.put("token",token);
//        responseAppJSON(resp,map);
//        return "OK";
    }

    @ResponseBody
    @GetMapping("/login")
    public void login1(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("URL地址:"+request.getRequestURL());
        System.out.println("获取ticket的地址:"+request.getParameter("ticket"));

        if(null == request.getParameter("ticket") || "".equals(request.getParameter("ticket"))){
            /*重定向到统一认证服务端，service参数是业务系统LoginModule请求地址*/
            System.out.println("重定向操作");
            response.sendRedirect("http://10.173.78.137:17001/isc_sso/login?service=http://25.73.1.171/api/SysUser/login");
            return;
        }
        String user = null;
//        String xmlResponse = null;
        String errorCode = null;
        String errorMessage = null;
        Cookie cookie = new Cookie("ticket",request.getParameter("ticket"));
        cookie.setPath("/");
        cookie.setMaxAge(-1);
        response.addCookie(cookie);
        /* ticket校验器 */
        IscServiceTicketValidator sv = new IscServiceTicketValidator();
        System.out.println("创建IscServiceTicketValidator实例");
        /*统一认证服务端校验器地址*/
        System.out.println("统一认证服务端校验器地址");
        sv.setCasValidateUrl("http://10.173.78.137:17001/isc_sso/serviceValidate");
        /*业务系统LoginModule访问地址  http://10.173.78.138:17001/isc_mp/framework/desktop/index.jsp*/
        System.out.println("业务系统LoginModule访问地址");
        sv.setService("http://25.73.1.171:80");
        /*设置Ticket*/
        System.out.println("设置Ticket");
        sv.setServiceTicket(request.getParameter("ticket"));
        System.out.println("校验");
        /*校验*/
        try {
            sv.validate();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        if (sv.isAuthenticationSuccesful()) {
            user = sv.getUser();
        } else {
            errorCode = sv.getErrorCode();
            errorMessage = sv.getErrorMessage();
            /* handle the error */
            System.out.println("errorInfo -----------> " + errorCode + "\r\n" + errorMessage);
        }
        System.out.println("userinfo >>>>>>>>>>>> " + user);
        IscSSOUserBean iscSSOUserBean = null;
        try {


            /*获取当前用户登录信息*/
            iscSSOUserBean = IscSSOResourceUtil.transferIscUserBean(user);
            /*当前登录用户ID*/
            String userid = iscSSOUserBean.getIscUserId();
            System.out.println("userid" + userid);

            //IIdentityService service = AdapterFactory.getIdentityService();
            IIdentityService service = (IIdentityService)AdapterFactory.getInstance(Constants.CLASS_IDENTITY);
            List<User> usersByLoginCode = service.getUsersByLoginCode(userid);

//            Map<String, String> param = new HashMap<String, String>();
//            param.put(Constants.PARAM_USER_IDENTITY_ID, "330000000003109");
//            String[] orderStr = new String[] {Constants. PARAM_ORDER_USER_NAME +" "+ Constants.PARAM_ORDER_ASC, Constants. PARAM_ORDER_USER_DISP_ORDER  +" "+  Constants.PARAM_ORDER_ASC };
//            try {
//                //Paging page = service.getUsersByOrg("330000600000000005", param, orderStr, 10, 0, true);
//                service.getUsersByLoginCode(userid);
//            } catch (Exception e) {
//                // TODO Auto-generated catch block
//                e.printStackTrace();
//            }



            System.out.println(usersByLoginCode);
            String baseOrgName = iscSSOUserBean.getBaseOrgName();
            System.out.println("baseOrgName"+baseOrgName);
//            String loginNameByfro = collectWorkOrderMapper.selectTgManager(userid);
//            System.out.println("登录人用户名为1"+loginNameByfro);
            //Cookie cookie1 = new Cookie("loName",loginNameByfro);
            //cookie1.setPath("/");
            //cookie1.setMaxAge(3600);
            //response.addCookie(cookie1);
            System.out.println("iscSSOUserBean"+iscSSOUserBean);
            /*当前登录用户账号*/
            String loginName = iscSSOUserBean.getIscUserSourceId();
            System.out.println("loName" + loginName);
            String loginNameByfro2 = collectWorkOrderMapper.selectTgManagerByLoginName(loginName);
            System.out.println("登录人用户名为2"+loginNameByfro2);
            System.out.println("当前时间"+ TimeUtil.getTodayTimes());
            Cookie cookie2 = new Cookie("loName2",loginNameByfro2);
            cookie2.setPath("/");
            cookie2.setMaxAge(-1);
            response.addCookie(cookie2);
            response.sendRedirect("http://25.73.1.171");
            return;
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
//            IIdentityService service = AdapterFactory.getIdentityService();
//            List<User> usersByLoginCode = service.getUsersByLoginCode(userid);
//1.  用户登录系统 调用login接口   发现没有ticket 调用redirect 让用户浏览器先打开 isc登录
//2. isc登录后 会根据之前redirect后面加的回调参数地址，让用户浏览器转到 我们系统的登录接口login并且带上ticket参数
//3. 为了防止用户随便输入个ticket=123 需要在login接口里加个校验，访问isc校验地址判断ticket合法性
//4. 判断ticket合法后  给当前用户签发本地token 让用户可以访问其他接口
//5. 前端收到login返回的token 存到cookies里 后面每个其他接口的请求都带上token
//6. 本系统的fiter里根据token 判断当前用户是否登录过，如果token无效或者超时，返回用户未登录或登录超时，
//    让用户去login重新登录
    //ST怎么发 什么时候发
    //

//    @Resource
//    private SysUserMapper sysUserMapper;


    @ResponseBody
    @PostMapping("/getToken")
    public String login2(HttpServletRequest request, HttpServletResponse resp) throws IOException {
        String loginName = "刘月焱";
        String passWord = "mengdian1234_+";
        SysUser user1 = new SysUser();
        user1.setLoginName(loginName);
        user1.setPassWord(passWord);
        user1.setUserRole("2");
        user1.setUserStation("1");
        String token = JwtUtil.generateToken(user1);
        Map<String,Object> map = new HashMap<>();
        map.put("token",token);
        responseAppJSON(resp,map);
        return "OK";
    }


    @ResponseBody
    @RequestMapping("/logout")
    public String logout(HttpServletResponse response,@RequestParam String username,@RequestParam String userId) throws IOException {
        //String service = "http://25.73.1.171:80";
        response.sendRedirect("http://10.173.78.137:17001/isc_sso/logout?username="+username+"&iscUserId="+userId+"&service=http://25.73.1.171:80");
        System.out.println("退出成功");
        return "退出成功";
    }

    @ResponseBody
    @RequestMapping("/logout1")
    public String logout1(HttpServletResponse response) throws IOException {
        //String service = "http://25.73.1.171:80";
        //response.sendRedirect("http://10.173.78.137:17001/isc_sso/logout?username="+username+"&iscUserId="+userId+"&service=http://25.73.1.171/api/SysUser/login1");
        Cookie cookie = new Cookie("ticket",null);
        cookie.setPath("/");
        cookie.setMaxAge(0);
        response.addCookie(cookie);
        Cookie cookie1 = new Cookie("loName2",null);
        cookie1.setPath("/");
        cookie1.setMaxAge(0);
        response.addCookie(cookie1);
        System.out.println("退出成功1");
        response.sendRedirect("http://10.1.118.88:8090/isc_sso/logout");
        return "退出成功1";
    }


    //TODO 角色权限Controller

    @ResponseBody
    @RequestMapping("/getUserRole")//每次登录后先根据isc或者掌机登录，使用用户名获取对应的权限信息
    public Map<String,String> getUserRole(@RequestParam String userName){
        //1.所站长  2.台区经理 3.管理员
        UserRole userRole = collectWorkOrderMapper.selectUserRole(userName);
        Map<String,String> map = new HashMap<>();
        if (!StringUtils.isEmpty(userName)){
            map.put("role",userRole.getIsRole());
        }else {
            map.put("role","2");
        }
        return map;
    }

//    @ResponseBody
//    @RequestMapping("/getIsManage")//判断是否是管理员 1是管理员 0不是管理员
//    public Map<String,String> getIsManage(@RequestParam String userName){
//        UserRole userRole = collectWorkOrderMapper.selectUserRole(userName);
//        Map<String,String> map = new HashMap<>();
//        if (!StringUtils.isEmpty(userName)){
//            map.put("manage",userRole.getIsManage());
//        }else{
//            map.put("manage","0");
//        }
//        return map;
//    }

    @ResponseBody
    @RequestMapping("/getUserInfor")//获取用户所有信息
    public UserRole getUserInfor(@RequestParam String userName){
        //1.所站长  2.台区经理
        UserRole userRole = collectWorkOrderMapper.selectUserRole(userName);
        return userRole;
    }


    @ResponseBody
    @RequestMapping("/getUserList")//
    public List<UserRole> getUserList(@RequestParam String orgNo){
        List<UserRole> userRoles = collectWorkOrderMapper.selectUserList(orgNo);
        return userRoles;
    }


    @ResponseBody
    @RequestMapping("/getReadName")//
    public List<UserRole> getReadName(@RequestParam String userName){
        List<UserRole> userRoles = collectWorkOrderMapper.selectReadName(userName);
        return userRoles;
    }

    @ResponseBody
    @RequestMapping(value = "/getinsertUser",produces = "application/json;charset=utf-8")//新增
    public String getinsertUser(UserRole userRole){
        Integer i = collectWorkOrderMapper.insertUserRole(userRole);
        if (i != 0) {
            return "新增成功";
        }
        return "新增成功";
    }

    @ResponseBody
    @RequestMapping(value = "/getupdateUser",produces = "application/json;charset=utf-8")//修改
    public String getupdateUser(UserRole userRole) {
        Integer i = collectWorkOrderMapper.updateUserRole(userRole);
        if (i != 0) {
            return "修改成功";
        }
        return "修改失败";

    }

    @ResponseBody
    @RequestMapping(value = "/getdeleteUser",produces = "application/json;charset=utf-8")//删除
    public String getdeleteUser(@RequestParam String id) {
        Integer i = collectWorkOrderMapper.deleteById(Integer.parseInt(id));
        if (i != 0) {
            return "删除成功";
        }
        return "删除失败";
    }
}
