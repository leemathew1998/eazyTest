package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.annotations.XStreamOmitField;
import com.thoughtworks.xstream.converters.basic.BooleanConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;
import lombok.Data;

/**
 * @ClassName Real1
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/14 20:04
 */
@Data
@XStreamAlias("R")
public class Real1 {


private String tgNo ;

private String mrDate;

}
