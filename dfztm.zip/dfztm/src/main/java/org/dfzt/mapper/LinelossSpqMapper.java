package org.dfzt.mapper;

import org.dfzt.entity.po.LinelossDateSynana;
import org.dfzt.entity.po.LinelossSpq;
import org.dfzt.entity.po.LinelossSynana;
import org.dfzt.entity.po.LinelossUserSynana;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/26
 * @Version: 1.00
 */
public interface LinelossSpqMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(LinelossSpq record);

    int insertSelective(LinelossSpq record);

    LinelossSpq selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(LinelossSpq record);

    int updateByPrimaryKey(LinelossSpq record);

    LinelossSpq selectNowAndMin(String dateTime,String consNo);//根据日期查找售电量明细表的值

    LinelossSpq selectlastday(String startTime);//查找用户当日售电量明细

    List<LinelossSpq> selectPowerUser(String consNo, String lastmon);//根据用户编号和上个月时间查询改用户每一天的电量(正向有功总)

    List<LinelossUserSynana> selectAllUser(String tgNo);//根据台区编号查找出该台区所有用户

    List<LinelossDateSynana> selectplatBydate(String LinelossDate);//根据月份查询一个月的台区供电量

    List<BigDecimal> selectlineSpq(String startMon,String consName);//根据台区编号获取皮尔逊相关数据
    List<String> selectConsName(String tgNo,String startMon); //查找表中所包含的所有用户名称集合

    List<LinelossSynana> selectLineloss(String tgNo, String startMon);//从台区考核单元中获取台区的损耗电量
}
