package org.dfzt.entity.tdo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 明细列表
 */
@Data
public class DetailList {
    //工单类型（采集运维、计量运维等）
    private Number workOrderType;
    //当月总计
    private Number currentMonthTotal;
    //待处理
    private Number toBeProcessed;
    //处理中
    private Number processing;
    //预警
    private Number warning;
    //当月已处理
    private Number currentMonthProcessed;
}
