package com.exam.modules.mapper;

import com.exam.modules.entity.SysRoleMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 角色菜单表 Mapper 接口
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu> {

}
