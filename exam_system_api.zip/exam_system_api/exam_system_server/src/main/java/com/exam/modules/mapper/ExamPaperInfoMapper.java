package com.exam.modules.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import com.exam.modules.entity.ExamPaperInfo;
import org.apache.ibatis.annotations.Update;

/**
 * (ExamPaperInfo)表数据库访问层
 *
 * @author makejava
 * @since 2022-11-08 15:32:48
 */
public interface ExamPaperInfoMapper extends BaseMapper<ExamPaperInfo> {

    @Update("UPDATE EXAM.EXAM_PAPER_INFO \n" +
                    "SET USE_NUM = NVL(USE_NUM, 0)+1" +
                    " WHERE EXAM_PAPER_ID = #{examPaperId}")
    boolean updateuseNum(Long examPaperId);
}


