package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/7
 * @Version: 1.00
 */
@Data
public class SPrcTacticScheme implements Serializable {
    private String spId;
    private String typeCode;//定价策略
    private String baCalcMode;//基本电费计算方式
    private BigDecimal dmdSpecValue;//需要核定值
    private String pfEvalMode;//功率因数考核方式
    private BigDecimal consId;//用户编号

}
