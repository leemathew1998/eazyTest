package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @Date:2022/7/7-10:53
 * @User:chengchuanlin
 * @Name:Performance
 * @Message:
 */
@Data
public class Performance {
    private Integer powerStationTodayTotalIntegrate;

    private Integer qiCountyCompanyTodayRanking;

    private Integer cityCompanyTodayRanking;

    private List<Indicators> indicators;
}
