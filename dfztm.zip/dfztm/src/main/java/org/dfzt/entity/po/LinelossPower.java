package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/20
 * @Version: 1.00 日冻结功率曲线
 */
@Data
public class LinelossPower {
    private Integer id;
    //供电单位
    private String orgName;
    //用户编码
    private String consNo;
    //用户名称
    private String consName;
    //电能表资产号
    private String meterAssetNo;
    //电能表厂家
    private String metManufacturer;
    //终端厂家
    private String factoryCode;
    //台区编号
    private String tgNo;
    //台区名称
    private String tgName;
    //抄表日期
    private Date mrDate;
    //数据来源
    private String dataSrc;
    //综合倍率
    private BigDecimal tFactor;
    //相序
    private String phaseFlag;
    //点数
    private String dataPointFlag;
    //1点
    private BigDecimal p1;
    //2点
    private BigDecimal p2;

    private BigDecimal p3;

    private BigDecimal p4;

    private BigDecimal p5;

    private BigDecimal p6;

    private BigDecimal p7;

    private BigDecimal p8;

    private BigDecimal p9;

    private BigDecimal p10;

    private BigDecimal p11;

    private BigDecimal p12;

    private BigDecimal p13;

    private BigDecimal p14;

    private BigDecimal p15;

    private BigDecimal p16;

    private BigDecimal p17;

    private BigDecimal p18;

    private BigDecimal p19;

    private BigDecimal p20;

    private BigDecimal p21;

    private BigDecimal p22;

    private BigDecimal p23;

    private BigDecimal p24;

    private BigDecimal p25;

    private BigDecimal p26;

    private BigDecimal p27;

    private BigDecimal p28;

    private BigDecimal p29;

    private BigDecimal p30;

    private BigDecimal p31;

    private BigDecimal p32;

    private BigDecimal p33;

    private BigDecimal p34;

    private BigDecimal p35;

    private BigDecimal p36;

    private BigDecimal p37;

    private BigDecimal p38;

    private BigDecimal p39;

    private BigDecimal p40;

    private BigDecimal p41;

    private BigDecimal p42;

    private BigDecimal p43;

    private BigDecimal p44;

    private BigDecimal p45;

    private BigDecimal p46;

    private BigDecimal p47;

    private BigDecimal p48;

    private BigDecimal p49;

    private BigDecimal p50;

    private BigDecimal p51;

    private BigDecimal p52;

    private BigDecimal p53;

    private BigDecimal p54;

    private BigDecimal p55;

    private BigDecimal p56;

    private BigDecimal p57;

    private BigDecimal p58;

    private BigDecimal p59;

    private BigDecimal p60;

    private BigDecimal p61;

    private BigDecimal p62;

    private BigDecimal p63;

    private BigDecimal p64;

    private BigDecimal p65;

    private BigDecimal p66;

    private BigDecimal p67;

    private BigDecimal p68;

    private BigDecimal p69;

    private BigDecimal p70;

    private BigDecimal p71;

    private BigDecimal p72;

    private BigDecimal p73;

    private BigDecimal p74;

    private BigDecimal p75;

    private BigDecimal p76;

    private BigDecimal p77;

    private BigDecimal p78;

    private BigDecimal p79;

    private BigDecimal p80;

    private BigDecimal p81;

    private BigDecimal p82;

    private BigDecimal p83;

    private BigDecimal p84;

    private BigDecimal p85;

    private BigDecimal p86;

    private BigDecimal p87;

    private BigDecimal p88;

    private BigDecimal p89;

    private BigDecimal p90;

    private BigDecimal p91;

    private BigDecimal p92;

    private BigDecimal p93;

    private BigDecimal p94;

    private BigDecimal p95;
    //96点
    private BigDecimal p96;
    //用电地址
    private String elecAddr;
    //电能表地址
    private String commAddr;
    //终端地址
    private String terminalAddr;
    //上送时间
    private Date recTime;
    //测量点号
    private String mpSn;
    //终端资产号
    private String tmnlAssetNo;
    //主用途类型
    private String usageTypeCode;
}
