package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class AcManager implements Serializable {

    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    private String tgManager;

    private String tgNo;
    private String tgName;

    private String toPoint;

    private String ymd;

    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date dataDate;

    private BigDecimal colSuccRate;

    private Integer colSuccPoint;

    private BigDecimal colFailRate;

    private Integer colFailPoint;

    private BigDecimal costconComeRate;

    private Integer costconComePoint;

    private BigDecimal costconStopRate;

    private Integer costconStopPoint;

    private BigDecimal autoPublishRate;

    private Integer autoPublishPoint;

    private BigDecimal lowLinelossRate;

    private Integer lowLinelossPoint;

    private BigDecimal highlossTgRate;

    private Integer highlossTgPoint;

    private BigDecimal lowlossTgRate;

    private Integer lowlossTgPoint;

    private BigDecimal econrunTgRate;

    private Integer econrunTgPoint;

    private BigDecimal tgHandleRate;

    private Integer tgHandlePoint;

    private BigDecimal powerfeesZeroRate;

    private Integer powerfeesZeroPoint;

    private Integer exceptTgNum;

    private Integer exceptTgPoint;

    private BigDecimal powerbackHandleRate;

    private Integer powerbackHandlePoint;

    private Integer complaintWorkorderNum;

    private Integer complaintWorkorderPoint;

    private BigDecimal repairSceneRate;

    private Integer repairScenePoint;

    private BigDecimal meterHandleRate;

    private Integer meterHandlePoint;

    private Integer totalScore;

    private String acStationId;

    private String acCountyId;
}
