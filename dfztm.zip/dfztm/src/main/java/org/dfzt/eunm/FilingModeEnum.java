package org.dfzt.eunm;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @ClassName FilingModeEnum
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/6/28 14:07
 */
public enum FilingModeEnum {
    FILING_MODE_ENUM_ONE(0,"自动归档"),
    FILING_MODE_ENUM_TWO(1,"手动归档");

    @EnumValue
    private int code;
    @JsonValue
    private String message;

    FilingModeEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
