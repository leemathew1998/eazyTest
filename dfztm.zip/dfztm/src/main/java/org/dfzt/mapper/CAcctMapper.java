package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.CAcct;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/14
 * @Version: 1.00
 */
public interface CAcctMapper extends BaseMapper<CAcct> {
}