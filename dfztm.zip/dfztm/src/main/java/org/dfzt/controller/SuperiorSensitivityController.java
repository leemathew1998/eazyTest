package org.dfzt.controller;


import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import org.dfzt.entity.vo.SuperiorSensitivity;
import org.dfzt.mapper.SuperiorSensitivityMapper;
import org.dfzt.service.SuperiorSensitivityService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * (SuperiorSensitivity)表控制层
 *
 * @author makejava
 * @since 2022-07-19 16:32:20
 */
@RestController
@RequestMapping("superiorSensitivity")
public class SuperiorSensitivityController extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private SuperiorSensitivityService superiorSensitivityService;

    @Resource
    private SuperiorSensitivityMapper superiorSensitivityMapper;

    /**
     * 分页查询所有数据
     *
     * @return 所有数据
     */
    @PostMapping("selectAll")
    public R selectAll(@RequestParam Map map) {
        System.out.println("=================="+map);
        return success(superiorSensitivityService.selectAll(map));
    }

    @PostMapping("selectWrapper")
    public R selectWrapper(Page<SuperiorSensitivity> page, String str) {
        return success(this.superiorSensitivityService.page(page, superiorSensitivityService.wrapper(str)));
    }


    @PostMapping("selectPlatName")
    public Object selectPlatName(){
        List<String> listname = new ArrayList<>();
        String s1 = superiorSensitivityMapper.selectAdd("区县1");
        String s2 = superiorSensitivityMapper.selectAdd("所属的供电单位");
        String s3 = superiorSensitivityMapper.selectAdd("地址中所包含的社区办事处后的字段");
        String s4 = superiorSensitivityMapper.selectAdd("联系电话");
        String s5 = superiorSensitivityMapper.selectAdd("主叫电话");
        if (s1.isEmpty()){
            String name1 = "";//通过地址查询所对应的抄表员
            listname.add(name1);
        }else if(s2.isEmpty()){
            String name2 = "";//查询所属的工单单位，如果有，则提取抄表员
            listname.add(name2);
        }else if(s3.isEmpty()){
            String name3 = "";//办事处后面字段查询出的地址，对应的抄表员
            listname.add(name3);
        }else if(s4.isEmpty()){
            String name4 = "";//通过联系电话查询地址
            listname.add(name4);
        }else if(s5.isEmpty()){
            String name5 = "";//通过主叫电话查询地址
            listname.add(name5);
        }
        return listname.get(0);//返回查询出的第一个抄表员
    }


}
