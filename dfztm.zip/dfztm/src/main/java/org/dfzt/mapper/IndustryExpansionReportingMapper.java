package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.IndustryExpansionReporting;
import org.springframework.stereotype.Repository;

/**
* @author luo
* @description 针对表【Industry_expansion_reporting(业扩报装)】的数据库操作Mapper
* @createDate 2022-08-03 10:30:03
* @Entity org.dfzt.modules.dfzt.entity.po.IndustryExpansionReporting
*/
@Repository
public interface IndustryExpansionReportingMapper extends BaseMapper<IndustryExpansionReporting> {

}




