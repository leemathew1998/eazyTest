package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/28
 * @Version: 1.00
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Demo4 {
    @XStreamAlias("R")
    private List<List<General>> general;
}
