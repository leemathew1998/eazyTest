package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName s_appinfo
 */
@TableName(value ="s_appinfo")
@Data
public class SAppinfo implements Serializable {
    /**
     * 终端设备编号:终端设备编号
     */
    private String zhongduanId;

    /**
     * 装表位置纬度:装表位置纬度
     */
    private String instLocPosy;

    /**
     * 供电电压:供电电压
     */
    private String voltCode;

    /**
     * 所属区县:所属区县
     */
    private String countyCode;

    /**
     * 计划恢复日期:YYYY-MM-DD,计划恢复日期
     */
    private Date planResumeDate;

    /**
     * 拟申请客户名称:拟申请客户名称
     */
    private String consName;

    /**
     * 行业分类:行业分类
     */
    private String tradeCode;

    /**
     * 是否需要回访标志:是否需要回访标志
     */
    private String retvisitFlag;

    /**
     * 接单时间:接单时间
     */
    private Date acceptTime;

    /**
     * 预受理业务子类:预受理业务子类，包括： 1永久性减容 2临时性减容 21101普通过户 21102实名通电 21501普通改类 21502基本电价计费方式变更 21503取消基本电价计费方式变更 21504调整最大需量核定值 21505居民峰谷变更
     */
    private String appSubTypeCode;

    /**
     * HDFS路径:HDFS路径
     */
    private String extendSource;

    /**
     * 装表位置经度:装表位置经度
     */
    private String instLocPosx;

    /**
     * 预申请信息标识:预申请信息标识
     */
    private Integer preAppId;

    /**
     * 受理渠道:受理渠道
     */
    private String acceptMode;

    /**
     * 开户银行:开户银行
     */
    private String bankName;

    /**
     * 接单部门:接单部门
     */
    private String acceptDept;

    /**
     * 合计合同容量:合计合同容量
     */
    private Integer tContractCap;

    /**
     * 是否产权/户主变更，标准代码“是否标志”：1是，0否；服务目录为更名/过户时必填:是否产权/户主变更，标准代码“是否标志”：1是，0否；服务目录为更名/过户时必填
     */
    private String isChgPpy;

    /**
     * 装表位置说明，用户输入位置说明0-50字:装表位置说明，用户输入位置说明0-50字
     */
    private String instLocRemark;

    /**
     * 是否安装变压器，标准代码“是否标志”：1是，0否:是否安装变压器，标准代码“是否标志”：1是，0否
     */
    private String isInstTrans;

    /**
     * 预约类型:预约类型
     */
    private String serviceType;

    /**
     * 是否为租赁房屋:是否为租赁房屋
     */
    private String isRent;

    /**
     * 所属地市:所属地市
     */
    private String cityCode;

    /**
     * 联系地址:联系地址
     */
    private String contactaddr;

    /**
     * 客户意见:客户意见
     */
    private String consOpinion;

    /**
     * 电费票据类型:电费票据类型
     */
    private String noteTypeCode;

    /**
     * 申请启用日期:YYYY-MM-DD,申请启用日期
     */
    private Date startDate;

    /**
     * 原有合同容量:原有合同容量
     */
    private Integer orgnContractCap;

    /**
     * 预约服务日期:预约服务日期
     */
    private Date serviceTime;

    /**
     * 备注:备注
     */
    private String remark;

    /**
     * 当前时间:当前时间
     */
    private String extendCurrentTs;

    /**
     * 业务资料获取方式（在线下载、自取、邮寄），标准代码“业务资料获取方式“:业务资料获取方式（在线下载、自取、邮寄），标准代码“业务资料获取方式“
     */
    private String obtainCode;

    /**
     * 用户性质 低压非居时传，01个人、02企业:用户性质 低压非居时传，01个人、02企业
     */
    private String userMarketSort;

    /**
     * 定价策略类型:定价策略类型标准码,（单一制、两部制）
     */
    private String typeCode;

    /**
     * 开户帐号:开户帐号
     */
    private String bankAcct;

    /**
     * 申请运行容量:申请运行容量
     */
    private Integer capRunCap;

    /**
     * 申请人签名:申请人签名
     */
    private String signName;

    /**
     * 装表位置名称:装表位置名称
     */
    private String instLocName;

    /**
     * 交易流水号:交易流水号
     */
    private String serialNo;

    /**
     * 抄表例日:抄表例日
     */
    private String mrDate;

    /**
     * 申请编号:申请编号
     */
    private String appNo;

    /**
     * 联系人姓名:联系人姓名
     */
    private String contactName;

    /**
     * 拟申请供电单位:拟申请供电单位
     */
    private String psOrgNo;

    /**
     * 用户编号:用电客户编号
     */
    private String consNo;

    /**
     * 预约服务时间段:预约服务时间段
     */
    private String serviceTimeQuantum;

    /**
     * 合计运行容量:合计运行容量
     */
    private Integer tRunCap;

    /**
     * 联系电话2:联系电话2
     */
    private String contactMode2;

    /**
     * 操作类型:操作类型
     */
    private String extendOpType;

    /**
     * 审计标识:审计标识
     */
    private String extendOpPosition;

    /**
     * 计费方式:计费方式
     */
    private String bacalcMode;

    /**
     * 预申请编号:预申请编号
     */
    private String preAppNo;

    /**
     * 证件号码:证件号码
     */
    private String certNo;

    /**
     * 申请需量值:申请需量值
     */
    private Integer dmdAppValue;

    /**
     * 接单人员:接单人员
     */
    private String acceptEmp;

    /**
     * 偏移量:偏移量
     */
    private Integer extendPos;

    /**
     * 统一社会信用代码:统一社会信用代码
     */
    private String usci;

    /**
     * 申请用电地址:申请用电地址
     */
    private String elecAddr;

    /**
     * 申请合同容量:申请合同容量
     */
    private Integer contractCap;

    /**
     * 预受理业务类型:预受理业务类型
     */
    private String appTypeCode;

    /**
     * 申请停用日期:YYYY-MM-DD,申请停用日期
     */
    private Date stopDate;

    /**
     * 故障类型描述:用户申请计量装置故障时的故障类型描述
     */
    private String faultTypeDesc;

    /**
     * 联系电话1:联系电话1
     */
    private String contactMode;

    /**
     * 实名认证标志，标准代码“是否标志”：1是，0否:实名认证标志，标准代码“是否标志”：1是，0否
     */
    private String isRnrg;

    /**
     * 签名图片ID:签名图片ID
     */
    private String fileId;

    /**
     * 负荷性质:负荷性质
     */
    private String lodeAttrCode;

    /**
     * 删除标识:删除标识
     */
    private Integer delFlag;

    /**
     * 变压器是否换拆，，标准代码“是否标志”：1是，0否；服务目录为暂停/减容、容量恢复时必填 ，对除浙江网省外的其他网省代码为：1减容、0暂停:变压器是否换拆，，标准代码“是否标志”：1是，0否；服务目录为暂停/减容、容量恢复时必填 ，对除浙江网省外的其他网省代码为：1减容、0暂停
     */
    private String isChgTrans;

    /**
     * 统一账户编号:统一账户编号
     */
    private String userAccountId;

    /**
     * 原有运行容量:原有运行容量
     */
    private Integer orgnRunCap;

    /**
     * 证件类别:证件类别
     */
    private String certTypeCode;

    /**
     * 是否执行峰谷标志:是否执行峰谷标志
     */
    private String tsFlag;

    /**
     * 是否变更计费方式:1是，0否
     */
    private String changeBacalcModeFlag;

    /**
     * 申请用电类别:申请用电类别
     */
    private String elecTypeCode;

    /**
     * 系统时间:系统时间
     */
    private String extendOpTs;

    /**
     * 申请容量:申请容量
     */
    private Integer cap;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}