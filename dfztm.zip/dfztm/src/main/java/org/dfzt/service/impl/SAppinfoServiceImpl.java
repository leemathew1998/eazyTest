package org.dfzt.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.SAppinfo;
import org.dfzt.mapper.SAppinfoMapper;
import org.dfzt.service.SAppinfoService;
import org.springframework.stereotype.Service;

/**
* @author 李木
* @description 针对表【s_appinfo】的数据库操作Service实现
* @createDate 2023-05-29 11:32:55
*/
@Service
public class SAppinfoServiceImpl extends ServiceImpl<SAppinfoMapper, SAppinfo>
    implements SAppinfoService {

}




