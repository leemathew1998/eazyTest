package org.dfzt.service.impl;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.vo.RunWorderDeal;
import org.dfzt.entity.vo.RunWorkOrder;
import org.dfzt.mapper.RunSupplementaryCopyMapper;
import org.dfzt.mapper.RunWorderDealMapper;
import org.dfzt.mapper.RunWorkOrderMapper;
import org.dfzt.service.RunWorderDealService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Service
public class RunWorderDealServiceImpl extends ServiceImpl<RunWorderDealMapper, RunWorderDeal> implements RunWorderDealService {

    @Resource
    RunWorkOrderMapper runWorkOrderMapper;

    @Resource
    RunSupplementaryCopyMapper runSupplementaryCopyMapper;
    /**
     * 查询最近提交的一条记录
     *
     * @return
     */
    @Override
    public R queryAll(String gdNo) {
       RunWorderDeal runGd =this.getBaseMapper().selectOne(new LambdaQueryWrapper<RunWorderDeal>()
                .eq(RunWorderDeal::getGdNo,gdNo)
                .orderByDesc(RunWorderDeal::getGdDealDate)
                .last("limit 1"));

        return R.ok(runGd);
    }

    /**
     * 查询历史数据记录
     * @param gdNo
     * @return
     */
    @Override
    public R queryRunDeals(String gdNo) {
        List<RunWorderDeal> list= baseMapper.selectList(new LambdaQueryWrapper<RunWorderDeal>()
                .eq(RunWorderDeal::getGdNo,gdNo));
        return R.ok(list);
    }

    /**
     * 1,是正常，2,是异常
     * 同时修改原始数据表的抄表状态和数据异常判断
     * 前端提交后，添加数据
     * @return
     */
    public int insertRunGdDeal(RunWorderDeal runGdDeal){
        int i=this.getBaseMapper().insert(runGdDeal);//添加工单处理对应的数据
        if(runGdDeal.getMeterNumber()!=null&&i==1){
           // int i2=runWorkOrderMapper.updateone(runGdDeal.getGdNo());//修改工单抄表状态为已抄表
            int i1=runWorkOrderMapper.updateStatus(3,runGdDeal.getGdNo());//修改工单状态为待归档
            int i3=runWorkOrderMapper.updateunusual(runGdDeal.getGdNo());//修改工单数据是否异常为否
            if(i1==1){
                RunWorkOrder runGd=runWorkOrderMapper.selectOne(new LambdaQueryWrapper<RunWorkOrder>()
                        .eq(RunWorkOrder::getAppNo,runGdDeal.getGdNo()));
                if(runGd.getConsNo()!=null){//修改原始数据的抄表状态为已抄表和数据异常为否
                    runSupplementaryCopyMapper.updateone(runGd.getAppNo());
                }
            }else {
                i=2;
            }
        }
        return i;
    }
}
