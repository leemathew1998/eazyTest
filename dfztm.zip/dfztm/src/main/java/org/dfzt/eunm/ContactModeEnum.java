package org.dfzt.eunm;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @ClassName ContactModeEunm
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/7/29 12:32
 */
public enum ContactModeEnum {
     CONTACT_MODE_ENUM_ONE("1","停送电联系人"),
     CONTACT_MODE_ENUM_TWO("2","账务联系人"),
     CONTACT_MODE_ENUM_THREE("3","法定联系人"),
    CONTACT_MODE_ENUM_FOUR("4","委托代理联系人"),
     ;

    @EnumValue
    private String code;
    @JsonValue
    private String message;

        ContactModeEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }
}
