package com.exam.modules.service;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.exam.modules.entity.ExamInfo;
import com.exam.modules.entity.ExamManage;
import com.exam.modules.entity.vo.ExamManageVo;
import com.exam.modules.entity.vo.UserQueryVo;

import java.util.List;
import java.util.Map;

/**
 * 考试信息(ExamInfo)表服务接口
 *
 * @author makejava
 * @since 2022-11-09 15:05:39
 */
public interface ExamInfoService extends IService<ExamInfo> {
    //提交是否参加考试
    boolean isTrue(ExamInfo examInfo);
    //新增考试信息
    boolean add(ExamManageVo examManageVo,Long examId);
    //修改考试信息
    boolean updateInfo(ExamManageVo examManageVo);
    //分页查询考试信息
    IPage<ExamInfo> selPage(IPage<ExamInfo> page, ExamManageVo examInfo);
    //提交异常记录
    boolean abnormal(ExamInfo examInfo);

    /**
     * 根据用户id查询个人公告
     * @param user
     * @return
     */
    LambdaQueryWrapper<ExamInfo> wrapper(UserQueryVo user);

    //（考核查询）查询考试详情
    IPage<ExamInfo> selectExampage(Map<String, Object> queryMap);
}

