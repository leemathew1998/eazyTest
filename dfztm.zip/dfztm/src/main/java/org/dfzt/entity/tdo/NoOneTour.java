package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 区无人巡视
 */
@Data
public class NoOneTour {
    //统计列表
    private List<Statistics> statistics;
    //预警列表
    private List<WarningList> warningLists;
}
