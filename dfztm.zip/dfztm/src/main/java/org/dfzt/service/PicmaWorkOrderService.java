package org.dfzt.service;

import org.dfzt.entity.po.PicmaWorkOrder;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 李木
* @description 针对表【picma_work_order】的数据库操作Service
* @createDate 2023-05-30 09:41:22
*/
public interface PicmaWorkOrderService extends IService<PicmaWorkOrder> {

}
