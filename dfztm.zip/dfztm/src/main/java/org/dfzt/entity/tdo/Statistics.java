package org.dfzt.entity.tdo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * //统计列表
 */
@Data
public class Statistics {
    //类型(电压、电流、温度、湿度)
    private String typeName;
    //离线
    private int offLine;
    //预警
    private int warning;
    //正常
    private int normal;
}
