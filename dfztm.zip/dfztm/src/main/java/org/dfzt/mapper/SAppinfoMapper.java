package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.SAppinfo;

/**
* @author 李木
* @description 针对表【s_appinfo】的数据库操作Mapper
* @createDate 2023-05-29 11:32:55
* @Entity org.afzt.entity.po.SAppinfo
*/
public interface SAppinfoMapper extends BaseMapper<SAppinfo> {

}




