package org.dfzt.entity.xmlDemoReal;

import org.dfzt.util.XStreamUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName RunDemo
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/14 20:12
 */
public class RunDemo {
    public static void main(String[] args) {
        ReaLDemo demo = new ReaLDemo();
        List<General> list =new ArrayList<>();

        General general =new General();
        general.setN("MR_DATE");
        general.setValue("2016-01-09");
        list.add(general);
        General general1 =new General();
        general1.setN("TG_NO");
        general1.setValue("123");

        list.add(general1);

        demo.setReal1List(list);
        String xml = XStreamUtils.objectToXml(demo);
        xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+xml;
        xml = xml.replaceAll("__","_");
        System.out.println(xml);

        ReaLDemo ss = XStreamUtils.xmlToObject(xml,ReaLDemo.class,new DemoConverter());
        System.out.println("ss = " + ss);
    }
}
