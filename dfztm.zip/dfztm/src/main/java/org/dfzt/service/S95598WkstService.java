package org.dfzt.service;

import org.dfzt.entity.po.S95598Wkst;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.SuperiorWorkOrder;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/20
 * @Version: 1.00
 */
public interface S95598WkstService extends IService<S95598Wkst>{

    Integer insert95598WorkOrder(SuperiorWorkOrder superiorWorkOrder,S95598Wkst s95598Wkst);

}
