package org.dfzt.eunm;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/11
 * @Version: 1.00
 */
public enum CollectTypeEnum {
    TYPE_ONE("1","采集失败"),
    TYPE_TWO("2","采集异常"),
    TYPE_THREE("3","采集未接入");

    private final String name;
    private final String value;

    CollectTypeEnum(String name,String value){
        this.name = name;
        this.value = value;
    }

    // 将数据缓存到map中
    private static final Map<String, String> map = new HashMap<>();

    static {
        for (CollectTypeEnum color : CollectTypeEnum.values()) {
            map.put(color.getName(), color.getValue());
        }
    }

    // 根据name查询value值
    public static String getValueByName(String name) {
        return map.get(name);
    }

//    // 根据name查询value值
//    public static String getNameByValue(String value) {
//        switch (value){
//            case "采集失败": {
//                return "1";
//            }
//            case "采集异常": {
//                return "2";
//            }
//            case "采集未接入": {
//                return "3";
//            }
//        }
//        return "错误";
//    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }
}
