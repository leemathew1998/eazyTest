package org.dfzt.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.dfzt.entity.vo.SuperiorFrequentoutages;
import org.dfzt.service.SuperiorFrequentoutagesService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * (SuperiorFrequentoutages)表控制层
 *
 * @author makejava
 * @since 2022-08-09 18:39:06
 */
@RestController
@RequestMapping("superiorFrequentoutages")
public class SuperiorFrequentoutagesController extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private SuperiorFrequentoutagesService superiorFrequentoutagesService;

    /**
     * 分页查询所有数据
     *
     * @param page                    分页对象
     * @param superiorFrequentoutages 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll")
    public R selectAll(Page<SuperiorFrequentoutages> page, SuperiorFrequentoutages superiorFrequentoutages) {
        return success(this.superiorFrequentoutagesService.page(page, new QueryWrapper<>(superiorFrequentoutages)));
    }

    @PostMapping("selectWrapper")
    public R selectWrapper(Page<SuperiorFrequentoutages> page, String str) {
        return success(this.superiorFrequentoutagesService.page(page, superiorFrequentoutagesService.wrapper(str)));
    }
}
