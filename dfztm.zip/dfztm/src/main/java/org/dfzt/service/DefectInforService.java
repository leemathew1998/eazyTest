package org.dfzt.service;


import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.vo.DefectInfor;


/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
public interface DefectInforService extends IService<DefectInfor> {
   /**
    * FIXME 查看缺陷详情
    *
    * @return
    */
   R QueryAll();

   /**
    * FIXME  添加
    * @param defectInfor
    * @return
    */
   int insertDefectInfor(DefectInfor defectInfor);//添加缺陷录入信息

   /**
    * FIXME 根据缺陷编号查询缺陷信息
    *
    * @param defectNo
    * @return
    */
   R defectQuery(String defectNo);

   DefectInfor selectOne(String workOrderNo);//查看缺陷录入信息
}
