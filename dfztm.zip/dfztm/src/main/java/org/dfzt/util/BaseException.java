package org.dfzt.util;

/**
 * @ClassName BaseException
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/8/10 18:47
 */
public interface BaseException {
    Integer getCode();

    String getMessage();
}
