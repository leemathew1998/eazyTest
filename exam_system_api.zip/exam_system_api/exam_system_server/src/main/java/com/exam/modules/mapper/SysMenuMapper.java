package com.exam.modules.mapper;

import com.exam.modules.entity.SysMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
 * <p>
 * 菜单表 Mapper 接口
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface SysMenuMapper extends BaseMapper<SysMenu> {
    /**
     * 根据用户ID查询权限列表
     * @param userId
     * @return
     */
    List<SysMenu> findSysMenuListByUserId(Long userId);

    /**
     * 根据角色ID查询权限列表
     * @param roleId
     * @return
     */
    List<SysMenu> findMenuListByRoleId(Long roleId);
}
