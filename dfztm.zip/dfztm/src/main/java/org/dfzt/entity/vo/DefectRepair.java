package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "DefectRepair对象", description = "")
public class DefectRepair implements Serializable {


    @ApiModelProperty(value = "id(缺陷立行立改修复录入信息)")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "处理过程描述")
    @TableField("handle_describe")
    private String handleDescribe;

    @ApiModelProperty(value = "处理时间")
    @TableField("handle_time")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date handleTime;

    @ApiModelProperty(value = "消耗运维材料")
    @TableField("consume_material")
    private String consumeMaterial;

    @ApiModelProperty(value = "处理后照片")
    @TableField("handle_photo")
    private String handlePhoto;

    @ApiModelProperty(value = "关联工单编号")
    @TableField("work_order_no")
    private String workOrderNo;


}
