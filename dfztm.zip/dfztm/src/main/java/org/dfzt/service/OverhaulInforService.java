package org.dfzt.service;


import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.vo.OverhaulInfor;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
public interface OverhaulInforService extends IService<OverhaulInfor> {
    int insertOverhaul(OverhaulInfor overhaulInfor);//新增检修信息
    R addOverhaul(OverhaulInfor overhaulInfor);
    OverhaulInfor selectOne(String workOrderNo);//根据工单编号查看检修处理信息
}
