package com.exam.modules.entity;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * 考试管理(ExamManage)表实体类
 *
 * @author makejava
 * @since 2022-11-08 17:16:06
 */
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.EXAM_MANAGE")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ExamManage implements Serializable{
    //考试id
    @TableId("EXAM_ID")
    private Long examId;
    //考试名称
    @TableField("EXAM_NAME")
    private String examName;
    //试卷id
    @TableField("EXAM_PAPER_ID")
    private Long examPaperId;
    //多个用户id
    @TableField("USER_IDS")
    private String userIds;
    //考试类型（1.普通在线考试/2.集中在线考试）
    @TableField("EXAM_TYPE")
    private String examType;
    //考试状态（1.未开始/2.考试中/3.已结束）
    @TableField("EXAM_STATUS")
    private String examStatus;
    //考试开始时间
    @TableField("EXAM_BEGIN_TIME")
    private Date examBeginTime;
    //考试结束时间
    @TableField("EXAM_END_TIME")
    private Date examEndTime;
    //考试时长
    @TableField("EXAM_LONG_TIME")
    private String examLongTime;
    //及格分数
    @TableField("PASS_SCORE")
    private String passScore;
    //应考人数
    @TableField(exist = false)
    private long sunNum;
    //实考人数
    @TableField(exist = false)
    private long perNum;
}
