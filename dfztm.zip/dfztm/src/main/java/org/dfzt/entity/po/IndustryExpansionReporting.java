package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 业扩报装
 * @TableName Industry_expansion_reporting
 */
@TableName(value ="Industry_expansion_reporting")
@Data
public class IndustryExpansionReporting implements Serializable {
    /**
     * ID(业扩报装)
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 方案编码
     */
    private String programCode;

    /**
     * 用户姓名
     */
    private String userName;

    /**
     * 客户确认签名
     */
    private String custConfSign;

    /**
     * 日期
     */
    private Date createTime;


    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}