package org.dfzt.service;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 */

public interface ThDapiService {
    Integer selectUpcomingWarning1(List<String> orgNames, String workorderType);//查询采集和计量的工单数
    Integer selectUpcomingWarning2(List<String> orgNames,String workorderType);//查询线损治理的工单数
    Integer selectUpcomingWarning3(List<String> orgNames,String workorderType);//查询费控复电工单数
    Integer selectUpcomingWarning4(List<String> orgNames,String workorderType);//查询电费工单数
    Integer selectUpcomingWarning5(List<String> orgNames,String workorderType);//查询服务工单数（优质服务）
    Integer selectUpcomingWarning6(List<String> orgNames,String workorderType);//运维抢修工单数
}
