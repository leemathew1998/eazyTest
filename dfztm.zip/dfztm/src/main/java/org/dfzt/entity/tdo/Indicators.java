package org.dfzt.entity.tdo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 指标列表
 */
@Data
public class Indicators {
    //类型1:采集成功率 2:费控停电成功率 3:费控复电成功率 4:自动发行比例
    // 5:低压线损率 6:高损台区占比 7:负损台区占比 8:经济运行台区占比
    // 9:电费结零率 10:配电异常台区次数 11:采集消缺及时率 12:现场复电及时率
    // 13:投诉建议工单数量 14:运维抢修到达现场及时率
    // 15:计量消缺及时率 16:高负损台区消缺及时率
    private int type;
    //类型名称
    private String typeName;
    //值
    //private int value;
    private double value;
}
