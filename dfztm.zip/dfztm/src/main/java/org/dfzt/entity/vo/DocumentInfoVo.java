package org.dfzt.entity.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 线路名称和文档信息的返回结果集
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DocumentInfoVo {


    /**
     *用户编号
     */
    @ApiModelProperty(value = "用户编号")
    private String consNo;

    /**
     *电能表资产号
     */
    @ApiModelProperty(value = "电能表资产号")
    private String assetNo;

    /**
     *姓名
     */
    @ApiModelProperty(value = "姓名")
    private String consName;

    /**
     *电话
     */
    @ApiModelProperty(value = "电话")
    private String mobile;

    /**
     * 用电地址
     */
    private String elecAddr;

//    /**
//     * 用电类别
//     */
//    private String tradeCode;


    /**
     * 台区id
     */
    @ApiModelProperty(value = " 台区id")
    private String tgId;

    /**
     * 线路id
     */
    @ApiModelProperty(value = " 线路id")
    private String lineId;

    /**
     * 线路名称
     */
    @ApiModelProperty(value = " 线路名称")
    private String lineName;

}
