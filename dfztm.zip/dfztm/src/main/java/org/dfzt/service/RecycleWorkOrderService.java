package org.dfzt.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.ARcvblFlow;
import org.dfzt.entity.po.SuperiorWorkOrder;
import org.dfzt.entity.vo.RecycleWorkOrder;

import java.util.List;
import java.util.Map;

/**
 * (RecycleWorkOrder)表服务接口
 *
 * @author makejava
 * @since 2022-07-11 15:38:15
 */
public interface RecycleWorkOrderService extends IService<RecycleWorkOrder> {

    /**
     * 状态扭转
     * @param
     * @return
     */
    int updateRecycleWorkOrder(String workOrderStatus,String workOrderNo);

    /**
     * 查询历史工单
     * @param workOrderId
     * @return
     */
    RecycleWorkOrder selectRecycleWordOrderId(String workOrderId);

    //获取上个月的欠费信息
    Integer selectArcByYM(String startMon,List<ARcvblFlow> aRcvblFlows);

    List<RecycleWorkOrder> selectByNoSta4();//查询当月没有完成的工单（状态4）

    int updateDes(String workOrderDes,String workorderNo);//根据工单编号 添加工单处理描述信息


    LambdaQueryWrapper queryWrapper(RecycleWorkOrder r, String role);
    LambdaQueryWrapper wrapper(List<String> readNames,String str, String role,String workOrderStatus,String elecType,String loName2);

    /**
     * 敏感用户工单查询
     * @return
     */
    List<SuperiorWorkOrder> selectWorkOrderList(RecycleWorkOrder recycleWorkorder);

}

