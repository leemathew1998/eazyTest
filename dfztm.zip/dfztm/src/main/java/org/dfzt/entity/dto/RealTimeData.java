package org.dfzt.entity.dto;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/19
 * @Version: 1.00
 * 实时透抄实体类
 */
@Data
public class RealTimeData {
    //终端地址
    private String terminalAddr;
    //电能表资产号
    private String meterAssetNo;
    //正向有功总电能示值
    private BigDecimal papE;
    //开关状态
    private String switchStatus;
    //电能表地址
    private String commAddr;
    //相位角
    private String phaseFlag;
}
