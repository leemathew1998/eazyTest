package org.dfzt.service;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.CCons;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
public interface CConsService extends IService<CCons> {

    List<CCons> selectList(LambdaQueryWrapper<CCons> queryWrapper);
}
