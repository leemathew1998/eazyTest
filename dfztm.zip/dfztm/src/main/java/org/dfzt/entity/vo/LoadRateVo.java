package org.dfzt.entity.vo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class LoadRateVo {

    /**
     * 四维接口的返回id
     */
    private String id;

    /**
     * 四维接口的返回名称
     */
    private String name;

    /**
     * 可用容量
     */
    @ApiModelProperty(value = "可变容量")
    private BigDecimal variableCap;

    /**
     * 台区变压容量
     */
    @ApiModelProperty(value = "台区变压容量")
    private Integer tgCap;



}
