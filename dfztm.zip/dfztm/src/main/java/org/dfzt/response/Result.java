package org.dfzt.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 *   接口返回数据格式
 * @author scott
 * @email jeecgos@163.com
 * @date  2019年1月19日
 */
@Data
@ApiModel(value="接口返回对象", description="接口返回对象")
public class Result<T> implements Serializable {

	@ApiModelProperty(value = "是否成功")
	private Boolean success;

	@ApiModelProperty(value = "返回码")
	private Integer code;

	@ApiModelProperty(value = "返回消息")
	private String message;

	@ApiModelProperty(value = "返回数据")
	private Map<String,Object> data = new HashMap<>();

	/**
	 * 构造方法私有化，里面的方法都是静态方法
	 * 达到保护属性的作用
	 */
	private Result(){

	}

	/**
	 * 这里是使用链式编程
	 */
	public static Result ok(){
		Result result = new Result();
		result.setSuccess(true);
		result.setCode(ResultCode.SUCCESS.getCode());
		result.setMessage(ResultCode.SUCCESS.getMessage());
		return result;
	}

	public static Result error(){
		Result result = new Result();
		result.setSuccess(false);
		result.setCode(ResultCode.ERROR.getCode());
		result.setMessage(ResultCode.ERROR.getMessage());
		return result;
	}

	/**
	 * 测试
	 * @return
	 */
	public static Result test500(){
		Result result = new Result();
		result.setSuccess(false);
		result.setCode(ResultCode.INTERNAL_SERVER_ERROR.getCode());
		result.setMessage(ResultCode.INTERNAL_SERVER_ERROR.getMessage());
		return result;
	}

	/**
	 * 自定义返回成功与否
	 * @param success
	 * @return
	 */
	public Result success(Boolean success) {
		this.setSuccess(success);
		return this;
	}

	public Result code(Integer code) {
		this.setCode(code);
		return this;
	}

	public Result message(String message) {
		this.setMessage(message);
		return this;
	}

	public Result data(String key, Object value) {
		this.data.put(key, value);
		return this;
	}

	public Result data(Map<String, Object> map) {
		this.setData(map);
		return this;
	}


}
