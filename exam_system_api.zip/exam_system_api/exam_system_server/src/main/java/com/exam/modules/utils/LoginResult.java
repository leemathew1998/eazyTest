package com.exam.modules.utils;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author dyy
 * @Date 2022/10/31 9:52
 * @PackageName:com.exam.modules.utils
 * @ClassName: LoginResult
 * @Description: TODO
 * @Version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginResult {
    //用户编号
    private Long id;
    //状态码
    private int code ;
    //token令牌
    private String token ;
    //token过期时问
    private Long expireTime ;
}
