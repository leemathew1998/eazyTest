package org.dfzt.entity.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CollectInformation {
    @Excel(name = "ID",orderNum = "0")
    private Integer id;
    @Excel(name = "上级供电单位",orderNum = "1")
    private String upSupplyUnit;
    @Excel(name = "供电单位",orderNum = "2")
    private String orgName;
    @Excel(name = "用户编码",orderNum = "3")
    private String consNo;
    @Excel(name = "用户名称",orderNum = "4")
    private String consName;
    @Excel(name = "异常数据",orderNum = "5")
//    @TableField("abnormalData")
    private String abnormalData;
    @Excel(name = "电能表资产号",orderNum = "6")
    private String elecmeterAssetNum;
    @Excel(name = "电能表厂家",orderNum = "7")
    private String elecmeterFactory;
    @Excel(name = "终端厂家",orderNum = "8")
    private String terminalFactory;
    @Excel(name = "接线方式",orderNum = "9")
//    @TableField("elecmeterContype")
    private String elecmeterContype;
    @Excel(name = "台区编号",orderNum = "10")
    private String tgId;
    @Excel(name = "台区名称",orderNum = "11")
    private String tgName;
    @Excel(name = "综合倍率",orderNum = "12")
    private Integer compMag;
    @Excel(name = "正向有功总",orderNum = "13")
    private BigDecimal totalPositiveActivePower;
    @Excel(name = "尖",orderNum = "14")
    private BigDecimal rateOne;
    @Excel(name = "峰",orderNum = "15")
    private BigDecimal rateTwo;
    @Excel(name = "平",orderNum = "16")
    private BigDecimal rateThree;
    @Excel(name = "谷",orderNum = "17")
    private BigDecimal rateFour;
    @Excel(name = "反向无功总",orderNum = "18")
    private BigDecimal totalReverseReactivePower;
    @Excel(name = "正向无功总",orderNum = "19")
    private BigDecimal totalPositiveReactivePower;
    @Excel(name = "反向有功总",orderNum = "20")
    private BigDecimal totalReverseActivePower;
    @Excel(name = "一象限无功",orderNum = "21")
    private BigDecimal oneQuadrantReactivePower;
    @Excel(name = "二象限无功",orderNum = "22")
    private BigDecimal twoQuadrantReactivePower;
    @Excel(name = "三象限无功",orderNum = "23")
    private BigDecimal threeQuadrantReactivePower;
    @Excel(name = "四象限无功",orderNum = "24")
    private BigDecimal fourQuadrantReactivePower;
    @Excel(name = "用电地址",orderNum = "25")
    private String consAddr;
    @Excel(name = "终端地址",orderNum = "26")
    private String terminalAdd;
    @Excel(name = "上送时间",orderNum = "27")
    private Date sendTime;
    @Excel(name = "终端抄表时间",orderNum = "28")
    private Date terMeterReadtime;
    @Excel(name = "测量点号",orderNum = "29")
    private Integer measurPnumber;
    @Excel(name = "抄表段编号",orderNum = "30")
    private Integer meterReadNo;
    @Excel(name = "终端资产号",orderNum = "31")
    private String terAssetNo;
    @Excel(name = "抄表员信息",orderNum = "32")
    private String meterReadInfo;
    @Excel(name = "同步人",orderNum = "33")
    private String synchro;
    @Excel(name = "同步人部门",orderNum = "34")
    private String synchroDep;
    @Excel(name = "同步时间",orderNum = "35")
    private Date synchroTime;
    @Excel(name = "同步方式",orderNum = "36")
    private String synchroMode;
    /**
     * 新增字段
     * @author dfzt-dyy
     * @since 2022-06-13
     */
    @Excel(name = "用户类型",orderNum = "37")
    private String userType;

    private int rankNo;

    private Date createTime;
    }
