package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/9
 * @Version: 1.00
 */
@Data
public class DMeterPo {
    private Integer id;
    //资产编号
    private String assetNo;
    //综合倍率
    private BigDecimal tFactor;
    //是否参考表
    private String refMeterFlag;
    //额定电压
    private String voltCode;
    //标定电流
    private String ratedCurrent;
    //有功准确度等级
    private String apPreLevelCode;
    //无功准确度等级
    private String rpPreLevelCode;
    //接线方式
    private String wiringMode;
    //接入方式
    private String conMode;
    //制造单位
    private String manufacturer;
    //通讯规约
    private String commProtCode;
    //终端地址码
    private String terminalAddr;
    //终端类型
    private String terminalTypeCode;
}
