package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/5/14
 * @Version: 1.00
 */
@Data
public class UserRole implements Serializable {
    private Integer id;

    private String userId;//用户id

    private String userName;//登录用户名
    private String userName1;//掌机登录用户名

    private String isRole;//角色权限 1.台区经理 2.所站长 3.管理员

    private String isManage;//是否是管理员 0不是 1是（暂时不用）

    private String relaName;//真实姓名
    private String readName;//抄表员姓名

    private String orgNo;//单位编号

    private String orgName;//单位名称
    private Integer consNum;//台区经理管辖用户数
    private Integer tgNum;//台区经理管辖台区数
}
