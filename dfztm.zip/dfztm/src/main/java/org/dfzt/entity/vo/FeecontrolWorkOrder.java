//package org.dfzt.entity.vo;
//
//
//import cn.afterturn.easypoi.excel.annotation.Excel;
//import com.baomidou.mybatisplus.annotation.IdType;
//import com.baomidou.mybatisplus.annotation.TableField;
//import com.baomidou.mybatisplus.annotation.TableId;
//import com.baomidou.mybatisplus.extension.activerecord.Model;
//
//import com.baomidou.mybatisplus.annotation.TableName;
//import io.swagger.annotations.ApiModelProperty;
//import lombok.Data;
//import org.dfzt.eunm.FeecontrWayEnum;
//import org.dfzt.eunm.WorkOrderStatusEnum;
//
//import java.util.Date;
//
///**
// * (FeecontrolWorkOrder)表实体类
// *
// * @author makejava
// * @since 2022-07-12 14:58:25
// */
//@SuppressWarnings("serial")
//@TableName("feecontrol_work_order")
//@Data
//public class FeecontrolWorkOrder extends Model<FeecontrolWorkOrder> {
//    //工单编号
//    @Excel(name = "工单编号",orderNum = "0",width = 20)
//    private String workOrderNo;
//    //台区经理
//    @Excel(name = "台区经理",orderNum = "1")
//    private String tgManager;
//    //台区编号
//    @Excel(name = "台区编号",orderNum = "2",width = 12)
//    private String tgId;
//    //台区名称
//    @Excel(name = "台区名称",orderNum = "3",width = 11)
//    private String tgName;
//    //供电单位
//    @Excel(name = "供电单位",orderNum = "4",width = 15)
//    private String orgNo;
//    //用户名称
//    @Excel(name = "用户名称",orderNum = "5")
//    private String consName;
//    //用户编号
//    @Excel(name = "用户编号",orderNum = "6",width = 15)
//    private String consNo;
//    //用户地址
//    @Excel(name = "用户地址",orderNum = "7",width = 40)
//    private String elecAddr;
//    //账务联系人电话
//    @Excel(name = "账务联系人电话",orderNum = "8",width = 30)
//    private String mobile;
//    //条码号
//    private String shapeCode;
//    //电能表资产号
//    private String elecmeterAssetNum;
//    //终端地址
//    private String terminalAdd;
//    //复电失败时间
//    private Date failTime;
//    //复电失败时长
//    private String failTimePeriod;
//    //复电方式
//    @ApiModelProperty("复电方式")
//    private String seretWay;
//    //工单状态，1.待处理，2.处理中，3.待归档，4.已归档
//    @ApiModelProperty("工单状态")
//    @Excel(name = "工单状态",orderNum = "9")
//    private WorkOrderStatusEnum workOrderStatus;
//    //是连续几天的工单
//    private Integer workOrderCycle;
//    //工单生成时间
//    @Excel(name = "工单生成时间",orderNum = "10")
//    private Date workOrderCtime;
//    //工单耗时
//    private String workOrderUtime;
//    //工单解决时间
//    private Date workOrderStime;
//    //工单归档时间
//    private Date workOrderFtime;
//    //处理人
//    private String handler;
//    //处理人接收时间
//    private Data handlerRtime;
//    //页码
//    @TableField(exist = false)
//    private long pageNo;
//    //每页条数
//    @TableField(exist = false)
//    private long pageSize;
//
//
//    //图片
//    @TableField(exist = false)
//    private String photo;
//
//    //下面三个图片整和在同一行
//    @TableField(exist = false)
//    @Excel(name = "图片1",orderNum = "10",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
//    private String photoOne;
//
//    @TableField(exist = false)
//    @Excel(name = "图片2",orderNum = "11",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
//    private String photoTwo;
//
//    @TableField(exist = false)
//    @Excel(name = "图片3",orderNum = "12",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
//    private String photoThree;
//
//
//    //图片处理时间
//    @TableField(exist = false)
//    private Date pTime;
//    //图片处理状态 （已解决 未解决）
//    @TableField(exist = false)
//    private String pStatus;
//    //现场情况
//    @TableField(exist = false)
//    private String liveSituation;
//    //现场照片
//    @TableField(exist = false)
//    private String livePhotos;
//    //现场视频
//    @TableField(exist = false)
//    private String liveVideo;
//
//    public void setSeretWay(String seretWay) {
//        this.seretWay = FeecontrWayEnum.getValueByName(seretWay);
//    }
//
////    public void setWorkOrderStatus(String workOrderStatus) {
////        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
////    }
//}
