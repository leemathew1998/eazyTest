package org.dfzt.service;

import org.dfzt.entity.po.SPowerViolateSteal;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface SPowerViolateStealService extends IService<SPowerViolateSteal>{


}
