package com.exam.modules.entity.dto;

import com.exam.modules.entity.vo.AnsRecordVo;
import lombok.Data;

import java.util.List;

/**
 * @Author dyy
 * @Date 2022/11/10 16:59
 * @PackageName:com.exam.modules.entity.dto
 * @ClassName: AnsRecordDTO
 * @Description: TODO
 * @Version 1.0
 */
@Data
public class AnsRecordDTO extends AnsRecordVo {
    //考生id
    private Long userId;
    private Long examId;
    private List<Object> list;
}
