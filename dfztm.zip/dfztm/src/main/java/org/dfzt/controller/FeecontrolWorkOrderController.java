package org.dfzt.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.models.auth.In;
import org.apache.commons.lang3.StringUtils;
import org.dfzt.annotation.CurrentUser;
import org.dfzt.entity.po.LinelossWorkOrder;
import org.dfzt.entity.po.MeterWorkOrder;
import org.dfzt.entity.po.WorkOrderInfor;
import org.dfzt.entity.po.FeecontrolWorkOrder;
import org.dfzt.entity.vo.RunWorkOrder;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.eunm.WorkOrderStatusEnum;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.mapper.FeecontrolWorkOrderMapper;
import org.dfzt.response.ResultCode;
import org.dfzt.service.FeecontrolWorkOrderService;
import org.dfzt.util.ExcelUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * (FeecontrolWorkOrder)表控制层
 *
 * @author makejava
 * @since 2022-07-12 14:58:25
 */
@RestController
@RequestMapping("feecontrolWorkOrder")
public class FeecontrolWorkOrderController extends ApiController {

    @Resource
    private FeecontrolWorkOrderService feecontrolWorkOrderService;
    @Resource
    private FeecontrolWorkOrderMapper feecontrolWorkOrderMapper;
    @Resource
    private CollectWorkOrderMapper collectWorkOrderMapper;


    @RequestMapping("export")  //excel/export
    public void exportExcel2(HttpServletResponse response, @RequestParam String ids) throws IOException {
        List<org.dfzt.entity.po.FeecontrolWorkOrder> feecontrolWorkOrders = collectWorkOrderMapper.selectExcel4(ids);
        ExcelUtils.exportExcel(feecontrolWorkOrders, "费控复电工单列表", "费控复电", org.dfzt.entity.po.FeecontrolWorkOrder.class, "费控复电工单文件", response);
    }

    @RequestMapping("exportAll")  //excel/export
    public void exportExcel2All(HttpServletResponse response, @RequestParam(required = false) String ids,org.dfzt.entity.po.FeecontrolWorkOrder feecontrolWorkOrder,
                                @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,
                                @RequestParam(required = false) String loName2) throws IOException {
        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<org.dfzt.entity.po.FeecontrolWorkOrder> feecontrolWorkOrders = feecontrolWorkOrderMapper.selectFeeList(feecontrolWorkOrder, 0, 999999999, status,orgName);
        ExcelUtils.exportExcel(feecontrolWorkOrders, "费控复电工单列表", "费控复电", org.dfzt.entity.po.FeecontrolWorkOrder.class, "费控复电工单文件", response);
    }

    /**
     * 查询全部工单
     *
     * @param
     * @param feecontrolWorkOrder
     * @return
     * @author xiayepeng
     */
    @PostMapping("selectAll")
    public R selectAll(org.dfzt.entity.po.FeecontrolWorkOrder feecontrolWorkOrder,@RequestParam(name = "pageNo",defaultValue = "1") String pageNo,
                       @RequestParam(name = "pageSize",defaultValue = "10") String pageSize,
                       @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String loName2) {

        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<org.dfzt.entity.po.FeecontrolWorkOrder> feecontrolWorkOrders = feecontrolWorkOrderMapper.selectFeeList(feecontrolWorkOrder,(Integer.parseInt(pageNo)-1)*Integer.parseInt(pageSize),Integer.parseInt(pageSize),status,orgName);
        int size = feecontrolWorkOrderMapper.selectFeeList(feecontrolWorkOrder, 1, 999999999, status,orgName).size();
        Map<Integer,List<org.dfzt.entity.po.FeecontrolWorkOrder>> map = new HashMap<>();
        map.put(size,feecontrolWorkOrders);
        R<Map<Integer,List<org.dfzt.entity.po.FeecontrolWorkOrder>>> success = success(map);

        if (success.getData().size() > 0) {
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }





    @PostMapping("selectAll1")
    public R selectAll1(@CurrentUser SysUser user, Page<FeecontrolWorkOrder> page, FeecontrolWorkOrder feecontrolWorkOrder) {

        String role = feecontrolWorkOrderService.selectRole(user.getLoginName());
        R<Page<FeecontrolWorkOrder>> success = success(feecontrolWorkOrderService.page(page, feecontrolWorkOrderService.queryWrapper(feecontrolWorkOrder, role)));
        if (success.getData().getRecords().size() > 0) {
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }

    @PostMapping("selectWrapper")
    public R selectWrapper(@RequestParam String loName2, @RequestParam(name = "pageNo", defaultValue = "0") String pageNo,
                           @RequestParam(name = "pageSize", defaultValue = "10") String pageSize,@RequestParam String str
            ,@RequestParam String workOrderStatus,@RequestParam(required = false) String role,@RequestParam(required = false) String loginName) {
        Page<FeecontrolWorkOrder> page=new Page<>(Integer.parseInt(pageNo),Integer.parseInt(pageSize));
        List<String> readNames = collectWorkOrderMapper.selectReadNames(loginName);
        //feecontrolWorkOrderService.selectRole(loName2);
        R<Page<FeecontrolWorkOrder>> success = success(feecontrolWorkOrderService.page(page, feecontrolWorkOrderService.wrapper(readNames,str, role,workOrderStatus,loName2)));
        if (success.getData().getRecords().size() > 0) {
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }


    /**
     * 根据工单号查询历史提交记录
     *
     * @param workOrderNo
     * @return
     */
    @PostMapping("selectWorkOrderScene")
    public R selectWorkOrderScene(@RequestParam String workOrderNo) {
        return success(feecontrolWorkOrderService.selectWorkOrderScene(workOrderNo));
    }

    /**
     * 查询敏感用户工单数据
     *
     * @param feecontrolWorkOrder
     * @return
     */
    @PostMapping("selectWorkOrderList")
    public R selectWorkOrderList(FeecontrolWorkOrder feecontrolWorkOrder) {
        return success(feecontrolWorkOrderService.selectWorkOrderList(feecontrolWorkOrder));
    }


    /**
     * 费控复电的状态扭转
     *
     * @param workOrderInfor
     * @return
     */
    @PostMapping("updateWorkOrderStatus")
    public R updateFeecontrolWordOrder(WorkOrderInfor workOrderInfor) {
        R<Integer> success = success(feecontrolWorkOrderService.updateWorkOrderStatus(workOrderInfor));
        if (success.getData() == 1) {
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }

    /**
     * 查询历史数据(含图片)
     *
     * @param workOrderNo
     * @return
     */
    @PostMapping("selectWordOrderId")
    public R selectFeecontrolWordOrder(@RequestParam String workOrderNo) {
        R<FeecontrolWorkOrder> success = success(feecontrolWorkOrderService.selectFeecontrolWordOrderNo(workOrderNo));
        if (success.getData() != null) {
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }

    /**
     * 判断复电是否成功
     * @param workOrderInfor
     * @return
     */
    @PostMapping("manualPigeonhole")
    public R manualPigeonhole(WorkOrderInfor workOrderInfor) {
        if (success(feecontrolWorkOrderService.manualPigeonhole(workOrderInfor)).getData() == 1) {
            return success("复电成功");
        }
        return success("复电失败");
    }

    /**
     * 费控复电导出
     *
     * @param ids
     * @return
     */
    @PostMapping("export1")  //excel/export
    public void export(HttpServletResponse response, @RequestParam List<String> ids) throws IOException {
        List<FeecontrolWorkOrder> list = new ArrayList<>();
        for (String id : ids) {
            FeecontrolWorkOrder feecontrolWorkOrder = feecontrolWorkOrderService.selectByFeecontrolWordOrderNo(id);
            if (StrUtil.isNotBlank(feecontrolWorkOrder.getPhoto())){
                String[] split = feecontrolWorkOrder.getPhoto().split(",");
                if (split.length > 0) {
                    feecontrolWorkOrder.setPhotoOne(split[0]);
                }
                if (split.length > 1) {
                    feecontrolWorkOrder.setPhotoTwo(split[1]);
                }
                if (split.length > 2) {
                    feecontrolWorkOrder.setPhotoThree(split[2]);
                }
            }
            list.add(feecontrolWorkOrder);
        }
        ExcelUtils.exportExcel(list, "费控复电工单列表", "费控复电", org.dfzt.entity.po.FeecontrolWorkOrder.class, "费控复电工单文件", response);
    }

}
