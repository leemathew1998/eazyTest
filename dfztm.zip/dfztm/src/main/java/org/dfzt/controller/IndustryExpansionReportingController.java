package org.dfzt.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import org.dfzt.entity.po.IndustryExpansionReporting;
import org.dfzt.mapper.IndustryExpansionReportingMapper;
import org.dfzt.service.IndustryExpansionReportingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;


/**
 * 业扩报装
 * @Author: 14259 luomin
 * @Date: 2022/7/15
 * @Version: 1.00
 */
@RestController
@RequestMapping("IndustryExpansionReporting")
public class IndustryExpansionReportingController {
    @Autowired
    private IndustryExpansionReportingService industryExpansionReportingService;
    @Autowired
    private IndustryExpansionReportingMapper industryExpansionReportingMapper;
    //插入数据
    @PostMapping("insert")
    public R insert(@RequestBody IndustryExpansionReporting industryExpansionReporting){
        String custConfSign = industryExpansionReporting.getCustConfSign();
        if (custConfSign==null){
            return R.failed("需要客户签名");
        }
        boolean save = industryExpansionReportingService.save(industryExpansionReporting);
        if (save){
            return R.ok("插入成功");
        }
        return R.failed("插入失败");

    }

    //查询数据
    @PostMapping("selectAll")
    public List<IndustryExpansionReporting> selectAll(){

        List<IndustryExpansionReporting> industryExpansionReportings = industryExpansionReportingService.list(null);
        return industryExpansionReportings;
    }
    //根据方案编码查询
    @PostMapping("selectByCode")
    public R selectByCode(@RequestParam String code){
        IndustryExpansionReporting ide = industryExpansionReportingMapper.selectOne(new QueryWrapper<IndustryExpansionReporting>().eq("Program_code", code));
        return R.ok(ide);
    }


    @PostMapping("3DAll")
    public R betchInsert(@RequestBody List<IndustryExpansionReporting> industryExpansionReporting){

        boolean b = industryExpansionReportingService.saveBatch(industryExpansionReporting);
        return R.ok(b);
    }
}
