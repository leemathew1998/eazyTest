package org.dfzt.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/5
 * @Version: 1.00
 */
public class PingUtil {
    public static String ping(String ip) {
        String result = null;
        BufferedReader br = null;
        try {
            //注意,linux环境与windows环境ping命令返回的不同
            //windows环境下: Process ps = Runtime.getRuntime().exec("ping  "+ ip);//ping后面有空格
            //下面是linux下使用的命令,需要注意的是,ping -c 4后面有一个空格,该空格不可去
//            Process ps = Runtime.getRuntime().exec("ping -c 4 "+ ip);
            Process ps = Runtime.getRuntime().exec("ping  "+ ip);
            //获取命令的返回数据
            br = new BufferedReader(new InputStreamReader(ps.getInputStream(), Charset.forName("GBK")));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                //执行结果加上回车
                sb.append(line).append("\n");
            }
            result = sb.toString();
            System.out.println(result);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (br != null) {
                    br.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result;
    }
}
