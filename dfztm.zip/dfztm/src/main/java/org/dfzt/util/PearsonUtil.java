package org.dfzt.util;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;

/**
 * @Author: 14259 zhangsheng TODO 皮尔逊相关性系数工具类
 * @Date: 2022/6/14
 * @Version: 1.00
 */
public class PearsonUtil {


    public static BigDecimal getPearsonCorrelationScore(BigDecimal[] xData, BigDecimal[] yData) {
        System.out.println(xData.length);
        System.out.println(yData.length);
        if (xData.length != yData.length)
            throw new RuntimeException("数据不正确！");
        BigDecimal xMeans;
        BigDecimal yMeans;
        BigDecimal numerator = new BigDecimal("0");// 求解皮尔逊的分子
        BigDecimal denominator = new BigDecimal("0");// 求解皮尔逊系数的分母

        BigDecimal result = new BigDecimal("0");
        // 拿到两个数据的平均值
        xMeans = getMeans(xData);
        yMeans = getMeans(yData);
        // 计算皮尔逊系数的分子
        numerator = generateNumerator(xData, xMeans, yData, yMeans);
        // 计算皮尔逊系数的分母
        denominator = generateDenomiator(xData, xMeans, yData, yMeans);
        // 计算皮尔逊系数
        result = numerator.divide(denominator,BigDecimal.ROUND_HALF_EVEN);
        return result;
    }

    /**
     * 计算分子
     *
     * @param xData
     * @param xMeans
     * @param yData
     * @param yMeans
     * @return
     */
    private static BigDecimal generateNumerator(BigDecimal[] xData, BigDecimal xMeans, BigDecimal[] yData, BigDecimal yMeans) {
        BigDecimal numerator = new BigDecimal("0.0");
        for (int i = 0; i < xData.length; i++) {
            numerator = numerator.add((xData[i].subtract(xMeans)).multiply ((yData[i].subtract(yMeans))));
        }
        return numerator;
    }

    /**
     * 生成分母
     *
     * @param yMeans
     * @param yData
     * @param xMeans
     * @param xData
     * @return 分母
     */
    private static BigDecimal generateDenomiator(BigDecimal[] xData, BigDecimal xMeans, BigDecimal[] yData, BigDecimal yMeans) {
        BigDecimal xSum = new BigDecimal("0.0");
        for (int i = 0; i < xData.length; i++) {
            xSum = xSum.add((xData[i].subtract(xMeans)).multiply((xData[i].subtract(xMeans))));
        }
        BigDecimal ySum = new BigDecimal("0.0");
        for (int i = 0; i < yData.length; i++) {
            ySum = ySum.add((yData[i].subtract(yMeans)).multiply((yData[i].subtract(yMeans))));
        }

        return sqrt(xSum,2).multiply(sqrt(ySum,2));
    }

    /**
     * 根据给定的数据集进行平均值计算
     *
     * @param
     * @return 给定数据集的平均值
     */
    private static BigDecimal getMeans(BigDecimal[] datas) {
        BigDecimal sum = new BigDecimal("0.0");
        for (int i = 0; i < datas.length; i++) {
            sum =sum.add(datas[i]);
        }
        return sum.divide(BigDecimal.valueOf(datas.length),BigDecimal.ROUND_HALF_EVEN);
    }

    /**
     * TODO 求BigDecimal的平方根
     * @param value 需要求的数
     * @param scale 开的根几次方
     * @return
     */
    public static BigDecimal sqrt(BigDecimal value, int scale){
        BigDecimal num2 = BigDecimal.valueOf(2);
        int precision = 100;
        MathContext mc = new MathContext(precision, RoundingMode.HALF_UP);
        BigDecimal deviation = value;
        int cnt = 0;
        while (cnt < precision) {
            deviation = (deviation.add(value.divide(deviation, mc))).divide(num2, mc);
            cnt++;
        }
        deviation = deviation.setScale(scale, BigDecimal.ROUND_HALF_EVEN);
        return deviation;
    }
}
