package org.dfzt.service;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.CContact;
import org.dfzt.entity.vo.ContList;

import java.util.List;


/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
public interface CContactService extends IService<CContact> {
    /**
     * 通过用户编号查询出所有的用户信息
     *
     * @param contList
     * @return
     */
    R QueryAll(ContList contList);

    /**
     * 全量查询
     *
     * @return
     */
    R selectConTactListAll(Long page ,Long pageSize);

    /**
     * 条件查询
     *
     * @return
     */
    R conditionQuery();


    R selconsinfo(String powerPointNo);

    /**
     * APP 端用户档案的模糊插叙
     * @param message
     * @return
     */
    R selectMessage(String message,Long pageNo,Long pageSize);
    R selectMessage1(String message,Long pageNo,Long pageSize);

    /**
     * 接口测试
     *
     * @return
     */
    R interfaceTest();

    List<CContact> selectList(LambdaQueryWrapper<CContact> query3);
}
