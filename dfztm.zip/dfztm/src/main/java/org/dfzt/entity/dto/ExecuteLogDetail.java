package org.dfzt.entity.dto;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.math.BigInteger;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/19
 * @Version: 1.00
 * 实时透抄实体类
 */
@Data
public class ExecuteLogDetail {

    @TableId(value = "id",type = IdType.AUTO)
    private int id;
    private String address;
    private double xmlLengthVol;
    private String xmlVol;
    private double xmlLengthCurr;
    private String xmlCurr;
    private int userCount;
    private int userCounta;
    private DateTime noa;
    private DateTime nob;
    private DateTime noc;
    private DateTime nod;
    private DateTime noe;
    private DateTime nof;
    private DateTime nog;
    private DateTime noh;
    private DateTime noi;
    private DateTime noj;
    private DateTime nok;
    private DateTime nol;
    private DateTime nom;
    private DateTime non;
    private DateTime noo;
    private DateTime nop;
}
