package org.dfzt.entity.tdo;

import lombok.Data;

/**
 * @Date:2022/7/7-10:57
 * @User:chengchuanlin
 * @Name:IndicatorsList
 * @Message:
 */
@Data
public class IndicatorsList {
    private Integer type;
    private String typeName;
    private Integer value;
}
