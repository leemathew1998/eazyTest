package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.RecycleWorkOrder;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@Mapper
public interface ARcvblFlowMapper extends BaseMapper<ARcvblFlow> {
    //15分钟获取上个月的欠费信息 生成工单
    //List<ARcvblFlow> selectArcByYM(String startMon);

    @DS("sele")
    List<ARcvblFlow> selectARcvbl(String rcvblym,List<String> lists);

    @DS("sele")
    List<ARcvblFlow> selectARcvbl1(String rcvblym,String orgNo);

    List<String> selectCycleMobile1(String ym);

    @DS("sele")
    List<BigDecimal> selectrcType4(String ym,String consNo);//查询价差收益

    @DS("sele")
    List<BigDecimal> selectrcType5(String ym,String consNo);//查询偏差考核


    @DS("sele")
    List<ARcvblFlow> selectARcvblType04(String rcvblym);
    @DS("sele")
    List<ARcvblFlow> selectARcvblType05(String rcvblym);

    Integer UpdateType04(BigDecimal deviationAssess,String consNo);
    Integer UpdateType05(BigDecimal differenceEarnings,String consNo);

    Integer UpdateStatus(BigDecimal rcvblAmtId);//从营销中获取，如果没有则将工单改为已归档

    List<BigDecimal> selectWorkOrder(String rcvblYm);//从工单中获取所有回收编号


    @DS("sele")
    String selectArfcon(BigDecimal rcvblAmtId,String rcvblYm);//通过用户编号和电费年月查询该用户欠费状态

    @DS("sele")
    ARcvblFlow selectRecycleupdate(BigDecimal rcvblAmtId);//查询并修改部分结清工单

    Integer updateRecWorkOrder(BigDecimal oweAmt,BigDecimal rcvblPenalty,BigDecimal rcvblAmtId);

    Integer insertARcvbl(ARcvblFlow aRcvblFlow);

    Integer selectRcvblId(BigDecimal rcvblId);

    @DS("mpg")
    CCons selectConsName(String consNo);//根据用户编号查询用户名称和用户地址

    @DS("mpg")
    List<String> selectMobiAddr(String consNo);//根据用户编号查询用户地址和电话

    @DS("mpg")
    List<RecycleMobile> selectMobiAddrs(List<String> consNos);//根据用户编号查询用户地址和电话

    Integer updateMobile(String mobile,String consNo,String tgNo,String tgName,String manager,String consName,String elecAddr,String rcvblYm);

//    @DS("mpg")
//    String selectAddr(String consNo);//根据用户编号查询用户地址

    @DS("mpg")
    List<GTg> selectTgNoName(String consNo);//根据consNo在c_mp表查询台区标识并查询台区编号和台区名称

    //@DS("mpg")
    //List<GTg> selectTgNoNames(List<String> consNos);//根据consNo在c_mp表查询台区标识并查询台区编号和台区名称


    @DS("mpg")
    List<String> selectElecTypeCode(String consNo);//根据用户编号在c_cons表中查询ElecTypeCode用电类别


}