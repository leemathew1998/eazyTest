package org.dfzt.entity.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.apache.poi.ss.formula.functions.Na;
import org.dfzt.eunm.*;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "RunWorkOrder对象", description = "")
public class RunWorkOrderPo extends Model<RunWorkOrderPo> {


    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "用户编号")
    @TableField("cons_no")
    @Excel(name = "用户编号",orderNum = "0",width = 20)
    private String consNo;

    @ApiModelProperty(value = "一般是用户的直接供电管理单位，也可以是大客户管理中心等由于管理原因产生的客户管理单位")
    @TableField("org_name")
    @Excel(name ="供电单位",orderNum = "9",width = 20)
    private String orgName;

    @ApiModelProperty(value = "用户的名称，一般等于客户实体中的客户名称，但也允许附加上一些非自然的信息。如 XXX（东城），便于通过用户名称直接识别。")
    @TableField("cons_name")
    @Excel(name = "用户名称",orderNum = "1",width = 20)
    private String consName;

    @ApiModelProperty(value = "抄表状态，已抄、未抄")
    @TableField("mr_status_code")
    private MeterReadingEnum mrStatusCode;

    @ApiModelProperty(value = "电费年月，此处用于描述抄表年月")
    @TableField("amt_ym")
    private String amtYm;

    @ApiModelProperty(value = "发电客户的并网电压等级代码，多个并网点时取并网点电压等级最高的并网电压等级代码 引用《国家电网公司信息分类与代码体系－综合代码类集－电压等级代码表》")
    @TableField("volt_code")
    @Excel(name = "电压等级",orderNum = "6")
    private String voltCode;

    @ApiModelProperty(value = "工单状态 1是待处理，2是处理中，3是待归档，4是已归档")
    @TableField("work_order_status")
    @Excel(name = "工单状态",orderNum = "8",replace = "待处理_'WORK_ORDER_ENUM_ONE',处理中_'WORK_ORDER_ENUM_TWO',待归档_'WORK_ORDER_ENUM_THREE',已归档_'WORK_ORDER_ENUM_FOUR'")
    private String workOrderStatus;

    @ApiModelProperty(value = "联系人的移动电话，可存储多个电话")
    private String mobile;

    @ApiModelProperty(value = "台区名称")
    @TableField("tg_name")
    private String tgName;

    @ApiModelProperty(value = "台区编号")
    @TableField("tg_no")
    private String tgNo;

    @ApiModelProperty(value = "工单编号")
    @TableField("app_no")
    @Excel(name = "工单编号",orderNum = "5",width = 20)
    private String appNo;

    @ApiModelProperty(value = "0101市场化直购用户、0102市场化零售客户、0103部分市场化零售客户、0201非市场化客户、0202放弃选择权的客户，空值认为是非市场化用户。 ")
    @TableField("market_type")
    private MarketTypeEnum marketType;

    @ApiModelProperty(value = "异常抄表类别：计量异常、门闭、违约用电、窃电、翻转、倒转 、倒转且翻转。")
    @TableField("excp_type_code")
    private int excpTypeCode;

    @ApiModelProperty(value = "用电类别")
    @TableField("elec_type_code")
    @Excel(name = "用电类别",orderNum = "7")
    private String elecTypeCode;

    @ApiModelProperty(value = "电能表资产编号")
    @TableField("meter_asset_no")
    private String meterAssetNo;

    @ApiModelProperty(value = "GPS经度 ")
    @TableField("gps_longitude")
    private String gpsLongitude;

    @ApiModelProperty(value = "GPS纬度 ")
    @TableField(exist = false)
    private String gpsLatitud;

    @ApiModelProperty(value = "归档方式")
    @TableField("arc_mode")
    private FilingModeEnum arcMode;

    @ApiModelProperty(value = "工单生成时间")
    @TableField("meter_generation_time")
    private String meterGenerationTime;

    @ApiModelProperty(value = "归档人员")
    @TableField("arc_emp_name")
    @Excel(name = "归档人员",orderNum = "4",width = 10)
    private String arcEmpName;

    @ApiModelProperty(value = "归档时间")
    @TableField("arc_date")
    private Date arcDate;

    @ApiModelProperty(value = "工单待处理时间")
    @TableField("meter_pending_time")
    private Date meterPendingTime;

    @ApiModelProperty(value = "工单处理中时间")
    @TableField("meter_processing_time")
    private Date meterProcessingTime;

    @ApiModelProperty(value = "工单待归档时间")
    @TableField("meter_to_be_time")
    private Date meterToBeTime;

    @ApiModelProperty(value = "用户地址")
    @TableField("elec_addr")
    @Excel(name = "用户地址",orderNum = "3",width = 25)
    private String elecAddr;

    @ApiModelProperty(value = "工单周期")
    @TableField("meter_cycle")
    private String meterCycle;

    //工单预警(0为不预警，1为预警)
    @TableField(exist = false)
    private String warningStatus;

    //图片
    @TableField(exist = false)
    private String photo;

    public void setWorkOrderStatus(String workOrderStatus){
        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
    }

    //下面三个图片整和在同一行
    @TableField(exist = false)
    @Excel(name = "图片1",orderNum = "10",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoOne;

    @TableField(exist = false)
    @Excel(name = "图片2",orderNum = "11",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoTwo;

    @TableField(exist = false)
    @Excel(name = "图片3",orderNum = "12",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoThree;

}
