package org.dfzt.entity.vo;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * (SuperiorFrequentoutages)表实体类
 *
 * @author makejava
 * @since 2022-07-19 17:04:33
 */
@SuppressWarnings("serial")
@TableName("superior_frequentoutages")
@Data
public class SuperiorFrequentoutages extends Model<SuperiorFrequentoutages> {
    //用户编号
    private String userId;
    //用户名称
    private String userName;
    //用户电话
    private String userPhone;
    //用户地址
    private String userLocation;
    //台区编号
    private String platformId;
    //台区名称
    private String platformName;
    //供电单位
    private String powerUnit;
    //停电描述
    private String description;
    //停电时间
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date powerCutTime;
    //来电时间
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date incomingTelegramTime;
    //0,1
    private String appType;
}
