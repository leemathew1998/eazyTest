package com.exam.modules.entity;



import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 作答记录(AnsRecord)表实体类
 *
 * @author makejava
 * @since 2022-11-09 15:33:34
 */
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.ANS_RECORD")
@Data
public class AnsRecord implements Serializable{
    //主键id
    @TableId(value = "ID",type = IdType.ASSIGN_ID)
    private Long id;
    //题目id
    @TableField("TID")
    private Long tid;
    //考生id
    @TableField("USER_ID")
    private Long userId;
    //考生答案
    @TableField("USER_ANS")
    private String userAns;
    //考试id
    @TableField("EXAM_ID")
    private String examId;
}
