package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@ApiModel(value="a_rcvbl_flow")
@Data
@TableName(value = "a_rcvbl_flow")
public class ARcvblFlow {
    /**
     * 应收电费标识 本实体记录唯一标识，产生规则为流水号
     */
    private Integer id;

    @TableId(value = "rcvbl_amt_id", type = IdType.INPUT)
    @ApiModelProperty(value = "应收电费标识 本实体记录唯一标识，产生规则为流水号")
    private BigDecimal rcvblAmtId;

    /**
     * 应收代征电费 代征电费，包括三峡，城附，农网基金等之和
     */
    @TableField(value = "rcvbl_pl_amt")
    @ApiModelProperty(value = "应收代征电费 代征电费，包括三峡，城附，农网基金等之和")
    private BigDecimal rcvblPlAmt;

    /**
     * 违约金起算日期，用于计算违约金时使用
     */
    @TableField(value = "penalty_bgn_date")
    @ApiModelProperty(value = "违约金起算日期，用于计算违约金时使用")
    private Date penaltyBgnDate;

    /**
     * 大营销数据转出转入标志 0默认或空，非结转 1转入2转出
     */
    @TableField(value = "carryover_flag")
    @ApiModelProperty(value = "大营销数据转出转入标志 0默认或空，非结转 1转入2转出")
    private String carryoverFlag;

    /**
     * 大营销数据转出转入后是否可见 0默认或空可见 1不可见
     */
    @TableField(value = "invisible_flag")
    @ApiModelProperty(value = "大营销数据转出转入后是否可见 0默认或空可见 1不可见")
    private String invisibleFlag;

    /**
     * 应收电费报告单编号
     */
    @TableField(value = "rece_rpt_no")
    @ApiModelProperty(value = "应收电费报告单编号")
    private String receRptNo;

    /**
     * 实收违约金 本笔应收电费实际收回的违约金总额
     */
    @TableField(value = "rcved_penalty")
    @ApiModelProperty(value = "实收违约金 本笔应收电费实际收回的违约金总额")
    private BigDecimal rcvedPenalty;

    /**
     * 应收报告单类型 01终端售电 02自备电厂03内部售电
     */
    @TableField(value = "rcvbl_type")
    @ApiModelProperty(value = "应收报告单类型 01终端售电 02自备电厂03内部售电")
    private String rcvblType;

    /**
     * 缴费方式  01电力机构，0101坐收0102走收0103自助缴费终端02金融机构0201代收0202特约委托0203代扣0204自助缴费
     */
    @TableField(value = "pay_mode")
    @ApiModelProperty(value = "缴费方式  01电力机构，0101坐收0102走收0103自助缴费终端02金融机构0201代收0202特约委托0203代扣0204自助缴费")
    private String payMode;

    /**
     * 用户编号，用于描述属性归属，选自用电客户用户编号
     */
    @TableField(value = "cons_no")
    @ApiModelProperty(value = "用户编号，用于描述属性归属，选自用电客户用户编号")
    private String consNo;

    /**
     * 电压等级
     */
    @TableField(value = "volt_code")
    @ApiModelProperty(value = "电压等级")
    private String voltCode;

    /**
     * 到账价内电费金额
     */
    @TableField(value = "dispose_inprice")
    @ApiModelProperty(value = "到账价内电费金额")
    private BigDecimal disposeInprice;

    /**
     * 零售交易电量
     */
    @TableField(value = "rtl_exchg_pq")
    @ApiModelProperty(value = "零售交易电量")
    private BigDecimal rtlExchgPq;

    /**
     * 表示实体属性总电量
     */
    @TableField(value = "t_pq")
    @ApiModelProperty(value = "表示实体属性总电量")
    private BigDecimal tPq;

    /**
     * 零售交易实收电费
     */
    @TableField(value = "rtl_exchg_rcved_amt")
    @ApiModelProperty(value = "零售交易实收电费")
    private BigDecimal rtlExchgRcvedAmt;

    /**
     * 售电公司标识 售电侧放开后，有售电许可，能够参与市场化售电竞争的公司
     */
    @TableField(value = "sec_id")
    @ApiModelProperty(value = "售电公司标识 售电侧放开后，有售电许可，能够参与市场化售电竞争的公司")
    private BigDecimal secId;

    /**
     * 零售交易应收电费
     */
    @TableField(value = "rtl_exchg_rcvbl_amt")
    @ApiModelProperty(value = "零售交易应收电费")
    private BigDecimal rtlExchgRcvblAmt;

    /**
     * 实收价内电费，包括目录电度，电费，基本电费功率因素调整电费之和
     */
    @TableField(value = "rcved_in_price_amt")
    @ApiModelProperty(value = "实收价内电费，包括目录电度，电费，基本电费功率因素调整电费之和")
    private BigDecimal rcvedInPriceAmt;

    /**
     * 应收金额 表示实体属性应收金额，如用电费，违约等业务产生的用电客户
     */
    @TableField(value = "rcvbl_amt")
    @ApiModelProperty(value = "应收金额 表示实体属性应收金额，如用电费，违约等业务产生的用电客户")
    private BigDecimal rcvblAmt;

    /**
     * 电费计算标识，来源于电费计算过程
     */
    @TableField(value = "calc_id")
    @ApiModelProperty(value = "电费计算标识，来源于电费计算过程")
    private BigDecimal calcId;

    /**
     * 记账编号  触发会计事务制作会计分录时，用于获取费用金额
     */
    @TableField(value = "acct_no")
    @ApiModelProperty(value = "记账编号  触发会计事务制作会计分录时，用于获取费用金额")
    private String acctNo;

    /**
     * 零售交易到账电费
     */
    @TableField(value = "dispose_rtl_exchg_amt")
    @ApiModelProperty(value = "零售交易到账电费")
    private BigDecimal disposeRtlExchgAmt;

    /**
     * 实收代征电费 包括三峡，城附，农网基金等之和
     */
    @TableField(value = "rcved_pl_amt")
    @ApiModelProperty(value = "实收代征电费 包括三峡，城附，农网基金等之和")
    private BigDecimal rcvedPlAmt;

    /**
     * 内部储蓄交易记录是否已经打印 是否打印0否1是
     */
    @TableField(value = "card_printed")
    @ApiModelProperty(value = "内部储蓄交易记录是否已经打印 是否打印0否1是")
    private String cardPrinted;

    /**
     * 应收年月 表示电费、业务费等应收发生费用年月
     */
    @TableField(value = "rcvbl_ym")
    @ApiModelProperty(value = "应收年月 表示电费、业务费等应收发生费用年月")
    private String rcvblYm;

    /**
     * 发行时间
     */
    @TableField(value = "render_date")
    @ApiModelProperty(value = "发行时间")
    private Date renderDate;

    /**
     * 本月分词电费是否从结算电费中冲减 0否或者空 1是
     */
    @TableField(value = "frac_flag")
    @ApiModelProperty(value = "本月分词电费是否从结算电费中冲减 0否或者空 1是")
    private String fracFlag;

    /**
     * 电价电费标识
     */
    @TableField(value = "prc_amy_id")
    @ApiModelProperty(value = "电价电费标识 ")
    private BigDecimal prcAmyId;

    /**
     * 风险级别  默认为低风险，风险基本的定义引用客户关系业务类的关于客户电费回收风险的定义
     */
    @TableField(value = "risk_level_code")
    @ApiModelProperty(value = "风险级别  默认为低风险，风险基本的定义引用客户关系业务类的关于客户电费回收风险的定义")
    private String riskLevelCode;

    /**
     * 欠费余额 用户电费发行时用户的欠费余额
     */
    @TableField(value = "owe_amt")
    @ApiModelProperty(value = "欠费余额 用户电费发行时用户的欠费余额")
    private BigDecimal oweAmt;

    /**
     * 供电单位编号 用电客户所属的供电所，用于描述属性归属
     */
    @TableField(value = "org_no")
    @ApiModelProperty(value = "供电单位编号 用电客户所属的供电所，用于描述属性归属")
    private String orgNo;

    /**
     * 电费结清的标志，欠费，部分结清，全部结清，坏账核销
     */
    @TableField(value = "settle_flag")
    @ApiModelProperty(value = "电费结清的标志，欠费，部分结清，全部结清，坏账核销")
    private String settleFlag;

    /**
     * 用户电价标识
     */
    @TableField(value = "tariff_id")
    @ApiModelProperty(value = "用户电价标识")
    private String tariffId;

    /**
     * 应收违约金 根据欠费金额及收费日期计算出的违约金总额
     */
    @TableField(value = "rcvbl_penalty")
    @ApiModelProperty(value = "应收违约金 根据欠费金额及收费日期计算出的违约金总额")
    private BigDecimal rcvblPenalty;

    /**
     * 到账代征金额
     */
    @TableField(value = "dispose_pl")
    @ApiModelProperty(value = "到账代征金额")
    private BigDecimal disposePl;

    /**
     * 应收价内电费 价内电费，包括目录电度电费，基本电费，功能因素调整电费之和
     */
    @TableField(value = "rcvbl_inprice_amt")
    @ApiModelProperty(value = "应收价内电费 价内电费，包括目录电度电费，基本电费，功能因素调整电费之和")
    private BigDecimal rcvblInpriceAmt;

    /**
     * 发行日期  描述电费发行日期
     */
    @TableField(value = "release_date")
    @ApiModelProperty(value = "发行日期  描述电费发行日期")
    private String releaseDate;

    /**
     * 申请编号
     */
    @TableField(value = "app_no")
    @ApiModelProperty(value = "申请编号")
    private String appNo;

    /**
     * 到账违约金
     */
    @TableField(value = "dispose_penalty")
    @ApiModelProperty(value = "到账违约金")
    private BigDecimal disposePenalty;

    /**
     * 到账金额
     */
    @TableField(value = "dispose_amt")
    @ApiModelProperty(value = "到账金额")
    private BigDecimal disposeAmt;

    /**
     * 实收金额 表示实体属性实收金额，如用电费，违约等业务尝尝的用电客户的费用，由实收记录累加而来
     */
    @TableField(value = "rcved_amt")
    @ApiModelProperty(value = "实收金额 表示实体属性实收金额，如用电费，违约等业务尝尝的用电客户的费用，由实收记录累加而来")
    private BigDecimal rcvedAmt;

    /**
     * 费用类型 区分电费组成01非市场化电费0101目录电费02市场化电费0201输配电费0202交易电费
     */
    @TableField(value = "amt_sort_code")
    @ApiModelProperty(value = "费用类型 区分电费组成01非市场化电费0101目录电费02市场化电费0201输配电费0202交易电费")
    private String amtSortCode;

    /**
     * 电费类型  按生产应收的来源分类，包括正常电费，退补电费，分次划拨等
     */
    @TableField(value = "amt_type")
    @ApiModelProperty(value = "电费类型  按生产应收的来源分类，包括正常电费，退补电费，分次划拨等")
    private String amtType;

    /**
     * 费用状态  费用收取过程的状态，包括非锁定，锁定（代扣在途、锁定（违收在途、锁定（托收在途
     */
    @TableField(value = "status_code")
    @ApiModelProperty(value = "费用状态  费用收取过程的状态，包括非锁定，锁定（代扣在途、锁定（违收在途、锁定（托收在途")
    private String statusCode;

    /**
     * 用电类别
     */
    @TableField(value = "elec_type_code")
    @ApiModelProperty(value = "用电类别")
    private String elecTypeCode;

    /**
     * 容器所属的计量点唯一标识号
     */
    @TableField(value = "mp_id")
    @ApiModelProperty(value = "容器所属的计量点唯一标识号")
    private String mpId;

    @TableField(exist = false)
    private String renderMan;

}



