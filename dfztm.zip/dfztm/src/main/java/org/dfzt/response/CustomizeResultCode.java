package org.dfzt.response;

/**
 * @Author dyy
 * @Date 2022/7/11 14:48
 * @PackageName:org.dfzt.response
 * @ClassName: CustomizeResultCode
 * @Description: TODO 获取状态码和信息
 * @Version 1.0
 */
public interface CustomizeResultCode {
    /**
     * 获取状态码
     * @return 状态码
     */
    Integer getCode();

    /**
     * 获取信息
     * @return 信息
     */
    String getMessage();
}
