package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
//@NoArgsConstructor
//@AllArgsConstructor
@ApiModel(value = "GTg对象", description = "")
public class GTg implements Serializable {


    @ApiModelProperty(value = "台区标识")
    @TableId("tg_id")
    private BigDecimal tgId;

    @ApiModelProperty(value = "管理单位编号")
    @TableField("org_no")
    private String orgNo;

    @ApiModelProperty(value = "台区编码")
    @TableField("tg_no")
    private String tgNo;

    @ApiModelProperty(value = "台区名称")
    @TableField("tg_name")
    private String tgName;

    @ApiModelProperty(value = "台区容量,为可并列运行的变压器容量之和")
    @TableField("tg_cap")
    private BigDecimal tgCap;

    @ApiModelProperty(value = "安装地址")
    @TableField("inst_addr")
    private String instAddr;

    @ApiModelProperty(value = "台区新装、拆除、变更的时间")
    @TableField("chg_date")
    private Date chgDate;

    @ApiModelProperty(value = "台区是0.公变或者1.专变")
    @TableField("pub_priv_flag")
    private String pubPrivFlag;

    @ApiModelProperty(value = "台区运行状态")
    @TableField("run_status_code")
    private String runStatusCode;


}
