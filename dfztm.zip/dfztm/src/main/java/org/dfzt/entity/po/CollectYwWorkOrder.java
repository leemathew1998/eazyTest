package org.dfzt.entity.po;

import lombok.Data;
import org.dfzt.eunm.WorkOrderStatusEnum;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
//@AllArgsConstructor
//@NoArgsConstructor
//采集运维工单原始数据库表
public class CollectYwWorkOrder implements Serializable {

    private Integer id;

    private Integer notConnectId;

    private Integer colInforId;

    private Integer failDetailsId;

    private String workOrderNo;

    private String areaManagerDesk;

    private String platformId;

    private String platformName;

    private String powerSupplyUnit;

    private String userName;

    private String userCode;

    private String userAdd;

    private BigDecimal userGpsLongitude;

    private BigDecimal userGpsLatitude;

    private String userPhone;

    private String elecmeterAssetNum;

    private String elecmeterCode;

    private String elecmeterFactory;

    private String eventType;

    private String eventReason;

    private String workOrderStatus;

    private String workOrderCreator;

    private Date workOrderCtime;

    private String workOrderUtime;

    private Date workOrderStime;

    private Date workOrderFtime;

    private String handler;

    private Date handlerRtime;

    private String hworkOrderHandler;

    private Date hworkOrderHandlerRtime;

    private Date hworkOrderHandlerTtime;

    private String workOrderCycle;
}
