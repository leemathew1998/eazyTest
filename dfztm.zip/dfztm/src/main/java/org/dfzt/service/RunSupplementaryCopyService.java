package org.dfzt.service;


import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.vo.RunSupplementaryCopy;

import java.io.FileNotFoundException;
import java.text.ParseException;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
public interface RunSupplementaryCopyService extends IService<RunSupplementaryCopy> {
    /**
     *
     */
//   void QueryAll();
    /**
     * 定时任务
     */
    void  Scheduled() throws ParseException;

    void QueryAll1() throws FileNotFoundException;

    void run() throws ParseException;
}
