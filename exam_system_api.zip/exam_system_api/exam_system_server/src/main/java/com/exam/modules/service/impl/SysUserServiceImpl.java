package com.exam.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.exam.modules.entity.SysUser;
import com.exam.modules.entity.vo.UserQueryVo;
import com.exam.modules.mapper.SysMenuMapper;
import com.exam.modules.mapper.SysRoleMapper;
import com.exam.modules.mapper.SysUserMapper;
import com.exam.modules.mapper.SysUserRoleMapper;
import com.exam.modules.service.ISysUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.exam.modules.utils.Result;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.PostMapping;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Service
@Transactional
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements ISysUserService {
    @Resource
    private SysUserMapper sysUserMapper;
    @Resource
    private ISysUserService sysUserService;
    @Resource
    private SysMenuMapper sysMenuMapper;
    @Resource
    private SysUserRoleMapper sysUserRoleMapper;
    @Resource
    private SysRoleMapper sysRoleMapper;



    /**
     * 根据用户名查询用户信息
     * @param userName
     * @return
     */
    @Override
    public SysUser findUserByUserName(String userName) {
        //创建构造器对象
        QueryWrapper<SysUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("USERNAME",userName);
        return baseMapper.selectOne(queryWrapper);
    }

    /**
     * 分页查询用户信息
     *
     * @param page
     * @param userQueryVo
     * @return
     */
    @Override
    public IPage<SysUser>   findUserListByPage(IPage<SysUser> page, UserQueryVo userQueryVo) {
        //创建条件构造器对象
        QueryWrapper<SysUser> queryWrapper = new QueryWrapper<SysUser>();
        //组别
        queryWrapper.eq(!ObjectUtils.isEmpty(userQueryVo.getTheGroup()),
                "THE_GROUP",userQueryVo.getTheGroup());
        //用户名
        queryWrapper.like(!ObjectUtils.isEmpty(userQueryVo.getUsername()),
                "USERNAME",userQueryVo.getUsername());
        //电话
        queryWrapper.like(!ObjectUtils.isEmpty(userQueryVo.getPhone()),
                "PHONE",userQueryVo.getPhone());
        //排序
        queryWrapper.orderByAsc("USER_ID");
        //查询并返回数据
        return baseMapper.selectPage(page,queryWrapper);
    }

    /**
     * 删除用户信息
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = RuntimeException.class)
    public boolean deleteById(Long id) {
        //删除用户角色关系
        baseMapper.deleteUserRole(id);
        //删除用户
        return baseMapper.deleteById(id) > 0;
    }

    @Override
    @Transactional(rollbackFor = RuntimeException.class)
    public boolean saveUserRole(Long userId, List<Long> roleIds) {
        //删除该用户对应的角色信息
        baseMapper.deleteUserRole(userId);
        //保存用户角色信息
        return baseMapper.saveUserRole(userId,roleIds)>0;
    }
}
