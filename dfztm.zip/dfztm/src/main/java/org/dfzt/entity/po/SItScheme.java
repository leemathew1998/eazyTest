package org.dfzt.entity.po;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;

/**
 * (SItScheme)表实体类
 *
 * @author makejava
 * @since 2022-08-01 10:11:27
 */
@SuppressWarnings("serial")
@TableName("s_it_scheme")
@Data
public class SItScheme extends Model<SItScheme> {
    //资产编号
    private String id;
    //类别
    private String sortCode;
    //额定电流变比
    private String ctRatio;
    //在用电流变比
    private String currentRatioCode;
    //可变变比
    private String changeRatio;
    //TA准确度等级
    private String taAccuracyCode;
    //制造单位
    private String manufacturer;

    //计量点编号
    private String mpNo;
}
