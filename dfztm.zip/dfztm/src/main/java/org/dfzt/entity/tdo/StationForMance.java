package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 */
@Data
public class StationForMance {
    //供电所当日总积分
    private int powerStationTodayTotalIntegrate;
    //旗县公司当日排名
    private int qiCountyCompanyTodayRanking;
    //市公司当日排名
    private int cityCompanyTodayRanking;
    //指标列表
    private List<Indicators> indicators;
}
