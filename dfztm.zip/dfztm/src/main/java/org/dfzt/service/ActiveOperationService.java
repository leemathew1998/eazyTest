package org.dfzt.service;



import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.vo.ActiveOperation;
import org.dfzt.entity.vo.DefectInfor;
import org.dfzt.entity.vo.DefectRepair;
import org.dfzt.entity.vo.OverhaulInfor;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
public interface ActiveOperationService extends IService<ActiveOperation> {
    List<ActiveOperation> selectAll();//查看主动运维工单列表

    /**
     * 主动运维查询,模糊查询和查询所有
     * @param
     * @return
     */

    List<ActiveOperation> selectList1(ActiveOperation a,String username);//主动运维工单条件模糊查询
    List<ActiveOperation> selectList2(String one,String username);//主动运维工单单条件模糊查询

    DefectInfor selectload(String workOrderNo);//根据工单编号回显录入数据
    DefectRepair selectdload(String workOrderNo);//根据工单编号回显立行立改数据
    OverhaulInfor selectoload(String workOrderNo);//根据工单编号回显检修数据

    Integer upStatus2(String workOrderNo);//改变工单状态为处理中
    Integer upStatus3(String workOrderNo);//改变工单状态为待归档
    Integer upStatus4(String workOrderNo);//改变工单状态为已归档
    Integer upStatus5(String workOrderNo);//改变工单状态为误报工单
    Integer upStatus6(String workOrderNo);//改变工单状态为抢修工单   传给主动抢修

    /**
     * 用于导出
     * 根据id查询工单
     */
    org.dfzt.entity.po.ActiveOperation selectByActiveOperationNo(String workOrderNo);

    List<ActiveOperation> selectAllYWOapp();//查询主动运维中包含敏感用户的工单


}
