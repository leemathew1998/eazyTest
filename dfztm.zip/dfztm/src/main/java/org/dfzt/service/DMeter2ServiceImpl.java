package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.DMeter2;
import org.dfzt.mapper.DMeter2Mapper;
import org.springframework.stereotype.Service;

/**
 * (DMeter2)表服务实现类
 *
 * @author makejava
 * @since 2022-08-01 10:10:42
 */
@Service("dMeter2Service")
public class DMeter2ServiceImpl extends ServiceImpl<DMeter2Mapper, DMeter2> implements DMeter2Service {

}

