package org.dfzt.filter;

import com.sgcc.isc.ualogin.client.IscServiceTicketValidator;
import com.sgcc.isc.ualogin.client.util.IscSSOResourceUtil;
import com.sgcc.isc.ualogin.client.vo.IscSSOUserBean;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/9/26
 * @Version: 1.00
 */

@Slf4j
//@Component
//@WebFilter(urlPatterns = {"/*"},filterName = "SsoFilter")
public class SsoFilter implements Filter {

    private static final Set<String> ALLOWED_PATHS = Collections.unmodifiableSet(new HashSet<>(
            Arrays.asList("/SysUser/login","/coll/wtest","/coll/testmpg","/runWorkOrder/testpg","/superiorWorkOrder/test95598","/coll/pingtest")));

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("~~~过滤器初始化~~~");
    }

    @SneakyThrows
    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) servletRequest;
        HttpServletResponse response = (HttpServletResponse) servletResponse;
        String path = request.getRequestURI().substring(request.getContextPath().length()).replaceAll("[/]+$", "");
        boolean allowedPath = ALLOWED_PATHS.contains(path);//非过滤接口判断
        System.out.println("进入到过滤器:");
        if (allowedPath) {//非过滤接口
            System.out.println("非过滤接口");
            filterChain.doFilter(servletRequest, servletResponse);
        } else {//过滤接口
            System.out.println("过滤接口");
            StringBuffer requestURL = request.getRequestURL();
            System.out.println("requestURL-->" + requestURL);
            System.out.println("ticket:" + request.getParameter("ticket"));
            String user = null;
//        String xmlResponse = null;
            String errorCode = null;
            String errorMessage = null;

            /* ticket校验器 */
            IscServiceTicketValidator sv = new IscServiceTicketValidator();
            /*统一认证服务端校验器地址*/
            sv.setCasValidateUrl("https://10.173.78.137:17001/isc_sso/serviceValidate");
            /*业务系统LoginModule访问地址  http://10.173.78.138:17001/isc_mp/framework/desktop/index.jsp*/
            sv.setService("http://25.73.1.171:80");
            /*设置Ticket*/
            sv.setServiceTicket(request.getParameter("ticket"));

            /*校验*/
            try {
                sv.validate();
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if (sv.isAuthenticationSuccesful()) {
                user = sv.getUser();
            } else {
                errorCode = sv.getErrorCode();
                errorMessage = sv.getErrorMessage();
                /* handle the error */
                System.out.println("errorInfo -----------> " + errorCode + "\r\n" + errorMessage);
            }
            System.out.println("userinfo >>>>>>>>>>>> " + user);
            IscSSOUserBean iscSSOUserBean;
            try {
                /*获取当前用户登录信息*/
                iscSSOUserBean = IscSSOResourceUtil.transferIscUserBean(user);
                /*当前登录用户ID*/
                String userid = iscSSOUserBean.getIscUserId();
                System.out.println("userid" + userid);
                /*当前登录用户账号*/
                String loginName = iscSSOUserBean.getIscUserSourceId();
                System.out.println("loginName" + loginName);
            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            //执行过滤器之后，放开通行，访问后续接口
            filterChain.doFilter(servletRequest, servletResponse);

        }
    }

    @Override
    public void destroy() {
        log.info("~~~过滤器销毁~~~");
    }
}
