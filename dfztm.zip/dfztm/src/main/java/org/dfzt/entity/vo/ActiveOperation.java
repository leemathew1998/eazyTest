package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.dfzt.eunm.WorkOrderStatusEnum;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "ActiveOperation对象", description = "")
public class ActiveOperation implements Serializable {

    @ApiModelProperty(value = "主动运维id(主动运维工单表)")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "工单编号")
    @TableField("work_order_no")
    private String workOrderNo;


    @ApiModelProperty(value = "工单日期")
    @TableField("work_order_date")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date workOrderDate;

    @ApiModelProperty(value = "工单状态")
    @TableField("work_order_status")
    private String workOrderStatus;
    //ActiveOperationEunm

    private String orgName;
    @ApiModelProperty(value = "用户名称")
    @TableField("user_name")
    private String userName;

    @ApiModelProperty(value = "台区经理")
    @TableField("tg_manager")
    private String tgManager;

    @ApiModelProperty(value = "台区编号")
    @TableField("tg_no")
    private String tgNo;

    @ApiModelProperty(value = "台区名称")
    @TableField("tg_name")
    private String tgName;

    @ApiModelProperty(value = "异常分类")
    @TableField("excp_type")
    private String excpType;

    @ApiModelProperty(value = "异常地点")
    @TableField("excp_add")
    private String excpAdd;

    @ApiModelProperty(value = "异常时间")
    @TableField("excp_date")
    private String excpDate;

    @ApiModelProperty(value = "研判分析结果")
    @TableField("analysis_result")
    private String analysisResult;

    @ApiModelProperty(value = "工单流转时间")
    @TableField("wander_time")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date wanderTime;

    @ApiModelProperty(value = "误报工单表述")
    private String reserve1;

    @ApiModelProperty(value = "工单周期")
    private String workOrderCycle;

    @ApiModelProperty(value = "备用字段3")
    private String reserve3;

    @ApiModelProperty(value = "备用字段4")
    private Integer reserve4;

    //是否有敏感工单用户
    private String appType;
    //工单处理时间
    private Integer handleTime;





//    private List<RepairsWorkOrder> repairsWorkOrder;
   // private RepairsWorkOrder repairsWorkOrder;

    //工单状态 枚举
    public void setWorkOrderStatus(String workOrderStatus) {
        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
    }


}
