package org.dfzt.service;


import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.vo.RunWorderDeal;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
public interface RunWorderDealService extends IService<RunWorderDeal> {

    /**
     * 查询单个工单处理数据情况
     * @param gdNo
     * @return
     */
    R queryAll(String gdNo);

    /**
     * 通过工单编号查询用户历史处理数据情况
     * @param gdNo
     * @return
     */
    R queryRunDeals(String gdNo);

}
