package org.dfzt.controller;


import com.baomidou.mybatisplus.extension.api.R;
import io.swagger.annotations.Api;

import org.dfzt.service.CInformationService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */
@Api(tags = "")
@RestController
@RequestMapping("/cInformation")
public class CInformationController {

    @Resource
    CInformationService cInformationService;

        @PostMapping(value = "/QueryAll")
    public R QueryAll(String powerPointNo){
        return cInformationService.QueryAll(powerPointNo);
    }
}

