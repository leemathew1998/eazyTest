package org.dfzt.config;

import org.dfzt.entity.po.CaccheCons;
import org.dfzt.entity.po.consTgScm;
import org.dfzt.entity.vo.PropListVo;
import org.dfzt.mapper.CachesMapper;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
@Component
public class CacheInitConfig implements CommandLineRunner {
    @Resource
    CachesMapper cachesMapper;

    @Override
    public void run(String... args) throws Exception {
        //获取呼市全域单位信息
         List<consTgScm> orgList = cachesMapper.getOrgList();
        BaseCache.put(CacheConstant.SYS_ORG_CACHE,orgList);

        //获取电流、电压码值 fro_cms_epsa_md.sa_prop_list
        List<PropListVo>propList = cachesMapper.getPropList();
        BaseCache.put(CacheConstant.SYS_PROP_CACHE,propList);

//        //获取全域用户，执行此代码内存会溢出
//        List<CaccheCons> consList = cachesMapper.getConsList();
//        BaseCache.put(CacheConstant.SYS_CONS_CACHE,consList);
    }
}
