package org.dfzt.entity.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/8/25
 * @Version: 1.00
 */
//主动运维和主动抢修工单的绩效显示
@Data
public class ActiveRepairWo implements Serializable {

    private Integer id;//id
    private String workOrderNo;//工单编号
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date workOrderDate;//工单日期
    private String workOrderStatus;//工单状态
    private String userName;//用户名称
    private String tgManager;//台区经理
    private String tgNo;//台区编号
    private String tgName;//台区名称
    private String excpType;//异常分类
    private String excpAdd;//异常地点
    private String excpDate;//异常时间
    private String analysisResult;//研判分析结果
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date wanderTime;//工单流转时间
    private String reserve1;//误报工单表述
    private String workOrderCycle;//工单周期
    private String reserve3;//备用字段3
    private Integer reserve4;//备用字段4
    private String appType;//是否有敏感工单用户
    private Integer handleTime;//工单处理时间

    private String failureEquipment;//故障设备
    private String voltCode;//电压
    private String ratedCurrent;//电流
    private String tgTemperature;//本体温度
    private String failureArea;//故障区域
    private String errorStetus;//异常开关状态
    private String repairsType;//抢修类型
    private String faultDescribe;//故障描述
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date disposeTime;//处理时间
    private String disposeResult;//处理结果
}
