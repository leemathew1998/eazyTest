package com.exam.modules.entity;

import com.alibaba.fastjson.annotation.JSONField;
import com.alibaba.fastjson.serializer.ToStringSerializer;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import javafx.util.converter.LongStringConverter;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 角色表
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.SYS_ROLE")
public class SysRole implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 角色表id
     */
    @TableId(value = "ROLE_ID",type = IdType.ASSIGN_ID)
    //此句为问题关键 相当于吧Long转换为String
//    @JsonFormat(shape = JsonFormat.Shape.STRING)
//    @JSONField(serializeUsing = ToStringSerializer.class)
    private Long roleId;

    /**
     * 角色名称
     */
    @TableField("ROLE_NAME")
    private String roleName;

    /**
     * 角色编码

     */
    @TableField("ROLE_CODE")
    private String roleCode;

    /**
     * 描述

     */
    @TableField("DESCRIPTION")
    private String description;

    /**
     * 创建人

     */
    @TableField("CREATE_BY")
    private String createBy;

    /**
     * 创建时间

     */
    @TableField("CREATE_TIME")
    private Date createTime;

    /**
     * 更新人

     */
    @TableField("UPDATE_BY")
    private String updateBy;

    /**
     * 更新时间

     */
    @TableField("UPDATE_TIME")
    private Date updateTime;

    /**
     * 删除

     */
    @TableField("DEL_FLAG")
    private Integer delFlag;


}
