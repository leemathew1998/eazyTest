package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.converters.MarshallingContext;
import com.thoughtworks.xstream.converters.UnmarshallingContext;
import com.thoughtworks.xstream.io.HierarchicalStreamReader;
import com.thoughtworks.xstream.io.HierarchicalStreamWriter;

/**
 * @ClassName DemoConverter
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/15 22:23
 */

/** XStream转化器 */
public class DemoConverter implements Converter {
    @Override
    public void marshal(Object source, HierarchicalStreamWriter writer, MarshallingContext marshallingContext) {
        General field = (General)source;
        //writer.startNode("field");
        writer.addAttribute("N", field.getN());/*addAttribute方法决定了节点属性值*/
        writer.setValue(field.getValue());/*属性值对应的标签值*/
        //writer.endNode();
    }

    @Override
    public Object unmarshal(HierarchicalStreamReader reader, UnmarshallingContext unmarshallingContext) {
        General general = new General();
        /*获取key为"N"的值*/
        String name = reader.getAttribute("N");
        general.setN(name);
        String value = reader.getValue();
        general.setValue(value);
        return general;
    }

    @Override
    public boolean canConvert(@SuppressWarnings("rawtypes") Class type) {
        /*如果类型一样则返回true*/
        return type == General.class;
    }
}
