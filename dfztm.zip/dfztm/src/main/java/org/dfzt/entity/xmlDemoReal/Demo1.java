package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


/**
 * @ClassName Demo1
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/15 18:32
 */
@Getter
@Setter
@XStreamAlias("DBSET")
public class Demo1 {

    @XStreamAlias("RETURN_STATUS")
    private Demo2 demo2;

    @XStreamAlias("DATA_CONTENT")
    private Demo3 demo3;

    @Override
    public String toString() {
        return "Demo1{" +
                "demo2=" + demo2 +
                ", demo3=" + demo3 +
                '}';
    }
}
