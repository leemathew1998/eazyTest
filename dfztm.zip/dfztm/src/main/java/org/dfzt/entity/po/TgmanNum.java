package org.dfzt.entity.po;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/3/30
 * @Version: 1.00
 */
@Data
public class TgmanNum {
    private Integer id;
    private String tgManager;//台区经理
    private String tgManid;//台区经理编号
    private String userName;//台区经理登录名
    private String orgNo;//所属营业站
    private String orgName;//供电单位名称
    private Integer consNum;//管辖的用户数
    private Integer tgNum;//管辖的台区数
    private String trueId;//标识

}
