package org.dfzt.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.dfzt.entity.dto.RepairsWorkOrderDto;
import org.dfzt.entity.po.ActiveOperation;
import org.dfzt.entity.po.RepairsWorkOrder;

/**
 * (RepairsWorkOrder)表数据库访问层
 *
 * @author makejava
 * @since 2022-07-28 09:29:25
 */
public interface RepairsWorkOrderMapper extends BaseMapper<RepairsWorkOrder> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<RepairsWorkOrder> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<RepairsWorkOrder> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<RepairsWorkOrder> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<RepairsWorkOrder> entities);

    /**
     * 状态扭转
     * @param repairsWorkOrder
     * @return
     */
    int updateRepairsWorkOrder(RepairsWorkOrder repairsWorkOrder);


    int updateRepinfo(RepairsWorkOrderDto repairsWorkOrder);

    @Select("SELECT work_order_no,work_order_date,tg_manager,tg_no,tg_name\n" +
            "FROM active_operation\n" +
            "WHERE work_order_status = 6")
    List<ActiveOperation> selectWorkOrderStatusInfo();

    @Select("SELECT count(1) FROM repairs_work_order WHERE work_order_no = #{workOrderNo}")
    int selectWorkOrderNo(String workOrderNo);

    List<RepairsWorkOrder> selectAllYWOapp();//查询主动抢修中包含敏感用户的工单

    RepairsWorkOrder selectAllYwByids(String id);//批量导出工单

    RepairsWorkOrder selectByOrderNo(@Param("workOrderNo") String workOrderNo,@Param("workOrderStatus") String workOrderStatus);

    RepairsWorkOrder selectByNO(@Param("workOrderNo") String workOrderNo);

    Integer insertRepairs(RepairsWorkOrder repairsWorkOrder);

    Integer selectRepairs(String workNo);

    List<RepairsWorkOrder> selectCycleOneList();
    List<RepairsWorkOrder> selectCycleTwoList();


    Integer updateCycle(String workNo, String cycle);
}

