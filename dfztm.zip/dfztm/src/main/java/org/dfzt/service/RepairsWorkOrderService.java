package org.dfzt.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
//import jdk.nashorn.internal.runtime.linker.LinkerCallSite;
import org.dfzt.entity.po.RepairsWorkOrder;

import java.util.List;
import java.util.Map;

/**
 * (RepairsWorkOrder)表服务接口
 *
 * @author makejava
 * @since 2022-07-28 09:29:26
 */
public interface RepairsWorkOrderService extends IService<RepairsWorkOrder> {

    /**
     * 状态扭转
     *
     * @param repairsWorkOrder
     * @return
     */
    int updateRepairsWorkOrder(RepairsWorkOrder repairsWorkOrder);

    String selectWorkOrderStatusInfo();

    //模糊查询
    LambdaQueryWrapper queryWrapper(RepairsWorkOrder repairsWorkOrder);

    //模糊查询
    LambdaQueryWrapper per(String str);

    List<Map<String,Object>> rushToRepair(String LoginName);

    List<RepairsWorkOrder> selectAllYWOapp();//查询主动抢修中包含敏感用户的工单

    RepairsWorkOrder selectAllYwByids(String id);//批量导出工单

    /**
     * web端主动运维工单详情
     * @param workOrderNo
     * @return
     */
    Map<String,String> selectByNo(String workOrderNo);

}

