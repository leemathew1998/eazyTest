package org.dfzt.entity.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/5/30
 * @Version: 1.00
 */
@Data
public class AcCity {

    //id(旗县绩效管理表
    private Integer id;
    //市级名称
    private String cityName;
    //总积分
    private String toPoint;
    private String tgName;
    //日期日月
    private String dateDm;
    //日期
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date dataDate;
    //采集成功率
    private Double colSuccRate;
    //采集成功积分
    private Integer colSuccPoint;
    //采集失败处理及时率
    private Double colFailRate;
    //采集失败处理及时积分
    private Integer colFailPoint;
    //费控复电成功率
    private Double costconComeRate;
    //不考核 null
    private Integer costconComePoint;
    //费控停电成功率
    private Double costconStopRate;
    //不考核 null
    private Integer costconStopPoint;
    //自动发行比例
    private BigDecimal autoPublishRate;
    //自动发行比例积分
    private Integer autoPublishPoint;
    //低压线损率
    private Double lowLinelossRate;
    //低压线损率积分
    private Integer lowLinelossPoint;
    //高损台区占比率
    private Double highlossTgRate;
    //高损台区占比率积分
    private Integer highlossTgPoint;
    //负损台区占比率
    private Double lowlossTgRate;
    //负损台区占比率积分
    private Integer lowlossTgPoint;
    //经济运行台区占比
    private Double econrunTgRate;
    //不考核 null
    private Integer econrunTgPoint;
    //高负损台区处理及时率
    private Double tgHandleRate;
    //高负损台区处理及时率积分
    private Integer tgHandlePoint;
    //电费结零率
    private Double powerfeesZeroRate;
    //电费结零率积分
    private Integer powerfeesZeroPoint;
    //异常台区治理
    private Integer exceptTgNum;
    //异常台区治理积分
    private Integer exceptTgPoint;
    //现场复电处理及时率
    private Double powerbackHandleRate;
    //现场复电处理及时率积分
    private Integer powerbackHandlePoint;
    //投诉意见工单数量
    private Integer complaintWorkorderNum;
    //投诉意见工单数量积分
    private Integer complaintWorkorderPoint;
    //运维抢修到达现场及时率
    private Double repairSceneRate;
    //运维抢修到达现场及时率积分
    private Integer repairScenePoint;
    //计量异常处理及时率
    private Double meterHandleRate;
    //计量异常处理及时率积分
    private Integer meterHandlePoint;
    //排名
    private String ranking;

    private String orgNo;
}
