package org.dfzt.entity.po;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/9
 * @Version: 1.00 互感器
 */
@Data
public class DItPo {
    private Integer id;
    private String assetNo;//资产编号
    private String sortCode;//类别
    private String rcRatioCode;//额定电流变比
    private String currentRatioCode;//在用电流变比
    private String chgRatioCode;//可变变比
    private String tvPreCode;//TA准确度等级
    private String manufacturer;//制造单位

}
