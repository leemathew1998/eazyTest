package com.exam.modules.entity;


import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 角色菜单表
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.SYS_ROLE_MENU")
public class SysRoleMenu implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    @TableId(value = "ID")
    private Long ID;

    /**
     * 角色id
     */
    @TableField("ROLE_ID")
    private Long roleId;

    /**
     * 菜单id

     */
    @TableField("MENU_ID")
    private Long menuId;

    /**
     * 创建人

     */
    @TableField("CREATE_BY")
    private String createBy;

    /**
     * 创建时间

     */
    @TableField("CREATE_TIME")
    private Date createTime;

    /**
     * 更新人

     */
    @TableField("UPDATE_BY")
    private String updateBy;

    /**
     * 更新时间

     */
    @TableField("UPDATE_TIME")
    private Date updateTime;


}
