package org.dfzt.eunm;

import com.baomidou.mybatisplus.annotation.EnumValue;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * @Date:2022/7/11-9:24
 * @User:chengchuanlin
 * @Name:WorkOrderStatusEnum
 * @Message:工单状态枚举
 */
@Getter
public enum WorkOrderStatusEnum {

    STATUS_ONE("1","待处理"),
    STATUS_TWO("2","处理中"),
    STATUS_THREE("3","待归档"),
    STATUS_FOUR("4","已归档");
    // 成员变量
    @EnumValue
    private final String name;
    private final String value;

    WorkOrderStatusEnum(String name, String value) {
        this.name = name;
        this.value = value;
    }

    // 将数据缓存到map中
    private static final Map<String, String> map = new HashMap<>();

    static {
        for (WorkOrderStatusEnum color : WorkOrderStatusEnum.values()) {
            map.put(color.getName(), color.getValue());
        }
    }



    // 根据name查询value值
    public static String getValueByName(String name) {
        return map.get(name);
    }

    /*// 根据name查询value值
    public static String getNameByValue(String value) {
        switch (value){
            case "待处理": {
                return "1";
            }
            case "处理中": {
                return "2";
            }
            case "待归档": {
                return "3";
            }
            case "已归档": {
                return "4";
            }
        }
        return "错误";
    }*/

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }

}
