package org.dfzt.util;

/**
 * @ClassName ServiceExceptionEnum
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/8/10 18:48
 */
public enum ServiceExceptionEnum implements BaseException {
    LOGIN_INVALID(600, "登陆失效，请重新登陆"),
    LOGIN_DIFFERENT(601, "该账号已在其他地方登陆。如非本人登陆，请尽快修改密码"),
    LOGIN_NO_ACCOUNT(602, "该账号未注册"),
    LOGIN_ERROR(603, "用户名、密码错误"),
    LGOIN_SMS_ERROR(604, "验证码错误"),
    LGOIN_SMS_LOSE(605, "验证码失效，请重新获取验证码"),
    TOKEN_NOEXIST(610, "token不存在"),
    TOKEN_ILLEGAL(611, "token非法"),
    ACCOUNT_UNBIND_WX(620, "微信未绑定商家账号，请登陆后绑定"),
    INFO_NOEXIST(700, "未找到相关信息，请刷新重试");

    private Integer code;
    private String message;

     ServiceExceptionEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return this.code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
