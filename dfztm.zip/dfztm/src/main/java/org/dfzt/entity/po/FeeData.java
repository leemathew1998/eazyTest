package org.dfzt.entity.po;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/19
 * @Version: 1.00
 * -低压远程费控执行返回实体类
 */
@Data
public class FeeData {
    private Integer id;
//    开关状态
    private String switchStatus;
//    工单号
    private String woNo;
//    工单执行状态
    private String woStatus;
//    数据来源
    private String dataSource;
//    上级供电单位
    private String upOrgName;
//    供电单位
    private String orgName;
//    供电所
    private String orgStation;
//    用户编号
    private String consNo;
//    用户名称
    private String consName;
    //台区编号
    private String tgNo;
//    台区名称
    private String tgName;
//    终端资产号
    private String assetNo;
//    终端地址
    private String terminalAddr;
//    抄表段号
    private String mrSectNo;
//    电能表资产号
    private String meterAssetNo;
//    营销工单编号
    private String woNo1;
//    控制类型
    private String conType;
//    执行结果
    private String imResult;
//    执行具体情况成功
    private String imSucc;
//    执行具体情况失败
    private String imFail;
//    执行具体情况异常
    private String imExce;
//    工单操作员
    private String woMaker;
//    是否反馈营销
    private String maFlag;
//    反馈营销时间
    private String maDate;
//    终端状态
    private String statusCode1;
//    操作时间
    private String makeDate;
//    失败原因
    private String failRea;
//    用电地址
    private String elecAddr;
//    通信方式
    private String collMode;
//    终端厂家
    private String factoryCode;
//    测量点
    private String mpSn;
//    波特率
    private String baudrateCode;
//    是否新型费控
    private String dataSrc;
//    工单来源
    private String woSource;

}
