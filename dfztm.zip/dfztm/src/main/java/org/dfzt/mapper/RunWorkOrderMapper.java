package org.dfzt.mapper;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.CCons;
import org.dfzt.entity.po.EAmtVerifyResult;
import org.dfzt.entity.po.MeterWorkOrder;
import org.dfzt.entity.po.RunWorkOrderPo;
import org.dfzt.entity.vo.RunWorkOrder;
import org.dfzt.entity.vo.RunWorkOutside;
import org.dfzt.entity.vo.SysUser;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Mapper
public interface RunWorkOrderMapper extends BaseMapper<RunWorkOrder> {

    int insertBatch(@Param("runGds") List<RunWorkOrder> runGds);

    int save(RunWorkOrder runGds);

    List<RunWorkOrder> queryAdd();

    int queryid(Integer id);

    int updateid(Integer dfbcGdfs, String id);

    //app端更新状态功能
    int updateStatus(Integer workOrderStatus, String id);

    int selectPeriod(String dfbcGdUserid, Integer dateTime);

    Boolean saves(RunWorkOrder runGd);

    List<RunWorkOrder> listAll();

    int queryOne(String userid);

    int updateone(String gdNo);

    int updateunusual(String gdNo);

    //根据工单编号查询电费补抄工单
    RunWorkOrderPo selectById(String appNo);

    @DS("pg")
    List<RunWorkOutside> selectRunwo();

    @DS("pg")
    List<EAmtVerifyResult> selectRunwo1(String lastYm,List<String> lists);

    @DS("pg")
    List<Object> selectRun1(String mrPlanNo);
    @DS("pg")
    List<Object> selectRun2(String ym);
    @DS("pg")
    List<Object> selectRun3(String consNo);
    @DS("pg")
    List<Object> selectRun4(String appNo);

    @DS("pg")
    List<EAmtVerifyResult> selectRunwo3(String lastYm);

    @DS("pg")
    List<RunWorkOutside> selectRunwo2();

    @DS("pg")
    List<Object> selectyyyy();


    List<RunWorkOrder> getRunWordOrderList(List<String> ids , String ym ,String code);


    List<EAmtVerifyResult> selectEAmtVer(String lastYm);


    @DS("mpg")
    CCons selectConsmarketSort(String consNo);//根据用户编号查询该用户的市场化属性分类

    Integer selectWorkByResultId(String resultId);//通过appNo查询该工单是否在工单表中已存在
    Integer selectByResultId(String resultId);//通过appNo查询该工单是否在源表中已存在
    List<String> getResultId(String ym);
    String selectByConsNo(String consNo);

    Integer updateRWOCycle(@Param("cycle") String cycle, @Param("workOrderNo") String workOrderNo);


    Integer insertEamtver(EAmtVerifyResult eAmtVerifyResult);//新增补抄源表
    Integer insertRunwork(RunWorkOrder runWorkOrder);


    List<RunWorkOrder> selectExcelList(@Param("r") RunWorkOrder r, @Param("orgName") String orgName, @Param("status") String status);
}
