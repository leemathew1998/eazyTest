package org.dfzt.entity.po;

import java.math.BigDecimal;
import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author dfzt
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="EMpReadCurve对象", description="")
public class EMpReadCurve implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "标识")
    private Integer id;

    @ApiModelProperty(value = "供电单位编号")
    private String orgNo;

    @ApiModelProperty(value = "数据日期")
    private Date dataDate;

    @ApiModelProperty(value = "CT")
    private Integer ct;

    @ApiModelProperty(value = "PT")
    private Integer pt;

    @ApiModelProperty(value = "标记")
    private Integer mark;

    @ApiModelProperty(value = "电能示值 0：备用：1：正向有功 2：正向无功 3：一象限无功 4：四象限无功 5：反向有功 6：反向无功 7：二象限无功 8：三象限无功电能量 9：正向有功 10：正向无功 11：一象限无功 12：四象限无功 13：反向有功 14：反向无功 15：二象限无功 16：三象限无功")
    private Long dataType;

    @ApiModelProperty(value = "数据点标志  1.96点，2.48点，3.24点")
    private Integer dataPointFlag;

    @ApiModelProperty(value = "数据完整性标志（用96个1或0来表示96点数据的完整性标志（左第一位表示第一点））")
    private String dataWholeFlag;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r1;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r2;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r3;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r4;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r5;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r6;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r7;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r8;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r9;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r10;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r11;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r12;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r13;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r14;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r15;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r16;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r17;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r18;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r19;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r20;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r21;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r22;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r23;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r24;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r25;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r26;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r27;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r28;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r29;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r30;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r31;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r32;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r33;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r34;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r35;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r36;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r37;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r38;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r39;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r40;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r41;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r42;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r43;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r44;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r45;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r46;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r47;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r48;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r49;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r50;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r51;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r52;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r53;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r54;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r55;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r56;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r57;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r58;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r59;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r60;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r61;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r62;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r63;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r64;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r65;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r66;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r67;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r68;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r69;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r70;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r71;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r72;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r73;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r74;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r75;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r76;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r77;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r78;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r79;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r80;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r81;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r82;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r83;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r84;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r85;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r86;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r87;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r88;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r89;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r90;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r91;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r92;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r93;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r94;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r95;

    @ApiModelProperty(value = "电能示值")
    private BigDecimal r96;

    @ApiModelProperty(value = "记录时间")
    private Date recTime;

    @ApiModelProperty(value = "电表标识")
    private String meterId;

    @ApiModelProperty(value = "数据来源")
    private String dataSrc;

    @ApiModelProperty(value = "是否有效")
    private Integer isValid;


}
