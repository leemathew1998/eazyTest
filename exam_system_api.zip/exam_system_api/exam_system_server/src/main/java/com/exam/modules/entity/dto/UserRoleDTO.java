package com.exam.modules.entity.dto;

import lombok.Data;

import java.util.List;

/**
 * @Author dyy
 * @Date 2022/11/5 15:13
 * @PackageName:com.exam.modules.entity.dto
 * @ClassName: UserRoleDTO
 * @Description: TODO 用于给用户分配角色时保存选中的角色数据
 * @Version 1.0
 */
@Data
public class UserRoleDTO {
    private Long userId;
    private List<Long> roleIds;
}
