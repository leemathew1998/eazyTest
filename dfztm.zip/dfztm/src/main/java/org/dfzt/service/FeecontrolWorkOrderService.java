package org.dfzt.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import io.minio.Result;
import io.swagger.models.auth.In;
import org.dfzt.entity.po.ARcaCtrlDet;
import org.dfzt.entity.po.SuperiorWorkOrder;
import org.dfzt.entity.po.WorkOrderInfor;
import org.dfzt.entity.po.FeecontrolWorkOrder;
import org.dfzt.entity.vo.RecycleWorkOrder;

import java.util.List;
import java.util.Map;

/**
 * (FeecontrolWorkOrder)表服务接口
 *
 * @author makejava
 * @since 2022-07-12 14:58:25
 */
public interface FeecontrolWorkOrderService extends IService<FeecontrolWorkOrder> {


    /**
     * 根据角色权限查看不同的数据
     * @param feecontrolWorkOrder
     * @param role
     * @return
     */
    LambdaQueryWrapper queryWrapper(FeecontrolWorkOrder feecontrolWorkOrder, String role);
    LambdaQueryWrapper wrapper(List<String> readNames,String str, String role,String workOrderStatus,String loName2);

    /**
     * 状态扭转
     * @param map
     * @return
     */
    int updateFeecontrolWorkOrder(Map map);

    /**
     * 根据id查询工单工单
     * @param workOrderNo
     * @return
     */
   FeecontrolWorkOrder selectFeecontrolWordOrderNo(String workOrderNo);

    /**
     * 查询历史数据(含图片)
     * @param workOrderNo
     * @return
     */
    FeecontrolWorkOrder selectWorkOrderScene(String workOrderNo);

    /**
     * 查询源表数据(费控复电)
     */
    List<FeecontrolWorkOrder> getWorkOrderData();

    /**
     * 费控复电生成工单
     */
    List<FeecontrolWorkOrder> createWorkerOrder();

    /**
     * 修改费控复电的复电方式
     * @param workOrderInfor
     * @return
     */
    Integer updateWorkOrderStatus(WorkOrderInfor workOrderInfor);


    /**
     * 提交功能
     * @param workOrderInfor
     * @return
     */
    int manualPigeonhole(WorkOrderInfor workOrderInfor);

    /**
     * 查询登录人员
     * @param loginName
     * @return
     */
    String selectRole(String loginName);//根据用户id差找所对应的权限

    /**
     * 用于导出
     * 根据id查询工单
     */
    FeecontrolWorkOrder selectByFeecontrolWordOrderNo(String workOrderNo);

    /**
     * 敏感用户工单查询
     * @return
     */
    List<SuperiorWorkOrder> selectWorkOrderList(FeecontrolWorkOrder feecontrolWorkOrder);


    void feecontrolVo();

    Integer insertFeeWorkOrder(org.dfzt.entity.po.FeecontrolWorkOrder feecontrolWorkOrder, ARcaCtrlDet aRcaCtrlDet);
}

