package org.dfzt.config;

import java.util.HashMap;
import java.util.Map;

public class BaseCache {
    private static Map<String,Object> caches = new HashMap<>();

    public static synchronized void put(String key,Object value){
        caches.put(key,value);
    }

    public static synchronized void remove(String key){
        caches.remove(key);
    }

    public static Object get(String key){
        return caches.get(key);
    }
}
