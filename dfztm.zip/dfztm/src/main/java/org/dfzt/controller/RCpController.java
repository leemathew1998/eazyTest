package org.dfzt.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.dfzt.entity.po.RCp;
import org.dfzt.service.RCpService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;

/**
 * (RCp)表控制层
 *
 * @author makejava
 * @since 2022-07-29 16:39:47
 */
@RestController
@RequestMapping("rCp")
public class RCpController extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private RCpService rCpService;

    /**
     * 分页查询所有数据
     *
     * @param page 分页对象
     * @param rCp  查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll")
    public R selectAll(Page<RCp> page, RCp rCp) {
        return success(this.rCpService.page(page, new QueryWrapper<>(rCp)));
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @PostMapping("/selectOne/{id}")
    public R selectOne(@PathVariable Serializable id) {
        return success(this.rCpService.getById(id));
    }

    /**
     * 新增数据
     *
     * @param rCp 实体对象
     * @return 新增结果
     */
    @PostMapping("insert")
    public R insert(@RequestBody RCp rCp) {
        return success(this.rCpService.save(rCp));
    }

    /**
     * 修改数据
     *
     * @param rCp 实体对象
     * @return 修改结果
     */
    @PostMapping("update")
    public R update(@RequestBody RCp rCp) {
        return success(this.rCpService.updateById(rCp));
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除结果
     */
    @PostMapping("delete")
    public R delete(Integer id) {
        return success(this.rCpService.removeById(id));
    }
}
