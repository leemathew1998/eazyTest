package com.exam.modules.service.impl;

import com.exam.modules.entity.SysMenu;
import com.exam.modules.entity.SysUser;
import com.exam.modules.entity.vo.RoleMenuVo;
import com.exam.modules.mapper.SysMenuMapper;
import com.exam.modules.mapper.SysUserMapper;
import com.exam.modules.service.ISysMenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.exam.modules.utils.MenuTree;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * <p>
 * 菜单表 服务实现类
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Service
public class SysMenuServiceImpl extends ServiceImpl<SysMenuMapper, SysMenu> implements ISysMenuService {

    @Resource
    private SysUserMapper userMapper;

    /**
     * 根据用户ID查询权限列表
     * @param userId
     * @return
     */
    @Override
    public List<SysMenu> findSysMenuListByUserId(Long userId) {
        return baseMapper.findSysMenuListByUserId(userId);
    }
    /**
     * 查询分配权限树列表
     * @param userId
     * @param roleId
     * @return
     */
    @Override
    public RoleMenuVo findMenuTree(Long userId, Long roleId) {
        //1.查询当前用户信息
        SysUser user = userMapper.selectById(userId);
        List<SysMenu> list = null;
        //2.判断当前用户角色，如果是管理员，则查询所有权限；如果不是管理员，则只查询自己所拥有的的权限
        if(!ObjectUtils.isEmpty(user.getIsAdmin()) && user.getIsAdmin().equals("1")){
            //查询所有权限
            list = baseMapper.selectList(null);
        }else{
            //根据用户ID查询
            list = baseMapper.findSysMenuListByUserId(userId);
        }
        //3.组装成树数据
        List<SysMenu> menuList = MenuTree.makeMenuTree(list, 0L);
        //4.查询要分配角色的原有权限
        List<SysMenu> roleMenu = baseMapper.findMenuListByRoleId(roleId);
        //创建集合保存权限id
        List<Long> listIds = new ArrayList<Long>();
        //5.找出该角色存在的数据
        Optional.ofNullable(list).orElse(new ArrayList<>())
                .stream()
                .filter(Objects::nonNull) //等同于 obj -> obj!=null
                .forEach(item -> {
                    Optional.ofNullable(roleMenu).orElse(new ArrayList<>())
                            .stream()
                            .filter(Objects::nonNull)
                            .forEach(obj ->{
                                //判断两者的权限id是否一致，如果一致，表示拥有该权限
                                if(item.getMenuId().equals(obj.getMenuId())){
                                    //将权限id保存到集合中
                                    listIds.add(obj.getMenuId());
                                    return;
                                }
                            });
                });
        //创建
        RoleMenuVo vo = new RoleMenuVo(menuList,listIds.toArray());
        return vo;
    }
}
