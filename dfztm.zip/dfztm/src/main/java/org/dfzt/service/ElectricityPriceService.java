package org.dfzt.service;


import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.ElectricityPrice;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */
public interface ElectricityPriceService extends IService<ElectricityPrice> {

}
