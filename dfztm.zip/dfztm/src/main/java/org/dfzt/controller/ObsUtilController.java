package org.dfzt.controller;

import cn.hutool.core.codec.Base64;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.obs.services.ObsClient;
import com.obs.services.model.*;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.util.Base64Util;
import org.springframework.util.Base64Utils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
//import sun.misc.BASE64Decoder;
//import sun.misc.BASE64Encoder;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/22
 * @Version: 1.00
 */
@Slf4j
@RestController
@CrossOrigin
@RequestMapping("/file")
public class ObsUtilController extends ApiController {

    @ResponseBody
    @PostMapping("upload")//@RequestPart MultipartFile file @RequestParam("file") MultipartFile file
    public String uploadFile() throws Exception {//@RequestParam("file") MultipartFile file
        System.out.println("=upload接口");
        log.info("=upload接口");
        //System.out.println("file为:"+file);
//        if (file.isEmpty()) {
//            System.out.printf("文件上传失败");
//        }
 //       String fileName = file.getOriginalFilename(); // 得到上传的文件名  MultipartFile
//        File tem = new File("D:/"+fileName);
//        file.transferTo(tem);
        //System.out.println(fileName);
        return "upload接口";
    }


    @ResponseBody
    @PostMapping("upload1")//
    public String uploadFile1(@RequestPart("file") MultipartFile file) throws Exception {//@RequestParam("file") MultipartFile file
        System.out.println("=upload接口");
        log.info("=upload接口");
        System.out.println("file为:"+file);
//        if (file.isEmpty()) {
//            System.out.printf("文件上传失败");
//        }
        //       String fileName = file.getOriginalFilename(); // 得到上传的文件名  MultipartFile
//        File tem = new File("D:/"+fileName);
//        file.transferTo(tem);
        //System.out.println(fileName);
        return "upload接口";
    }

    @ResponseBody
    @PostMapping("uploadfile")
    public String uploadfile(@RequestParam MultipartFile file) throws Exception {//@RequestParam("file") MultipartFile file
        System.out.println("进入该接口");
        System.out.println(file);
        return "uploadfile";
    }


    @ResponseBody
    @PostMapping("uploadarray")//   @RequestParam("files") List<String> file @RequestBody String[] file
    public String uploadarray(@RequestBody List<String> file) throws Exception {//@RequestParam("file") MultipartFile file
        System.out.println("====uploadarray接口");
        System.out.println(file);
        StringBuffer stringBuffer = new StringBuffer();
        for (String f : file) {
            stringBuffer.append(f);
        }
        System.out.println("数组拼接"+stringBuffer);
        return "uploadarray";
    }


    @PostMapping("uploadarray3")
    public String uploadarray3(@RequestParam("file") List<String> file) {
        System.out.println("====uploadarray3接口");
        System.out.println(file);
        //System.out.println(JSONObject.toJSONString(file));
        StringBuffer stringBuffer = new StringBuffer();
        for (String f : file) {
            System.out.println(f);
            stringBuffer.append(f);
        }
        System.out.println("数组拼接"+stringBuffer);
        return "uploadarray3";
    }



    @PostMapping("uploadarray2")
    public String uploadarray2() throws Exception {
        System.out.println("====uploadarray2接口");
        //System.out.println("file2为"+file);
        return "====uploadarray2接口";
    }

//
//    @PostMapping("uploadarray2")
//    public String uploadarray2(@RequestParam("file") String file) throws Exception {
//        System.out.println("====uploadarray2接口");
//        System.out.println("file2为"+file);
//        return file;
//    }


//    @ResponseBody
//    @PostMapping("uploadarray1")//   @RequestParam("files") List<String> file @RequestBody String[] file
//    public String uploadarray1(@RequestBody Map<String,Object> file) throws Exception {//@RequestParam("file") MultipartFile file
//        System.out.println("====uploadarray1接口");
//        System.out.println(file);
//        ArrayList<?> array = (ArrayList<?>) file.get("file");
//        System.out.println(JSONObject.toJSONString(array));
//        StringBuffer stringBuffer = new StringBuffer();
//        for (Object o : array) {
//            System.out.println(o);
//            stringBuffer.append(o);
//        }
//        System.out.println("数组拼接"+stringBuffer);
//        return "uploadarray1";
//    }







    @PostMapping("uploadjson")//@RequestBody JSONObject jsonObject
    public String uploadarray1() throws Exception {//@RequestParam("file") MultipartFile file
        System.out.println("====uploadjson");
        //System.out.println("jsonObject为"+jsonObject);
        return "uploadjson";
    }



    @ResponseBody
    @RequestMapping("getUrl")
    public String getUrl(){ //流文件乱码 https://blog.51cto.com/u_15076204/4281748
                            //字节字符转换 https://www.cnblogs.com/xiaodeyao/p/5049781.html
                            //base64和图片相互转换 https://blog.csdn.net/a2272062968/article/details/126243319
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            String endPoint = "https://obs.im-region-1.sgic.sgcc.com.cn";
            String ak = "FJKCAJIHHXNBTSWG0QN3";
            String sk = "D3Gtp3rz59WT9EpZ1RxBEDcvIjWrLcbXOzivv6gY";
            String bucketname = "tqgl-upload-product";
            ObsClient obsClient = new ObsClient(ak, sk, endPoint);
            ObsObject obsObject = obsClient.getObject(bucketname, "测试图111.jpg");
    // 读取对象内容
            System.out.println("Object content:");
            InputStream input = obsObject.getObjectContent();
            System.out.println("input"+input);
            byte[] b = new byte[1024];

            int len;
            while ((len=input.read(b)) != -1){
                bos.write(b, 0, len);
            }
            System.out.println("1=="+ Base64.encode(bos.toByteArray()));
            bos.close();
            input.close();
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("抛出异常");
        }

        return Base64.encode(bos.toByteArray());
    }



    @ResponseBody
    @RequestMapping("getUrl1")
    public String getUrl1(){ //流文件乱码 https://blog.51cto.com/u_15076204/4281748
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            String endPoint = "https://obs.im-region-1.sgic.sgcc.com.cn";
            String ak = "FJKCAJIHHXNBTSWG0QN3";
            String sk = "D3Gtp3rz59WT9EpZ1RxBEDcvIjWrLcbXOzivv6gY";
            String bucketname = "tqgl-upload-product";
            ObsClient obsClient = new ObsClient(ak, sk, endPoint);
            //ObsObject obsObject = obsClient.getObject(bucketname, "测试图111.jpg");
            FileInputStream input = new FileInputStream(new File("src/main/resources/测试a123.jpg"));
            obsClient.putObject(bucketname,"测试a112233.jpg",input);

        }catch (Exception e){
            e.printStackTrace();
            System.out.println("抛出异常");
        }
        return new String(bos.toByteArray());
    }


    @PostMapping("uploadarray1")
    public Map<String,String> uploadarray1(@RequestParam String file,@RequestParam String uniqueId) throws Exception {//@RequestParam("file") MultipartFile file
        System.out.println("====uploadarray1接口");
        Map<String,String> map = new HashMap<>();
        try {
            String endPoint = "https://obs.im-region-1.sgic.sgcc.com.cn";
            String ak = "FJKCAJIHHXNBTSWG0QN3";
            String sk = "D3Gtp3rz59WT9EpZ1RxBEDcvIjWrLcbXOzivv6gY";
            String bucketname = "tqgl-upload-product";
            ObsClient obsClient = new ObsClient(ak, sk, endPoint);
            //ObsObject obsObject = obsClient.getObject(bucketname, "测试图111.jpg");
            //FileInputStream input = new FileInputStream(new File("src/main/resources/测试a123.jpg"));
            obsClient.putObject(bucketname,"obs-pic/"+uniqueId+".txt",new ByteArrayInputStream(file.getBytes()));
            map.put("uniqueId",uniqueId);
            System.out.println(uniqueId + ".txt文件上传成功");
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("抛出异常");
        }
        return map;

    }


    @ResponseBody
    @PostMapping("getDown")//下载图片
    public Map<String,String> getDwon(@RequestParam String uniqueId){//@RequestParam String str
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        Map<String,String> map = new HashMap<>();
        InputStream fis =null;
        try {
            String endPoint = "https://obs.im-region-1.sgic.sgcc.com.cn";
            String ak = "FJKCAJIHHXNBTSWG0QN3";
            String sk = "D3Gtp3rz59WT9EpZ1RxBEDcvIjWrLcbXOzivv6gY";
            String bucketname = "tqgl-upload-product";
            ObsClient obsClient = new ObsClient(ak, sk, endPoint);
            ObsObject obsObject = obsClient.getObject(bucketname, "obs-pic/"+uniqueId+".txt");
            //ObsObject obsObject = obsClient.getObject(bucketname, uniqueId+".txt");
            InputStream input = obsObject.getObjectContent();
            fis = input;

//
            byte[] b = new byte[1024];
            int len;
            while ((len=fis.read(b)) != -1){
                bos.write(b, 0, len);
                System.out.println(new String(b,0,len));
            }
//            System.out.println(bos.toByteArray());
//            System.out.println("返回base64"+Base64.encode(bos.toByteArray()));
//            map.put("base64",Base64.encode(bos.toByteArray()));
            map.put("base64",bos.toString());
            //map.put("base642",new String(b,0,len));
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("抛出异常");
        }finally {
            //需要进行非空判断,才能进行文件字节输入流的关闭
            // 若是空的话,无需去理会她,因为过段时间会被gc垃圾回收器去进行回收的
            //非空判断对象名.notnull就会自动生成非空判断语句
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return map;
    }

    @ResponseBody
    @RequestMapping("getUp")//上传图片
    public String getUp(){
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            String endPoint = "https://obs.im-region-1.sgic.sgcc.com.cn";
            String ak = "FJKCAJIHHXNBTSWG0QN3";
            String sk = "D3Gtp3rz59WT9EpZ1RxBEDcvIjWrLcbXOzivv6gY";
            String bucketname = "tqgl-upload-product";
            ObsClient obsClient = new ObsClient(ak, sk, endPoint);
            //ObsObject obsObject = obsClient.getObject(bucketname, "测试图111.jpg");
            FileInputStream input = new FileInputStream(new File("src/main/resources/测试a123.jpg"));
            obsClient.putObject(bucketname,"测试a112233.jpg",input);

        }catch (Exception e){
            e.printStackTrace();
            System.out.println("抛出异常");
        }
        return new String(bos.toByteArray());
    }
    // URL有效期，3600秒
//        long expireSeconds = 3600L;
//        TemporarySignatureRequest request = new TemporarySignatureRequest(HttpMethodEnum.GET,
//                expireSeconds);
//        request.setBucketName(bucketname);
//        request.setObjectKey("测试图111");
//        // 设置图片转码参数
//        Map<String,Object> queryParams = new HashMap<String, Object>();
//        queryParams.put("x-image-process","image/resize,m_fixed,w_100,h_100/rotate,100");
//        request.setQueryParams(queryParams);
//        TemporarySignatureResponse response = obsClient.createTemporarySignature(request);
//        //获取支持图片转码的下载链接
//        System.out.println("Getting object using temporary signature url:");
//        System.out.println("\t" + response.getSignedUrl());
//        return response.getSignedUrl();

    @ResponseBody
    @RequestMapping("getTest")//下载图片
    public String getTest() {//@RequestParam String str
        String strImg =  Base64Util.GetImageStr();
        System.out.println("strImg"+strImg);
        Base64Util.GenerateImage(strImg);
        return "1";
    }
}
