package com.exam.modules.entity.vo;

import lombok.Data;

import java.util.List;

/**
 * @Author dyy
 * @Date 2022/11/10 15:12
 * @PackageName:com.exam.modules.entity.dto
 * @ClassName: AnsRecordDTO
 * @Description: TODO
 * @Version 1.0
 */
@Data
public class AnsRecordVo {
    //题目id集合
    private List<Long> tid;
    //考生答案集合
    private List<String> userAns;
}
