package org.dfzt.util.jwt;

import com.alibaba.fastjson.JSON;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTCreator;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.AlgorithmMismatchException;
import com.auth0.jwt.exceptions.InvalidClaimException;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.dfzt.entity.vo.SysUser;

import java.util.Calendar;

/**
 * @Author dyy
 * @Date 2022/7/22 11:30
 * @Version 1.0
 */
public class JwtUtil {
    private static final String KEY = "dfztboot123456";  //盐

    /**
     * 生成token
     * @param user
     * @return
     */
    public static String generateToken(SysUser user){
        //过期时间
        Calendar calendar = Calendar.getInstance();
//        calendar.add(Calendar.DAY_OF_YEAR,7);
//        calendar.add(Calendar.MINUTE,1);
        calendar.add(Calendar.HOUR,5);
        //claim声明
        //Payload由一个个claim组成
        JWTCreator.Builder builder = JWT.create()
                .withClaim("userInfo", JSON.toJSONString(user))
                .withExpiresAt(calendar.getTime());
        String token= builder.sign(Algorithm.HMAC256(KEY));
        return token;
    }

    /**
     * 校验
     * @param tokenToVerify
     * @return
     */
    public static DecodedJWT verify(String tokenToVerify){
        DecodedJWT verify = null;
        try{
                verify = JWT.require(Algorithm.HMAC256(KEY)).build().verify(tokenToVerify);
        }catch (SignatureVerificationException e){
                e.printStackTrace();
            System.out.println("签名不一致");
        }catch (TokenExpiredException e){
            e.printStackTrace();
            System.out.println("令牌过期");
        }catch (AlgorithmMismatchException e){
            e.printStackTrace();
            System.out.println("签名算法不匹配");
        }catch (InvalidClaimException e){
            e.printStackTrace();
            System.out.println("payload不可用");
        }catch (Exception e){
            e.printStackTrace();
            System.out.println("校效失败");
        }
        return verify;
    }

    /**
     * 解析user对象
     * @param decodedJWT
     * @return
     */
    public static SysUser parse(DecodedJWT decodedJWT){
        Claim claim = decodedJWT.getClaim("userInfo");
        if (claim != null){
            //获取payLoad里面的信息,注意类型，如果类型不一致，是获取不到的
            String userString = claim.asString();
            SysUser user = JSON.parseObject(userString, SysUser.class);
            return user;
        }
        return null;
    }
}
