package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import org.dfzt.entity.po.AcAll;
import org.dfzt.entity.po.CaccheCons;
import org.dfzt.entity.po.consTgScm;
import org.dfzt.entity.vo.PropListVo;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CachesMapper {

    //查询呼伦贝尔所有供电单位编号
    @DS("mpgt")
    List<consTgScm> getOrgList();

    //查询电流、电压码值表
    @DS("mpgt")
    List<PropListVo> getPropList();

    //查询全域用户
    @DS("mpg")
    List<CaccheCons> getConsList();
}