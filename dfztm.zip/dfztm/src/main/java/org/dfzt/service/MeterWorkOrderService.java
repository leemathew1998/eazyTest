package org.dfzt.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import org.dfzt.entity.po.MeterWorkOrder;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dfzt-dyy
 * @since 2022-07-11
 */
public interface MeterWorkOrderService extends IService<MeterWorkOrder> {
    int insertSelective(MeterWorkOrder mwo);

    //获取近三天数据
    void selThreeday();

    //查询明细表所有信息
    String findAll();

    //计算计量异常绩效
    void meterperformance();

    //模糊查询
    LambdaQueryWrapper queryWrapper(MeterWorkOrder meterWorkOrder);
    //模糊查询
    LambdaQueryWrapper queryWrapper1(MeterWorkOrder meterWorkOrder,String status);

    //app模糊查询
    LambdaQueryWrapper Wrapper(String str,String workOrderStatus,String loName2);
    //app模糊查询
    LambdaQueryWrapper Wrapper1(List<String> readNames,String str,String workOrderStatus,String loName2);
    //查询用户角色信息
    int selRole(String loginName);
    //计量敏感用户
    List<MeterWorkOrder> selectAllByAppType();

    List<Map<String,Object>> workOrderMeasurement(String loginName);
}
