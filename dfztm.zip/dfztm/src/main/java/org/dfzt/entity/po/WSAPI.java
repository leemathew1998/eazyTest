package org.dfzt.entity.po;




import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * @ClassName WSAPI
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/8 13:15
 */
//@WebService
//public interface WSAPI {
//    @WebMethod
//    String getInfo();
//
//    @WebMethod
//    CollectFailure getInfoGood();
//
//    @WebMethod
//    String getInfoBad(String message);
//
//}
