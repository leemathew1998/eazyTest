package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/25
 * @Version: 1.00
 */
@Data
public class FeeNum implements Serializable {
    private Integer feeNumAll;
    private Integer feeNumSuc;
}
