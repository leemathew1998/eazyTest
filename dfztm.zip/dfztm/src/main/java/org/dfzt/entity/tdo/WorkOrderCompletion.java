package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 区工单完成情况
 */
@Data
public class WorkOrderCompletion {
    //当月累计工单
    private Number currentMonthGrandTotal;
    //待处理
    private Number toBeProcessed;
    //处理中
    private Number processing;
    //已处理
    private String processed;
    //明细列表
    private List<DetailList> detailList;
}
