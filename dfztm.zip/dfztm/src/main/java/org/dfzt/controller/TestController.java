package org.dfzt.controller;

import lombok.extern.slf4j.Slf4j;
import org.dfzt.util.PingUtil;
import org.dfzt.util.TracertUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.sql.DataSource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.Charset;
import java.sql.SQLException;
import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/6
 * @Version: 1.00
 */
@RestController
@Slf4j
@CrossOrigin
@RequestMapping("/testcon")
public class TestController {

    @Autowired
    DataSource dataSource;


    @RequestMapping(value = "getPing31",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing31(){
        String cmdPing = "ping 20.72.1.240";
        String line = null;
        try {
            Runtime run = Runtime.getRuntime();
            Process process = run.exec(cmdPing);
            process.waitFor();
            BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), Charset.forName("GBK")));

            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return line;
    }

    @RequestMapping(value = "getPing32",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing32(){
        String cmdPing = "ping 10.4.1.199";
        String line = null;
        try {
            Runtime run = Runtime.getRuntime();
            Process process = run.exec(cmdPing);
            process.waitFor();
            BufferedReader br = new BufferedReader(new     InputStreamReader(process.getInputStream(), Charset.forName("GBK")));

            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return line;
    }



    @RequestMapping(value = "getPing1",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing1(){
        String ping = PingUtil.ping("20.72.1.240");
        return ping;
    }

    @RequestMapping(value = "getPing2",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing2(){
        String ping = PingUtil.ping("10.173.14.201");
        return ping;
    }

    @RequestMapping(value = "getPing3",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing3(){
        String ping = PingUtil.ping("10.173.78.137");
        return ping;
    }

    @RequestMapping(value = "getPing4",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing4(){
        String ping = PingUtil.ping("10.4.1.199");
        return ping;
    }

    @RequestMapping(value = "getPing21",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing21(){
        String ping = PingUtil.ping("20.72.1.240");
        return ping;
    }

    @RequestMapping(value = "getPing22",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing22(){
        String ping = PingUtil.ping("10.173.14.201");
        return ping;
    }

    @RequestMapping(value = "getPing23",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing23(){
        String ping = PingUtil.ping("10.173.78.137");
        return ping;
    }

    @RequestMapping(value = "getPing24",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getPing24(){
        String ping = PingUtil.ping("10.4.1.199");
        return ping;
    }

    @RequestMapping(value = "getTracert1",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getTracert1(){
        TracertUtil util = new TracertUtil();
        System.out.println("营销库pg===============");
        List<String> tracert = util.Tracert("20.72.1.240", "10", "10");
        System.out.println(tracert);
        return "执行完成";
    }
    @RequestMapping(value = "getTracert2",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getTracert2(){
        TracertUtil util = new TracertUtil();
        System.out.println("webservice===============");
        List<String> tracert1 = util.Tracert("10.173.14.201", "10", "10");
        System.out.println(tracert1);
        return "执行完成";
    }
    @RequestMapping(value = "getTracert3",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getTracert3(){
        TracertUtil util = new TracertUtil();
        System.out.println("i===============");
        List<String> tracert2 = util.Tracert("10.173.78.137", "10", "10");
        System.out.println(tracert2);
        return "执行完成";
    }
    @RequestMapping(value = "getTracert4",produces = "application/json;charset=utf-8")//tracert跟踪路由
    @ResponseBody
    public String getTracert4(){
        TracertUtil util = new TracertUtil();
        System.out.println("营销数据库===============");
        List<String> tracert3 = util.Tracert("10.4.1.199", "10", "10");
        System.out.println(tracert3);
        return "执行完成";
    }


    @RequestMapping("telnet1")
    @ResponseBody
    public boolean getTelnet1(){
        return false;
    }


    @RequestMapping("pingtest1")//营销pg库
    @ResponseBody
    public boolean getPingtest1(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("20.72.1.240", 15432), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }

    @RequestMapping("pingtest2")//用采webservice
    @ResponseBody
    public boolean getPingtest2(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("10.173.14.201", 20013), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
            System.out.println("true");
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("false");       // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("关闭异常 - false");
            }
        }
        return isConnected;
    }



    @RequestMapping("pingtest3")//isc测试认证地址
    @ResponseBody
    public boolean getPingtest3(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("10.173.78.137", 17001), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }

    @RequestMapping("pingtest3a")//isc认证地址
    @ResponseBody
    public boolean getPingtest3a(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("10.1.118.88", 8089), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }


    @RequestMapping("pingtest4")//营销库
    @ResponseBody
    public boolean getPingtest4(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("10.4.1.199", 11521), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }


    @RequestMapping("pingtest5")//isc认证地址
    @ResponseBody
    public boolean getPingtest5(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("10.173.172.9", 18880), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }


    @RequestMapping("pingtest6")//营销pg库
    @ResponseBody
    public boolean getPingtest6(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("20.72.1.214", 15432), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }


    @RequestMapping("pingtest7")//数据中台ip
    @ResponseBody
    public boolean getPingtest7(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("25.73.0.219", 18000), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }


    @RequestMapping("pingtest8")//三维驾驶舱
    @ResponseBody
    public boolean getPingtest8(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("10.173.172.9", 18880), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }


    @RequestMapping("pingtest9")//智能断路器
    @ResponseBody
    public boolean getPingtest9(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("10.173.13.6", 11521), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }


    @RequestMapping("pingtest10")//智能断路器
    @ResponseBody
    public boolean getPingtest10(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("192.168.149.168", 6379), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }


    @RequestMapping("pingtest11")//合众厂家接口
    @ResponseBody
    public boolean getPingtest11(){
        Socket socket = new Socket();
        boolean isConnected = false;
        try  {
            socket.connect(new InetSocketAddress("10.172.12.131",18088), 30000);
            isConnected = socket.isConnected(); // 通过现有方法查看连通状态// 建立连接
        } catch (IOException e) {
            System.out.println("false");        // 当连不通时，直接抛异常，异常捕获即可
        }finally{
            try {
                socket.close();   // 关闭连接
            } catch (IOException e) {
                System.out.println("false");
            }
        }
        return isConnected;
    }



}
