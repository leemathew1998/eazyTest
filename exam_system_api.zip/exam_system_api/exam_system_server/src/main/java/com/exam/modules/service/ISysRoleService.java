package com.exam.modules.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.exam.modules.entity.SysRole;
import com.baomidou.mybatisplus.extension.service.IService;
import com.exam.modules.entity.dto.RoleMenuDTO;
import com.exam.modules.entity.vo.RoleQueryVo;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * <p>
 * 角色表 服务类
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface ISysRoleService extends IService<SysRole> {

    /**
     * 根据用户查询角色列表
     * @param page
     * @param roleQueryVo
     * @return
     */
    IPage<SysRole> findRoleListByUserId(IPage<SysRole> page, RoleQueryVo roleQueryVo);

    /**
     * 检查角色是否被使用
     * @param id
     * @return
     */
    boolean hashRoleCount(Long id);

    /**
     * 删除角色
     * @param id
     * @return
     */
    boolean deletRoleById(Long id);

    /**
     * 保存角色权限关系
     * @param roleMenuDTO
     * @return
     */
    boolean saveRoleMenu(RoleMenuDTO roleMenuDTO);

    /**
     * 根据用户ID查询该用户拥有的角色ID
     * @param userId
     * @return
     */
    List<Long> findRoleIdByUserId(Long userId);
}
