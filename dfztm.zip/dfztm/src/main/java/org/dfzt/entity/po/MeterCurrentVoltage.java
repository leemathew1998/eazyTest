package org.dfzt.entity.po;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

/**
 * (MeterCurrentVoltage)表实体类
 *
 * @author makejava
 * @since 2022-06-15 14:09:38
 */
@SuppressWarnings("serial")
@TableName("meter_current_voltage")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeterCurrentVoltage extends Model<MeterCurrentVoltage> {
    //ID
    private Integer id;
    //供电单位
    private String orgName;
    //用户编码
    private String consNo;
    //用户名称
    private String consName;
    //电能表资产号
    private String meterAssetNo;
    //电能表厂家
    private String metManufacturer;
    //终端厂家
    private String factoryCode;
    //台区编号
    private String tgNo;
    //台区名称
    private String tgName;
    //抄表日期
    private Date mrDate;
    //数据来源
    private String dataSrc;
    //综合倍率
    private Integer tFactor;
    //相序
    private String phaseFlag;
    //点数
    private Integer dataPointFlag;
    //0时
    private BigDecimal v1;
    //0时15分
    private BigDecimal v2;
    //0时30分
    private BigDecimal v3;
    //0时45分
    private BigDecimal v4;
    //1时
    private BigDecimal v5;
    //1时15分
    private BigDecimal v6;
    //1时30分
    private BigDecimal v7;
    //1时45分
    private BigDecimal v8;
    //2时
    private BigDecimal v9;
    //2时15分
    private BigDecimal v10;
    //2时30分
    private BigDecimal v11;
    //2时45分
    private BigDecimal v12;
    //3时
    private BigDecimal v13;
    //3时15分
    private BigDecimal v14;
    //3时30分
    private BigDecimal v15;
    //3时45分
    private BigDecimal v16;
    //4时
    private BigDecimal v17;
    //4时15分
    private BigDecimal v18;
    //4时30分
    private BigDecimal v19;
    //4时45分
    private BigDecimal v20;
    //5时
    private BigDecimal v21;
    //5时15分
    private BigDecimal v22;
    //5时30分
    private BigDecimal v23;
    //5时45分
    private BigDecimal v24;
    //6时
    private BigDecimal v25;
    //6时15分
    private BigDecimal v26;
    //6时30分
    private BigDecimal v27;
    //6时45分
    private BigDecimal v28;
    //7时
    private BigDecimal v29;
    //7时15分
    private BigDecimal v30;
    //7时30分
    private BigDecimal v31;
    //7时45分
    private BigDecimal v32;
    //8时
    private BigDecimal v33;
    //8时15分
    private BigDecimal v34;
    //8时30分
    private BigDecimal v35;
    //8时45分
    private BigDecimal v36;
    //9时
    private BigDecimal v37;
    //9时15分
    private BigDecimal v38;
    //9时30分
    private BigDecimal v39;
    //9时45分
    private BigDecimal v40;
    //10时
    private BigDecimal v41;
    //10时15分
    private BigDecimal v42;
    //10时30分
    private BigDecimal v43;
    //10时45分
    private BigDecimal v44;
    //11时
    private BigDecimal v45;
    //11时15分
    private BigDecimal v46;
    //11时30分
    private BigDecimal v47;
    //11时45分
    private BigDecimal v48;
    //12时
    private BigDecimal v49;
    //12时15分
    private BigDecimal v50;
    //12时30分
    private BigDecimal v51;
    //12时45分
    private BigDecimal v52;
    //13时
    private BigDecimal v53;
    //13时15分
    private BigDecimal v54;
    //13时30分
    private BigDecimal v55;
    //13时45分
    private BigDecimal v56;
    //14时
    private BigDecimal v57;
    //14时15分
    private BigDecimal v58;
    //14时30分
    private BigDecimal v59;
    //14时45分
    private BigDecimal v60;
    //15时
    private BigDecimal v61;
    //15时15分
    private BigDecimal v62;
    //15时30分
    private BigDecimal v63;
    //15时45分
    private BigDecimal v64;
    //16时
    private BigDecimal v65;
    //16时15分
    private BigDecimal v66;
    //16时30分
    private BigDecimal v67;
    //16时45分
    private BigDecimal v68;
    //17时
    private BigDecimal v69;
    //17时15分
    private BigDecimal v70;
    //17时30分
    private BigDecimal v71;
    //17时45分
    private BigDecimal v72;
    //18时
    private BigDecimal v73;
    //18时15分
    private BigDecimal v74;
    //18时30分
    private BigDecimal v75;
    //18时45分
    private BigDecimal v76;
    //19时
    private BigDecimal v77;
    //19时15分
    private BigDecimal v78;
    //19时30分
    private BigDecimal v79;
    //19时45分
    private BigDecimal v80;
    //20时
    private BigDecimal v81;
    //20时15分
    private BigDecimal v82;
    //20时30分
    private BigDecimal v83;
    //20时45分
    private BigDecimal v84;
    //21时
    private BigDecimal v85;
    //21时15分
    private BigDecimal v86;
    //21时30分
    private BigDecimal v87;
    //21时45分
    private BigDecimal v88;
    //22时
    private BigDecimal v89;
    //22时15分
    private BigDecimal v90;
    //22时30分
    private BigDecimal v91;
    //22时45分
    private BigDecimal v92;
    //23时
    private BigDecimal v93;
    //23时15分
    private BigDecimal v94;
    //23时30分
    private BigDecimal v95;
    //23时45分
    private BigDecimal v96;
    //用户地址
    private String elecAddr;
    //电能表地址
    private String commAddr;
    //终端地址
    private String terminalAdd;
    //上送时间
    private Date recTime;
    //测量点号
    private Integer mpSn;
    //终端资产号
    private String tmnlAssetNo;
    //类型
    private String type;
    //用户类型
    private String userType;
    //电压
    private BigDecimal Voltage;
    //电流
    private String electricity;
    private Date createTime;
}
