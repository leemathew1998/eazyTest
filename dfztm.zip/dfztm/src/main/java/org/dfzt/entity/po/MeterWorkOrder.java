package org.dfzt.entity.po;


import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.dfzt.eunm.WorkOrderEnum;
import org.dfzt.eunm.meterEventType;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * (MeterWorkOrder)表实体类
 *
 * @author dfzt-dyy
 * @since 2022-06-13 14:56:03
 */
@SuppressWarnings("serial")
@TableName("meter_work_order")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeterWorkOrder extends Model<MeterWorkOrder> {
    //ID
    @TableId(value = "id",type = IdType.AUTO)
    private Integer id;
    //工单编号
    @Excel(name = "工单编号",orderNum = "1",width = 20)
    private String workOrderNo;
    //台区经理
    @Excel(name = "台区经理",orderNum = "2",width = 20)
    private String tgManager;
    //台区编号
    @Excel(name = "台区编号",orderNum = "3",width = 20)
    private String tgId;
    //台区名称
    @Excel(name = "台区名称",orderNum = "4",width = 20)
    private String tgName;
    //供电单位
    @Excel(name = "供电单位",orderNum = "5",width = 20)
    private String orgName;
    //用户名称
    @Excel(name = "用户名称",orderNum = "6",width = 20)
    private String consName;
    //用户编码
    @Excel(name = "用户编码",orderNum = "7",width = 20)
    private String consNo;
    //用户地址
    @Excel(name = "用户地址",orderNum = "8",width = 20)
    private String consAddr;
    //用户电话
    @Excel(name = "用户电话",orderNum = "9",width = 20)
    private String mobile;
    //电能表资产号
    @Excel(name = "电能表资产号",orderNum = "10",width = 20)
    private String assetNo;
    //电能表条形码号
    private String barCode;
    //终端厂家
    private String FactoryCode;
    //电能表厂家
    private String elecmeterFactory;
    //终端厂家
    private String terminalFactory;
    //事件类型
    @Excel(name = "事件类型",orderNum = "11",width = 20,replace = {"反向有功示值大于0_1",
            "失压_2","电表倒走_3","超容_4","零火电流异常_5"})
    private meterEventType eventType;
    //工单状态
    private WorkOrderEnum workOrderStatus;
    private String workOrderStatus1;
    //工单创建人
    private String workOrderCreator;
    //工单创建时间
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date workOrderCtime;
    @Excel(name = "工单创建时间",orderNum = "12",width = 20)
    private String workOrderCtime1;
    //工单耗时
    private String workOrderUtime;
    //工单解决时间
    private Date workOrderStime;
    //工单归档时间
    private Date workOrderFtime;
    //工单周期
    private Integer workOrderCycle;
    //处理人
    private String handler;
    //处理人接收时间
    private Date handlerRtime;
    //历史工单处理人
    private String hworkOrderHandler;
    //历史工单处理人接收工单时间
    private Date hworkOrderHandlerRtime;
    //历史工单处理人转出流转时间
    private Date hworkOrderHandlerTtime;

//    public void setWorkOrderStatus(String workOrderStatus) {
//        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
//    }

}
