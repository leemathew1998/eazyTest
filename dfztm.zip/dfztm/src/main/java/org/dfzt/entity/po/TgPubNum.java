package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/23
 * @Version: 1.00 公变专变数量
 */
@Data
public class TgPubNum implements Serializable {
    private Integer Pub1;
}
