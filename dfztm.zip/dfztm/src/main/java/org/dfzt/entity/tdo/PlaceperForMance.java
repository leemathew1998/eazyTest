package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @ClassName Placeperformance
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/7/7 10:56
 */
@Data
public class PlaceperForMance {
    private int theCompanyTotalPointsForTheDay;
    private int companyRankingOfTheDay;
    private List<Indicators> indicators;
}
