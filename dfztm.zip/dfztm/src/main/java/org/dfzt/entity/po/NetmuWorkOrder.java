package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 
 * @TableName netmu_work_order
 */
@TableName(value ="netmu_work_order")
@Data
public class NetmuWorkOrder implements Serializable {
    /**
     * 唯一标识
     */
    @TableId
    private Integer id;

    /**
     * 工单编号
     */
    private String workOrderNo;

    /**
     * 申请编号
     */
    private String appNo;

    /**
     * 用户编号
     */
    private String consNo;

    /**
     * 用户名称
     */
    private String consName;

    /**
     * 台区编号
     */
    private String tgNo;

    /**
     * 台区名称
     */
    private String tgName;

    /**
     * 供电单位编号
     */
    private String orgNo;

    /**
     * 供电单位名称
     */
    private String orgName;

    /**
     * 用户地址
     */
    private String elecAddr;

    /**
     * 申请方式
     */
    private String appMode;

    /**
     * 业务类型
     */
    private String appTypeCode;

    /**
     * 受理时间
     */
    private Date handleTime;

    /**
     * 联系人
     */
    private String contactName;

    /**
     * 联系类型
     */
    private String contactMode;

    /**
     * 联系方式
     */
    private String mobile;

    /**
     * 更改后地址
     */
    private String newElecAddr;

    /**
     * 更改后联系人
     */
    private String newContactName;

    /**
     * 更改后联系方式
     */
    private String newMobile;

    /**
     * 所站长查看标识
     */
    private String countStatus;

    /**
     * 工单创建时间
     */
    private Date workOrderCtime;

    /**
     * 工单状态
     */
    private String workOrderStatus;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    //联系人
    @TableField(exist = false)
    private List<String> contactNames;

    //联系类型
    @TableField(exist = false)
    private List<String> contactModes;

    //联系方式
    @TableField(exist = false)
    private List<String> mobiles;

    @TableField(exist = false)
    private Long pageNo;

    @TableField(exist = false)
    private Long pageSize;
}