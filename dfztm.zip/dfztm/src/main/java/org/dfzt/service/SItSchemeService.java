package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.SItScheme;

/**
 * (SItScheme)表服务接口
 *
 * @author makejava
 * @since 2022-08-01 10:11:27
 */
public interface SItSchemeService extends IService<SItScheme> {

}

