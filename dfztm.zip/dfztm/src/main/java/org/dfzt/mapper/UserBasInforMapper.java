package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.CContact;
import org.dfzt.entity.po.CInformation;
import org.dfzt.entity.po.ElectricityPrice;
import org.dfzt.entity.po.UserBasInfor;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */

public interface UserBasInforMapper extends BaseMapper<UserBasInfor> {
    Page<UserBasInfor> selectUserAll(@Param("page") Page<UserBasInfor> page, @Param("one") String one);//查看敏感用户档案所有内容
    List<CContact> selectCcon(String consNo);//查看用户联系信息表
    List<ElectricityPrice> selectElec(String consNo);//查看定价策略及电价表
    List<CInformation> selectInfor(String consNo);//查看受电点基础信息

    Integer selectConsNo(String consNo);//通过用户编号查询该号是否存在敏感用户表中
    Integer insertUserBase(UserBasInfor userBasInfor);
}
