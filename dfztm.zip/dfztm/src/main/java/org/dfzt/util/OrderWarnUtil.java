package org.dfzt.util;

import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.po.CollectWorkOrder;
import org.dfzt.entity.po.CollectYwWorkOrder;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.text.DecimalFormat;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/6/8
 * @Version: 1.00
 */
@Slf4j
@Component
public class OrderWarnUtil {
    static int num=1;//每天进行重新赋值为1
//0 0 0 * * ? //每天12点执行一次
    @Scheduled(cron = "0 0 0 * * ?")
    public static void getnum(){
        num=1;
    }


    public static String OrderNum(){
//        int num1 = OrderWarnUtil.getnum();
        //工单后6位序号
        DecimalFormat df = new DecimalFormat("000000");
        String format = df.format(num);
        num++;
        return format;
    }

    public static String OrderNum1(){
//        int num1 = OrderWarnUtil.getnum();
        //工单后6位序号
        DecimalFormat df = new DecimalFormat("0000000");
        String format = df.format(num);
        num++;
        return format;
    }

    public static int getWarning(CollectWorkOrder cWO, Date date, String eventReason) {
        if(cWO!=null){//是否相同资产号，如果没有，则直接跳过，生成新工单
            if(cWO.getEventReason()!=eventReason){//判断原因是否相同，如果不同，则直接跳过，生成新工单
                if(!cWO.getWorkOrderStatus().equals("4")){//判断是否已归档，如果归档，则跳过生成新工单
                    Date workOrderCtime = cWO.getWorkOrderCtime();
                    int n = Math.abs((int) ((date.getTime() - workOrderCtime.getTime()) / (24 * 60 * 60 * 1000)));
                    if(n ==1){//如果周期大等于1 说明是昨天的工单 修改工单状态为1待处理，并且标记为2天工单
                        return 1;
                    }else if(n==2){
                        return 2;
                    }
                    return 0;
                }
                return 0;
            }
            return 0;
        }
        return 0;
    }

}
