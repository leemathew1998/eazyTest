package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.SPowerViolateSteal;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface SPowerViolateStealMapper extends BaseMapper<SPowerViolateSteal> {
}