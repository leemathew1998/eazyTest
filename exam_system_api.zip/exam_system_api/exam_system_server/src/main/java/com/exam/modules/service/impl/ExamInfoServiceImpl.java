package com.exam.modules.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.Query;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.exam.modules.entity.ExamManage;
import com.exam.modules.entity.vo.ExamManageVo;
import com.exam.modules.entity.vo.UserQueryVo;
import com.exam.modules.mapper.ExamInfoMapper;
import com.exam.modules.entity.ExamInfo;
import com.exam.modules.service.ExamInfoService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.SelectKey;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 考试信息(ExamInfo)表服务实现类
 *
 * @author makejava
 * @since 2022-11-09 15:05:39
 */
@Service("examInfoService")
@Slf4j
public class ExamInfoServiceImpl extends ServiceImpl<ExamInfoMapper, ExamInfo> implements ExamInfoService {

    @Resource
    private ExamInfoService examInfoService;

    @Override
    public boolean isTrue(ExamInfo examInfo) {
        return baseMapper.isTrue(examInfo.getUserId(),examInfo.getExamId());
    }

    @Override
    public boolean add(ExamManageVo examManageVo,Long examId) {
        ExamInfo examInfo = new ExamInfo();
//        考生id
        List<String> list = Arrays.asList(examManageVo.getUserIds().split(","));
        for (String s : list) {
            examInfo.setUserId(Long.valueOf(s));
            //试卷ID
            examInfo.setExamPaperId(examManageVo.getExamPaperId());
            //试卷名称
            examInfo.setExamPaperName(examManageVo.getExamPaperName());
            //考试id
            examInfo.setExamId(examId);
            //考试名称
            examInfo.setExamName(examManageVo.getExamName());
           //考生成绩(默认0分)
            examInfo.setScoreSum(0L);
            //所属组别
//            examInfo.setTheGroup(examManageVo.getTheGroup());
            //出题人
            examInfo.setTheAuthor(examManageVo.getTheAuthor());
            //试卷总分
            examInfo.setPSum(examManageVo.getPSum());
            //阅卷状态
            examInfo.setMarkStatus("3");
            //考试时间
            examInfo.setExamTime(examManageVo.getExamBeginTime());
            //是否参加考试
            examInfo.setIsTrue("1");
            examInfoService.save(examInfo);
        }
        return true;
    }

    @Override
    public boolean updateInfo(ExamManageVo examManageVo) {
        //根据考试id修改考试信息
        QueryWrapper<ExamInfo> wrapper = new QueryWrapper<>();
        wrapper.eq("EXAM_ID",examManageVo.getExamId());
        //删除原来分配的考试信息
        baseMapper.delete(wrapper);

        ExamInfo examInfo = new ExamInfo();
        //考生id
        List<String> list = Arrays.asList(examManageVo.getUserIds().split(","));
        for (String s : list) {
            examInfo.setUserId(Long.valueOf(s));
            //试卷ID
            examInfo.setExamPaperId(examManageVo.getExamPaperId());
            //试卷名称
            examInfo.setExamPaperName(examManageVo.getExamPaperName());
            //考试id
            examInfo.setExamId(examManageVo.getExamId());
            //考试名称
            examInfo.setExamName(examManageVo.getExamName());
            //出题人
            examInfo.setTheAuthor(examManageVo.getTheAuthor());
            //试卷总分
            examInfo.setPSum(examManageVo.getPSum());
            //阅卷状态
            examInfo.setMarkStatus("3");
            //考试时间
            examInfo.setExamTime(examManageVo.getExamBeginTime());
            //是否参加考试
            examInfo.setIsTrue("1");
            //重新添加
            examInfoService.save(examInfo);
        }
        return true;
    }

    @Override
    public IPage<ExamInfo> selPage(IPage<ExamInfo> page, ExamManageVo examInfo) {
        QueryWrapper<ExamInfo> queryWrapper = new QueryWrapper<>();
        queryWrapper.like(StrUtil.isNotBlank(examInfo.getExamName()),"EXAM_NAME",examInfo.getExamName());
        queryWrapper.like(StrUtil.isNotBlank(examInfo.getUserName()),"USER_NAME",examInfo.getUserName());
        queryWrapper.like(StrUtil.isNotBlank(examInfo.getMarkBy()),"MARK_BY",examInfo.getMarkBy());
        queryWrapper.like(StrUtil.isNotBlank(examInfo.getIsTrue()),"IS_TRUE",examInfo.getIsTrue());
        if(examInfo.getBeginTime()!=null && examInfo.getEndTime()!=null){
            queryWrapper.between("EXAM_TIME",examInfo.getBeginTime(),examInfo.getEndTime());
        }
        return baseMapper.selectPage(page,queryWrapper);
    }


    /**
     * 提交异常状态
     * @param examInfo
     * @return
     */
    @Override
    public boolean abnormal(ExamInfo examInfo) {
        return baseMapper.abnormal(examInfo.getAbnormal(),examInfo.getUserId(),examInfo.getExamId());
    }

    /**
     * 根据用户id查询我的公告
     * @param user
     * @return
     */
    @Override
    public LambdaQueryWrapper<ExamInfo> wrapper(UserQueryVo user) {
        LambdaQueryWrapper<ExamInfo> lambda = new LambdaQueryWrapper<>();
        lambda.eq(ExamInfo::getUserId,user.getUserId());
        return lambda;
    }

    //（考试查询）考试详情
    @Override
    public IPage<ExamInfo> selectExampage(Map<String, Object> params) {
        // size 每页多少条
        long pageSize = Long.parseLong(StringUtils.defaultIfBlank(String.valueOf(params.get("pageSize")), "10"));
        // 当前页
        long pageNo = Long.parseLong(StringUtils.defaultIfBlank(String.valueOf(params.get("pageNo")), "1"));
        //创建构造器
        QueryWrapper<ExamInfo> queryWrapper = new QueryWrapper<>();
        //取出参数
        Object examId = params.get("examId");
        log.info("========"+examId);
        if (null != examId && examId.toString().trim().length() > 0) {
            log.info("========进入方法");
            queryWrapper.eq("EI.EXAM_ID",examId);
        }
        IPage<ExamInfo> page = baseMapper.selectExampage(new Page<>(pageNo, pageSize), queryWrapper);
        return page;
    }


}
