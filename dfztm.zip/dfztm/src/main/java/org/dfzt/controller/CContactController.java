package org.dfzt.controller;


import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.dfzt.entity.po.CContact;
import org.dfzt.entity.po.CInformation;
import org.dfzt.entity.po.ElectricityPrice;
import org.dfzt.entity.po.UserBasInfor;
import org.dfzt.entity.vo.ContList;
import org.dfzt.mapper.UserBasInforMapper;
import org.dfzt.service.CContactService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */
@Api(tags = "用户档案")
@RestController
@RequestMapping("/cContact")
public class CContactController {

    @Resource
    CContactService cContactService;
    @Resource
    UserBasInforMapper userBasInforMapper;


   @ApiOperation(value = "用户信息",notes = "查询信息-条件查询")
   @PostMapping(value = "/QueryAll")
   public R QueryAllInfo(ContList contList){
       return cContactService.QueryAll(contList);
   }



    @ApiOperation(value = "用户信息",notes = "查询信息-全量查询")
    @PostMapping(value = "/SelectAll")
    public R SelectAllInfo(Long page ,Long pageSize){
        return cContactService.selectConTactListAll(page , pageSize);
    }

    @PostMapping(value = "/selconsinfo")
    public R selconsinfo(String powerPointNo){
        return cContactService.selconsinfo(powerPointNo);
    }


    @PostMapping(value = "/selectMessage")
    @ApiOperation(value = "APP端的用户档案模糊查询",notes = "查询信息-全量查询--分页")
    public R selectMessage(@RequestParam(required = false) String  message,
                        @RequestParam(defaultValue = "1")  Long pageNo,
                        @RequestParam(defaultValue = "10")  Long pageSize){
        return cContactService.selectMessage(message, pageNo, pageSize);


    }

    @PostMapping(value = "/selectMessage1")
    @ApiOperation(value = "APP端的用户档案模糊查询",notes = "查询信息-全量查询--分页")
    public R selectMessage1(@RequestParam(required = false) String  message,
                           @RequestParam(defaultValue = "1")  Long pageNo,
                           @RequestParam(defaultValue = "10")  Long pageSize){
        return cContactService.selectMessage1(message, pageNo, pageSize);


    }

    @PostMapping(value = "/interfaceTest")
    public R interfaceTest(){
       return cContactService.interfaceTest();
    }


    @PostMapping("selectMess")
    public Page<UserBasInfor> selectMess1(String one, @RequestParam Integer pageNo, @RequestParam Integer pageSize){
//        PageHelper.startPage(pageNo,pageSize);
        Page<UserBasInfor> page = new Page<>(pageNo,pageSize);
        Page<UserBasInfor> userBasInforPage = userBasInforMapper.selectUserAll(page,one);
        return userBasInforPage;
    }

    @PostMapping("selectCcon")
    public List<CContact> selectCcon1(String consNo){
        List<CContact> cContacts = userBasInforMapper.selectCcon(consNo);
        return cContacts;
    }

    @PostMapping("selectElec")
    public List<ElectricityPrice> selectElec1(String consNo){
        List<ElectricityPrice> elecs = userBasInforMapper.selectElec(consNo);
        return elecs;
    }

    @PostMapping("selectInfor")
    public List<CInformation> selectInfor(String consNo){
        List<CInformation> cInfors = userBasInforMapper.selectInfor(consNo);
        return cInfors;
    }


}

