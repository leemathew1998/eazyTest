package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.AcCounty;

import java.util.List;

/**
 * (AcCounty)表数据库访问层
 *
 * @author makejava
 * @since 2022-07-15 10:48:09
 */
public interface AcCountyMapper extends BaseMapper<AcCounty> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<AcCounty> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<AcCounty> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<AcCounty> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<AcCounty> entities);

    AcCounty selectCountyPoint(String orgName,String datedm);//所当日的总积分 以及记录
}

