package org.dfzt.entity.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/8/16
 * @Version: 1.00
 * TODO 计量运维研判原因参与计算的值
 */
@Data
public class MeterData implements Serializable {

    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date dateTime;

    private BigDecimal RateAll;//尖峰平谷之和
    private BigDecimal positiveActive;//正向有功总
    private BigDecimal diff;//尖峰平谷之和  减 正向有功总  的差值

    private BigDecimal oneReverseActive;//近一天反向有功
    private BigDecimal twoReverseActive;//近两天反向有功
    private BigDecimal threeReverseActive;//近三天反向有功

    private String ninesix1;//96点的其中一点1
    private String voltageValue1;//该点电压值1

    private String ninesix2;//96点的其中一点2
    private String voltageValue2;//该点电压值2
    private String currentValue2;//该点电流值2

    private BigDecimal nowPositiveActive;//当天0点电能示值
    private BigDecimal beforePositiveActive;//前一天天0点电能示值
    private BigDecimal maxVoltage;//所有相中电压最大值
    private BigDecimal edVoltage;//表计额定电压
    private BigDecimal beforeavgCurrentA;//前一天A相电流平均值
    private BigDecimal beforeavgCurrentB;//前一天B相电流平均值
    private BigDecimal beforeavgCurrentC;//前一天C相电流平均值
    private BigDecimal nowavgCurrentA;//当天A相电流平均值
    private BigDecimal nowavgCurrentB;//当天B相电流平均值
    private BigDecimal nowavgCurrentC;//当天C相电流平均值

    private String ratedVoltage;//额定电压
    private String maxCurrent;//最大电流
    private String resultValue;//结果



}
