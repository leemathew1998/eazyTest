package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.LinelossSynana;
import org.dfzt.entity.po.LinelossWorkOrder;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface LinelossWorkOrderMapper extends BaseMapper<LinelossWorkOrder> {
    int deleteByPrimaryKey(Integer id);

    int insertSelective(LinelossWorkOrder record);

    LinelossWorkOrder selectByPrimaryKey(Integer id);

    List<LinelossWorkOrder> selectAllLine();//查询所有工单

    Integer updateTypeNum(String tgId, Integer comQuesNum, Integer elestealNum, Integer zeroFireNum, Integer currentNobalNum, Integer platOverloadNum, Integer userOverloadNum);

    LinelossWorkOrder selectOne(String tgId);

    Integer updateWoStatus2(String tgId);//根据工单id改变工单状态为2处理中
    Integer updateWoStatus3(String workOrderNo);//根据工单id改变工单状态为3待归档

    IPage<LinelossWorkOrder> selectAllLine1(Page<LinelossWorkOrder> page);//查询线损工单表--分页查询

    String selectRole(String username);//根据用户id差找所对应的权限

    List<LinelossWorkOrder> selectList1(@Param("l")LinelossWorkOrder l,@Param("pageNo") Integer pageNo,@Param("pageSize") Integer pageSize,@Param("orgName") String orgName,@Param("status") String status);//线损条件查询
    List<LinelossWorkOrder> selectList3(@Param("l")LinelossWorkOrder l,@Param("pageNo") Integer pageNo,@Param("pageSize") Integer pageSize,@Param("orgName") String orgName,@Param("status") String status);//线损条件查询

    List<LinelossWorkOrder> selectList2(List<String> readNames,String one, Integer pageNo,Integer pageSize,String workOrderStatus,String username);//线损单个条件查询
    List<LinelossWorkOrder> selectList4(String one,Integer pageNo,Integer pageSize,String workOrderStatus,String username);//线损单个条件查询

    Integer updateWoStatus4(String tgId);//根据工单id改变工单状态为4已归档

    Integer insertlilossSynana(LinelossSynana linelossSynana);

    @DS("mpg")
    BigDecimal selectConCap(String consNo);

    List<String> selectLinelossStatus(String yesdtime);//查询昨日线损数据的台区编号列表

    Integer updateworkCycle(String tgNo,String today,String workOrderCycle);//根据昨天的日期和工单编号，将工单状态修改

    String selectWorkCycle(String tgNo,String yestoday);//查询昨日工单的cycle周期


    List<String> selectYesdayLineWo(String ymd);//查询线损昨日的工单列表

    void updateLineloss(String tgId,String ymd);//修改线损工单的归档状态

}