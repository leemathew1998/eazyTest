package org.dfzt.entity.po;

import lombok.Data;
import oracle.sql.DATE;
import oracle.sql.NUMBER;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Date:2023/5/31-16:38
 * @User:chengchuanlin
 * @Name:MmdHEMpVolCurve
 * @Message:
 */
@Data
public class MmdHEMpVolCurve {
    /**
     * 主键
      */
    private Integer  id;
    /**
     * 供电单位编号
      */
    private String orgNo;
    /**
     * 数据时间
      */
    private Date dataDate;
    /**
     * 电压
      */
    private Integer pt;
    /**
     * 数据补全标志
      */
    private Integer mark;
    /**
     * 相序标志
      */
    private Integer phaseFlag;
    /**
     * 数据完整性标志  ( 用96个1或0来表示96点数据的完整性标志（左第一位表示第1点） )
      */
    private String dataWholeFlag;
    /**
     * 数据点标志 (1：96点 2: 48点 3: 24点)
      */
    private BigDecimal dataPointFlag;
    /**
     * 电压
      */
    private BigDecimal u1;
    /**
     * 电压
      */
    private BigDecimal u2;
    /**
     * 电压
      */
    private BigDecimal u3;
    /**
     * 电压
      */
    private BigDecimal u4;
    /**
     * 电压
      */
    private BigDecimal u5;
    /**
     * 电压
      */
    private BigDecimal u6;
    /**
     * 电压
      */
    private BigDecimal u7;
    /**
     * 电压
      */
    private BigDecimal u8;
    /**
     * 电压
      */
    private BigDecimal u9;
    /**
     * 电压
      */
    private BigDecimal u10;
    /**
     * 电压
      */
    private BigDecimal u11;
    /**
     * 电压
      */
    private BigDecimal u12;
    /**
     * 电压
      */
    private BigDecimal u13;
    /**
     * 电压
      */
    private BigDecimal u14;
    /**
     * 电压
      */
    private BigDecimal u15;
    /**
     * 电压
      */
    private BigDecimal u16;
    /**
     * 电压
      */
    private BigDecimal u17;
    /**
     * 电压
      */
    private BigDecimal u18;
    /**
     * 电压
      */
    private BigDecimal u19;
    /**
     * 电压
      */
    private BigDecimal u20;
    /**
     * 电压
      */
    private BigDecimal u21;
    /**
     * 电压
      */
    private BigDecimal u22;
    /**
     * 电压
      */
    private BigDecimal u23;
    /**
     * 电压
      */
    private BigDecimal u24;
    /**
     * 电压
      */
    private BigDecimal u25;
    /**
     * 电压
      */
    private BigDecimal u26;
    /**
     * 电压
      */
    private BigDecimal u27;
    /**
     * 电压
      */
    private BigDecimal u28;
    /**
     * 电压
      */
    private BigDecimal u29;
    /**
     * 电压
      */
    private BigDecimal u30;
    /**
     * 电压
      */
    private BigDecimal u31;
    /**
     * 电压
      */
    private BigDecimal u32;
    /**
     * 电压
      */
    private BigDecimal u33;
    /**
     * 电压
      */
    private BigDecimal u34;
    /**
     * 电压
      */
    private BigDecimal u35;
    /**
     * 电压
      */
    private BigDecimal u36;
    /**
     * 电压
      */
    private BigDecimal u37;
    /**
     * 电压
      */
    private BigDecimal u38;
    /**
     * 电压
      */
    private BigDecimal u39;
    /**
     * 电压
      */
    private BigDecimal u40;
    /**
     * 电压
      */
    private BigDecimal u41;
    /**
     * 电压
      */
    private BigDecimal u42;
    /**
     * 电压
      */
    private BigDecimal u43;
    /**
     * 电压
      */
    private BigDecimal u44;
    /**
     * 电压
      */
    private BigDecimal u45;
    /**
     * 电压
      */
    private BigDecimal u46;
    /**
     * 电压
      */
    private BigDecimal u47;
    /**
     * 电压
      */
    private BigDecimal u48;
    /**
     * 电压
      */
    private BigDecimal u49;
    /**
     * 电压
      */
    private BigDecimal u50;
    /**
     * 电压
      */
    private BigDecimal u51;
    /**
     * 电压
      */
    private BigDecimal u52;
    /**
     * 电压
      */
    private BigDecimal u53;
    /**
     * 电压
      */
    private BigDecimal u54;
    /**
     * 电压
      */
    private BigDecimal u55;
    /**
     * 电压
      */
    private BigDecimal u56;
    /**
     * 电压
      */
    private BigDecimal u57;
    /**
     * 电压
      */
    private BigDecimal u58;
    /**
     * 电压
      */
    private BigDecimal u59;
    /**
     * 电压
      */
    private BigDecimal u60;
    /**
     * 电压
      */
    private BigDecimal u61;
    /**
     * 电压
      */
    private BigDecimal u62;
    /**
     * 电压
      */
    private BigDecimal u63;
    /**
     * 电压
      */
    private BigDecimal u64;
    /**
     * 电压
      */
    private BigDecimal u65;
    /**
     * 电压
      */
    private BigDecimal u66;
    /**
     * 电压
      */
    private BigDecimal u67;
    /**
     * 电压
      */
    private BigDecimal u68;
    /**
     * 电压
      */
    private BigDecimal u69;
    /**
     * 电压
      */
    private BigDecimal u70;
    /**
     * 电压
      */
    private BigDecimal u71;
    /**
     * 电压
      */
    private BigDecimal u72;
    /**
     * 电压
      */
    private BigDecimal u73;
    /**
     * 电压
      */
    private BigDecimal u74;
    /**
     * 电压
      */
    private BigDecimal u75;
    /**
     * 电压
      */
    private BigDecimal u76;
    /**
     * 电压
      */
    private BigDecimal u77;
    /**
     * 电压
      */
    private BigDecimal u78;
    /**
     * 电压
      */
    private BigDecimal u79;
    /**
     * 电压
      */
    private BigDecimal u80;
    /**
     * 电压
      */
    private BigDecimal u81;
    /**
     * 电压
      */
    private BigDecimal u82;
    /**
     * 电压
      */
    private BigDecimal u83;
    /**
     * 电压
      */
    private BigDecimal u84;
    /**
     * 电压
      */
    private BigDecimal u85;
    /**
     * 电压
      */
    private BigDecimal u86;
    /**
     * 电压
      */
    private BigDecimal u87;
    /**
     * 电压
      */
    private BigDecimal u88;
    /**
     * 电压
      */
    private BigDecimal u89;
    /**
     * 电压
      */
    private BigDecimal u90;
    /**
     * 电压
      */
    private BigDecimal u91;
    /**
     * 电压
      */
    private BigDecimal u92;
    /**
     * 电压
      */
    private BigDecimal u93;
    /**
     * 电压
      */
    private BigDecimal u94;
    /**
     * 电压
      */
    private BigDecimal u95;
    /**
     * 电压
      */
    private BigDecimal u96;
    /**
     * 数据入库时间
      */
    private Date recTime;
    /**
     * 电表标识
      */
    private Integer meterId;
    /**
     * 数据来源
      */
    private String dataSrc;
    /**
     * 是否有效
      */
    private Integer isValid;
}
