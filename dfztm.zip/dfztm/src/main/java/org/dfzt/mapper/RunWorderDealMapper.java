package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.vo.RunWorderDeal;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
public interface RunWorderDealMapper extends BaseMapper<RunWorderDeal> {

}
