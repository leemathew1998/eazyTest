package org.dfzt.util;

import com.obs.services.ObsClient;
//import sun.misc.BASE64Decoder;
//import sun.misc.BASE64Encoder;

import java.io.*;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/4
 * @Version: 1.00
 */
public class Base64Util {
    public static String GetImageStr() {
        //待处理的图片
        String imgFile = "src/main/resources/测试a123.jpg";
        InputStream in = null;
        byte[] data = null;
        //读取图片字节数组
        try {
            in = new FileInputStream(imgFile);
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        //对字节数组Base64编码
//        BASE64Encoder encoder = new BASE64Encoder();
//        //返回Base64编码过的字节数组字符串
//        return encoder.encode(data);
        return "";
    }

    /**
     * base64字符串转化成图片
     * @param imgStr
     * @return
     */
    public static boolean GenerateImage(String imgStr) {  //对字节数组字符串进行Base64解码并生成图片
        //图像数据为空
        return true;
//        if (imgStr == null) {
//            return false;
//        }
//        BASE64Decoder decoder = new BASE64Decoder();
//        try {
//            //Base64解码
//            byte[] b = decoder.decodeBuffer(imgStr);
//            for (int i = 0; i < b.length; ++i) {
//                //调整异常数据
//                if (b[i] < 0) {
//                    b[i] += 256;
//                }
//            }
//
//            String endPoint = "https://obs.im-region-1.sgic.sgcc.com.cn";
//            String ak = "FJKCAJIHHXNBTSWG0QN3";
//            String sk = "D3Gtp3rz59WT9EpZ1RxBEDcvIjWrLcbXOzivv6gY";
//            String bucketname = "tqgl-upload-product";
//            ObsClient obsClient = new ObsClient(ak, sk, endPoint);
//            obsClient.putObject(bucketname,System.currentTimeMillis() + ".jpg",new ByteArrayInputStream(b));
//            //生成jpeg图片
//            //新生成的图片
//            //String imgFilePath = "src/main/resources/" + System.currentTimeMillis() + ".jpg";
//            //OutputStream out = new FileOutputStream(imgFilePath);
//            //out.write(b);
//            //out.flush();
//            //out.close();
//            return true;
//        } catch (Exception e) {
//            return false;
//        }
    }
}
