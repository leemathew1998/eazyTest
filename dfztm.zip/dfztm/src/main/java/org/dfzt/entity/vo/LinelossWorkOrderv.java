package org.dfzt.entity.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 线损工单表 (传给前端)
 */

@Data
public class LinelossWorkOrderv implements Serializable {
    private Integer id;

    private String workOrderNo;//工单编号

    private String areaManagerDesk;//台区经理

    private String tgId;//台区编号

    private String orgName;//供电单位

    private String tgName;//台区名称

    private Integer tgCap;//台区容量

    private String statDate;//线损统计日期

    private BigDecimal ppq;//供电量

    private BigDecimal tgSpq;//售电量

    private BigDecimal lossPq;//损耗电量

    private BigDecimal linelossRate;//损耗率

    private String meterAssetNo;//电能表资产号

    private String wiringMode;//接线方式

    private BigDecimal tFactor;//综合倍率

    private BigDecimal papE;//正向有功总

    private BigDecimal rapE;//反向有功总

    private Integer comQuesNum;//采集通信问题个数

    private Integer elestealNum;//可能存在窃电个数

    private Integer zeroFireNum;//零线大于火线个数

    private Integer currentNobalNum;//电流不平衡超阈值

    private Integer platOverloadNum;//台区负荷超容个数

    private Integer userOverloadNum;//用户负荷超容个数

    private String workOrderCycle;//工单周期

    private String workOrderStatus;//工单状态

    private Date workOrderCtime;//工单创建时间

    private String userType;//用户类型

    }