package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

@Data
public class WorkOrderSum implements Serializable {
    //id
    private String id;
    //年月份
    private String dataMonth;
    //台区名称
    private String tgName;
    //台区编号
    private String tgNo;
    //待处理数量
    private Integer statusOnenums;
    //待处理占比
    private String perOne;
    //处理中数量
    private Integer statusTwonums;
    //处理中占比
    private String perTwo;
    //已处理数量
    private Integer statusThrnums;
    //已处理占比
    private String perThree;
    //备用字段
    private String reserve;

}