package org.dfzt.service;


import org.dfzt.entity.po.WorkOrderInfor;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/6/7
 * @Version: 1.00
 */
public interface WorkOrderInforService {
    int insertSelective(WorkOrderInfor record);

    WorkOrderInfor SelectVandP(String workOrderNo);//采集运维表中回显图片视频数据
}
