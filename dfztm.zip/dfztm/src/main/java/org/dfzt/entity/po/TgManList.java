package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng 台区经理管辖的用户数
 * @Date: 2023/3/27
 * @Version: 1.00
 */
@Data
public class TgManList implements Serializable {
    private Integer id;
    private String mrSectNo;//抄表段编号
    private Integer consNum;
    private String realName;//台区经理名称

}
