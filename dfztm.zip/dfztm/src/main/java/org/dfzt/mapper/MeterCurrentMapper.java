package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.dfzt.entity.po.IndicationValue;
import org.dfzt.entity.po.LinelossPower;
import org.dfzt.entity.po.MeterCurrent;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * (MeterCurrent)表数据库访问层
 *
 * @author makejava
 * @since 2022-06-17 19:53:08
 */
@Repository
public interface MeterCurrentMapper extends BaseMapper<MeterCurrent> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<MeterCurrent> 实例对象列表
     * @return 影响行数
     */
//    int insertBatch(@Param("entities") List<MeterCurrent> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<MeterCurrent> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
//    int insertOrUpdateBatch(@Param("entities") List<MeterCurrent> entities);
    //查询电流表数据
    @Select("SELECT * FROM meter_current")
    List<MeterCurrent> selAll();

    //查询每一项电流平均值
    List<MeterCurrent> selcurrentAvg(String num);



    List<MeterCurrent> selectMeterCVByPfid(String platformId);//根据台区编号查询该台区所有用户电流和电压曲线

    List<Integer> selectAllUserId(String platformId);

    MeterCurrent selectAcurrByuserid(String useri);//根据用户id查看A相电流数据
    MeterCurrent selectBcurrByuserid(String useri);//根据用户id查看B相电流数据
    MeterCurrent selectCcurrByuserid(String useri);//根据用户id查看C相电流数据
    MeterCurrent selectZecurrByuserid(String useri);//根据用户id查看零相电流数据

    LinelossPower selectPowerBypid(String tgNo);//根据台区id查找功率值

    List<IndicationValue> selectAllIndValue(String tgNo,String startTime);//查询示值表所有信息

    IndicationValue selectTomorrZero(String meterAssetNo,String tomorr);

    List<LinelossPower> selectAllPower(String tgNo,String startTime);//查询功率表表所有信息



}

