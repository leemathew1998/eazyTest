package org.dfzt.entity.po;

import lombok.Data;
import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Data
public class CaccheCons implements Serializable {
    private String consNo;
    private String consName;
    private String elecAddr;
    private String marketPropSort;
    private String orgNo;
    private String mrSectNo;
}
