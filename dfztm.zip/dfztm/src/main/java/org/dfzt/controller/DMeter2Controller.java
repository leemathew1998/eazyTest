package org.dfzt.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.dfzt.entity.po.DMeter;
import org.dfzt.entity.po.DMeter2;
import org.dfzt.mapper.DMeter2Mapper;
import org.dfzt.service.DMeter2Service;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;

/**
 * (DMeter2)表控制层
 *
 * @author makejava
 * @since 2022-08-01 10:10:41
 */
@RestController
@RequestMapping("dMeter2")
public class DMeter2Controller extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private DMeter2Service dMeter2Service;
    @Resource
    private DMeter2Mapper dMeter2Mapper;

    @RequestMapping("selectAllDmeter")//请求方式需要改成post
    public R selectAllDmeter() {
        return success(dMeter2Mapper.selectDeter("154212206"));
    }

    @RequestMapping("insAllDmeter")//请求方式需要改成post
    public R insAllDmeter() {
        int i=0;
        for (DMeter dMeter : dMeter2Mapper.selectDeter("154212206")) {
            if(dMeter2Mapper.selectBymeterId(dMeter.getMeterId())==0){
                i += dMeter2Mapper.insertDMeter(dMeter);
            }
        }
        return success("新增条数"+i);
    }



    /**
     * 分页查询所有数据
     *
     * @param page    分页对象
     * @param dMeter2 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll")
    public R selectAll(Page<DMeter2> page, DMeter2 dMeter2) {
        return success(this.dMeter2Service.page(page, new QueryWrapper<>(dMeter2)));
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @PostMapping("/selectOne/{id}")
    public R selectOne(@PathVariable Serializable id) {
        return success(this.dMeter2Service.getById(id));
    }

    /**
     * 新增数据
     *
     * @param dMeter2 实体对象
     * @return 新增结果
     */
    @PostMapping("insert")
    public R insert(@RequestBody DMeter2 dMeter2) {
        return success(this.dMeter2Service.save(dMeter2));
    }

    /**
     * 修改数据
     *
     * @param dMeter2 实体对象
     * @return 修改结果
     */
    @PostMapping("update")
    public R update(@RequestBody DMeter2 dMeter2) {
        return success(this.dMeter2Service.updateById(dMeter2));
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除结果
     */
    @PostMapping("delete")
    public R delete(Integer id) {
        return success(this.dMeter2Service.removeById(id));
    }
}
