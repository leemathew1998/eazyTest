package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

@Data
public class EventType implements Serializable {
    private Integer id;

    private String consNo;//用户编号

    private String consName;//用户名称

    private String elecAddr;//用户地址

    private String mobile;//用户电话

    private String meterAssetNo;//电脑表资产号

    private String terminalAddr;//终端地址

    private String eventType;

    private String tgId;

}