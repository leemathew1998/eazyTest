package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/26
 * @Version: 1.00
 */
@Data
public class LinelossUserSynana {
    private Integer id;

    private String consNo;//用户编码

    private String consName;//用户名称

    private String elecAddr;//用户地址

    private String meterAssetNo;//电能表资产号

    private String orgName;//供电单位名称

    private String tgName;//台区名称

    private String tgNo;//台区编号

    private Integer tgCap;//台区容量

    private String chkunitName;//考核单元名称

    private Date dataDate;//日期

    private BigDecimal ppq;//供电量

    private BigDecimal tgSqp;//售电量

    private BigDecimal spq;//自用电

    private BigDecimal lossPq;//损耗电量

    private BigDecimal linelossRate;//线损率

    private BigDecimal llIdxUp;//线损指标上限

    private BigDecimal llIdxLow;//线损指标下限

    private BigDecimal differValue;//差异值

    private BigDecimal starTg;//星级台区

    private BigDecimal readSuccCnt;//抄表成功率

    private BigDecimal instRate;//安装率

    private BigDecimal pfFlag;//功率因数

    private BigDecimal linelossTheory;//理论线损

    private BigDecimal uRate;//电压三相不平衡度

    private BigDecimal iRate;//电流三相不平衡度

    private BigDecimal loadRate;//负载率

    private String terminalFactory;//终端厂商

    private String terminalAddr;//终端地址

    private String chargePerson;//负责人

    private String composeSign;//组合标志

    private BigDecimal ppqRepair;//修复供电量

    private BigDecimal spqRepair;//修复售电量

    private String tgLabel;//台区标签

    private String synchroUserName;//同步人

    private String synchroUserDeptno;//同步部门

    private Date synchroUserTime;//同步时间

    private String synchroUserType;//同步方式
}
