package com.exam.modules.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.modules.entity.ExamT;
import com.exam.modules.entity.vo.ExamTVo;
import com.exam.modules.service.ExamTService;
import com.exam.modules.utils.Result;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;

/**
 * (ExamT)表控制层
 *  题库管理
 * @author dyy
 * @since 2022-11-08 09:58:15
 */
@RestController
@RequestMapping("api/examT")
public class ExamTController{
    /**
     * 服务对象
     */
    @Resource
    private ExamTService examTService;

    /**
     * 分页查询所有数据
     * @param examTVo 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll")
    public Result selectAll(@RequestBody ExamTVo examTVo) {
        //创建分页对象
        IPage<ExamT> page = new Page<ExamT>(examTVo.getPageNo(),examTVo.getPageSize());
        //调用分页查询
        examTService.findExamTList(page,examTVo);
        return Result.ok(page);
    }

    /**
     * 添加或修改题库
     * @param examT
     * @return
     */
    @PostMapping("/add")
    public Result add(@RequestBody ExamT examT){
        if(examTService.saveOrUpdate(examT)){
            return Result.ok().message("添加成功");
        }
        return Result.error().message("添加失败");
    }

    /**
     * 删除
     * @param id
     * @return
     */
    @GetMapping("/delete")
    public Result delete(Long id){
        if(examTService.removeById(id)){
            return Result.ok().message("删除成功");
        }
        return Result.error().message("删除失败");
    }


}
