package org.dfzt.entity.po;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;

/**
 * (CMp)表实体类
 *
 * @author makejava
 * @since 2022-07-29 14:51:17
 */
@SuppressWarnings("serial")
@TableName("c_mp")
@Data
public class CMp extends Model<CMp> {

    private Integer id;
    //计量点编号
    private String mpNo;
    //计量点容量
    private Double mpCap;
    //电压等级
    private String voltCode;
    //电价金额
    private Double kwhPrc;
    //电价名称
    private String catPrcName;
    //计算方式
    private String calcMode;
    //定比定量值
    private Double fqrValue;
    //定比扣减标志
    private String frDeductFlag;
    //计量方式
    private String measMode;
    //变损计费标志
    private String tlBillFlag;
    //变损分摊标志
    private String tlShareFlag;
    //线损计费标志
    private String llBillFlag;
    //线损计算方式
    private String llCalcMode;
    //线损分摊标志
    private String llShareFlag;
    //计量点状态
    private String statusCode;
    //台区编号
    private String tgId;
    //台区名称
    private String tgName;
    //线路编号
    private String lineId;
    //线路名称
    private String lineName;
    //接线方式
    private String wiringMode;
    //市场化类型
    private String marketType;

    //终端地址
    private String terminalAddr;
    //受电点编号
    private String powerPointNo;
    //计量点地址
    private String mpAddr;
}
