package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.dfzt.eunm.MeterReadingEnum;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "RunSupplementaryCopy对象", description = "")
public class RunSupplementaryCopy implements Serializable {


    @ApiModelProperty(value = "主键")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "用户编号")
    @TableField("cons_no")
    private String consNo;

    @ApiModelProperty(value = "供电单位编号")
    @TableField("org_no")
    private String orgNo;

    @ApiModelProperty(value = "一般是用户的直接供电管理单位，也可以是大客户管理中心等由于管理原因产生的客户管理单位")
    @TableField("org_name")
    private String orgName;

    @ApiModelProperty(value = "用户的名称，一般等于客户实体中的客户名称，但也允许附加上一些非自然的信息。如 XXX（东城），便于通过用户名称直接识别。")
    @TableField("cons_name")
    private String consName;

    @ApiModelProperty(value = "用户地址")
    @TableField("elec_addr")
    private String elecAddr;

    @ApiModelProperty(value = "抄表段标识,用于表示用电客户所属的抄表段")
    @TableField("mr_sect_no")
    private String mrSectNo;

    @ApiModelProperty(value = "抄表状态，已抄、未抄")
    @TableField("mr_status_code")
    private MeterReadingEnum mrStatusCode;

    @ApiModelProperty(value = "用电客户的用电类别分类引用国家电网公司营销管理代码类集:5110.4 用电类别大工业用电，中小化肥，居民生活用电，农业生产用电，贫困县农业排灌用电")
    @TableField("elec_type_code")
    private String elecTypeCode;

    @ApiModelProperty(value = "用电客户正在使用的合同容量，如暂停客户，在暂停期间其运行容量等于合同容量减去已暂停的容量")
    @TableField("run_cap")
    private BigDecimal runCap;

    @ApiModelProperty(value = "合同约定的本用户的容量")
    @TableField("contract_cap")
    private BigDecimal contractCap;

    @ApiModelProperty(value = "电费年月，此处用于描述抄表年月")
    @TableField("amt_ym")
    private String amtYm;

    @ApiModelProperty(value = "用户一种常用的分类方式，方便用户的管理01高压，02低压非居民，03低压居民")
    @TableField("cons_sort_code")
    private String consSortCode;

    @ApiModelProperty(value = "电源的供电电压等级")
    @TableField("volt_code")
    private String voltCode;

    @ApiModelProperty(value = "抄表计划编号:本实体记录外部唯一标识，产生规则为流水号")
    @TableField("mr_plan_no")
    private String mrPlanNo;

    @ApiModelProperty(value = "抄表方式：引用国家电网公司营销管理代码类集: 5110.31 电能计量抄表方式/采集方式分prop_type_id = 'mr_mode'")
    @TableField("mr_mode_code")
    private String mrModeCode;

    @ApiModelProperty(value = "例日")
    @TableField("mr_day")
    private String mrDay;

    @ApiModelProperty(value = "运行状态")
    @TableField("run_status_code")
    private String runStatusCode;

    @ApiModelProperty(value = "异常抄表类别：计量异常、门闭、违约用电、窃电、翻转、倒转 、倒转且翻转。")
    @TableField("excp_type_code")
    private int excpTypeCode;

    @ApiModelProperty(value = "抄表员-台区经理")
    @TableField("arc_emp_name")
    private String arcEmpName;

    @ApiModelProperty(value = "创建时间")
    @TableField("create_time")
    private String createTime;
}
