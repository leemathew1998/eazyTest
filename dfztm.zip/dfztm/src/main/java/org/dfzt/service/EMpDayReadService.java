package org.dfzt.service;


import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.EMpDayRead;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
public interface EMpDayReadService extends IService<EMpDayRead> {

}
