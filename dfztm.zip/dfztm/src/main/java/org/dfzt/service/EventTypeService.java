package org.dfzt.service;

import org.dfzt.entity.po.EventType;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/6/20
 * @Version: 1.00
 */
public interface EventTypeService {
    int insertSelective(EventType eventType);//存到事件表中

    Integer selectType1Byplatid(String tgId);//根据事件类型为1的查询1的个数
    Integer selectType2Byplatid(String tgId);//根据事件类型为2的查询1的个数
    Integer selectType3Byplatid(String tgId);//根据事件类型为3的查询1的个数
    Integer selectType4Byplatid(String tgId);//根据事件类型为4的查询1的个数
    Integer selectType5Byplatid(String tgId);//根据事件类型为5的查询1的个数
    Integer selectType6Byplatid(String tgId);//根据事件类型为6的查询1的个数

    List<EventType> selectType1(String tgId);//点击查询类型1的详情
    List<EventType> selectType2(String tgId);//点击查询类型2的详情
    List<EventType> selectType3(String tgId);//点击查询类型3的详情
    List<EventType> selectType4(String tgId);//点击查询类型4的详情
    List<EventType> selectType5(String tgId);//点击查询类型5的详情
    List<EventType> selectType6(String tgId);//点击查询类型6的详情
}
