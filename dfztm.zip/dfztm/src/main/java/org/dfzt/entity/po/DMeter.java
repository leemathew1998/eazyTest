package org.dfzt.entity.po;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class DMeter implements Serializable {
    private Long meterId;

    private String areaCode;

    private String prOrg;

    private String belongDept;

    private Long contractId;

    private Long rcvId;

    private String barCode;

    private String lotNo;

    private String assetNo;

    private String madeNo;

    private String sortCode;

    private String typeCode;

    private String modelCode;

    private String wiringMode;

    private String voltCode;

    private String ratedCurrent;

    private String overloadFactor;

    private String apPreLevelCode;

    private String rpPreLevelCode;

    private BigDecimal meterDigits;

    private BigDecimal tsDigits;

    private String constCode;

    private String rpConstant;

    private String manufacturer;

    private Date madeDate;

    private BigDecimal eqipPrc;

    private Integer selfFactor;

    private String bothWayCalc;

    private String prepayFlag;

    private String multirateFalg;

    private String demandMeterFlag;

    private String harmonicMeasFalg;

    private String ccPreventFlag;

    private String pulseConstantCode;

    private String prPulseConstantCode;

    private String pulseAmplitudeCode;

    private String pulseSortCode;

    private String freqCode;

    private String conMode;

    private String readingTypeCode;

    private String meterUsage;

    private String measTheory;

    private String bearingStruc;

    private String ci;

    private String carrierWave;

    private String congealFlag;

    private String relayJoint;

    private String elecMeasDispFlag;

    private String vlFlag;

    private String clFlag;

    private String antiPhaseFlag;

    private String superPowerFlag;

    private String loadCurveFlag;

    private String poweroffMrFlag;

    private String infraredFlag;

    private String docTypeCode;

    private Date latestChkDate;

    private Date instDate;

    private Date rmvDate;

    private Integer rotateCycle;

    private String discardReason;

    private Date descardDate;

    private String prCode;

    private String handoverDept;

    private Date handoverDate;

    private String curStatusCode;

    private String borrowFlag;

    private String newFlag;

    private String erpBatchNo;

    private String remark;

    private Long whId;

    private Long whAreaId;

    private Long storeAreaId;

    private Long storeLocId;

    private Date docCreateDate;

    private String boxBarCode;

    private String docCreatorNo;

    private String storeNo;

    private String baudrateCode;

    private String meterCloseMode;

    private String registerMode;

    private String dispMode;

    private String hardVer;

    private String softVer;

    private String commProtCode;

    private Integer rs485RouteQty;

    private String commMode;

    private String attachequipTypeCode;

    private String backReason;

    private String madeStandard;

    private String useGroup;

    private String workType;

    private String productId;

    private String sampleType;

    private String meterKind;

    private String projectNo;

    private String priceType;

    private Long carrierWaveId;

    private String prcCode;

    private String catPrcName;

    private BigDecimal kwhPrc;

    private Long paraVn;

    private String freezeFalg;

    private String specCode;

    private String attachequipSortCode;

    private Long id;

    private BigDecimal prElecCharge;

    private String isSupportMoudle;

    private String bindMoudleFlag;

    private Long extendElecCode;

    private String remotePowerOn;

}