package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.vo.OverhaulInfor;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Repository
public interface OverhaulInforMapper extends BaseMapper<OverhaulInfor> {
    int insertOverhaul(OverhaulInfor overhaulInfor);//新增检修信息

    OverhaulInfor selectOne(String workOrderNo);//根据工单编号查看检修处理信息
}
