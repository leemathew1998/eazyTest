package org.dfzt.service.impl;

import org.springframework.stereotype.Service;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.mapper.SPowerViolateStealMapper;
import org.dfzt.entity.po.SPowerViolateSteal;
import org.dfzt.service.SPowerViolateStealService;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@Service
public class SPowerViolateStealServiceImpl extends ServiceImpl<SPowerViolateStealMapper, SPowerViolateSteal> implements SPowerViolateStealService{

}
