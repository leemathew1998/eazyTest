package org.dfzt.service;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.vo.SuperiorSensitivity;

import java.util.List;
import java.util.Map;

/**
 * (SuperiorSensitivity)表服务接口
 *
 * @author makejava
 * @since 2022-10-27 11:24:50
 */
public interface SuperiorSensitivityService extends IService<SuperiorSensitivity> {
    List<SuperiorSensitivity> selectAll(Map map);

    LambdaQueryWrapper wrapper(String str);

}
