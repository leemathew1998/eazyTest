package org.dfzt.entity.po;


import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.dfzt.eunm.WorkOrderStatusEnum;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * (SuperiorWorkOrder)表实体类
 *
 * @author makejava
 * @since 2022-07-11 14:51:01
 */
@SuppressWarnings("serial")
@TableName("superior_work_order")
@Data
public class
SuperiorWorkOrder extends Model<SuperiorWorkOrder> {
    private Integer id;
    //工单id

    private String workOrderNo;
    //工单来源
    @Excel(name = "工单来源",orderNum = "1",width = 20)
    private String workOrderSource;
    //95598中的申请编号
    @Excel(name = "工单编号",orderNum = "2",width = 20)
    private String appNo;
    //95598中的业务类型
    @Excel(name = "业务类型",orderNum = "3",width = 20)
    private String busiTypeCode;
    //95598中的业务子类型
    @Excel(name = "业务子类型",orderNum = "4",width = 20)
    private String busiSubType;
    //联系人
    @Excel(name = "联系人",orderNum = "5",width = 20)
    private String contactName;
    @Excel(name = "供电单位名称",orderNum = "13",width = 20)
    private String orgName;
    //联系地址
    @Excel(name = "联系地址",orderNum = "6",width = 20)
    private String addr;
    //联系电话
    @Excel(name = "手机号",orderNum = "7",width = 20)
    private String mobile;
    //主叫电话
    @Excel(name = "主叫号码",orderNum = "8",width = 20)
    private String dialingNumber;
    //95598中的受理时间
    @Excel(name = "受理时间",orderNum = "9",format = "yyyy-MM-dd HH:mm:ss",width = 20)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date handleTime;
    private String tgId;
    private String tgName;
    //95598中的处理状态(00接单分理01服务处理02工单受理03接单派工04故障处理05答复用电客户06故障调度07工单审核08归档)
    private String handleStatusCode;
    //台区经理
    @Excel(name = "台区经理",orderNum = "10",width = 20)
    private String tgManager;
    //是否频繁换停电用户，1.是，2.否
    private String whetherOutage;
    //是否敏感用户，1.是，2.否
    private String whetherSensitivity;
    //95598中的受理内容
    @Excel(name = "受理内容",orderNum = "11",width = 20)
    private String acceptContent;
    //工单状态，1.待处理，2.处理中，3.待归档，4.已归档
    @ApiModelProperty("状态")
    private String workOrderStatus;
    //工单创建人
    private String workOrderCreator;
    //工单生成时间
    @Excel(name = "工单日期",orderNum = "12",format = "yyyy-MM-dd HH:mm:ss",width = 20)
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderCtime;
    private String workOrderCtime1;
    //工单耗时
    private String workOrderUtime;
    //工单解决时间
    private Date workOrderStime;
    //工单处理结果
    private String workOrderResult;
    //工单归档时间
    private Date workOrderFtime;
    //处理人
    private String handler;
    //处理人接收时间
    private Date handlerRtime;
    //是连续几天的工单
    private Integer workOrderCycle;
    //历史工单处理人
    private String hworkOrderHandler;
    //历史工单处理人接收工单时间
    private Date hworkOrderHandlerRtime;
    //历史工单处理人转出流转时间
    private Date hworkOrderHandlerTtime;
    private String relationId;
    private String examineStatus;
    private String orgNo;


//    public void setWorkOrderStatus(String workOrderStatus) {
//        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
//    }
}
