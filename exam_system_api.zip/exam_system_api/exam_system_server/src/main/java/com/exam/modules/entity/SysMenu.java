package com.exam.modules.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 菜单表
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.SYS_MENU")
public class SysMenu implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 菜单表id
     */
    @TableId("MENU_ID")
    private Long menuId;

    /**
     * 菜单名称

     */
    @TableField("NAME")
    private String name;

    /**
     * 父菜单id，一级菜单为0

     */
    @TableField("PID")
    private Long pid;

    /**
     * 菜单URL(sys/user)

     */
    @TableField("URL")
    private String url;

    /**
     * 授权（sys:user:add，sys:user:update）逗号分割

     */
    @TableField("PERMS")
    private String perms;

    /**
     * 类型（0：目录，1：菜单，2：按钮）

     */
    @TableField("TYPE")
    private Integer type;

    /**
     * 菜单图标

     */
    @TableField("ICON")
    private String icon;

    /**
     * 排序

     */
    @TableField("ORDER_NUM")
    private Integer orderNum;

    /**
     * 创建人

     */
    @TableField("CREATE_BY")
    private String createBy;

    /**
     * 创建时间

     */
    @TableField("CREATE_TIME")
    private Date createTime;

    /**
     * 更新人

     */
    @TableField("UPDATE_BY")
    private String updateBy;

    /**
     * 更新时间

     */
    @TableField("UPDATE_TIME")
    private Date updateTime;

    /**
     * 授权标识符
    (暂时不用)
     */
    @TableField("CODE")
    private String code;

    /**
     * 子菜单列表
     */
    @JsonInclude(JsonInclude.Include.NON_NULL) //属性值为null的不进行序列化操作
    @TableField(exist = false) //表中没有此字段
    private List<SysMenu> children = new ArrayList<>();

    /**
     * 用在前端判断，当前是目录，菜单还是按钮
     */
    @TableField(exist = false)
    private String value;

    /**
     *是否展开
     */
    @TableField(exist = false)
    private Boolean open;
}
