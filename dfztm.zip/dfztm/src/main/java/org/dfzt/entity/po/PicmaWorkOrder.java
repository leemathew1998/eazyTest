package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName picma_work_order
 */
@TableName(value ="picma_work_order")
@Data
public class PicmaWorkOrder implements Serializable {
    /**
     * 唯一标识
     */
    @TableId(type = IdType.AUTO)
    private Integer id;

    /**
     * 工单编号
     */
    private String workOrderNo;

    /**
     * 申请编号
     */
    private String appNo;

    /**
     * 新换装标识
     */
    private String newReplaceId;

    /**
     * 用户编号
     */
    private String consNo;

    /**
     * 用户名称
     */
    private String consName;

    /**
     * 台区编号
     */
    private String tgNo;

    /**
     * 台区名称
     */
    private String tgName;

    /**
     * 供电单位编号
     */
    private String orgNo;

    /**
     * 供电单位名称
     */
    private String orgName;

    /**
     * 申请类型
     */
    private String appMode;

    /**
     * 工单创建时间
     */
    private Date workOrderCtime;

    /**
     * 工单状态
     */
    private String workOrderStatus;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @TableField(exist = false)
    private Long pageSize;

    @TableField(exist = false)
    private Long pageNo;
}