package org.dfzt.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@RestController
@RequestMapping("/eMpDayRead")
public class EMpDayReadController {

}

