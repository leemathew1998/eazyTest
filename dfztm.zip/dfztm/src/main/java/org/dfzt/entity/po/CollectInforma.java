package org.dfzt.entity.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

//采集异常
@Data
public class CollectInforma implements Serializable {
    private Integer id;
    @Excel(name = "上级供电单位",orderNum = "1")
    private String upOrgName;
    @Excel(name = "供电单位",orderNum = "2")
    private String orgName;
    @Excel(name = "用户编码",orderNum = "3")
    private String consNo;
    @Excel(name = "用户名称",orderNum = "4")
    private String consName;
    @Excel(name = "异常数据",orderNum = "5")
    private String abnormalData;
    @Excel(name = "电能表资产号",orderNum = "6")
    private String meterAssetNo;
    @Excel(name = "电能表厂家",orderNum = "7")
    private String elecmeterFactory;
    @Excel(name = "终端厂家",orderNum = "8")
    private String terminalFactory;
    @Excel(name = "接线方式",orderNum = "9")
    private String elecmeterContype;
    @Excel(name = "台区编号",orderNum = "10")
    private String tgId;
    @Excel(name = "台区名称",orderNum = "11")
    private String tgName;
    @Excel(name = "综合倍率",orderNum = "12")
    private String tFactor;
    @Excel(name = "正向有功总",orderNum = "13")
    private BigDecimal papE;
    @Excel(name = "尖",orderNum = "14")
    private BigDecimal rateOne;
    @Excel(name = "峰",orderNum = "15")
    private BigDecimal rateTwo;
    @Excel(name = "平",orderNum = "16")
    private BigDecimal rateThree;
    @Excel(name = "谷",orderNum = "17")
    private BigDecimal rateFour;
    @Excel(name = "反向无功总",orderNum = "18")
    private BigDecimal rrpE;
    @Excel(name = "正向无功总",orderNum = "19")
    private BigDecimal prpE;
    @Excel(name = "反向有功总",orderNum = "20")
    private BigDecimal rapE;
    @Excel(name = "一象限无功",orderNum = "21")
    private BigDecimal rp1R;
    @Excel(name = "二象限无功",orderNum = "22")
    private BigDecimal rp2R;
    @Excel(name = "三象限无功",orderNum = "23")
    private BigDecimal rp3R;
    @Excel(name = "四象限无功",orderNum = "24")
    private BigDecimal rp4R;
    @Excel(name = "用电地址",orderNum = "25")
    private String elecAddr;
    @Excel(name = "终端地址",orderNum = "26")
    private String terminalAddr;
    @Excel(name = "上送时间",orderNum = "27")
    private Date recTime;
    @Excel(name = "终端抄表时间",orderNum = "28")
    private Date statDate;
    @Excel(name = "测量点号",orderNum = "29")
    private String mpSn;
    @Excel(name = "抄表段编号",orderNum = "30")
    private String mrSectNo;
    @Excel(name = "终端资产号",orderNum = "31")
    private String tmnlAssetNo;
    @Excel(name = "抄表员信息",orderNum = "32")
    private String readerName;

    private String synchro;

    private String synchroDep;

    private Date synchroTime;

    private String synchroMode;
    @Excel(name = "用户类型",orderNum = "33")
    private String consType;

    private Date createTime;
    @Excel(name = "台区经理",orderNum = "34")
    private String tgManager;
    @Excel(name = "用户电话",orderNum = "35")
    private String mobile;

    private String colSign;
    @Excel(name = "条形码号",orderNum = "36")
    private String elecmeterCode;
    private String userType;

}