package com.exam.config.security.handler;

import cn.hutool.extra.servlet.ServletUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.exam.config.redis.RedisService;
import com.exam.modules.entity.SysLog;
import com.exam.modules.entity.SysUser;
import com.exam.modules.service.ISysLogService;
import com.exam.modules.service.ISysUserService;
import com.exam.modules.utils.JwtUtils;
import com.exam.modules.utils.LoginResult;
import com.exam.modules.utils.ResultCode;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Objects;

/**
 * @Author dyy
 * @Date 2022/10/28 10:11
 * @PackageName:com.exam.config.security.handler
 * @ClassName: LoginSuccessHandler
 * @Description: TODO 登录认证成功处理器类
 * @Version 1.0
 */
@Component
public class LoginSuccessHandler implements AuthenticationSuccessHandler {

    @Resource
    private JwtUtils jwtUtils;
    @Resource
    private RedisService redisService;
    @Autowired
    private ISysLogService sysLogService;
    @Resource
    private ISysUserService sysUserService;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
                                        Authentication authentication) throws IOException, ServletException {
        //设置相应的编码格式
        response.setContentType("application/json;charset=utf-8");
        //获取输出流
        ServletOutputStream outputStream = response.getOutputStream();
        //获取当前登录用户信息
        SysUser user = (SysUser) authentication.getPrincipal();
        System.out.println(user+"============");
        // 记录登录日志
        QueryWrapper<SysUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("USERNAME",user.getUsername());
        queryWrapper.eq("PASSWORD",user.getPassword());
        //根据用户名和密码查询用户id
        SysUser user1 = sysUserService.getOne(queryWrapper);
        //记录日志（新增）
        SysLog loginLog = new SysLog();
        loginLog.setUserId(user1.getUserId());
        loginLog.setLogIp( ServletUtil.getClientIP(Objects.requireNonNull(( (ServletRequestAttributes)
                RequestContextHolder.getRequestAttributes()).getRequest()), ""));
        loginLog.setUserName(user.getUsername());
        loginLog.setStatus(0);
        loginLog.setLoginTime(new Date());
        loginLog.setRemark(String.format("username:%s; pass:%s; message:%s", user.getUsername(), user.getPassword(), "验证通过"));
        sysLogService.save(loginLog);

        //添加登录时间
        user.setLastLoginTime(new Date());
        sysUserService.updateById(user);
        //生成token
        String token = jwtUtils.generateToken(user);
        //设置token签名密钥及过期时间
        long expireTime = Jwts.parser()//获取DefaultJwtParser对象
                .setSigningKey(jwtUtils.getSecret()) //设置签名的密钥
                .parseClaimsJws(token.replace("jwt_", ""))
                .getBody().getExpiration().getTime();//获取token过期时间
        //创建登录结果对象
        LoginResult loginResult = new LoginResult(user.getUserId(),
                ResultCode.SUCCESS,token,expireTime);

        //将对象转换成JSON格式,并消除循环引用
        String result = JSON.toJSONString(loginResult, SerializerFeature.DisableCircularReferenceDetect);

        outputStream.write(result.getBytes(StandardCharsets.UTF_8));
        outputStream.flush();
        outputStream.close();

        //把生成的token存到redis
        String tokenKey = "token_"+token;
        redisService.set(tokenKey,token,jwtUtils.getExpiration() / 1000);
    }
}
