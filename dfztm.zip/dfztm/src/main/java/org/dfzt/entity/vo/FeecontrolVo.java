package org.dfzt.entity.vo;

import lombok.Data;
import oracle.security.crypto.core.MAC;

/**
 * @Date:2023/2/25-12:55
 * @User:chengchuanlin
 * @Name:FeecontroVo
 * @Message:
 */
@Data
public class FeecontrolVo {
    private String ctrlId;
    private String tacticDetId;
    private String ctrlBatchId;
    private String orgNo;
    private String consNo;
    private String ctrlType;
    private String cpNo;
    private String meterId;
    private String mpId;
    private String remoteType;
    private String remoteOpr;
    private String remoteDate;
    private String remoteRslt;
    private String remoteRtDate;
    private String remark;
    private String terminalId;
    private String switchNo;
    private String switchFlag;
    private String macMoveStatus;
    private String prrtType;
    private String noticeCjDate;
    private String sourceChangeTime;
    private String targetWriteTime;
}
