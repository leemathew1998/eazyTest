package org.dfzt.util;

import java.math.BigDecimal;

public class BigDecimalUtil {
    public static BigDecimal nonNull(BigDecimal collectInforma) {
        return collectInforma == null ? BigDecimal.ZERO : collectInforma;
    }

    public static BigDecimal notNull(BigDecimal b) {
        return b == null ? BigDecimal.ZERO : b;
    }
}
