package org.dfzt.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.PicmaWorkOrder;
import org.dfzt.service.PicmaWorkOrderService;
import org.dfzt.mapper.PicmaWorkOrderMapper;
import org.springframework.stereotype.Service;

/**
* @author 李木
* @description 针对表【picma_work_order】的数据库操作Service实现
* @createDate 2023-05-30 09:41:22
*/
@Service
public class PicmaWorkOrderServiceImpl extends ServiceImpl<PicmaWorkOrderMapper, PicmaWorkOrder>
    implements PicmaWorkOrderService{

}




