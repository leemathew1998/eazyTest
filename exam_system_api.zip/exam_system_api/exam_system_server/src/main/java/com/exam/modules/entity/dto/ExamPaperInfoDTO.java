package com.exam.modules.entity.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

/**
 * @Author dyy
 * @Date 2022/11/8 19:34
 * @PackageName:com.exam.modules.entity.dto
 * @ClassName: ExamPaperInfoDTO
 * @Description: TODO
 * @Version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExamPaperInfoDTO {
    //试卷名称
    private String examPaperName;
    //创建人
    private String createBy;
    //创建时间
    private Date createTime;
    //知识分类（1.前端 2.后端 3.设计 4.测试）
    private String knowGory;
    //单选题数量
    private Long singleTnum;
    //多选题数量
    private Long moreTnum;
    //判断题数量
    private Long judgeTnum;
    //简答题数量
    private Long ansTnum;
    //编程题数量
    private Long programTnum;
    //题目id(逗号分割)
    private String tids;
    //题目类型
    private String type1;
    private String type2;
    private String type3;
    private String type4;
    private String type5;
    //总分
    private String sum;
    private String diff;
}
