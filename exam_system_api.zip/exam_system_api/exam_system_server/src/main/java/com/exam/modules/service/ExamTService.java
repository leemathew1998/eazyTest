package com.exam.modules.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.exam.modules.entity.ExamT;
import com.exam.modules.entity.vo.ExamTVo;

/**
 * (ExamT)表服务接口
 *
 * @author makejava
 * @since 2022-11-08 09:58:14
 */
public interface ExamTService extends IService<ExamT> {

    /**
     * 分页查询
     * @param page
     * @param examTVo
     * @return
     */
    IPage<ExamT> findExamTList(IPage<ExamT> page, ExamTVo examTVo);
}

