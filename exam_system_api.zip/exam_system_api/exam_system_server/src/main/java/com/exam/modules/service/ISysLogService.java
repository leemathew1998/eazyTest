package com.exam.modules.service;

import com.exam.modules.entity.SysLog;
import com.baomidou.mybatisplus.extension.service.IService;
import com.exam.modules.entity.vo.LogVo;
import com.exam.modules.entity.vo.UserQueryVo;

import java.util.List;

/**
 * <p>
 * 登录日志 服务类
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface ISysLogService extends IService<SysLog> {

    //登录失败日志信息
    List<LogVo> loglFailure();
}
