package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "CInformation对象", description = "")
public class CInformation implements Serializable {


    @ApiModelProperty(value = "主键")
    @TableId("key_id")
    private String keyId;

    @ApiModelProperty(value = "受电点名称")
    @TableField("ele_name")
    private String eleName;

    @ApiModelProperty(value = "电源数目")
    @TableField("num_of_power_supplies")
    private String numOfPowerSupplies;

    @ApiModelProperty(value = "用户编号")
    private String consNo;

    @ApiModelProperty(value = "受电点编号")
    private String  powerPointNo;

}
