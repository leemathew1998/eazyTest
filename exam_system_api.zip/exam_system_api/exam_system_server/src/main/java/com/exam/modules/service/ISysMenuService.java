package com.exam.modules.service;

import com.exam.modules.entity.SysMenu;
import com.baomidou.mybatisplus.extension.service.IService;
import com.exam.modules.entity.vo.RoleMenuVo;

import java.util.List;

/**
 * <p>
 * 菜单表 服务类
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface ISysMenuService extends IService<SysMenu> {
    /**
     * 根据用户ID查询权限列表
     * @param userId
     * @return
     */
    List<SysMenu> findSysMenuListByUserId(Long userId);

    /**
     * 查询分配权限树列表
     * @param userId
     * @param roleId
     * @return
     */
    RoleMenuVo findMenuTree(Long userId, Long roleId);
}
