package org.dfzt.job;

import org.dfzt.service.CollectInformaService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;


@Component
public class MeterWorkOrderJob extends QuartzJobBean {
    @Autowired
    private CollectInformaService collectWorkOrderInforService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

        //collectWorkOrderInforService.meterWorkOrder();
    }
}
