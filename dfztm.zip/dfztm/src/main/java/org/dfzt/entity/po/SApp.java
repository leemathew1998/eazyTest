package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @TableName s_app
 */
@TableName(value ="s_app")
@Data
public class SApp implements Serializable {
    /**
     * 是否储备库项目:01是02否
     */
    private String prFlag;

    /**
     * 电费结算方式:用于区分是否分期结算 01分期结算，02抄表结算
     */
    private String settleMode;

    /**
     * 保安负荷容量:用户保安设施对应负荷容量
     */
    private Integer securityCap;

    /**
     * 中止日期:计划中止日期
     */
    private Date cancelDate;

    /**
     * 删除标识:删除标识
     */
    private Integer delFlag;

    /**
     * 确定申请编号:用于客户申请确认转为正式受理时记录正式受理的申请编号 通过此编号可以关联客户申请确定工作单和正式受理的工作单
     */
    private String relaAppCode;

    /**
     * 当前时间:当前时间
     */
    private String extendCurrentTs;

    /**
     * 供电电压:用电客户的供电电压等级代码，多路电源时取电压等级最高的供电电压等级代码 引用《国家电网公司信息分类与代码体系－综合代码类集－电压等级代码表》
     */
    private String voltCode;

    /**
     * 近期用电容量:此属性针对用电大项目前期咨询业务，表示用电大项目预计的近期用电容量
     */
    private Integer stUpq;

    /**
     * 是否可开放容量:01是02否
     */
    private String openCapFlag;

    /**
     * 是否三零服务 1是，0否:是否三零服务 1是，0否
     */
    private String isThreezero;

    /**
     * 审计标识:审计标识
     */
    private String extendOpPosition;

    /**
     * 抄表难度系数:用于表示用电客户的抄表难度情况，用于抄表员的工作量管理。可根据各地情况确定。如住在高层的居民，可能是1.1,住在平房的居民，可能是0.8。
     */
    private String mrdFactorCode;

    /**
     * 用户名称:用户的名称，一般等于客户实体中的客户名称，但也允许附加上一些非自然的信息。如XXX（东城），便于通过用户名称直接识别。
     */
    private String consName;

    /**
     * 容量情况:容量情况
     */
    private String capCase;

    /**
     * 申请原因:客户申请此业务原因描述。如对不装表临时用电延期业务申请时候提出的延期原因的记录，对提出申请校验业务的原因记录等。
     */
    private String reason;

    /**
     * 储备库项目退库标志:01在库02退库申请中03已退库
     */
    private String rtFlag;

    /**
     * 是否需答复:是否需答复
     */
    private String replyFlag;

    /**
     * 申请执行止日期:变更用电时提出的申请业务的执行止日期，如对暂拆业务是用电客户申请时提出的计划复装日期。
     */
    private Date endDate;

    /**
     * 客户标识:客户的唯一标识，变更的时候用于对应客户子域中的客户和申请客户自然信息中的客户信息
     */
    private Integer custId;

    /**
     * 是否分期:是否分期(0：否1：是)
     */
    private String staFlag;

    /**
     * 是否风险类用户:是,否:是否风险类用户:是,否
     */
    private String riskUserFlag;

    /**
     * 偏移量:偏移量
     */
    private Integer extendPos;

    /**
     * 工单编号:工单编号
     */
    private String tmpUseAppNo;

    /**
     * 不能受理原因:办理客户申请确定业务时候的不能受理的原因
     */
    private String refuseReason;

    /**
     * 抄表段编号:抄表段编号，引用国家电网公司营销管理代码类集:5110.7抄表段编号规则。
     */
    private String mrSectNo;

    /**
     * 用户分类:用户一种常用的分类方式，方便用户的管理 01高压，02低压非居民，03低压居民
     */
    private String consSortCode;

    /**
     * 票据类型:用电客户每月电费默认打印的票据类型 引用国家电网公司营销管理代码类集:5110.107票据类型 普通发票，增值税发票，收据，无
     */
    private String noteTypeCode;

    /**
     * 重点项目标签:重点项目标签
     */
    private String importantPrjFlag;

    /**
     * 此属性针对以下情况设计 减容期满后的用户以及新装、增容用户，二年内不得申办减容或暂停。如确需继续办理减容或暂停的，减少或暂停部分容量的基本电费应按百分之五十计算收取 本属性记录继续减容或暂停到期日期，到期日期后变动容量则不生效了，仍按铭牌容量收取基本电费。:此属性针对以下情况设计 减容期满后的用户以及新装、增容用户，二年内不得申办减容或暂停。如确需继续办理减容或暂停的，减少或暂停部分容量的基本电费应按百分之五十计算收取 本属性记录继续减容或暂停到期日期，到期日期后变动容量则不生效了，仍按铭牌容量收取基本电费。
     */
    private Date dueDate;

    /**
     * 申请合同容量:申请合同容量
     */
    private Integer appContractCap;

    /**
     * 转入合同容量:此属性是针对合同容量发生转移类业务，用于表示其他用电客户转入到本用电客户的合同容量，如并户的时候，被并户转入到并入户的合同容量。
     */
    private Integer shiftInCap;

    /**
     * 申请方式:提出用电申请的方式 01营业厅、0295598、03服务平台
     */
    private String appMode;

    /**
     * 申请编号:工作单的外部唯一标识，引用国家电网公司营销管理代码类集:5110.48业务受理编号规则
     */
    private String appNo;

    /**
     * 申请合同容量:申请增加或减少的合同容量
     */
    private Integer contractCap;

    /**
     * 生产班次:用电客户的生产班次分类 引用国家电网公司营销管理代码类集:5110.6用电客户生产班次代码 单班，二班，三班，连续生产
     */
    private String shiftNo;

    /**
     * 申请执行止日期:申请执行止日期
     */
    private Integer runCap;

    /**
     * 转出合同容量:此属性是针对合同容量发生转移类业务，用于表示用电客户转出给其他用电客户的合同容量，如分户的时候，原户转出给分出户的合同容量。
     */
    private Integer shiftOutCap;

    /**
     * 抄表段编号:抄表段编号
     */
    private String orgNo;

    /**
     * 进展情况:进展情况
     */
    private String marchCase;

    /**
     * 申请执行起日期:变更用电时提出的申请业务的执行起日期，如对暂拆业务是用电客户申请时提出的要求暂拆日期。
     */
    private Date bgnDate;

    /**
     * 用户的首次送电日期:用户的首次送电日期
     */
    private Date psDate;

    /**
     * 原有运行容量:用电客户变更用电运行容量，新增客户运行容量等于合同容量，发生暂停等业务后运行容量才不等于合同容量
     */
    private Integer orgnRunCap;

    /**
     * 增值税标识:增值税标识
     */
    private Integer vatId;

    /**
     * 电力用途:预期用电的电力的用途描述。用电大项目前期咨询需要填写的内容。
     */
    private String powerUsage;

    /**
     * 储备项目申请编号:储备项目申请编号
     */
    private String strAppNo;

    /**
     * 临时缴费关系号:方便收费操作，用户间建立的松散的缴费关系的标识，可根据此编号缴费，系统显示该编号的所有客户欠费记录，但用户间不能互相共用余额
     */
    private String tmpPayRelaNo;

    /**
     * 申请编号:申请编号
     */
    private String specReadFlag;

    /**
     * 是否受理:办理客户申请确定业务时候表示申请是否能被受理 01正式受理，02暂不能受理
     */
    private String handleFlag;

    /**
     * 自定义查询号:存储客户提供的自己熟悉的一串标识码，客户通过各种服务渠道可以通过这个查询号来查询自己用电的信息，如客户有多个用电地址，可提供不同的查询号
     */
    private String custQueryNo;

    /**
     * 申请运行容量:申请增加或减少的运行容量，主要处理合同容量不变，但实际运行容量要求减少的业务，如暂停或恢复，记录要求增加或减少的运行容量
     */
    private Integer appRunCap;

    /**
     * 申请变更内容:申请变更的内容描述信息 如批量更改线路台区时候申请更改的具体内容，线路改成哪条，台区改成哪个等
     */
    private String content;

    /**
     * 高耗能行业类别:依据国家最新的高耗能行业划分
     */
    private String hecIndustryCode;

    /**
     * 生成日期:辅助供电方案的生成日期
     */
    private Date buildDate;

    /**
     * 负荷特点:负荷特点
     */
    private String loadTrait;

    /**
     * 特殊要求:特殊要求
     */
    private String specialDemand;

    /**
     * 用户编号:用电客户的外部标识 引用国家电网公司营销管理代码类集:5110.1用电客户编号规则
     */
    private String consNo;

    /**
     * 收费次数:收费次数
     */
    private Integer chargeNum;

    /**
     * 负荷特性:用户对应负荷特性，包含：一般负荷、连续性负荷
     */
    private String loadFeatureCode;

    /**
     * 催费段编号:催费段编号
     */
    private String remindSectNo;

    /**
     * 风险行业分类:煤矿,非煤矿山,危险化学品,石油化工,煤化工...:风险行业分类:煤矿,非煤矿山,危险化学品,石油化工,煤化工...
     */
    private String riskCategory;

    /**
     * 是否发送至经研院（所）:是否发送至经研院（所）
     */
    private String sendFlag;

    /**
     * 用电地址:用电客户的用电地址
     */
    private String elecAddr;

    /**
     * 用户（投资主体）:用户（投资主体）
     */
    private String consInverst;

    /**
     * 小区新装的项目编号，用于统计数据:小区新装的项目编号，用于统计数据
     */
    private String prjNo;

    /**
     * 计量方式:引用国家电网公司营销管理代码类集:5110.33电能计量方式代码（1高供高计、2高供低计、3低供低计）
     */
    private String measMode;

    /**
     * 申请业务类型:办理客户申请确定业务时候客户要求申请的业务类型。 此属性只处理客户申请确定业务，其他业务时本属性为空，其他业务本身的业务类型保存在流程实例中。 引用国家电网公司营销管理代码类集:5110.47新装、增容及变更用电业务受理类别分类与代码 低压居民新装，低压非居民新装，小区新装，高压新装，装表临时用电
     */
    private String appTypeCode;

    /**
     * 小微企业标志：0 否 1 是:小微企业标志：0 否 1 是
     */
    private String smallBusinessFlag;

    /**
     * 预约换表时间:预约换表时间
     */
    private Date appHandleTime;

    /**
     * 原有合同容量:增容或变更用电时候用电客户原有合同容量
     */
    private Integer orgnContractCap;

    /**
     * 操作类型:操作类型
     */
    private String extendOpType;

    /**
     * 转供标志:标识客户是否是转供相关客户，如果涉及转供，是属于转供户还是被转供户 引用国家电网公司营销管理代码类集:5110.35转供标志分类与代码 无转供，转供户，被转供户
     */
    private String transferCode;

    /**
     * 储备库项目退库日期:退库生效日期
     */
    private Date rtDate;

    /**
     * 是否跨省用户:是否跨省用户
     */
    private String isCrossProvince;

    /**
     * 项目区域:项目区域
     */
    private String prjArea;

    /**
     * 供电单位:供电单位编码，一般是指的用户的直接供电管理单位，也可以是大客户管理中心等由于管理原因产生的客户管理单位
     */
    private String psOrgNo;

    /**
     * 远期用电容量:此属性针对用电大项目前期咨询业务，表示用电大项目预计的远期用电容量
     */
    private Integer longtermCap;

    /**
     * 是否充电桩 1是，0否:是否充电桩 1是，0否
     */
    private String busiTip;

    /**
     * 是否为园区:是否为园区
     */
    private String areaMark;

    /**
     * 要求用电日期:用电申请时客户提出的要求用电日期
     */
    private Date dmdDate;

    /**
     * 项目来源:项目来源
     */
    private String prjSource;

    /**
     * 临时用电到期日期:临时用电用户临时用电的到期日期
     */
    private Date tmpDate;

    /**
     * 申请信息标识:本实体记录的唯一标识，产生规则为流水号
     */
    private Integer appId;

    /**
     * 拟投产时间:拟投产时间
     */
    private Date planTime;

    /**
     * 原用户编号:原用户编号，用于系统升级的时候用户编号重新编号可以在一段时间内继续使用原用户编号查询用户信息
     */
    private String orgnConsNo;

    /**
     * 临时用电标志:表示是否是临时用电的用电客户，且属于哪种临时用电 01装表临时用电，02无表临时用电，03非临时用电
     */
    private String tmpFlag;

    /**
     * 关联园区ID:关联园区ID
     */
    private Integer relaAreaId;

    /**
     * 园区标识:园区标识
     */
    private String areaFlag;

    /**
     * 受理部门:受理申请的供电企业的部门代码
     */
    private String handleDeptNo;

    /**
     * 主申请信息标识:对于分户或并户等一个工作有多个用户申请的情况，主申请信息标识表示和关联哪个是主申请信息标识。 如分户，原户为主申请信息标识，其他户的主申请信息标识则为原户的申请信息标识
     */
    private Integer mainAppId;

    /**
     * 储备库项目联系人信息:储备库项目联系人信息
     */
    private String contactRemark;

    /**
     * 受理时间:受理申请的时间
     */
    private Date handleTime;

    /**
     * 负荷性质:负荷的重要程度分类 引用国家电网公司营销管理代码类集:5110.44负荷类别分类与代码 一类，二类，三类
     */
    private String lodeAttrCode;

    /**
     * 城乡类别:城乡类别：01城市、02农村、03特殊边远地区
     */
    private String urbanRuralFlag;

    /**
     * 行业分类:用电客户的行业分类代码 引用国标GB/T4754-2002
     */
    private String tradeCode;

    /**
     * 厂休日:周休日通过数字连续表示周休哪几天，类似于飞机航班日期表示，如1.2.3,表示星期一星期二和星期三休息。
     */
    private String holiday;

    /**
     * 风险类型:高危用户，重要用户，维稳敏感用户，重点保电用户:风险类型:高危用户，重要用户，维稳敏感用户，重点保电用户
     */
    private String riskType;

    /**
     * 申请备注:申请的其他需要说明的信息
     */
    private String remark;

    /**
     * 电费通知方式:用户每月电费的通知方式 引用国家电网公司营销管理代码类集:5110.57催费方式分类与代码 短信，通知单，电话，传真，E-MAIL等
     */
    private String notifyMode;

    /**
     * 合计合同容量:合计合同容量对应客户核心模型中的用电客户的合同容量 合计合同容量的计算公司分三种情况： 增减容时：合计合同容量＝申请合同容量+原有合同容量＋转入合同容量－转出合同容量 分户的分出户，并户的并入户：合计合同容量＝原有合同容量＋转入合同容量 分户的原户，并户的被并户：合计合同容量＝原有合同容量－转出合同容量
     */
    private Integer tContractCap;

    /**
     * 市场化属性分类:市场化属性分类
     */
    private String marketPropSort;

    /**
     * 知识状态:知识状态，由标准代码表取得。如： 01正常 02停用 03过期 。。。
     */
    private String statusCode;

    /**
     * 操作状态:操作状态
     */
    private String operateStatus;

    /**
     * 合计运行容量:合计运行容量＝申请运行容量＋原有运行容量
     */
    private Integer tRunCap;

    /**
     * 用电类别:用电客户的用电类别分类 引用国家电网公司营销管理代码类集:5110.4用电类别 大工业用电，中小化肥，居民生活用电，农业生产用电，贫困县农业排灌用电
     */
    private String elecTypeCode;

    /**
     * 客户经理:客户经理
     */
    private String customerManager;

    /**
     * 业务子类:此属性针对减容、过户、改类业务，表明其业务子类 01永久性减容02临时性减容 21101普通过户 21102实名通电 21501普通改类 21502基本电价计费方式变更 21503取消基本电价计费方式变更 21504调整最大需量核定值 21505居民峰谷变更
     */
    private String permenantReduceFlag;

    /**
     * 重要性等级:用户重要性等级：特级、一级、二级、临时
     */
    private String prioCode;

    /**
     * HDFS路径:HDFS路径
     */
    private String extendSource;

    /**
     * 系统时间:系统时间
     */
    private String extendOpTs;

    /**
     * 用户标识:用电客户的唯一标识，变更的时候用于对应客户子域中的用电客户
     */
    private Integer consId;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}