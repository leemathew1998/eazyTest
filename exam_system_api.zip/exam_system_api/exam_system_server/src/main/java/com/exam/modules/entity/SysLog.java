package com.exam.modules.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 登录日志
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.SYS_LOG")
public class SysLog implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 登录日志id
     */
    @TableId(value = "LONGIN_ID",type = IdType.ASSIGN_ID)
    private Long longinId;

    /**
     * 登录时间

     */
    @TableField("LOGIN_TIME")
    private Date loginTime;

    /**
     * 登录人

     */
    @TableField("USERNAME")
    private String userName;

    /**
     * 登录人id
     */
    @TableField("USER_ID")
    private Long userId;

    /**
     * 备注
     */
    @TableField("REMARK")
    private String remark;

    /**
     * 登录IP
     */
    @TableField("LOG_IP")
    private String logIp;

    /**
     * 登录状态
     */
    @TableField("STATUS")
    private Integer status;

    @TableField(exist = false)
    private String theGroup;

}
