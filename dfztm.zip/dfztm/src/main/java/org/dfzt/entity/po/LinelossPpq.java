package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/19
 * @Version: 1.00 供电量值
 */
@Data
public class LinelossPpq {
    private Integer id;
    //用户编号
    private String consNo;
    //用户名称
    private String consName;
    //用户类型
    private String consType;
    //用电地址
    private String elecAddr;
    //终端地址
    private String terminalAddr;
    //总分表标识
    private String totalPointsIdent;
    //数据时间
    private Date dataDate;
    //起码值（正向有功总）
    private BigDecimal startpapE;
    //止码值（正向有功总）
    private BigDecimal endpapE;
    //电量值（正向有功总）
    private BigDecimal papE;
    //起码值（反向有功总）
    private BigDecimal startrapE;
    //止码值（反向有功总）
    private BigDecimal endrapE;
    //电量值（反向有功总）
    private BigDecimal rapE;
    //供电量值
    private BigDecimal tgPpq;
    //主用途类型
    private String usageTypeCode;
    //综合倍率
    private BigDecimal tFactor;
    //CT
    private String ct;
    //PT
    private String pt;
    //电表资产号
    private String meterAssetNo;
    //采集器资产号
    private String fmrAssetNo;
    //测量点号
    private String mpSn;
}
