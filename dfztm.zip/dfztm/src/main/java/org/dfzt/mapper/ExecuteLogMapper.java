package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.dto.ExecuteLog;
import org.dfzt.entity.po.AcCounty;

import java.util.List;


public interface ExecuteLogMapper extends BaseMapper<ExecuteLog> {

}

