package org.dfzt.service;

import org.dfzt.entity.po.*;

import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/6
 * @Version: 1.00
 */
public interface AchievementsManagerService {
    AchievementsManager selectByTgno(String tgno);//根据台区编号查询出对应台区经理的绩效考核
    /**
     * 查询全部旗县
     * @return
     */
    List<AcCounty> selectAcCounty(Map map);

    /**
     * TODO 采集相关绩效
     */
    void selectdayPoint(String tgManager);//根据台区经理查询工单表中出现的次数并且算出得分

    AcManager selectdayRP(String id);//根据台区经理id查询出某个日期的所有分数
    //int updateSuccRP(String tgManager, BigDecimal colSuccR, int colSuccP);//修改该台区经理的采集成功率和积分
    AcStation selectStaPoint(Integer id);//根据营业站id查询具体营业站信息
    List<CollectWorkOrder> managerWorkOrder(String tgManager);//根据台区经理名称查询该台区经理采集工单表具体工单信息


    /**
     * TODO 线损相关绩效
     * @param tgManager
     */
    void selectLowLineloss(String tgManager);//低压线损率 --根据台区经理算出管辖台区的损耗电量/该台区的供电量

    List<LinelossWorkOrder> managerLineWorkOrder(String tgManager);//根据台区经理名称查询该台区经理线损治理工单表具体工单信息
}
