package com.exam.modules.controller;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.modules.entity.ExamInfo;
import com.exam.modules.entity.SysUser;
import com.exam.modules.entity.vo.ExamInfoVo;
import com.exam.modules.entity.vo.ExamManageVo;
import com.exam.modules.mapper.ExamInfoMapper;
import com.exam.modules.service.ExamInfoService;
import com.exam.modules.service.ISysUserService;
import com.exam.modules.utils.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 考试信息(ExamInfo)表控制层
 *
 * @author dyy
 * @since 2022-11-09 15:05:40
 */
@Slf4j
@RestController
@RequestMapping("api/examInfo")
public class ExamInfoController{

    @Resource
    private ExamInfoMapper examInfoMapper;
    @Resource
    private ExamInfoService examInfoService;
    @Resource
    private ISysUserService sysUserService;

    //提交是否参加考试
    @PostMapping("isTrue")//api/examInfo/isTrue
    public Result isTrue(@RequestBody ExamInfo examInfo){
        if (examInfoService.isTrue(examInfo)){
            return Result.ok().message("修改成功");
        }
        return Result.error().message("修改失败");
    }

    //提交异常
    @PostMapping("abnormal")//api/examInfo/abnormal
    public Result abnormal(@RequestBody ExamInfo examInfo){
        if (examInfoService.abnormal(examInfo)){
            return Result.ok().message("修改成功");
        }
        return Result.error().message("修改失败");
    }

    //分页查询考试信息
    @PostMapping("selAll")//api/examInfo/selAll
    public Result selAll(@RequestBody ExamManageVo examInfo){
        IPage<ExamInfo> page = new Page<>(examInfo.getPageNo(), examInfo.getPageSize());
        List<ExamInfo> infoList = examInfoService.list();
        for (ExamInfo record : infoList) {
            //根据用户id查姓名
            List<SysUser> sysUsers = sysUserService.list()
                    .stream()
                    .filter(Objects::nonNull)
                    .filter(item -> Objects.equals(item.getUserId(), record.getUserId()))
                    .collect(Collectors.toList());
            //将考生姓名添加在考试信息表中
            for (SysUser sysUser : sysUsers) {
                    UpdateWrapper<ExamInfo> wrapper = new UpdateWrapper<>();
                    wrapper.set("USER_NAME",sysUser.getUsername());
                    wrapper.eq("USER_ID",sysUser.getUserId());
                    examInfoService.update(wrapper);
            }
        }
        IPage<ExamInfo> page1 = examInfoService.selPage(page, examInfo);
        return Result.ok(page1);
    }

    //考试人数分布
    @PostMapping("examPerCount")//api/examInfo/examPerCount
    public Result examPerCount(){
        Map<String,Object> map = new HashMap<>();
        //前端考试人数
        Integer front = examInfoMapper.examPerCount("1");
        //后端考试人数
        Integer after = examInfoMapper.examPerCount("2");
        //设计考试人数
        Integer design = examInfoMapper.examPerCount("3");
        //测试考试人数
        Integer test = examInfoMapper.examPerCount("4");
        map.put("front",front);
        map.put("after",after);
        map.put("design",design);
        map.put("test",test);
        return Result.ok(map);
    }


    //成绩分段人数分布
    @PostMapping("examScoreCount")//api/examInfo/examScoreCount
    public Result examScoreCount(){
        Map<String, List<Integer>> map = new HashMap<>();
        //前端知识分类，成绩分段
        Integer num = examInfoMapper.examScoreCount(0, 60, "1");
        Integer num1 = examInfoMapper.examScoreCount(60, 69, "1");
        Integer num2 = examInfoMapper.examScoreCount(70, 79, "1");
        Integer num3 = examInfoMapper.examScoreCount(80, 89, "1");
        Integer num4 = examInfoMapper.examScoreCount(90, 100, "1");
        List<Integer > front = new ArrayList<>();
        front.add(num);
        front.add(num1);
        front.add(num2);
        front.add(num3);
        front.add(num4);
        //后端知识分类，成绩分段
        Integer num5 = examInfoMapper.examScoreCount(0, 60, "2");
        Integer num6 = examInfoMapper.examScoreCount(60, 69, "2");
        Integer num7 = examInfoMapper.examScoreCount(70, 79, "2");
        Integer num8 = examInfoMapper.examScoreCount(80, 89, "2");
        Integer num9 = examInfoMapper.examScoreCount(90, 100, "2");
        List<Integer > after = new ArrayList<>();
        after.add(num5);
        after.add(num6);
        after.add(num7);
        after.add(num8);
        after.add(num9);
        //设计知识分类，成绩分段
        Integer num10 = examInfoMapper.examScoreCount(0, 60, "3");
        Integer num11 = examInfoMapper.examScoreCount(60, 69, "3");
        Integer num12 = examInfoMapper.examScoreCount(70, 79, "3");
        Integer num13 = examInfoMapper.examScoreCount(80, 89, "3");
        Integer num14 = examInfoMapper.examScoreCount(90, 100, "3");
        List<Integer > design = new ArrayList<>();
        design.add(num10);
        design.add(num11);
        design.add(num12);
        design.add(num13);
        design.add(num14);
        //测试知识分类，成绩分段
        Integer num15 = examInfoMapper.examScoreCount(0, 60, "4");
        Integer num16 = examInfoMapper.examScoreCount(60, 69, "4");
        Integer num17 = examInfoMapper.examScoreCount(70, 79, "4");
        Integer num18 = examInfoMapper.examScoreCount(80, 89, "4");
        Integer num19 = examInfoMapper.examScoreCount(90, 100, "4");
        List<Integer > test = new ArrayList<>();
        test.add(num15);
        test.add(num16);
        test.add(num17);
        test.add(num18);
        test.add(num19);
        //存数据
        map.put("front",front);
        map.put("after",after);
        map.put("design",design);
        map.put("test",test);
        return Result.ok(map);
    }

    //考试查询
    @PostMapping("selectExam")//api/examInfo/selectExam
    public Result selectExam(@RequestBody ExamInfoVo examInfo){
        IPage<ExamInfo> page = new Page<>(examInfo.getPageNo(), examInfo.getPageSize());
        List<ExamInfo> infoList = examInfoService.list();
        for (ExamInfo record : infoList) {
            //根据用户id查姓名
            List<SysUser> sysUsers = sysUserService.list()
                    .stream()
                    .filter(Objects::nonNull)
                    .filter(item -> Objects.equals(item.getUserId(), record.getUserId()))
                    .collect(Collectors.toList());
            //将考生姓名修改在考试信息表中
            for (SysUser sysUser : sysUsers) {
                UpdateWrapper<ExamInfo> wrapper = new UpdateWrapper<>();
                wrapper.set("USER_NAME",sysUser.getUsername());
                wrapper.eq("USER_ID",sysUser.getUserId());
                examInfoService.update(wrapper);
            }
        }
        QueryWrapper<ExamInfo> queryWrapper = new QueryWrapper<>();
        //考试名称
        queryWrapper.like(StrUtil.isNotBlank(examInfo.getExamName()),"EXAM_NAME",examInfo.getExamName());
        //阅卷状态
        queryWrapper.like(StrUtil.isNotBlank(examInfo.getMarkStatus()),"MARK_STATUS",examInfo.getMarkStatus());
        //考试时间
        if (examInfo.getExamBeginTime() !=null && examInfo.getExamEndTime() != null){
            queryWrapper.between("EXAM_TIME",examInfo.getExamBeginTime(),examInfo.getExamEndTime());
        }
        IPage<ExamInfo> page1 = examInfoService.page(page, queryWrapper);

        for (ExamInfo examInfoRecord : page1.getRecords()) {
            ExamInfo examInfo1 = new ExamInfo();
            //应考人数(根据考试id查询)
            long sunNum = Optional.ofNullable(examInfoService.list()).orElse(new ArrayList<>())
                    .stream()
                    .filter(Objects::nonNull)
                    .filter(item -> Objects.equals(item.getExamId(), examInfoRecord.getExamId()))
                    .count();
            log.info("应考人数=="+sunNum);
            //实考人数
            long perNum = Optional.ofNullable(examInfoService.list()).orElse(new ArrayList<>())
                    .stream()
                    .filter(Objects::nonNull)
                    .filter(item -> Objects.equals(item.getExamId(), examInfoRecord.getExamId()))
                    .filter(item -> item.getIsTrue().equals("2"))
                    .count();
            log.info("实考人数=="+perNum);
            //每场考试平均分
            Double avg = Optional.ofNullable(examInfoService.list()).orElse(new ArrayList<>())
                    .stream()
                    .filter(Objects::nonNull)
                    .filter(item -> Objects.equals(item.getExamId(), examInfoRecord.getExamId()))
                    .filter(item -> item.getIsTrue().equals("2"))
                    .map(ExamInfo::getScoreSum)
                    .collect(Collectors.averagingDouble(a -> Double.parseDouble(String.valueOf(a))));
            log.info("每场考试平均分=="+avg);

            examInfo1.setSunNum(sunNum);
            examInfo1.setPerNum(perNum);
            examInfo1.setExamAvg(avg);
            examInfo1 .setExamId(examInfoRecord.getExamId());
            List<ExamInfo> list = new ArrayList<>();
            list.add(examInfo1);
            for (ExamInfo record : page1.getRecords()) {
                list.forEach(s->{
                    if (s.getExamId().equals(record.getExamId())){
                        record.setSunNum(s.getSunNum());
                        record.setPerNum(s.getPerNum());
                        record.setExamAvg(s.getExamAvg());
                    }
                });
            }
        }
        //根据考试id去重
        TreeSet<ExamInfo> collect = page1.getRecords().stream()
                .collect(Collectors.toCollection(
                        () -> new TreeSet<>(Comparator.comparing(a -> a.getExamId()))
                ));
        return Result.ok(collect);
    }

    //根据考试id查询详情
    @PostMapping("examInfo")//api/examInfo/examInfo
    public Result examInfo(@RequestBody Map<String, Object> queryMap){
        return Result.ok(examInfoService.selectExampage(queryMap)).message("查询成功");
    }
}
