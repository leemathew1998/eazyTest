package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 日测量点功率曲线
 */
@Data
public class MdHEMpPowerCurve {


    /**
     * 主键
     */
    private Long id;

    /**
     * 供电单位编号
     */
    private String orgNo;

    /**
     * 数据时间
     */
    private Date dataDate;

    /**
     * 电流
     */
    private Integer ct;

    /**
     * 电压
     */
    private Integer pt;

    /**
     * 数据补全标志
     */
    private Integer mark;

    /**
     * 数据类型
     */
    private Integer dataType;

    /**
     * 数据点标志
     */
    private Integer dataPointFlag;

    /**
     * 数据完整性标志
     */
    private String dataWholeFlag;

    /**
     * 功率
     */
    private BigDecimal p1;

    /**
     * 功率
     */
    private BigDecimal p2;

    /**
     * 功率
     */
    private BigDecimal p3;

    /**
     * 功率
     */
    private BigDecimal p4;

    /**
     * 功率
     */
    private BigDecimal p5;

    /**
     * 功率
     */
    private BigDecimal p6;

    /**
     * 功率
     */
    private BigDecimal p7;

    /**
     * 功率
     */
    private BigDecimal p8;

    /**
     * 功率
     */
    private BigDecimal p9;

    /**
     * 功率
     */
    private BigDecimal p10;

    /**
     * 功率
     */
    private BigDecimal p11;

    /**
     * 功率
     */
    private BigDecimal p12;

    /**
     * 功率
     */
    private BigDecimal p13;

    /**
     * 功率
     */
    private BigDecimal p14;

    /**
     * 功率
     */
    private BigDecimal p15;

    /**
     * 功率
     */
    private BigDecimal p16;

    /**
     * 功率
     */
    private BigDecimal p17;

    /**
     * 功率
     */
    private BigDecimal p18;

    /**
     * 功率
     */
    private BigDecimal p19;

    /**
     * 功率
     */
    private BigDecimal p20;

    /**
     * 功率
     */
    private BigDecimal p21;

    /**
     * 功率
     */
    private BigDecimal p22;

    /**
     * 功率
     */
    private BigDecimal p23;

    /**
     * 功率
     */
    private BigDecimal p24;

    /**
     * 功率
     */
    private BigDecimal p25;

    /**
     * 功率
     */
    private BigDecimal p26;

    /**
     * 功率
     */
    private BigDecimal p27;

    /**
     * 功率
     */
    private BigDecimal p28;

    /**
     * 功率
     */
    private BigDecimal p29;

    /**
     * 功率
     */
    private BigDecimal p30;

    /**
     * 功率
     */
    private BigDecimal p31;

    /**
     * 功率
     */
    private BigDecimal p32;

    /**
     * 功率
     */
    private BigDecimal p33;

    /**
     * 功率
     */
    private BigDecimal p34;

    /**
     * 功率
     */
    private BigDecimal p35;

    /**
     * 功率
     */
    private BigDecimal p36;

    /**
     * 功率
     */
    private BigDecimal p37;

    /**
     * 功率
     */
    private BigDecimal p38;

    /**
     * 功率
     */
    private BigDecimal p39;

    /**
     * 功率
     */
    private BigDecimal p40;

    /**
     * 功率
     */
    private BigDecimal p41;

    /**
     * 功率
     */
    private BigDecimal p42;

    /**
     * 功率
     */
    private BigDecimal p43;

    /**
     * 功率
     */
    private BigDecimal p44;

    /**
     * 功率
     */
    private BigDecimal p45;

    /**
     * 功率
     */
    private BigDecimal p46;

    /**
     * 功率
     */
    private BigDecimal p47;

    /**
     * 功率
     */
    private BigDecimal p48;

    /**
     * 功率
     */
    private BigDecimal p49;

    /**
     * 功率
     */
    private BigDecimal p50;

    /**
     * 功率
     */
    private BigDecimal p51;

    /**
     * 功率
     */
    private BigDecimal p52;

    /**
     * 功率
     */
    private BigDecimal p53;

    /**
     * 功率
     */
    private BigDecimal p54;

    /**
     * 功率
     */
    private BigDecimal p55;

    /**
     * 功率
     */
    private BigDecimal p56;

    /**
     * 功率
     */
    private BigDecimal p57;

    /**
     * 功率
     */
    private BigDecimal p58;

    /**
     * 功率
     */
    private BigDecimal p59;

    /**
     * 功率
     */
    private BigDecimal p60;

    /**
     * 功率
     */
    private BigDecimal p61;

    /**
     * 功率
     */
    private BigDecimal p62;

    /**
     * 功率
     */
    private BigDecimal p63;

    /**
     * 功率
     */
    private BigDecimal p64;

    /**
     * 功率
     */
    private BigDecimal p65;

    /**
     * 功率
     */
    private BigDecimal p66;

    /**
     * 功率
     */
    private BigDecimal p67;

    /**
     * 功率
     */
    private BigDecimal p68;

    /**
     * 功率
     */
    private BigDecimal p69;

    /**
     * 功率
     */
    private BigDecimal p70;

    /**
     * 功率
     */
    private BigDecimal p71;

    /**
     * 功率
     */
    private BigDecimal p72;

    /**
     * 功率
     */
    private BigDecimal p73;

    /**
     * 功率
     */
    private BigDecimal p74;

    /**
     * 功率
     */
    private BigDecimal p75;

    /**
     * 功率
     */
    private BigDecimal p76;

    /**
     * 功率
     */
    private BigDecimal p77;

    /**
     * 功率
     */
    private BigDecimal p78;

    /**
     * 功率
     */
    private BigDecimal p79;

    /**
     * 功率
     */
    private BigDecimal p80;

    /**
     * 功率
     */
    private BigDecimal p81;

    /**
     * 功率
     */
    private BigDecimal p82;

    /**
     * 功率
     */
    private BigDecimal p83;

    /**
     * 功率
     */
    private BigDecimal p84;

    /**
     * 功率
     */
    private BigDecimal p85;

    /**
     * 功率
     */
    private BigDecimal p86;

    /**
     * 功率
     */
    private BigDecimal p87;

    /**
     * 功率
     */
    private BigDecimal p88;

    /**
     * 功率
     */
    private BigDecimal p89;

    /**
     * 功率
     */
    private BigDecimal p90;

    /**
     * 功率
     */
    private BigDecimal p91;

    /**
     * 功率
     */
    private BigDecimal p92;

    /**
     * 功率
     */
    private BigDecimal p93;

    /**
     * 功率
     */
    private BigDecimal p94;

    /**
     * 功率
     */
    private BigDecimal p95;

    /**
     * 功率
     */
    private BigDecimal p96;

    /**
     * 数据入库时间
     */
    private Date recTime;

    /**
     * 电表标识
     */
    private Integer meterId;

    /**
     * 数据来源
     */
    private String dataSrc;

    /**
     * 是否有效
     */
    private Integer isValid;
}