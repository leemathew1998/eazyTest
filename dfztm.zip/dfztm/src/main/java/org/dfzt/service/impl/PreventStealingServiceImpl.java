package org.dfzt.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import org.dfzt.entity.po.PreventStealing;
import org.dfzt.mapper.PreventStealingMapper;
import org.dfzt.service.PreventStealingService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/5
 * @Version: 1.00
 */
@Service
public class PreventStealingServiceImpl extends ServiceImpl<PreventStealingMapper, PreventStealing> implements PreventStealingService {

    @Resource
    PreventStealingMapper preventStealingMapper;

    @Override
    public List<PreventStealing> PreventStealingServiceSelect() {
        List<PreventStealing> list = preventStealingMapper.select();
        return list;
    }

    @Override
    public List<PreventStealing> selectNo() {
        List<PreventStealing> no = preventStealingMapper.selectNo();
        return no;
    }

    @Override
    public List<PreventStealing> selectAllStatus(PreventStealing p) {

        List<PreventStealing> allStatus = preventStealingMapper.selectAllStatus(p);

        return allStatus;
    }

    /**
     * 各个状态的数量
     *
     * @return
     */
    @Override
    public List<Map<String, Object>> statusNumber() {
        //1.声明变量
        List<Map<String,Object>> list= Lists.newArrayList();
        Map<String,Object> map = new HashMap<>();
        //2.查询个数
        long count = list().stream().map(PreventStealing::getId).count();
        //3.存入
        map.put("number",count);
        list.add(map);

        return list;
    }
}
