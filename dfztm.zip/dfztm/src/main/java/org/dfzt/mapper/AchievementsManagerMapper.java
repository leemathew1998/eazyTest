package org.dfzt.mapper;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.AchievementsManager;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.ActiveRepairWo;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Repository
public interface AchievementsManagerMapper extends BaseMapper<AchievementsManager> {
    int deleteByPrimaryKey(Integer id);

    int insert(AchievementsManager record);

    int insertSelective(AchievementsManager record);

    AchievementsManager selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(AchievementsManager record);

    int updateByPrimaryKey(AchievementsManager record);

    AchievementsManager selectByTgno(String tgno);//根据台区编号查询出对应台区经理的绩效考核

    //查询台区绩效指标信息
    List<AchievementsManager> achievementinfo();

    /**
     * 查询全部旗县
     * @return
     */
    List<AcCounty> selectAcCounty(Map map);

    /**
     * TODO 采集相关绩效--台区经理
     */
    int updateSuccRP(String tgManager, BigDecimal colSuccR, int colSuccP, String tgNo);//修改该台区经理的采集成功率和积分

    AcManager selectdayRP(String id);//根据台区经理查询出某个日期的所以分数

    AcStation selectStaPoint(Integer id);//根据营业站id查询具体营业站信息

    List<CollectWorkOrder> managerWorkOrder(String tgManager);//根据台区经理名称查询该台区经理工单表具体工单信息
    Integer selectdayPoint(String tgManager);//根据台区经理查询工单表中出现的次数并且算出得分

    List<CollectWorkOrder> selectNoHandle(String tgManager);//根据台区经理查询工单表中未处理的工单数
    List<CollectWorkOrder> selectConfail(String tgManager);//根据台区经理查询工单表中采集失败的工单数
    Integer updateBytgman(AcManager acManager);//根据台区经理来修改各项指标数据

    /**
     * TODO 采集相关绩效--营业站
     */
    int updateSuccSta(String id, BigDecimal colSuccR, int colSuccP, String tgName);//修改该营业站的采集成功率和积分
    Integer updateBytgSta(AcStation acStation);//根据台区经理来修改各项指标数据

    /**
     * TODO 线损相关绩效
     * @param tgManager
     */
    List<LinelossWorkOrder> selectLowLineloss(String tgManager);//低压线损率 --根据台区经理算出管辖台区的损耗电量/该台区的供电量

    List<LinelossWorkOrder> selectHighTgNum(String tgManager);//高损台区占比--查询台区经理线损为6以上的个数

    List<LinelossWorkOrder> selectlowTgNum(String tgManager);//负损台区占比--查询台区经理线损小于等于-1的个数

    List<LinelossWorkOrder> selectEconTgNum(String tgManager);//经济运行台区占比 --线损率在0-4的台区数量

    List<LinelossWorkOrder> selectThreeNoHandle(String tgManager);//高负损台区处理即使率 -- 三天以上未处理的高负损台区工单数

    List<LinelossWorkOrder> managerLineWorkOrder(String tgManager);//根据台区经理名称查询该台区经理线损治理工单表具体工单信息

    List<SuperiorWorkOrder> selectSuperworko(String tgManager);//查找优质服务中的意见和投诉工单

    List<MeterWorkOrder> selectWorkOrder(String tgManager);//16 查询三天以上未处理计量工单数

    List<FeecontrolWorkOrder> selectFeecon1(String tgManager);//13复电时间小于45分钟的工单数

    List<RecycleWorkOrder> selectRecycle11(String tgManager);//电费结零率
    List<MeterWorkOrder> selectMeter12(String tgManager);////配电异常台区次数具体工单详情,同一个台区连续两周出现三相不平衡或低电压

    List<ActiveRepairWo> selectRepairs(String tgManager);
    List<ActiveRepairWo> selectActive(String tgManager);

    List<AcManager> selectTgmanByymd(String username,String ymd);//通过


    //TODO 台区经理日指标
    List<UserRole> selectUserRoleAll();

    Integer selecttgd1(String tgManager,String ymd);//指标1 采集成功率

    Integer selecttgd2(String tgManager,String ymd);//指标2 采集失败未处理工单数



    BigDecimal selectLossMan61(String tgManager,String ymd);//台区经理低压线损率 指标6

    BigDecimal selectLossMan61a(String tgManager,String ymd);//台区经理低压线损率 指标6 详情
    BigDecimal selectLossMan61b(String tgManager,String ymd);//台区经理低压线损率 指标6 详情

    Integer selecttgd8(String tgManager,String ymd);//指标8 高损台区占比
    Integer selecttgd9(String tgManager,String ymd);//指标9 负损台区占比
    Integer selecttgd89(String tgManager,String ymd);//指标89 正常台区占比

    Integer selecttgd11(String tgManager);//三天以上未处理工单数

    Integer selecttgd15(String tgManager,String ymd);//投诉工单数
    Integer selecttgd16(String tgManager,String ymd);//意见工单数

    Integer insertAcman1(AcManager acManager);//

    Integer insertOrgNameNums(OrgNameNums orgNameNums);

    List<OrgNameNums> selectOrgNameNums(String orgNo,String ymd);

    Integer insertAcCity(AcCity acCity);
    Integer insertAcCounty(AcCounty acCounty);//新增旗县所每日绩效
    Integer insertAcStation(AcStation acStation);//新增营业站每日绩效
    Integer insertAcManager(AcManager acManager);//新增台区经理每日绩效

//    @DS("mpgt")
//    List<String> selectAcCountyFromOrg();//查询所有所旗县

    @DS("mpgt")
    List<consTgScm> selectAcCountyFromOrgs();//查询所有所旗县包含单位编号

    @DS("mpgt")
    List<consTgScm> selectAcStationFromOrg();//查询所有所营业站 要改

//    @DS("mpgt")
//    List<consTgScm> selectAcStationFromOrg1();//查询所有所营业站

    @DS("mpgt")
    List<String> selectAcStationFromOrg2(String orgNo);//根据旗县级编号查询该旗县下的营业站


    List<consTgScm> selectAcCountyList();//查询所有所旗县
    List<consTgScm> selectAcStationList();//查询所有营业站
    List<consTgScm> selectAcManagerList();//查询所有台区经理


    List<AcManager> selectAcMans(@Param("orgNo") String orgNo, @Param("ymd")String ymd);
    List<AcStation> selectAcStas(@Param("orgNo") String orgNo, @Param("ymd")String ymd);


    List<CollectWorkOrder> getAcManDetails1(String tgManager,String ymd);//绩效 台区经理 查询采集失败详情
    List<CollectWorkOrder> getAcStaDetails1(String orgName,String ymd);//绩效 营业站 查询采集失败详情
    List<CollectWorkOrder> getAcCouDetails1(String pOrgName,String ymd);//绩效 旗县 查询采集失败详情
    List<CollectWorkOrder> getAcCityDetails1(String orgNo,String ymd);//绩效 市 查询采集失败详情

   // List<AcCounty> selectCouList(@Param("ymd")String ymd);

    Integer selectAcCity1(String ymd);//获取市级采集失败数量
    @DS("mpg")
    Integer selectAllnums();//查询市级所有用户数

    Integer selectAcCityzb2(String ymd);//采集失败处理及时率

    @DS("sele")
    Integer selectFee3(String ymd,String remote);//获取费控两个指标 复电
    @DS("sele")
    Integer selectFee4(String ymd,String remote);//获取费控两个指标 停电

    BigDecimal selectLoss6(String ymd);//低压线损率 指标6
    BigDecimal selectLoss61(String ymd);//低压线损率 指标6

    Integer selectLine8(String ymd);//查询线损大于6的工单数
    Integer selectLine9(String ymd);//查询线损小于-1的工单数
    Integer selectLine10(String ymd);//查询线损0-4之间的工单数

    @DS("mpg")
    Integer selectActgNums();//市总台区数

    BigDecimal selectAcCou11a(String ym);//市级 电费结零率 指标11 电费发行金额
    BigDecimal selectAcCou11b(String ym);//市级 电费结零率 指标11  欠费金额

    Integer selectAc13(String ymd);//市级 查询复电时长小于45的工单数
    Integer selectAc13a(String ymd);//市级 查询复电所有的工单数

    Integer selectAc14tou(String ymd);//市级 投诉数量 指标14
    Integer selectAc14yi(String ymd);//市级 意见数量 指标14

    Integer selectAc16a(String ymd);//市 指标16 所有计量工单数
    Integer selectAc16(String ymd);//市 指标16 所有三天未处理计量工单数
    
}
