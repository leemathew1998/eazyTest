package org.dfzt.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.AcManager;
import org.dfzt.entity.po.AcStation;
import org.dfzt.entity.vo.AcManagerSp;
import org.dfzt.entity.vo.AcStationSp;
import org.dfzt.mapper.AcStationMapper;
import org.dfzt.mapper.FeecontrolWorkOrderMapper;
import org.dfzt.service.AcStationService;
import org.dfzt.util.TimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * (AcStation)表服务实现类
 *
 * @author makejava
 * @since 2022-07-15 15:19:50
 */
@Service("acStationService")
public class AcStationServiceImpl extends ServiceImpl<AcStationMapper, AcStation> implements AcStationService {

    @Autowired
    private AcStationMapper acStationMapper;

    @Resource
    private FeecontrolWorkOrderMapper feecontrolWorkOrderMapper;

    @Override
    public List<AcStation> selectAllStation(String ymd,String orgNo,String id) {
        return acStationMapper.selectAllStation(ymd,orgNo,id);
    }

    @Override
    public List<AcManager> selectByStation(String ymd,String orgNo,String id,String tgManager) {
        return acStationMapper.selectByStation(ymd,orgNo,id,tgManager);
    }

    @Override
    public List<AcStation> selectByCounty(Integer id) {
        return acStationMapper.selectByCounty(id);
    }

    /**
     * 旗县下营业站的采集总数，失败数，成功数
     * @return
     */
    @Override
    public List<Map> selectFailure() {
        List<Map> list = acStationMapper.selectFailure();
        if (list.size() > 0){
            for (int i = 0; i < list.size(); i++) {
                list.get(i).put("caiji",(100 - (long) list.get(i).get("COUNT")));
                list.get(i).put("zongshu",100);
            }
            return list;
        }
        return null;
    }

    /**
     * 工单失败成功数据
     * @param business
     * @return
     */
//    @Override
//    public List<Map> selectBusiness(int business) {
//        // 采集失败数量
//        if (business == 0){
//            List<Map> list = acStationMapper.selectFailure();
//            if (list.size() > 0){
//                for (int i = 0; i < list.size(); i++) {
//                    list.get(i).put("caiji",(100 - (long) list.get(i).get("COUNT")));
//                    list.get(i).put("zongshu",100);
//                }
//                return list;
//            }
//        // 费控停电失败数量
//        }else if (business == 1){
//            List<Map> list = feecontrolWorkOrderMapper.selectBusiness1();
//            if (list.size() > 0){
//                for (int i = 0; i < list.size(); i++) {
//                    list.get(i).put("chenggong",(100 - (long) list.get(i).get("count")));
//                    list.get(i).put("zongshu",100);
//                }
//                return list;
//            }
//        // 费控复电失败数量
//        }else if (business == 2){
//            List<Map> list = feecontrolWorkOrderMapper.selectBusiness2();
//            if (list.size() > 0){
//                for (int i = 0; i < list.size(); i++) {
//                    list.get(i).put("chenggong",(100 - (long) list.get(i).get("count")));
//                    list.get(i).put("zongshu",100);
//                }
//                return list;
//            }
//        }
//        return null;
//    }

    @Override
    public Map<String, List<AcManagerSp>> selectpBySid(String id) {
        Map<String, List<AcManagerSp>> map = new HashMap<>();
        List<AcManager> acManagers = acStationMapper.selectManagerGroupBy(id, TimeUtil.getSevenDay(),TimeUtil.getTomDay());
        for (AcManager acManager : acManagers) {
            List<AcManagerSp> acManagerSps = acStationMapper.selectacManagerSp(id, TimeUtil.getSevenDay(), TimeUtil.getTomDay(), acManager.getTgManager());
            map.put(acManager.getTgManager(),acManagerSps);
        }
        return map;
    }

    @Override
    public Map<String, List<AcStationSp>> selectpByCid(String id) {
        Map<String,List<AcStationSp>> map = new HashMap<>();
        List<AcStation> acStations = acStationMapper.selectStationGroupBy(id, TimeUtil.getSevenDay(),TimeUtil.getTomDay());
        for (AcStation acStation : acStations) {
            List<AcStationSp> acStationSps = acStationMapper.selectacStationSp(id, TimeUtil.getSevenDay(), TimeUtil.getTomDay(), acStation.getStationName());
            map.put(acStation.getStationName(),acStationSps);
        }
        return map;
    }


    @Override
    public List<AcManager> selectStationP(String AcStationId) {
        return acStationMapper.selectStationP(AcStationId);
    }

    @Override
    public int updateSnum(String acStationId, int stanum) {
       acStationMapper.updateSnum(acStationId,stanum);
       int point = 5;
       if(stanum<5){
           BigDecimal s1 = new BigDecimal(stanum);
           BigDecimal rate = new BigDecimal(100).subtract(s1.multiply(new BigDecimal(1)));
           acStationMapper.updatestaPR(acStationId,rate,point-stanum);
           return 1;
       }else {
           acStationMapper.updatestaPR(acStationId, new BigDecimal(95), 0);
           return 1;
       }
    }

    @Override
    public AcStation selectOneStation(String acStationId) {
        return acStationMapper.selectOneStation(acStationId);
    }
}

