package org.dfzt.service;

import org.dfzt.entity.po.EMpReadCurve;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author dfzt
 * @since 2022-07-11
 */
public interface EMpReadCurveService extends IService<EMpReadCurve> {

}
