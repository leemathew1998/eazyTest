package org.dfzt.entity.po;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/9
 * @Version: 1.00 计费关系
 */
@Data
public class RealMpPo {
    private String relaSortCode;//关系分类
    private String mpName;//计量点名称
    private String mpId;//计量点编号
    private String consName;//用电客户
    private String relaRatio;//关系比例值
    private String consNo;//用户编号
    private String mpDirectionCode;//相关计量点计量方向

}
