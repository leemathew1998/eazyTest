package org.dfzt.job;

import org.dfzt.service.CollectInformaService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

@Component
public class SolveOrderJob extends QuartzJobBean {
    @Autowired
    private CollectInformaService collectWorkOrderInforService;

    /**
     * 查看是否被修复，已修复归档
     * @param context
     * @throws JobExecutionException
     */
    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

        collectWorkOrderInforService.solveOrder();
    }
}
