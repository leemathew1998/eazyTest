package org.dfzt.jobConfig;

import org.dfzt.job.*;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;

/**
 * Quartz_learn_11：推荐使用方式
 */
@Component
public class JobInit implements CommandLineRunner{

    @Autowired
    public Scheduler scheduler;

    //已废弃
    //@PostConstruct
    /*public void initJob1() throws SchedulerException {
        JobDetail detail = JobBuilder
                .newJob(MeterWorkOrderJob.class)
                .withIdentity("detail1","group1")
                .build();

        Trigger trigger = TriggerBuilder.newTrigger()
                .startNow()
                .withIdentity("trigger1", "group1")
                .withSchedule(CronScheduleBuilder.cronSchedule("0 0 8 * * ? *"))
                .build();

        scheduler.scheduleJob(detail, trigger);
    }*/

//    /**
//     * 查看是否被修复，已修复归档
//     * @throws SchedulerException
//     */
//    @PostConstruct
    //已废弃
    /*public void initJob2() throws SchedulerException {
        JobDetail detail = JobBuilder
                .newJob(SolveOrderJob.class)
                .withIdentity("detail2","group1")
                .build();

        Trigger trigger = TriggerBuilder.newTrigger()
                .startNow()
                .withIdentity("trigger2", "group1")
                .withSchedule(CronScheduleBuilder.cronSchedule("0 0 5 * * ? *"))
                .build();

        scheduler.scheduleJob(detail, trigger);
    }*/

    /**
     * 每15分钟从S_APP表获取申请方式（APP_MODE）为政务WEB端且申请业务类型（APP_TYPE_CODE）为过户的数据
     * 每15分钟将待归档的工单编号和营销系统中的表进行校验，判断是否完成，完成则同步已归档。
     * @throws SchedulerException
     */
    @PostConstruct
    public void initJob5() throws SchedulerException {
        JobDetail detail = JobBuilder
                .newJob(InternetAndInternetOffice.class)
                .withIdentity("detail5","group1")
                .build();

        Trigger trigger = TriggerBuilder.newTrigger()
                .startNow()
                .withIdentity("trigger5", "group1")
//                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withRepeatCount(1).withIntervalInHours(1).repeatForever())
                .withSchedule(CronScheduleBuilder.cronSchedule("0 0/15 6-22 * * ? *"))
                .build();

        scheduler.scheduleJob(detail, trigger);
    }

    /**
     * 系统每15分钟（暂定）从S_APP表中获取申请业务类型（APP_TYPE_CODE）为销户或批量销户的数据以及新换装标识为新装的数据
     * @throws SchedulerException
     */
    @PostConstruct
    public void initJob6() throws SchedulerException {
        JobDetail detail = JobBuilder
                .newJob(FigureMoldMaintenance.class)
                .withIdentity("detail6","group1")
                .build();

        Trigger trigger = TriggerBuilder.newTrigger()
                .startNow()
                .withIdentity("trigger6", "group1")
//                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withRepeatCount(1).withIntervalInHours(1).repeatForever())
                .withSchedule(CronScheduleBuilder.cronSchedule("0 0/15 6-22 * * ? *"))
                .build();

        scheduler.scheduleJob(detail, trigger);
    }

    //费控复电生成工单(作废)
//    @PostConstruct
//    public void initJob3() throws SchedulerException {
//        JobDetail detail = JobBuilder
//                .newJob(FeeWorkOrderJob.class)
//                .withIdentity("detail3","group1")
//                .build();
//
//        Trigger trigger = TriggerBuilder.newTrigger()
//                .startNow()
//                .withIdentity("trigger3", "group1")
//                .withSchedule(CronScheduleBuilder.cronSchedule("0 0 8 * * ? *"))
//                .build();
//
//        scheduler.scheduleJob(detail, trigger);
//    }

    //费控复电数据转移（作废）
//    @PostConstruct
//    public void initJob4() throws SchedulerException {
//        JobDetail detail = JobBuilder
//                .newJob(FeeSevenWorkOrderJob.class)
//                .withIdentity("detail4","group1")
//                .build();
//
//        Trigger trigger = TriggerBuilder.newTrigger()
//                .startNow()
//                .withIdentity("trigger4", "group1")
//                .withSchedule(CronScheduleBuilder.cronSchedule("0 0 7 * * ? *"))
//                .build();
//
//        scheduler.scheduleJob(detail, trigger);
//    }

    //一个是用户档案信息 一个是联系信息维护信息表
    //根据原始数据条件查询出工单需要信息，生成工单
//    public void initJobRunWorkOrder1() throws SchedulerException {
//        JobDetail detail = JobBuilder
//                .newJob(RunWorkOrderJob.class)
//                .withIdentity("detailRunWorkOrder1","groupRunWorkOrder1")
//                .build();
//
//        Trigger trigger = TriggerBuilder.newTrigger()
//                .startNow()
//                .withIdentity("triggerRunWorkOrder1", "groupRunWorkOrder1")
//                .withSchedule(CronScheduleBuilder.cronSchedule("0 0 08 1 * ? "))
//                .build();
//
//        scheduler.scheduleJob(detail, trigger);
//    }


    //电费补抄工单生成（作废）
//    public void initJobRunWorkOrder2() throws SchedulerException {
//        JobDetail detail = JobBuilder
//                .newJob(RunWorkOrderJob1.class)
//                .withIdentity("detailRunWorkOrder2","groupRunWorkOrder2")
//                .build();
//
//        Trigger trigger = TriggerBuilder.newTrigger()
//                .startNow()
//                .withIdentity("triggerRunWorkOrder2", "groupRunWorkOrder2")
//                .withSchedule(CronScheduleBuilder.cronSchedule("0 0 07 1 * ? "))
//                .build();
//
//        scheduler.scheduleJob(detail, trigger);
//    }

    @Override
    public void run(String... args) throws Exception {
    }
}
