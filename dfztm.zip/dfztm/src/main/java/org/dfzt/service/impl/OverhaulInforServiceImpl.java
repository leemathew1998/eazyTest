package org.dfzt.service.impl;


import com.baomidou.mybatisplus.extension.api.R;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.vo.OverhaulInfor;
import org.dfzt.mapper.OverhaulInforMapper;
import org.dfzt.service.OverhaulInforService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Service
public class OverhaulInforServiceImpl extends ServiceImpl<OverhaulInforMapper, OverhaulInfor> implements OverhaulInforService {

    @Autowired
    private OverhaulInforMapper overhaulInforMapper;

    @Override
    public int insertOverhaul(OverhaulInfor overhaulInfor) {
        return overhaulInforMapper.insertOverhaul(overhaulInfor);
    }



    public R addOverhaul(OverhaulInfor overhaulInfor){
        Object o="数据为空";
        if(overhaulInfor==null){
            R.ok(o);
        }else {
            Boolean b=saveOrUpdate(overhaulInfor);
            if(b==true){
                return R.ok("主动运维-处理缺陷-检修-添加成功");
            }else {
                return R.ok("主动运维-处理缺陷-检修-添加失败");
            }
        }
        return null;
    }

    @Override
    public OverhaulInfor selectOne(String workOrderNo) {
        return overhaulInforMapper.selectOne(workOrderNo);
    }
}
