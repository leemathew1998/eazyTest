package com.exam.modules.entity.vo;

import com.exam.modules.entity.ExamT;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author dyy
 * @Date 2022/11/8 10:05
 * @PackageName:com.exam.modules.entity.vo
 * @ClassName: ExamTVo
 * @Description: TODO
 * @Version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExamTVo extends ExamT {
    private Long pageNo = 1L;//当前页码
    private Long pageSize = 10L;//每页显示数量
}
