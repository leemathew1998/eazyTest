package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/6/4
 * @Version: 1.00
 */
@Data
public class ConAssetNo implements Serializable {
    private BigDecimal ctrlId;
    private String consNo;
    private String assetNo;
}
