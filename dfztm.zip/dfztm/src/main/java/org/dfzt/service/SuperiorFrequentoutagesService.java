package org.dfzt.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.vo.SuperiorFrequentoutages;
import org.dfzt.entity.vo.SuperiorWorkOrder;

/**
 * (SuperiorFrequentoutages)表服务接口
 *
 * @author makejava
 * @since 2022-08-09 18:39:07
 */
public interface SuperiorFrequentoutagesService extends IService<SuperiorFrequentoutages> {
    LambdaQueryWrapper queryWrapper(SuperiorWorkOrder s);
    LambdaQueryWrapper wrapper(String str);
}

