package org.dfzt.service;

import org.dfzt.entity.po.ARcaCtrlDet;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface ARcaCtrlDetService extends IService<ARcaCtrlDet>{


}
