package org.dfzt.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.CMp;

import java.util.List;

/**
 * (CMp)表服务接口
 *
 * @author makejava
 * @since 2022-07-29 14:51:17
 */
public interface CMpService extends IService<CMp> {
    LambdaQueryWrapper queryWrapper(CMp cMp);
    LambdaQueryWrapper wrapper(String str);

    List<CMp> selectListByMany(String str);

    LambdaQueryWrapper selectCmpByUser(CMp cMp);
}

