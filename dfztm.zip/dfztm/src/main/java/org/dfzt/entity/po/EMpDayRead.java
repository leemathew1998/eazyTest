package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "EMpDayRead对象", description = "")
public class EMpDayRead implements Serializable {


    @ApiModelProperty(value = "实体唯一标识")
    private String id;

    @ApiModelProperty(value = "供电单位编号")
    @TableField("org_no")
    private String orgNo;

    @ApiModelProperty(value = "数据日期")
    @TableField("data_date")
    private Date dataDate;

    @ApiModelProperty(value = "终端抄表时间")
    @TableField("col_time")
    private Date colTime;

    @ApiModelProperty(value = "CT")
    private BigDecimal ct;

    @ApiModelProperty(value = "PT变比")
    private BigDecimal pt;

    @ApiModelProperty(value = "标记")
    private BigDecimal mark;

    @ApiModelProperty(value = "正向有功总电能示值")
    @TableField("pap_r")
    private BigDecimal papR;

    @ApiModelProperty(value = "正向有功费率1电能示值")
    @TableField("pap_r1")
    private BigDecimal papR1;

    @ApiModelProperty(value = "正向有功费率2电能示值")
    @TableField("pap_r2")
    private BigDecimal papR2;

    @ApiModelProperty(value = "正向有功费率3电能示值")
    @TableField("pap_r3")
    private BigDecimal papR3;

    @ApiModelProperty(value = "正向有功费率4电能示值")
    @TableField("pap_r4")
    private BigDecimal papR4;

    @ApiModelProperty(value = "正向无功总电能示值")
    @TableField("prp_r")
    private BigDecimal prpR;

    @ApiModelProperty(value = "正向无功费率1电能示值")
    @TableField("prp_r1")
    private BigDecimal prpR1;

    @ApiModelProperty(value = "正向无功费率2电能示值")
    @TableField("prp_r2")
    private BigDecimal prpR2;

    @ApiModelProperty(value = "正向无功费率3电能示值")
    @TableField("prp_r3")
    private BigDecimal prpR3;

    @ApiModelProperty(value = "正向无功费率4电能示值")
    @TableField("prp_r4")
    private BigDecimal prpR4;

    @ApiModelProperty(value = "反向有功总电能示值")
    @TableField("rap_r")
    private BigDecimal rapR;

    @ApiModelProperty(value = "反向有功费率1电能示值")
    @TableField("rap_r1")
    private BigDecimal rapR1;

    @ApiModelProperty(value = "反向有功费率2电能示值")
    @TableField("rap_r2")
    private BigDecimal rapR2;

    @ApiModelProperty(value = "反向有功费率3电能示值")
    @TableField("rap_r3")
    private BigDecimal rapR3;

    @ApiModelProperty(value = "反向有功费率4电能示值")
    @TableField("rap_r4")
    private BigDecimal rapR4;

    @ApiModelProperty(value = "反向无功总电能示值")
    @TableField("rrp_r")
    private BigDecimal rrpR;

    @ApiModelProperty(value = "反向无功费率1电能示值")
    @TableField("rrp_r1")
    private BigDecimal rrpR1;

    @ApiModelProperty(value = "反向无功费率2电能示值")
    @TableField("rrp_r2")
    private BigDecimal rrpR2;

    @ApiModelProperty(value = "反向无功费率3电能示值")
    @TableField("rrp_r3")
    private BigDecimal rrpR3;

    @ApiModelProperty(value = "反向无功费率4电能示值")
    @TableField("rrp_r4")
    private BigDecimal rrpR4;

    @ApiModelProperty(value = "一象限无功电能示值")
    @TableField("rp1_r")
    private BigDecimal rp1R;

    @ApiModelProperty(value = "四象限无功电能示值")
    @TableField("rp4_r")
    private BigDecimal rp4R;

    @ApiModelProperty(value = "二象限无功电能示值")
    @TableField("rp2_r")
    private BigDecimal rp2R;

    @ApiModelProperty(value = "三象限无功电能示值")
    @TableField("rp3_r")
    private BigDecimal rp3R;

    @ApiModelProperty(value = "记录时间")
    @TableField("rec_time")
    private Date recTime;

    @ApiModelProperty(value = "正向有功费率5示值")
    @TableField("pap_r5")
    private BigDecimal papR5;

    @ApiModelProperty(value = "正向有功费率6示值")
    @TableField("pap_r6")
    private BigDecimal papR6;

    @ApiModelProperty(value = "正向有功费率8示值")
    @TableField("pap_r8")
    private BigDecimal papR8;

    @ApiModelProperty(value = "正向有功费率9示值")
    @TableField("pap_r9")
    private BigDecimal papR9;

    @ApiModelProperty(value = "正向有功费率10示值")
    @TableField("pap_r10")
    private BigDecimal papR10;

    @ApiModelProperty(value = "正向有功费率11示值")
    @TableField("pap_r11")
    private BigDecimal papR11;

    @ApiModelProperty(value = "正向有功费率12示值")
    @TableField("pap_r12")
    private BigDecimal papR12;

    @ApiModelProperty(value = "正向有功费率13示值")
    @TableField("pap_r13")
    private BigDecimal papR13;

    @ApiModelProperty(value = "正向有功费率14示值")
    @TableField("pap_r14")
    private BigDecimal papR14;

    @ApiModelProperty(value = "正向无功费率5示值")
    @TableField("prp_r5")
    private BigDecimal prpR5;

    @ApiModelProperty(value = "正向无功费率6示值")
    @TableField("prp_r6")
    private BigDecimal prpR6;

    @ApiModelProperty(value = "正向无功费率7示值")
    @TableField("prp_r7")
    private BigDecimal prpR7;

    @ApiModelProperty(value = "正向无功费率8示值")
    @TableField("prp_r8")
    private BigDecimal prpR8;

    @ApiModelProperty(value = "正向无功费率9示值")
    @TableField("prp_r9")
    private BigDecimal prpR9;

    @ApiModelProperty(value = "正向无功费率10示值")
    @TableField("prp_r10")
    private BigDecimal prpR10;

    @ApiModelProperty(value = "正向无功费率11示值")
    @TableField("prp_r11")
    private BigDecimal prpR11;

    @ApiModelProperty(value = "正向无功费率12示值")
    @TableField("prp_r12")
    private BigDecimal prpR12;

    @ApiModelProperty(value = "正向无功费率13示值")
    @TableField("prp_r13")
    private BigDecimal prpR13;

    @ApiModelProperty(value = "正向无功费率14示值")
    @TableField("prp_r14")
    private BigDecimal prpR14;

    @ApiModelProperty(value = "反向有功费率5示值")
    @TableField("rap_r5")
    private BigDecimal rapR5;

    @ApiModelProperty(value = "反向有功费率6示值")
    @TableField("rap_r6")
    private BigDecimal rapR6;

    @ApiModelProperty(value = "反向有功费率7示值")
    @TableField("rap_r7")
    private BigDecimal rapR7;

    @ApiModelProperty(value = "反向有功费率8示值")
    @TableField("rap_r8")
    private BigDecimal rapR8;

    @ApiModelProperty(value = "反向有功费率9示值")
    @TableField("rap_r9")
    private BigDecimal rapR9;

    @ApiModelProperty(value = "反向有功费率10示值")
    @TableField("rap_r10")
    private BigDecimal rapR10;

    @ApiModelProperty(value = "反向有功费率11示值")
    @TableField("rap_r11")
    private BigDecimal rapR11;

    @ApiModelProperty(value = "反向有功费率12示值")
    @TableField("rap_r12")
    private BigDecimal rapR12;

    @ApiModelProperty(value = "反向有功费率13示值")
    @TableField("rap_r13")
    private BigDecimal rapR13;

    @ApiModelProperty(value = "反向有功费率14示值")
    @TableField("rap_r14")
    private BigDecimal rapR14;

    @ApiModelProperty(value = "反向无功费率5示值")
    @TableField("rrp_r5")
    private BigDecimal rrpR5;

    @ApiModelProperty(value = "反向无功费率6示值")
    @TableField("rrp_r6")
    private BigDecimal rrpR6;

    @ApiModelProperty(value = "反向无功费率7示值")
    @TableField("rrp_r7")
    private BigDecimal rrpR7;

    @ApiModelProperty(value = "反向无功费率8示值")
    @TableField("rrp_r8")
    private BigDecimal rrpR8;

    @ApiModelProperty(value = "反向无功费率10示值")
    @TableField("rrp_r10")
    private BigDecimal rrpR10;

    @ApiModelProperty(value = "反向无功费率11示值")
    @TableField("rrp_r11")
    private BigDecimal rrpR11;

    @ApiModelProperty(value = "反向无功费率12示值")
    @TableField("rrp_r12")
    private BigDecimal rrpR12;

    @ApiModelProperty(value = "反向无功费率13示值")
    @TableField("rrp_r13")
    private BigDecimal rrpR13;

    @ApiModelProperty(value = "反向无功费率14示值")
    @TableField("rrp_r14")
    private BigDecimal rrpR14;

    @ApiModelProperty(value = "正向有功费率7示值")
    @TableField("pap_r7")
    private BigDecimal papR7;

    @ApiModelProperty(value = "反向无功费率9示值")
    @TableField("rrp_r9")
    private BigDecimal rrpR9;

    @ApiModelProperty(value = "sysdate")
    @TableField("first_time")
    private Date firstTime;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp1_r1")
    private BigDecimal rp1R1;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp1_r2")
    private BigDecimal rp1R2;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp1_r3")
    private BigDecimal rp1R3;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp1_r4")
    private BigDecimal rp1R4;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp4_r1")
    private BigDecimal rp4R1;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp4_r2")
    private BigDecimal rp4R2;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp4_r3")
    private BigDecimal rp4R3;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp4_r4")
    private BigDecimal rp4R4;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp2_r1")
    private BigDecimal rp2R1;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp2_r2")
    private BigDecimal rp2R2;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp2_r3")
    private BigDecimal rp2R3;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp2_r4")
    private BigDecimal rp2R4;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp3_r1")
    private BigDecimal rp3R1;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp3_r2")
    private BigDecimal rp3R2;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp3_r3")
    private BigDecimal rp3R3;

    @ApiModelProperty(value = "抄表示数")
    @TableField("rp3_r4")
    private BigDecimal rp3R4;

    @ApiModelProperty(value = "备用")
    @TableField("copper_losses")
    private BigDecimal copperLosses;

    @ApiModelProperty(value = "备用")
    @TableField("iron_losses")
    private BigDecimal ironLosses;

    @ApiModelProperty(value = "正向有功A相电量")
    @TableField("pap_r_a")
    private BigDecimal papRA;

    @ApiModelProperty(value = "正向有功B相电量")
    @TableField("pap_r_b")
    private BigDecimal papRB;

    @ApiModelProperty(value = "正向有功C相电量")
    @TableField("pap_r_c")
    private BigDecimal papRC;

    @ApiModelProperty(value = "正向无功A相电量")
    @TableField("prp_r_a")
    private BigDecimal prpRA;

    @ApiModelProperty(value = "正向无功B相电量")
    @TableField("prp_r_b")
    private BigDecimal prpRB;

    @ApiModelProperty(value = "正向无功C相电量")
    @TableField("prp_r_c")
    private BigDecimal prpRC;

    @ApiModelProperty(value = "反向有功A相电量")
    @TableField("rap_r_a")
    private BigDecimal rapRA;

    @ApiModelProperty(value = "反向有功B相电量")
    @TableField("rap_r_b")
    private BigDecimal rapRB;

    @ApiModelProperty(value = "反向有功C相电量")
    @TableField("rap_r_c")
    private BigDecimal rapRC;

    @ApiModelProperty(value = "反向无功A相电量")
    @TableField("rrp_r_a")
    private BigDecimal rrpRA;

    @ApiModelProperty(value = "反向无功B相电量")
    @TableField("rrp_r_b")
    private BigDecimal rrpRB;

    @ApiModelProperty(value = "反向无功C相电量")
    @TableField("rrp_r_c")
    private BigDecimal rrpRC;

    @ApiModelProperty(value = "电表标识")
    @TableField("meter_id")
    private BigDecimal meterId;

    @ApiModelProperty(value = "数据来源")
    @TableField("data_src")
    private String dataSrc;

    @ApiModelProperty(value = "是否有效")
    @TableField("is_valid")
    private BigDecimal isValid;

    @ApiModelProperty(value = "修复方式 修复方式(空：默认：1：科大算法示值修复 2：评价功率估计电量 3营销吵见电量修复 9无法修复")
    @TableField("verify_method")
    private String verifyMethod;

    @ApiModelProperty(value = "标识")
    @TableField("change_flag")
    private String changeFlag;

    @ApiModelProperty(value = "突增突减量")
    @TableField("change_value")
    private String changeValue;

    @TableField("verify_rap_flag")
    private String verifyRapFlag;

    @TableField("verify_rap_methoo")
    private String verifyRapMethoo;

    @TableField("change_rap_flag")
    private String changeRapFlag;

    @TableField("change_rap_value")
    private String changeRapValue;

    @TableField("cis_chk_flag")
    private String cisChkFlag;

    @TableField("mark_rap")
    private String markRap;

    @TableField("mark_pub")
    private String markPub;

    @TableField("mark_rap_pub")
    private String markRapPub;

    @ApiModelProperty(value = "原始正向有功总示值")
    @TableField("ori_pap_r")
    private BigDecimal oriPapR;

    @TableField("ori_rap_r")
    private BigDecimal oriRapR;


}
