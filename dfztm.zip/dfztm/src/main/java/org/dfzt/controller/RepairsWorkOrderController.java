package org.dfzt.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;

import org.dfzt.entity.dto.RepairsWorkOrderDto;
import org.dfzt.entity.po.RepairsWorkOrder;
import org.dfzt.mapper.RepairsWorkOrderMapper;
import org.dfzt.service.RepairsWorkOrderService;
import org.dfzt.util.ExcelUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


/**
 * (RepairsWorkOrder)表控制层
 *
 * @author dyy
 * @since 2022-07-28 09:29:24
 */
@RestController
@RequestMapping("repairsWorkOrder")
public class RepairsWorkOrderController extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private RepairsWorkOrderService repairsWorkOrderService;

    @Resource
    private RepairsWorkOrderMapper repairsWorkOrderMapper;

    /**
     * 分页查询所有数据
     *
     * @param repairsWorkOrder 查询实体
     * @return 所有数据
     */
    @RequestMapping("selectAll")
//    public R selectAll(Page<RepairsWorkOrder> page, RepairsWorkOrder repairsWorkOrder) {
    public R selectAll(RepairsWorkOrder repairsWorkOrder,
                       @RequestParam(name = "pageNo", defaultValue = "1") Integer pageNo,
                       @RequestParam(name = "pageSize", defaultValue = "10") Integer pageSize) {
        System.out.println("主动抢修1");
        Page<RepairsWorkOrder> page = new Page<>(pageNo, pageSize);
        System.out.println("主动抢修2");
        LambdaQueryWrapper lambdaQueryWrapper = repairsWorkOrderService.queryWrapper(repairsWorkOrder);
        System.out.println("主动抢修3");
        Page page1 = this.repairsWorkOrderService.page(page, lambdaQueryWrapper);
        System.out.println("主动抢修4");
        return success(page1);
    }

    /**
     * app 模糊查询
     * @param page
     * @param str
     * @return
     */
    @PostMapping("selectAppAll")
    public R selectAppAll(Page<RepairsWorkOrder> page, String str) {
        System.out.println("============"+str);
        return success(this.repairsWorkOrderService.page(page, repairsWorkOrderService.per(str)));
    }

    @PostMapping("updateRepairsWorkOrder")
    public R updateRepairsWorkOrder(RepairsWorkOrder repairsWorkOrder) {
        return success(repairsWorkOrderService.updateRepairsWorkOrder(repairsWorkOrder));
    }

    /**
     * 主动抢修工单详情
     * @param workOrderNo
     * @return
     */
    @PostMapping("/selectByNo")
    public R selectByNo(String workOrderNo){
        return success(repairsWorkOrderService.selectByNo(workOrderNo));
    }

    /**
     * App端故障详情查询
     * @param
     * @return
     */
    @PostMapping("/selectByOrderNo")
    public R selectByOrderNo(String workOrderNo,String workOrderStatus){
        System.out.println("workOrderNo:"+workOrderNo+"  "+"workOrderStatus:"+"   "+workOrderStatus);
        List<RepairsWorkOrder> list = new ArrayList<>();
        RepairsWorkOrder repairsWorkOrder = repairsWorkOrderMapper.selectByOrderNo(workOrderNo, workOrderStatus);
        if (repairsWorkOrder != null) {
            list.add(repairsWorkOrderMapper.selectByOrderNo(workOrderNo,workOrderStatus));
            return success(list);
        }
        R<Object> objectR = new R<>();
        objectR.setData(repairsWorkOrder);
        return objectR;
    }
    //App端上传故障详情
    @PostMapping("updateRepinfo")
    public R updateRepinfo(RepairsWorkOrderDto repairsWorkOrder){
        return success(repairsWorkOrderMapper.updateRepinfo(repairsWorkOrder));
    }

    //生成抢修工单
    @PostMapping("selectWorkOrderStatusInfo")
    public R selectWorkOrderStatusInfo(){
        return success(repairsWorkOrderService.selectWorkOrderStatusInfo());
    }

    /**
     * TODO 主动抢修工单 包含敏感用户
     */
    @PostMapping("/listapp")
    public List<RepairsWorkOrder> RepairsListapp(){
        List<RepairsWorkOrder> repairsWorkOrders = repairsWorkOrderService.selectAllYWOapp();
        return repairsWorkOrders;
    }


    @PostMapping("export1")  //excel/export
    public  void exportExcel(HttpServletResponse response) throws IOException {

        List<RepairsWorkOrder> list=new ArrayList<>();
        List<RepairsWorkOrder> repairsWorkOrders = repairsWorkOrderService.selectAllYWOapp();
        for (RepairsWorkOrder repairsWorkOrder : repairsWorkOrders) {
            list.add(repairsWorkOrder);
        }
        ExcelUtils.exportExcel(list,"主动抢修工单列表","主动抢修",RepairsWorkOrder.class,"主动抢修工单文件",response);
    }



    @PostMapping("export")  //excel/export

    public  void exportExcel1(HttpServletResponse response,@RequestParam List<String> ids) throws IOException {

        List<RepairsWorkOrder> list=new ArrayList<>();
        for (String id : ids) {
            RepairsWorkOrder repairsWorkOrder = repairsWorkOrderService.selectAllYwByids(id);
            list.add(repairsWorkOrder);
        }
        ExcelUtils.exportExcel(list,"主动抢修工单列表","主动抢修",RepairsWorkOrder.class,"主动抢修工单文件",response);
    }


}

