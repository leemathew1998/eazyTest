package org.dfzt.entity.vo;

import lombok.Data;
import org.dfzt.eunm.WorkOrderStatusEnum;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
//@AllArgsConstructor
//@NoArgsConstructor
public class CollectYwWorkOrderv implements Serializable {

    private Integer id;

    private Integer notConnectId;//关联采集未接入id

    private Integer colInforId;//关联采集异常id

    private Integer failDetailsId;//关联采集失败id

    private String workOrderNo;//工单编号

    private String areaManagerDesk;//台区经理

    private String tgId;//台区编号

    private String tgName;//台区名称

    private String orgName;//上级供电单位名称

    private String consNo;//用户编号

    private String consName;//用户名称

    private String elecAddr;//用电地址（用户地址）

    private String gpsLongitude;//经度

    private String gpsLatitude;//纬度

    private String mobile;//移动电话

    private String meterAssetNo;//电能表资产号

    private String meterBarCode;//电能表条码

    private String metManufacturer;//电能表厂家

    private String eventType;//事件类型

    private String eventReason;//研判原因

    private String workOrderStatus;//工单状态

    private Date workOrderCtime;//工单创建时间

    private String workOrderCycle;//是连续几天的工单

}
