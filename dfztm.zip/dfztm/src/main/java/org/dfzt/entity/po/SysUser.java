package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

@Data
public class SysUser implements Serializable {
    private Integer id;

    private String loginName;

    private String passWord;

    private String userRole;

    private String userStation;

    private String reserveOne;

    private String pNo;

    private String reserveThree;


}