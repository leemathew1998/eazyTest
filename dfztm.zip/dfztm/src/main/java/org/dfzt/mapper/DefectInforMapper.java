package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.vo.DefectInfor;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
public interface DefectInforMapper extends BaseMapper<DefectInfor> {
    int insertDefectInfor(DefectInfor defectInfor);//添加缺陷录入信息

    DefectInfor selectOne(String workOrderNo);//查看缺陷录入信息
}
