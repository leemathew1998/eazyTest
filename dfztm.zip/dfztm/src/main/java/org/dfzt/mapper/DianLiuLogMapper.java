package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.dto.DianLiuLog;
import org.dfzt.entity.dto.DianYaLog;


public interface DianLiuLogMapper extends BaseMapper<DianLiuLog> {

}

