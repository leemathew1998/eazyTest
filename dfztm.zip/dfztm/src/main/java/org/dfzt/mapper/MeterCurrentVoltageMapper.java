package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.dfzt.entity.po.MeterCurrentVoltage;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * (MeterCurrentVoltage)表数据库访问层
 *
 * @author makejava
 * @since 2022-06-15 14:09:38
 */
@Mapper
@Repository
public interface MeterCurrentVoltageMapper extends BaseMapper<MeterCurrentVoltage> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<MeterCurrentVoltage> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<MeterCurrentVoltage> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<MeterCurrentVoltage> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<MeterCurrentVoltage> entities);

    //获取前一天的数据
    @Select("SELECT a.point_zero, a.point_zero_fif, a.point_zero_thir, a.point_zero_forfive, a.point_one,\n" +
            "                    a.point_one_fif, a.point_one_thir, a.point_one_forfive, a.point_two, a.point_two_fif, a.point_two_thir, a.point_two_forfive,\n" +
            "                    a.point_thr, a.point_thr_fif, a.point_thr_thir, a.point_thr_forfive, a.point_four, a.point_four_fif, a.point_four_thir,\n" +
            "                    a.point_four_forfive, a.point_five, a.point_five_fif, a.point_five_thir, a.point_five_forfive, a.point_six, a.point_six_fif,\n" +
            "                    a.point_six_thir, a.point_six_forfive, a.point_sen, a.point_sen_fif, a.point_sen_thir, a.point_sen_forfive, a.point_eig,\n" +
            "                    a.point_eig_fif, a.point_eig_thir, a.point_eig_forfive, a.point_nine, a.point_nine_fif, a.point_nine_thir,\n" +
            "                    a.point_nine_forfive, a.point_ten, a.point_ten_fif, a.point_ten_thir, a.point_ten_forfive, a.point_ele, a.point_ele_fif,\n" +
            "                    a.point_ele_thir, a.point_ele_forfive, a.point_twe, a.point_twe_fif, a.point_twe_thir, a.point_twe_forfive, a.point_thirtn,\n" +
            "                    a.point_thirtn_fif, a.point_thirtn_thir, a.point_thirtn_forfive, a.point_fourtn, a.point_fourtn_fif, a.point_fourtn_thir,\n" +
            "                    a.point_fourtn_forfive, a.point_fiftn, a.point_fiftn_fif, a.point_fiftn_thir, a.point_fiftn_forfive, a.point_sixth,\n" +
            "                    a.point_sixth_fif, a.point_sixth_thir, a.point_sixth_forfive, a.point_sentn, a.point_sentn_fif, a.point_sentn_thir,\n" +
            "                    a.point_sentn_forfive, a.point_eigtn, a.point_eigtn_fif, a.point_eigtn_thir, a.point_eigtn_forfive, a.point_nineth,\n" +
            "                    a.point_nineth_fif, a.point_nineth_thir, a.point_nineth_forfive, a.point_twety, a.point_twety_fif, a.point_twety_thir,\n" +
            "                    a.point_twety_forfive, a.point_twetyone, a.point_twetyone_fif, a.point_twetyone_thir, a.point_twetyone_forfive,\n" +
            "                    a.point_twetytwo, a.point_twetytwo_fif, a.point_twetytwo_thir, a.point_twetytwo_forfive, a.point_twetythr,\n" +
            "                    a.point_twetythr_fif, a.point_twetythr_thir, a.point_twetythr_forfive,a.user_type,b.voltage,b.electricity,a.elecmeter_asset_num,a.create_time\n" +
            "            FROM meter_current_voltage a ,meter_rated b\n" +
            "            WHERE DATE(create_time) = DATE_SUB(CURDATE(),INTERVAL 1 DAY)\n" +
            "            AND a.elecmeter_asset_num = b.property_id\n" +
            "            HAVING user_type = \"A\" OR  user_type = \"B\" OR user_type = \"F\"")
    List<MeterCurrentVoltage> selOneDay();

    //查询所有相中电压最大值
   MeterCurrentVoltage selPointMax();



}

