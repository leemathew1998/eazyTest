package org.dfzt.webservice;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;

import javax.xml.namespace.QName;
import javax.xml.rpc.ParameterMode;
import javax.xml.rpc.encoding.XMLType;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/21
 * @Version: 1.00
 */
public class Test01 {

    public static void main(String[] args) {
        try {
            String endpoint = "http://localhost:18080/api/services/getvalue?wsdl";
            Service service = new Service();
            Call call = (Call) service.createCall(); //创建服务
            call.setTargetEndpointAddress(endpoint);
            //2、定义报名和接口方法
            call.setOperationName(new QName("targetNamespace", //wsdl文件中的targetNamespace
                    "getKPIValue") //接口实现功能的方法
            );

//            //3、设置参数
            //call.addParameter("param", XMLType.XSD_INT, ParameterMode.IN);// 接口的参数
            call.addParameter("param",XMLType.XSD_STRING,ParameterMode.IN);// 接口的参数
            call.setReturnType(XMLType.XSD_STRING);// 设置返回类型

            int resType=1000;
            String nodeIndexCode="";

            //4、给方法传递参数，并且调用方法
            String result = (String) call.invoke(new Object[] {nodeIndexCode ,resType});
            System.out.println(result);

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
