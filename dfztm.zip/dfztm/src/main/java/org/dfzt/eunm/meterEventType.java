package org.dfzt.eunm;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * @Author dyy
 * @Date 2022/7/21 10:00
 * @PackageName:org.dfzt.eunm
 * @ClassName: meterEventType
 * @Description: TODO 计量工单事件类型
 * @Version 1.0
 */
public enum meterEventType {
    EVENT_TYPE_ONE(1,"反向有功示值大于0"),
    EVENT_TYPE_TWO(2,"失压"),
    EVENT_TYPE_THREE(3,"电能表倒走"),
    EVENT_TYPE_FOUR(4,"超容"),
    EVENT_TYPE_FIVE(5,"零火电流异常");
//    EVENT_TYPE_SIX(6,"电能表飞走"),
//    EVENT_TYPE_SEVEN(7,"电能表倒走"),
//    EVENT_TYPE_EIGHT(8,"接线错误");

    @EnumValue
    private int code;
    @JsonValue
    private String message;

    meterEventType(int code, String message) {
        this.code = code;
        this.message = message;
    }
}
