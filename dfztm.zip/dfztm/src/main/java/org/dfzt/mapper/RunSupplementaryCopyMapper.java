package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.vo.RunSupplementaryCopy;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
public interface RunSupplementaryCopyMapper extends BaseMapper<RunSupplementaryCopy> {
    int updateone(String uerid);
}
