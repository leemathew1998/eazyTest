package org.dfzt.service;

import com.baomidou.mybatisplus.extension.api.R;
import org.dfzt.entity.po.OStaff;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface OStaffService extends IService<OStaff>{

    R selectMessage(String message, Long pageNo, Long pageSize);



}
