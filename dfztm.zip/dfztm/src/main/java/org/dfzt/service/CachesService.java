package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.AcManager;
import org.dfzt.entity.po.AcStation;
import org.dfzt.entity.po.consTgScm;
import org.dfzt.entity.vo.AcManagerSp;
import org.dfzt.entity.vo.AcStationSp;

import java.util.List;
import java.util.Map;

/**
 * (AcStation)表服务接口
 *
 * @author makejava
 * @since 2022-07-15 15:19:50
 */
public interface CachesService {
    List<String> getBusinessPlace();
    String getOrgName(String orgNo);
    String getOrgNameRedis(String orgNo);
    String getPropName(String codeType,String value);
    String getConsName(String consNo);

}

