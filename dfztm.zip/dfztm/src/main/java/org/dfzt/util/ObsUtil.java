package org.dfzt.util;

import com.obs.services.ObsClient;
import com.obs.services.exception.ObsException;
import com.obs.services.model.HttpMethodEnum;
import com.obs.services.model.PutObjectRequest;
import com.obs.services.model.TemporarySignatureRequest;
import com.obs.services.model.TemporarySignatureResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import sun.misc.BASE64Encoder;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/21
 * @Version: 1.00
 */
@Slf4j

@RestController
@RequestMapping("obs")
public class ObsUtil {
    /**
     * 测试是否能获取到OBS对象存储服务
     */
//    @Scheduled(cron = "0/30 * * * * ?")//每30秒运行一次
    @RequestMapping("obs")
    public void getObs(){
        try {
            System.out.println("*******************************************");
            System.out.println("=================obs测试开始===============");
            System.out.println("*******************************************");
            String endPoint1s = "https://obs.im-region-1.sgic.sgcc.com.cn";
            String ak = "FJKCAJIHHXNBTSWG0QN3";
            String sk = "D3Gtp3rz59WT9EpZ1RxBEDcvIjWrLcbXOzivv6gY";
            log.info("*******************************");
            ObsClient obsClient1s = new ObsClient(ak,sk,endPoint1s);
            //创建ObsClient实例
            PutObjectRequest request = new PutObjectRequest();
            request.setBucketName("tqgl-upload-product");
            request.setObjectKey("yx1.jpg");
            request.setFile(new File("./src/main/resources/pic/yx.jpg"));
            obsClient1s.putObject(request);
            System.out.println("*******************************************");
            System.out.println("=================obs测试结束===============");
            System.out.println("*******************************************");

        } catch (ObsException e) {
            System.out.println("********** HTTP Code:" + e.getResponseCode());
            System.out.println("********** Error Code:" + e.getErrorCode());
            System.out.println("********** Request ID:" + e.getErrorRequestId());
            e.printStackTrace(System.out);
        }
    }


    @RequestMapping("getBase")
    public void getBase64(){

        String filePath = "./src/main/resources/pic/yx.jpg";//测试文件的全路径
        String fileBase64 = this.convertFileToBase64(filePath); //pdf文件转换成Base64字符串
        System.out.println("getBase"+fileBase64);
        String filePath1 = "pic/yx.jpg";//测试文件的全路径
        String fileBase641 = this.convertFileToBase64(filePath1); //pdf文件转换成Base64字符串
        System.out.println("getBase1"+fileBase641);
    }

    @RequestMapping("getBase2")
    public void getBase642(){
        String base64 = "";  //待转换文件的base64位数据
        String path = "https://obs.im-region-1.sgic.sgcc.com.cn/tqgl-upload-product/yx2.jpg";  //转换后文件所在的目录和文件名
        this.generateBase64StringToFile(base64,path);
        System.out.println("base64位转文件成功");
    }

    //文件转base64
    public static String convertFileToBase64(String imgPath) {
        byte[] data = null;
        // 读取文件字节数组
        try {
            InputStream in = new FileInputStream(imgPath);
            System.out.println("文件大小（字节）="+in.available());
            data = new byte[in.available()];
            in.read(data);
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // 对字节数组进行Base64编码，得到Base64编码的字符串
//        BASE64Encoder encoder = new BASE64Encoder();
//        String base64Str = encoder.encode(data);
//        return base64Str;
        return "";
    }


    /**
     * 对字节数组字符串进行Base64解码并生成文件
     * @param fileStr 文件base64位数据
     * @param fileFilePath 保存文件全路径地址
     * @return
     */
    public static boolean generateBase64StringToFile(String fileStr,String fileFilePath){
        if (fileStr == null) //文件base64位数据为空
            return false;
        try
        {
            //Base64解码
            byte[] b = Base64.decodeBase64(fileStr);
            for(int i=0;i<b.length;++i)
            {
                if(b[i]<0)
                {//调整异常数据
                    b[i]+=256;
                }
            }
            //生成文件
            OutputStream out = new FileOutputStream(fileFilePath);
            out.write(b);
            out.flush();
            out.close();
            return true;
        }
        catch (Exception e)
        {
            return false;
        }
    }


}
