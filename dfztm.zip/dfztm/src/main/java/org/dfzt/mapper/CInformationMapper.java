package org.dfzt.mapper;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.dfzt.entity.po.CInformation;
import org.dfzt.entity.po.CSp;

import javax.sound.sampled.Line;
import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */
@Mapper
public interface CInformationMapper extends BaseMapper<CInformation> {
    @DS("mpg")
    List<CSp> selectScp(BigDecimal consId);//根据consid查询出所关联的受电点信息

    List<BigDecimal> selectConsIdList();//查询用户列表中所有的consid

    Integer insertSCP(CInformation cInformation);//将信息添加到表中

}
