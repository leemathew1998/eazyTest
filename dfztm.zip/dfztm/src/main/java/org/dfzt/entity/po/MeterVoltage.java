package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/20
 * @Version: 1.00 日冻结电压曲线
 */
@Data
public class MeterVoltage {
    private Integer id;
    //供电单位
    private String orgName;
    //用户编码
    private String consNo;
    //用户名称
    private String consName;
    //电能表资产号
    private String meterAssetNo;
    //电能表厂家
    private String metManufacturer;
    //终端厂家
    private String factoryCode;
    //台区编号
    private String tgNo;
    //台区名称
    private String tgName;
    //抄表日期
    private Date mrDate;
    //数据来源
    private String dataSrc;
    //综合倍率
    private BigDecimal tFactor;
    //相序
    private String phaseFlag;
    //点数
    private String dataPointFlag;
    //1点
    private BigDecimal v1;
    //2点
    private BigDecimal v2;

    private BigDecimal v3;

    private BigDecimal v4;

    private BigDecimal v5;

    private BigDecimal v6;

    private BigDecimal v7;

    private BigDecimal v8;

    private BigDecimal v9;

    private BigDecimal v10;

    private BigDecimal v11;

    private BigDecimal v12;

    private BigDecimal v13;

    private BigDecimal v14;

    private BigDecimal v15;

    private BigDecimal v16;

    private BigDecimal v17;

    private BigDecimal v18;

    private BigDecimal v19;

    private BigDecimal v20;

    private BigDecimal v21;

    private BigDecimal v22;

    private BigDecimal v23;

    private BigDecimal v24;

    private BigDecimal v25;

    private BigDecimal v26;

    private BigDecimal v27;

    private BigDecimal v28;

    private BigDecimal v29;

    private BigDecimal v30;

    private BigDecimal v31;

    private BigDecimal v32;

    private BigDecimal v33;

    private BigDecimal v34;

    private BigDecimal v35;

    private BigDecimal v36;

    private BigDecimal v37;

    private BigDecimal v38;

    private BigDecimal v39;

    private BigDecimal v40;

    private BigDecimal v41;

    private BigDecimal v42;

    private BigDecimal v43;

    private BigDecimal v44;

    private BigDecimal v45;

    private BigDecimal v46;

    private BigDecimal v47;

    private BigDecimal v48;

    private BigDecimal v49;

    private BigDecimal v50;

    private BigDecimal v51;

    private BigDecimal v52;

    private BigDecimal v53;

    private BigDecimal v54;

    private BigDecimal v55;

    private BigDecimal v56;

    private BigDecimal v57;

    private BigDecimal v58;

    private BigDecimal v59;

    private BigDecimal v60;

    private BigDecimal v61;

    private BigDecimal v62;

    private BigDecimal v63;

    private BigDecimal v64;

    private BigDecimal v65;

    private BigDecimal v66;

    private BigDecimal v67;

    private BigDecimal v68;

    private BigDecimal v69;

    private BigDecimal v70;

    private BigDecimal v71;

    private BigDecimal v72;

    private BigDecimal v73;

    private BigDecimal v74;

    private BigDecimal v75;

    private BigDecimal v76;

    private BigDecimal v77;

    private BigDecimal v78;

    private BigDecimal v79;

    private BigDecimal v80;

    private BigDecimal v81;

    private BigDecimal v82;

    private BigDecimal v83;

    private BigDecimal v84;

    private BigDecimal v85;

    private BigDecimal v86;

    private BigDecimal v87;

    private BigDecimal v88;

    private BigDecimal v89;

    private BigDecimal v90;

    private BigDecimal v91;

    private BigDecimal v92;

    private BigDecimal v93;

    private BigDecimal v94;

    private BigDecimal v95;
    //96点
    private BigDecimal v96;
    //用电地址
    private String elecAddr;
    //电能表地址
    private String commAddr;
    //终端地址
    private String terminalAddr;
    //上送时间
    private Date recTime;
    //测量点号
    private String mpSn;
    //终端资产号
    private String tmnlAssetNo;
}
