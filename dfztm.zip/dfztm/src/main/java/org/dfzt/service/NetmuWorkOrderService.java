package org.dfzt.service;

import org.dfzt.entity.po.NetmuWorkOrder;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 李木
* @description 针对表【netmu_work_order】的数据库操作Service
* @createDate 2023-05-29 14:22:28
*/
public interface NetmuWorkOrderService extends IService<NetmuWorkOrder> {

    int updateNetmuWorkOrder(NetmuWorkOrder netmuWorkOrder);
}
