package org.dfzt.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.EMpDayRead;
import org.dfzt.mapper.EMpDayReadMapper;
import org.dfzt.service.EMpDayReadService;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Service
public class EMpDayReadServiceImpl extends ServiceImpl<EMpDayReadMapper, EMpDayRead> implements EMpDayReadService {

}
