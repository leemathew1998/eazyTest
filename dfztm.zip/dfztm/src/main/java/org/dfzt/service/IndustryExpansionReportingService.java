package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.IndustryExpansionReporting;

/**
* @author luo
* @description 针对表【Industry_expansion_reporting(业扩报装)】的数据库操作Service
* @createDate 2022-08-03 10:30:03
*/
public interface IndustryExpansionReportingService extends IService<IndustryExpansionReporting> {

}
