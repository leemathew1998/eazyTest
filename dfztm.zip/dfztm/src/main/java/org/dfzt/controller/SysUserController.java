package org.dfzt.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/6
 * @Version: 1.00
 */
@Slf4j
@RestController
@RequestMapping("/sysuser")
@CrossOrigin
public class SysUserController {

    @PostMapping("insert")
    public void insert(){


    }

    @PostMapping("delete")
    public void delete(){


    }

    @PostMapping("update")
    public void update(){


    }

}
