package org.dfzt.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.dfzt.entity.po.CollectInformation;
import org.dfzt.entity.po.CollectWorkOrder;
import org.dfzt.entity.po.MeterWorkOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dfzt-dyy
 * @since 2022-07-11
 */
@Mapper
public interface MeterWorkOrderMapper extends BaseMapper<MeterWorkOrder> {
    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<MeterWorkOrder> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<MeterWorkOrder> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<MeterWorkOrder> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<MeterWorkOrder> entities);

    int insertSelective(MeterWorkOrder record);

    //查询近三天数据
    @Select("SELECT a.total_reverse_active_power,a.elecmeter_asset_num,a.user_name,(@i:= @i+1) AS rank_no , a.create_time\n" +
            "     FROM (\n" +
            "           SELECT *\n" +
            "           FROM collect_information\n" +
            "           ORDER BY create_time DESC\n" +
            "     ) a,(SELECT @i:=0) b\n" +
            "           WHERE create_time > DATE_SUB(NOW(),INTERVAL 3 DAY)\n" +
            "            AND elecmeter_asset_num = #{elecmeter_asset_num}")
    List<CollectInformation> selThreeday(String eleAssNum);

    //查询明细表所有信息
    List<CollectInformation> findAll();

    //近两天0点冻结电能示值
    //当天的
    @Select("SELECT total_positive_active_power,ter_meter_readtime,elecmeter_asset_num FROM collect_information\n" +
            "WHERE ter_meter_readtime > DATE_SUB(CURDATE(),INTERVAL 1 DAY)")
    List<CollectInformation> seltwoD();
    //前一天的
    @Select("SELECT total_positive_active_power,ter_meter_readtime,elecmeter_asset_num FROM collect_information\n" +
            "WHERE ter_meter_readtime = DATE_SUB(CURDATE(),INTERVAL 1 DAY)")
    List<CollectInformation> seloneD();

    //    修改工单状态为2---处理中
    int updateWorkOrderStu2(String id);
    //    修改工单状态为3---待归档
    int updateWorkOrderStu3(String id);
    // 修改工单状态为1---待处理
    int updateWorkOrderStu1(String id);
    // 修改工单状态为4---已归档
    int updateWorkOrderStu4(String id);

    @Select("SELECT * FROM meter_work_order " +
            "WHERE  cons_no = #{userCode} and work_order_status != '4'")
    List<MeterWorkOrder> selectWorkOrder(String userCode);
    //修改工单周期
    int updateWorkOrderCyc2(int workOrderCycle,String workOrderNo);

    //查询三天以上未处理计量异常工单数
    @Select("SELECT COUNT(1) FROM meter_work_order\n" +
            "WHERE work_order_status = 1\n" +
            "AND work_order_ctime < DATE_SUB(CURDATE(),INTERVAL 3 DAY)")
    int selfeilmeter();

    // 查询所有异常工单
    @Select("SELECT event_type,tg_name,work_order_ctime,work_order_no,work_order_status FROM meter_work_order\n" +
            "WHERE work_order_status = 1\n" +
            "AND work_order_ctime < DATE_SUB(CURDATE(),INTERVAL 3 DAY)")
    List<MeterWorkOrder> findfeilmeterAll();

    @Select("SELECT total_positive_active_power \n" +
            "FROM collect_information \n" +
            "WHERE ter_meter_readtime BETWEEN '2022-06-27' AND '2022-06-29'\n" +
            "AND elecmeter_asset_num = #{elecmeterAssetNum};")
    List<Map> selEleVal(String elecmeterAssetNum);

    @Select("SELECT user_role FROM sys_user WHERE login_name = #{loginName}")
    int selRole(String loginName);

    //根据用户编码查询敏感用户
    @Select("SELECT a.* FROM meter_work_order a,superior_sensitivity b\n" +
            "WHERE a.user_code = b.user_id\n" +
            "And b.app_type = 1\n")
    List<MeterWorkOrder> selectAppType();


    MeterWorkOrder selectOne(String workOrderNo);//查询单个工单数据

    CollectInformation selectByUsercode(String consNo);//根据用户编码查询工单的原始数据

    CollectInformation selectByUsercode1(String consNo,String tertime);//根据用户编码查询工单的原始数据

    List<MeterWorkOrder> selectExcelList(@Param("m")MeterWorkOrder m,@Param("orgName") String orgName, @Param("status") String status);//采集运维条件查询


}
