package org.dfzt.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.EMpVolCurve;
import org.dfzt.service.EMpVolCurveService;
import org.dfzt.mapper.EMpVolCurveMapper;
import org.springframework.stereotype.Service;

/**
* @author 李木
* @description 针对表【e_mp_vol_curve】的数据库操作Service实现
* @createDate 2023-02-25 14:24:13
*/
@Service
public class EMpVolCurveServiceImpl extends ServiceImpl<EMpVolCurveMapper, EMpVolCurve>
    implements EMpVolCurveService{

}




