package org.dfzt.job;

import org.dfzt.service.SAppService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

@Component
public class FigureMoldMaintenance extends QuartzJobBean {

    @Autowired
    private SAppService appService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {
        appService.insertPicmaWorkOrder();
    }
}
