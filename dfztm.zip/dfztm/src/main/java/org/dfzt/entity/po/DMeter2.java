package org.dfzt.entity.po;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;

/**
 * (DMeter2)表实体类
 *
 * @author makejava
 * @since 2022-08-01 10:10:42
 */
@SuppressWarnings("serial")
@TableName("d_meter2")
@Data
public class DMeter2 extends Model<DMeter2> {

    private Integer id;
    //资产编号
    private String meterAssetNo;
    //综合倍率
    private String tFactor;
    //是否参考表
    private String refMeterFlag;
    //额定电压
    private String voltCode;
    //标定电流
    private String ratedCurrent;
    //有功准确度等级
    private String apPreLevelCode;
    //无功准确度等级
    private String rpPreLevelCode;
    //接线方式 
    private String wiringMode;
    //接入方式
    private String conMode;
    //制造单位
    private String manufacturer;
    //通信规约
    private String protocolCode;

    //计量点编号
    private String mpNo;
}
