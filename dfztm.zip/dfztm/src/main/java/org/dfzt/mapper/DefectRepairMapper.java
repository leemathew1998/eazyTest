package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.vo.DefectRepair;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Repository
public interface DefectRepairMapper extends BaseMapper<DefectRepair> {
    int insertDefectRepair(DefectRepair defectRepair);//缺陷立行立改修复录入信息

}
