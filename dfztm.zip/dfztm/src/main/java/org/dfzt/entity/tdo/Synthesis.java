package org.dfzt.entity.tdo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00 综合排名
 */
@Data
public class Synthesis {
    //所名称、人名称id
    private String id;
    //所名称、人名称id
    private String name;
    //排序
    private Number sort;
    //当日积分
    private Number currentDayIntegrate;
    //当月积分
    private Number currentMonthIntegrate;
}
