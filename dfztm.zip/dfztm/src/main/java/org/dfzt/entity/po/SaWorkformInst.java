package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

import java.io.Serializable;

@TableName(value ="sa_workform_inst")
@Data
public class SaWorkformInst implements Serializable {
    //主键
    private String instanceId;

    //申请号(工单号)
    private String keydataId;
    private String instanceStatus;
    private String orgNo;
    private String delFlag;
    private String extendOpType;
}