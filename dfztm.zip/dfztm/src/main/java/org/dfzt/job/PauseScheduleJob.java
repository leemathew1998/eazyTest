package org.dfzt.job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

/**
 * @ClassName PauseScheduleJob
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2023/2/27 17:41
 */
public class PauseScheduleJob extends QuartzJobBean {
    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

    }
}
