package org.dfzt;


import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.web.servlet.ServletComponentScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
@EnableWebMvc
@SpringBootApplication(exclude={DataSourceAutoConfiguration.class} )
@MapperScan(basePackages = {"org.dfzt.mapper"})
@EnableScheduling
@EnableOpenApi
@EnableAsync
//@ServletComponentScan
public class DfztApplication {

    public static void main(String[] args) {
        SpringApplication.run(DfztApplication.class, args);
    }



    @Bean
    public Docket docket () {
        return new Docket(DocumentationType.OAS_30);
    }
}
