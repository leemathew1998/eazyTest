package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.dfzt.entity.po.SaWorkformInst;

@DS("mpgt")
@Mapper
public interface SaWorkformInstMapper extends BaseMapper<SaWorkformInst> {

}




