package com.exam.modules.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.exam.modules.entity.AnsRecord;
import com.exam.modules.entity.dto.AnsRecordDTO;
import com.exam.modules.entity.vo.AnsRecordVo;

/**
 * 作答记录(AnsRecord)表服务接口
 *
 * @author dyy
 * @since 2022-11-09 15:33:34
 */
public interface AnsRecordService extends IService<AnsRecord> {

}

