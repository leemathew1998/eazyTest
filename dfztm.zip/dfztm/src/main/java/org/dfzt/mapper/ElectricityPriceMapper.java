package org.dfzt.mapper;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.dfzt.entity.po.CInformation;
import org.dfzt.entity.po.CSp;
import org.dfzt.entity.po.ElectricityPrice;
import org.dfzt.entity.po.SPrcTacticScheme;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */
@Mapper
public interface ElectricityPriceMapper extends BaseMapper<ElectricityPrice> {
    @DS("mpg")
    List<SPrcTacticScheme> selectSPrc(BigDecimal spId);//根据SpId查询出所关联的电价策略信息

    List<BigDecimal> selectKeyIdList();//查询受电点中所有的KeyId

    Integer insertSPrc(ElectricityPrice elecPrice);//将信息添加到表中
}
