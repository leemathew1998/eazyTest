package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.core.metadata.IPage;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.dfzt.entity.po.*;

import java.util.List;

/**
 * @ClassName CcontactList
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/7/29 14:58
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ConTactList {

    private List<IPage<CCons>> cCons;
    private List<IPage<UserBasInfor>> userBasInfor;

    private List<CContact> cContact;
    private List<OStaff> oStaff;

    private List<CInformation> cInformation;

    private List<ElectricityPrice> electricityPrice;

    private Integer total;
}
