package org.dfzt.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.ActiveRepairWo;
import org.dfzt.entity.vo.CollectNum;
import org.dfzt.mapper.*;
import org.dfzt.service.AcStationService;
import org.dfzt.service.AchievementsManagerService;
import org.dfzt.util.TimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.math.BigDecimal;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/6
 * @Version: 1.00
 * TODO 台区经理绩效Controller层
 */
@Slf4j
@RestController
@RequestMapping("/ach")
@CrossOrigin
@Component
public class AchievementsManagerController extends ApiController {
    @Autowired
    private AchievementsManagerService achievementsManagerService;
    @Autowired
    private AcStationService acStationService;
    @Autowired
    private AchievementsManagerMapper achievementsManagerMapper;
    @Autowired
    private AcStationMapper acStationMapper;
    @Resource
    private CollectWorkOrderMapper collMapper;
    @Resource
    private AcAllMapper acAllMapper;





//    public

    /**
     * TODO 台区经理查询具体的工单详情
     * @param tgManager
     * @param achOne
     * @return
     */
    @PostMapping("/oneEach")
    public Object selectoneEach(String tgManager,Integer achOne){
        switch (achOne){
            case 1://采集成功率工单具体工单详情
                //1-(采集失败的用户数量/该客户经理所管辖的所有用户数量)
                return achievementsManagerMapper.selectConfail(tgManager);
            case 2://采集失败处理及时率具体工单详情
                //1-(当天未处理采集失败工单数/所有采集失败工单数)
                return achievementsManagerMapper.selectNoHandle(tgManager);
            case 3://费控复电成功率具体工单详情
                return "从系统单独获取（指令类型为复电，结果为执行成功）/指令类型为复电";
            case 4://费控停电成功率具体工单详情
                return "从系统单独获取（指令类型为停电，结果为执行成功）/指令类型为停电";
            case 5://自动发行比例具体工单详情
                //中止（站长手动归档的客户数）/该台区经理或者该营业所站/旗县所有的营业户数
                return achievementsManagerMapper.selectNoHandle(tgManager);
            case 6://低压线损率具体工单详情
                //台区经理所管辖台区的损耗电量/台区经理所管辖台区的供电量
                return achievementsManagerMapper.selectLowLineloss(tgManager);
            case 7://高损台区占比具体工单详情
                //高损台区（线损为6及以上）个数以上/台区经理管辖的所有台区个数
                return achievementsManagerMapper.selectHighTgNum(tgManager);
            case 8://负损台区占比具体工单详情
                //负损台区个数（线损小于等于-1）/台区经理管辖的所有台区个数
                return achievementsManagerMapper.selectlowTgNum(tgManager);

            case 9://经济运行台区占比具体工单详情
                //线损率在0-4（包含0，4）的台区数量/客户经理管辖的所有台区个数
                return achievementsManagerMapper.selectEconTgNum(tgManager);

            case 10://高负损台区消缺及时率具体工单详情
                //三天以上未处理的高负损台区工单数/所有高负损台区工单数
                return achievementsManagerMapper.selectThreeNoHandle(tgManager);

            case 11://电费回收率（电费结零率）具体工单详情
                //1➖（欠费金额包含偏差考核与价差收益/发行金额）
                return achievementsManagerMapper.selectRecycle11(tgManager);
            case 12://配电异常台区次数具体工单详情
                //同一个台区连续两周出现三相不平衡或低电压，扣2分，连续三周出现三相不平衡或低电压不开展治理的，扣3分，
                // 连续四周及以上出现三相不平衡或低电压，扣5分。
                //在计量运维中获取
                //对连续周次的判断
                return achievementsManagerMapper.selectMeter12(tgManager);
            case 13://现场复电及时率具体工单详情
                //复电时间小于45分钟的工单数/所有现场复电工单数
                return achievementsManagerMapper.selectFeecon1(tgManager);

            case 14://投诉意见工单数量具体工单详情
                //投诉意见工单数量
                return achievementsManagerMapper.selectSuperworko(tgManager);
            case 15://运维抢修现场及时率（包含主动运维以及主动抢修）具体工单详情
                //45min到达现场（app需要加上签到功能，获取定位以及时间）以内的包含45/所有工单数量
                List<ActiveRepairWo> list = new ArrayList<>();
                for (ActiveRepairWo activeRepairWo : achievementsManagerMapper.selectActive(tgManager)) {
                    list.add(activeRepairWo);
                }

                for (ActiveRepairWo selectRepair : achievementsManagerMapper.selectRepairs(tgManager)) {
                    list.add(selectRepair);
                }
                return list;

            case 16://计量消缺及时率具体工单详情
                //1-(三天以上未处理计量异常工单数/所有计量异常工单数)
                return achievementsManagerMapper.selectWorkOrder(tgManager);

        }
        return null;
    }


    @PostMapping("/oneach")
    public AchievementsManager selectAch(String tgno){
        AchievementsManager achManager = achievementsManagerService.selectByTgno(tgno);
        return achManager;
    }

    /**
     * TODO 查询计算过程的数以及总数
     */
    @PostMapping("collall")
    public CollectNum selectcollAll(){
        CollectNum collectNum = new CollectNum();
        collectNum.setCollall(3200);
        collectNum.setCollsucc(3180);
        collectNum.setCollfail(20);
        return collectNum;
    }

    /**
     * TODO 点击查询出所有的营业站信息 PC 11111
     * @return
     */
    @PostMapping("/stationList")
    public R stationList(@RequestParam String ymd,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String id){
        return success(acStationMapper.selectAllStation1(ymd,orgNo,id));
    }



    /**
     * TODO 点击查询出所有的旗县信息 PC 11111
     * @return
     */
    @PostMapping("/countyList")
    public R countyList(@RequestParam String ymd,@RequestParam(required = false) String id){
        return success(acStationMapper.selectAllAcCounty1(ymd, id));
    }

    /**
     * 查询市下面所有旗县的信息
     */
    @PostMapping("/cityList")
    public R cityyList(@RequestParam String ymd,@RequestParam(required = false) String orgNo){
        return success(acStationMapper.selectAllAcCity(ymd, orgNo));
    }

    /**
     * TODO 通过营业站id查询出该营业站下所有台区经理 PC 11111
     * @param id
     * @return
     */
    @PostMapping("/selectStaByman")
    public R selectStaByman(@RequestParam String ymd,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String id
            ,@RequestParam(required = false) String tgManager){
        return success(acStationService.selectByStation(ymd,orgNo,id,tgManager));
    }


    /**
     * TODO 查询单个台区经理 采集成功率 指标分数 PC
     */
    @PostMapping("/dayPoint")
    public R dayPoint(@RequestParam String id){
        return success(achievementsManagerService.selectdayRP(id));//point返回的是得分
    }

    /**
     * TODO 查询某个营业站台区经理的积分曲线 PC
     */
    @PostMapping("/acManagerSp")
    public R acManagerSp(@RequestParam String id){
        return success(acStationService.selectpBySid(id));
    }

    /**
     * TODO 查询某个旗县营业站的积分曲线 PC
     */
    @PostMapping("/acStationSp")
    public R acStationSp(@RequestParam String id){
        return success(acStationService.selectpByCid(id));
    }



    /**
     * TODO 营业站绩效联动效果
     */
    @PostMapping("/selectStaByman1")
    public AcStation selectStaByman1(@RequestParam Integer id){

        List<AcManager> acManagers = null;//acStationService.selectByStation(id,TimeUtil.getTodayTime());
        AcStation acStation = acStationMapper.selectOneStation(id.toString());
        Integer snum = 0;
        Integer s2 = 0;
        int high = 0;
        int low = 0;
        int econ = 0;
        int thrHandle = 0;

        int point = 5;//总分为5
        int pointen = 10;//总分为10
        for (AcManager acManager : acManagers) {
            List<CollectWorkOrder> collectWorkOrders = achievementsManagerMapper.selectNoHandle(acManager.getTgManager());
            if (collectWorkOrders != null && collectWorkOrders.size()>0){
                s2 +=collectWorkOrders.size();
            }
//            s2 += achievementsManagerMapper.selectNoHandle(acManager.getTgManager()).size();//查询该台区经理当天未处理工单条数
            //snum = Integer.parseInt(acManager.getTgNo())+snum;//遍历改营业站下所有台区经理的失败用户

            List<LinelossWorkOrder> linelossWorkOrders = achievementsManagerMapper.selectHighTgNum(acManager.getTgManager());
            if (linelossWorkOrders != null && linelossWorkOrders.size()>0){
                high += linelossWorkOrders.size();
            }
//            high += achievementsManagerMapper.selectHighTgNum(acManager.getTgManager()).size();//线损率为6以上的个数

            List<LinelossWorkOrder> linelossWorkOrders1 = achievementsManagerMapper.selectlowTgNum(acManager.getTgManager());
            if (linelossWorkOrders1 !=null && linelossWorkOrders1.size()>0){
                low +=linelossWorkOrders1.size();
            }
//            low += achievementsManagerMapper.selectlowTgNum(acManager.getTgManager()).size();//线损率小于等于-1台区数量

            List<LinelossWorkOrder> linelossWorkOrders2 = achievementsManagerMapper.selectEconTgNum(acManager.getTgManager());
            if (linelossWorkOrders2 != null && linelossWorkOrders2.size()>0){
                econ +=linelossWorkOrders2.size();
            }
//            econ += achievementsManagerMapper.selectEconTgNum(acManager.getTgManager()).size();//线损率在0-4的台区数量

            List<LinelossWorkOrder> linelossWorkOrders3 = achievementsManagerMapper.selectThreeNoHandle(acManager.getTgManager());
            if (linelossWorkOrders3 != null && linelossWorkOrders3.size()>0){
                thrHandle +=linelossWorkOrders3.size();
            }
//            thrHandle += achievementsManagerMapper.selectThreeNoHandle(acManager.getTgManager()).size();//高负损台区处理及时率的工单数
        }
        if(snum<5){
            BigDecimal rate = new BigDecimal(100).subtract(new BigDecimal(snum).multiply(new BigDecimal(1)));
            achievementsManagerMapper.updateSuccSta(id.toString(),rate,point-snum,snum.toString());
        }else{
            achievementsManagerMapper.updateSuccSta(id.toString(), new BigDecimal(95), 0, snum.toString());
        }

        if(s2<5){
            BigDecimal rate1 = new BigDecimal(100).subtract(new BigDecimal(s2).multiply(new BigDecimal(1)));
            AcStation as = new AcStation();
            as.setId(id);
            as.setColFailRate(rate1);
            as.setColFailPoint(pointen-s2);
            achievementsManagerMapper.updateBytgSta(as);
        }else {
            AcStation as = new AcStation();
            as.setId(id);
            as.setColFailRate(new BigDecimal(95));
            as.setColFailPoint(0);
            achievementsManagerMapper.updateBytgSta(as);
        }

        /**
         * TODO 营业站线损相关绩效
         */
        List<LinelossWorkOrder> lineWs = new ArrayList<>();
        for (AcManager acManager : acManagers) {
            for (LinelossWorkOrder selLowll : achievementsManagerMapper.selectLowLineloss(acManager.getTgManager())) {
                lineWs.add(selLowll);
            }
        }
        for (LinelossWorkOrder lineW : lineWs) {
            BigDecimal lowrate = lineW.getLossPq().divide(lineW.getPpq(), BigDecimal.ROUND_HALF_EVEN);
            BigDecimal l = lowrate.multiply(new BigDecimal(100)).abs();

            int num = 3;//台区经理管辖的台区数
            if (l.compareTo(new BigDecimal(5))==-1){//获取的数据比5小
                AcStation as = new AcStation();
                as.setId(id);
                as.setLowLinelossRate(new BigDecimal(100).subtract(l));
                as.setLowLinelossPoint(5-l.intValue());
                achievementsManagerMapper.updateBytgSta(as);
            }else {
                AcStation as = new AcStation();
                as.setId(id);
                as.setLowLinelossRate(new BigDecimal(95));
                as.setLowLinelossPoint(0);
                achievementsManagerMapper.updateBytgSta(as);
            }
            //高损台区占比
            if(high<5){
                AcStation as = new AcStation();
                as.setId(id);
                as.setHighlossTgRate(new BigDecimal(100).subtract(new BigDecimal(high)));
                as.setHighlossTgPoint(5-high);
                achievementsManagerMapper.updateBytgSta(as);
            }else {
                AcStation as = new AcStation();
                as.setId(id);
                as.setHighlossTgRate(new BigDecimal(95));
                as.setHighlossTgPoint(0);
                achievementsManagerMapper.updateBytgSta(as);
            }
            //负损台区占比
            if(low<5){
                AcStation as = new AcStation();
                as.setId(id);
                as.setLowlossTgRate(new BigDecimal(100).subtract(new BigDecimal(low)));
                as.setLowlossTgPoint(5-low);
                achievementsManagerMapper.updateBytgSta(as);
            }else {
                AcStation as = new AcStation();
                as.setId(id);
                as.setLowlossTgRate(new BigDecimal(95));
                as.setLowlossTgPoint(0);
                achievementsManagerMapper.updateBytgSta(as);
            }
            //经济运行台区占比
            if(econ>=0){
                AcStation as = new AcStation();;
                as.setId(id);
                as.setEconrunTgRate(new BigDecimal(100).subtract(new BigDecimal(econ)));
                achievementsManagerMapper.updateBytgSta(as);
            }
            //高负损台区处理及时率
            if(thrHandle<5){
                AcStation as = new AcStation();
                as.setId(id);
                as.setTgHandleRate(new BigDecimal(100).subtract(new BigDecimal(thrHandle)));
                as.setTgHandlePoint(5-thrHandle);
                achievementsManagerMapper.updateBytgSta(as);
            }else {
                AcStation as = new AcStation();
                as.setId(id);
                as.setTgHandleRate(new BigDecimal(95));
                as.setTgHandlePoint(0);
                achievementsManagerMapper.updateBytgSta(as);
            }
        }

        return acStation;
    }




    /**
     * TODO 通过营业站id查询出该营业站具体信息
     * @param id
     * @return
     */
    @PostMapping("/selectStaPoint")
    public R selectStaPoint(@RequestParam Integer id){
        return success(achievementsManagerService.selectStaPoint(id));
    }



    /**
     * TODO 通过旗县id查询出该旗县下所有营业站
     * @param id
     * @return
     */
    @PostMapping("/selectCouBysta")
    public R selectByCounty(@RequestParam Integer id){
        return success(acStationService.selectByCounty(id));
    }

    /**
     * TODO 通过旗县id查询出该旗县下所有营业站的绩效信息
     * @param id
     * @return
     */
    @PostMapping("/selectCouBysta1")
    public AcCounty selectByCounty1(@RequestParam Integer id){
        List<AcStation> acStations = acStationService.selectByCounty(id);
        AcCounty acCounty = acStationMapper.selectOneCounty(id.toString());
        Integer snum = 0;
        Integer s2 = 0;
        int high = 0;
        int low = 0;
        int econ = 0;
        int thrHandle = 0;

        int point = 5;//总分为5
        int pointen = 10;//总分为10
        for (AcStation acStation : acStations) {
            List<CollectWorkOrder> collectWorkOrders1 = achievementsManagerMapper.selectNoHandle(acStation.getStationName());
            if (collectWorkOrders1 !=null && collectWorkOrders1.size()>0){
                s2 +=collectWorkOrders1.size();
            }
//            s2 += achievementsManagerMapper.selectNoHandle(acStation.getStationName()).size();//查询该台区经理当天未处理工单条数
            //snum = Integer.parseInt(acStation.getTgName())+snum;//遍历改营业站下所有台区经理的失败用户

            List<LinelossWorkOrder> linelossWorkOrders = achievementsManagerMapper.selectHighTgNum(acStation.getStationName());
            if (linelossWorkOrders !=null && linelossWorkOrders.size()>0){
                high +=linelossWorkOrders.size();
            }
//            high += achievementsManagerMapper.selectHighTgNum(acStation.getStationName()).size();//线损率为6以上的个数

            List<LinelossWorkOrder> linelossWorkOrders1 = achievementsManagerMapper.selectlowTgNum(acStation.getStationName());
            if (linelossWorkOrders1 !=null && linelossWorkOrders1.size()>0){
                low += linelossWorkOrders1.size();
            }
//            low += achievementsManagerMapper.selectlowTgNum(acStation.getStationName()).size();//线损率小于等于-1台区数量

            List<LinelossWorkOrder> linelossWorkOrders2 = achievementsManagerMapper.selectEconTgNum(acStation.getStationName());
            if (linelossWorkOrders2 !=null && linelossWorkOrders2.size()>0){
                econ +=linelossWorkOrders2.size();
            }
//            econ += achievementsManagerMapper.selectEconTgNum(acStation.getStationName()).size();//线损率在0-4的台区数量

            List<LinelossWorkOrder> linelossWorkOrders3 = achievementsManagerMapper.selectThreeNoHandle(acStation.getStationName());
            if (linelossWorkOrders3 !=null && linelossWorkOrders3.size()>0){
                thrHandle +=linelossWorkOrders3.size();
            }
//            thrHandle += achievementsManagerMapper.selectThreeNoHandle(acStation.getStationName()).size();//高负损台区处理及时率的工单数

        }
        if(snum<5){
            BigDecimal rate = new BigDecimal(100).subtract(new BigDecimal(snum).multiply(new BigDecimal(1)));
            achievementsManagerMapper.updateSuccSta(id.toString(),rate,point-snum,snum.toString());
        }else{
            achievementsManagerMapper.updateSuccSta(id.toString(), new BigDecimal(95), 0, snum.toString());
        }

        if(s2<5){
            BigDecimal rate1 = new BigDecimal(100).subtract(new BigDecimal(s2).multiply(new BigDecimal(1)));
            AcStation as = new AcStation();
            as.setId(id);
            as.setColFailRate(rate1);
            as.setColFailPoint(pointen-s2);
            achievementsManagerMapper.updateBytgSta(as);
        }else {
            AcStation as = new AcStation();
            as.setId(id);
            as.setColFailRate(new BigDecimal(95));
            as.setColFailPoint(0);
            achievementsManagerMapper.updateBytgSta(as);
        }

        /**
         * TODO 旗县线损相关绩效
         */
        List<LinelossWorkOrder> lineWs = new ArrayList<>();
        for (AcStation acStation1: acStations) {
            for (LinelossWorkOrder selLowll : achievementsManagerMapper.selectLowLineloss(acStation1.getStationName())) {
                lineWs.add(selLowll);
            }
        }
        for (LinelossWorkOrder lineW : lineWs) {
            BigDecimal lowrate = lineW.getLossPq().divide(lineW.getPpq(), BigDecimal.ROUND_HALF_EVEN);
            BigDecimal l = lowrate.multiply(new BigDecimal(100)).abs();

            int num = 3;//台区经理管辖的台区数
            if (l.compareTo(new BigDecimal(5))==-1){//获取的数据比5小
                AcStation as = new AcStation();
                as.setId(id);
                as.setLowLinelossRate(new BigDecimal(100).subtract(l));
                as.setLowLinelossPoint(5-l.intValue());
                achievementsManagerMapper.updateBytgSta(as);
            }else {
                AcStation as = new AcStation();
                as.setId(id);
                as.setLowLinelossRate(new BigDecimal(95));
                as.setLowLinelossPoint(0);
                achievementsManagerMapper.updateBytgSta(as);
            }
            //高损台区占比
            if(high<5){
                AcStation as = new AcStation();
                as.setId(id);
                as.setHighlossTgRate(new BigDecimal(100).subtract(new BigDecimal(high)));
                as.setHighlossTgPoint(5-high);
                achievementsManagerMapper.updateBytgSta(as);
            }else {
                AcStation as = new AcStation();
                as.setId(id);
                as.setHighlossTgRate(new BigDecimal(95));
                as.setHighlossTgPoint(0);
                achievementsManagerMapper.updateBytgSta(as);
            }
            //负损台区占比
            if(low<5){
                AcStation as = new AcStation();
                as.setId(id);
                as.setLowlossTgRate(new BigDecimal(100).subtract(new BigDecimal(low)));
                as.setLowlossTgPoint(5-low);
                achievementsManagerMapper.updateBytgSta(as);
            }else {
                AcStation as = new AcStation();
                as.setId(id);
                as.setLowlossTgRate(new BigDecimal(95));
                as.setLowlossTgPoint(0);
                achievementsManagerMapper.updateBytgSta(as);
            }
            //经济运行台区占比
            if(econ>=0){
                AcStation as = new AcStation();;
                as.setId(id);
                as.setEconrunTgRate(new BigDecimal(100).subtract(new BigDecimal(econ)));
                achievementsManagerMapper.updateBytgSta(as);
            }
            //高负损台区处理及时率
            if(thrHandle<5){
                AcStation as = new AcStation();
                as.setId(id);
                as.setTgHandleRate(new BigDecimal(100).subtract(new BigDecimal(thrHandle)));
                as.setTgHandlePoint(5-thrHandle);
                achievementsManagerMapper.updateBytgSta(as);
            }else {
                AcStation as = new AcStation();
                as.setId(id);
                as.setTgHandleRate(new BigDecimal(95));
                as.setTgHandlePoint(0);
                achievementsManagerMapper.updateBytgSta(as);
            }
        }

        return acCounty;
    }


    /**
     * 分页查询所有数据
     *
     * @return 所有数据
     */
    @PostMapping("/selectAcCounty")
    public R selectAcCounty(@RequestParam Map map) {
        return success(achievementsManagerService.selectAcCounty(map));
    }

    @PostMapping("/selectAcStation")
    public R selectAcStation(@RequestParam Map map) {
        return success(achievementsManagerMapper.achievementinfo());
    }




    /**
     * TODO 查询单个台区经理所对应的采集失败工单详情
     */
    @PostMapping("/managerWorkOrder")
    public List<CollectWorkOrder> managerWorkOrder(@RequestParam String tgManager){
        return achievementsManagerService.managerWorkOrder(tgManager);//point返回的是得分
    }
    /**
     * TODO 查询单个台区经理所对应的当天未处理采集失败工单详情
     */
    @PostMapping("/selectNoHandle")
    public List<CollectWorkOrder> selectNoHandle(@RequestParam String tgManager){
        return achievementsManagerMapper.selectNoHandle(tgManager);
    }

    /**
     * TODO 查询单个台区经理所对应的线损治理工单详情 (包含低压线损率，列出工单的损耗电量和供电量)
     */
    @PostMapping("/managerLineWorkOrder")
    public List<LinelossWorkOrder> managerLineWorkOrder(@RequestParam String tgManager){
        return achievementsManagerMapper.selectLowLineloss(tgManager);
    }


    /**
     * TODO 查询 高损台区占比 相关工单详情 线损率为6以上的个数
     */
    @PostMapping("/selectHighWork")
    public List<LinelossWorkOrder> selectHighWork(String tgManager){
        return achievementsManagerMapper.selectHighTgNum(tgManager);
    }

    /**
     * TODO 查询 负损台区占比 相关工单详情 线损率小于等于-1的个数
     */
    @PostMapping("/selectlowWork")
    public List<LinelossWorkOrder> selectlowWork(String tgManager){
        return achievementsManagerMapper.selectlowTgNum(tgManager);
    }

    /**
     * TODO 经济 运行台区占比 相关工单详情 线损率在0-4的台区数量
     */
    @PostMapping("/selectEconWork")
    public List<LinelossWorkOrder> selectEconWork(String tgManager){
        return achievementsManagerMapper.selectEconTgNum(tgManager);
    }
    /**
     * TODO 高负损台区处理及时率 相关工单详情 三天未处理的工单
     */
    @PostMapping("/selectThreeWork")
    public List<LinelossWorkOrder> selectThreeWork(String tgManager){
        return achievementsManagerMapper.selectThreeNoHandle(tgManager);
    }


    /**
     *TODO 营业站下所有失败条数，再进行指标计算和积分
     */
    @PostMapping("/oneStation")
    public AcStation stationPoint(@RequestParam String acStationId){
        //根据营业站id，查询出该营业站下所有台区经理信息，获取失败条数，就是该营业站的失败条数
        List<AcManager> acManagers = acStationService.selectStationP(acStationId);
        int Snum = 0;//营业站的失败总数
        for (AcManager acManager : acManagers) {
            String temp = acManager.getTgNo();
            if (temp != null){
                int tgNo = Integer.parseInt(temp);
                Snum +=tgNo;
            }
        }
        //根据营业站id修改营业站总失败条数
        int i = acStationService.updateSnum(acStationId, Snum);
        AcStation acStation = acStationService.selectOneStation(acStationId);
        return acStation;
    }

    @RequestMapping("getAcCity")
    @Async
    @Scheduled(cron = "01 10 00 * * ? ")
    public String getAcCity(){
        AcCity acCity = new AcCity();
        acCity.setCityName("国网呼伦贝尔供电公司");
        acCity.setOrgNo("15421");
        BigDecimal i0 = BigDecimal.ZERO;
        AcAll acAll = new AcAll();
        String ym = TimeUtil.getStartMon1();
        String ymd = TimeUtil.getStart5Time();
        acAll.setAcName("国网呼伦贝尔供电公司");
        acAll.setDataDate(new DateTime());
        acAll.setYmd(ymd);
        acAll.setOrgNo("15421");
        acAll.setAcId("4");
        //TODO 采集成功率1
        Integer int1a = achievementsManagerMapper.selectAcCity1(ymd);//采集失败用户数量
        if(int1a==null)int1a=0;//固化采集失败用户数量
        BigDecimal i1 = new BigDecimal(int1a);//采集失败工单数
        acAll.setFailNums(int1a);////固态数据新增
        Integer int1 = achievementsManagerMapper.selectAllnums();//所有用户数
        if(int1==null||int1==0)int1=1;
        BigDecimal j1 = new BigDecimal(int1);//管理的总用户数
        acAll.setAllNums(int1);//固态数据新增
        acAll.setAllNums5(j1.toString());//固态数据新增
        //得出扣分数
        BigDecimal s1 = new BigDecimal("1").subtract(i1.divide(j1, 4, BigDecimal.ROUND_HALF_UP));
        acCity.setColSuccRate(s1.multiply(new BigDecimal("100")).setScale(2).doubleValue());
        Integer p1 = Integer.parseInt(new BigDecimal("0.9997").subtract(s1).divide(new BigDecimal("0.0001")).toString());
        Integer t1 =0;
        if(p1 <= 5 && p1>0){
            t1=5-p1;
        }else if(p1 <= 0){
            t1=5;
        }else {
            t1=0;
        }
        acCity.setColSuccPoint(t1);

        //TODO 采集失败及时处理率 2
        BigDecimal i2;
        Integer int2 = achievementsManagerMapper.selectAcCityzb2(ymd);
        if (int2==null)int2=0;
        i2 = new BigDecimal(int2);//采集失败未处理数量
        if (i2.compareTo(i0)==0){
            i2= new BigDecimal("1");
        }
        acAll.setNohandleNums(int2);//固化数据
        if (i1==null || i1.compareTo(i0)==0){
            i1= new BigDecimal("1");
        }
        BigDecimal r2 = i2.divide(i1, 4, BigDecimal.ROUND_HALF_UP);
        Integer p2 = Integer.parseInt(r2.divide(new BigDecimal("0.1"),0,BigDecimal.ROUND_HALF_UP).toString());
        acCity.setColFailPoint(10-p2);
        acCity.setColFailRate((new BigDecimal("1").subtract(r2)).multiply(new BigDecimal("100")).setScale(2).doubleValue());
        //TODO 费控停电成功率和费控复电成功率 3 4

        Integer i3all = achievementsManagerMapper.selectFee3(ymd, null);//复电总数
        Integer i3succ = achievementsManagerMapper.selectFee3(ymd, "03");//复电执行成功
        acAll.setFeestartSucnums(i3succ.toString());//固化数据
        acAll.setFeestartAllnums(i3all.toString());//固化数据
        acCity.setCostconComeRate(new BigDecimal((float)(i3succ+1)/(i3all+1)).setScale(4,BigDecimal.ROUND_HALF_UP).doubleValue()*100);
        Integer i4all = achievementsManagerMapper.selectFee4(ymd, null);//停电总数
        Integer i4succ = achievementsManagerMapper.selectFee4(ymd, "03");//停电执行成功数
        acAll.setFeestopSucnums(i4succ.toString());//固化数据
        acAll.setFeestopAllnums(i4all.toString());//固化数据
        acCity.setCostconStopRate(new BigDecimal((float)(i4succ+1)/(i4all+1)).setScale(4,BigDecimal.ROUND_HALF_UP).doubleValue()*100);
        //TODO 自动发行占比 5
        BigDecimal b5 = new BigDecimal((float) 10 / (int1+1)).setScale(4, BigDecimal.ROUND_HALF_UP);
        acAll.setHandNums("0");//固化数据
        acCity.setAutoPublishRate(b5);
        Integer t5;
        Integer i5 = Integer.parseInt(b5.divide(new BigDecimal("0.001"), 0, BigDecimal.ROUND_HALF_UP).toString())-1;
        if(i5 <= 5 && i5>0){
            t5=5-i5;
        }else if(i5 <= 0){
            t5=5;
        }else {
            t5=0;
        }
        acCity.setAutoPublishPoint(t5);
        //TODO 低压线损率 6
        BigDecimal bigDecimal = achievementsManagerMapper.selectLoss6(TimeUtil.getStartTwoTime());//要改 TWO
        //BigDecimal bigDecimal = collMapper.selectLoss6(cons.getOrgName(), TimeUtil.getStartThreeTime());
        if (bigDecimal==null){
            bigDecimal = BigDecimal.ZERO;
        }
        acAll.setLossPqall(bigDecimal.toString());//固化数据
        BigDecimal multiply = bigDecimal.multiply(new BigDecimal("100"));
        acCity.setLowLinelossRate(multiply.doubleValue());
        acCity.setLowLinelossPoint(5);
        //TODO 高损台区占比 7
        //TODO 负损台区占比 8
        //TODO 经济运行台区占比 9

        Integer i7s = achievementsManagerMapper.selectLine8(TimeUtil.getStartTwoTime());
        if(i7s == null) i7s=0;
        acAll.setLossrateHigh(i7s.toString());//固化数据
        Integer i7 = achievementsManagerMapper.selectActgNums();//TODO 旗县管辖的台区数
        if (i7==null || i7==0) i7=1;
        acAll.setTgNums(i7);//固化数据
        BigDecimal d7 = new BigDecimal(i7s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
        Integer s7 = Integer.parseInt(d7.divide(new BigDecimal("0.05"), 0, BigDecimal.ROUND_HALF_DOWN).toString());
        Integer t7;
        if(s7<=5 && s7 >0){
            t7 = 5-s7;
        }else if(s7 <=0){
            t7 = 5;
        }else {
            t7 = 0;
        }
        acCity.setHighlossTgPoint(t7);
        acCity.setHighlossTgRate(d7.doubleValue());
        Integer i8s = achievementsManagerMapper.selectLine9(TimeUtil.getStartTwoTime());
        if(i8s==null) i8s=0;
        acAll.setLossrateLow(i8s.toString());
        BigDecimal d8 = new BigDecimal(i8s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
        Integer s8 = Integer.parseInt(d8.divide(new BigDecimal("0.05"), 0, BigDecimal.ROUND_HALF_DOWN).toString());
        Integer t8;
        if(s8<=5 && s8 >0){
            t8 = 5-s8;
        }else if(s8 <=0){
            t8 = 5;
        }else {
            t8 = 0;
        }
        acCity.setLowlossTgRate(d8.doubleValue());
        acCity.setLowlossTgPoint(t8);

        Integer i9s = achievementsManagerMapper.selectLine10(TimeUtil.getStartTwoTime());
        if(i9s==null) i9s=0;
        acAll.setLossrateNormal(i9s.toString());
        BigDecimal d9 = new BigDecimal(i9s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
        acCity.setEconrunTgRate(d9.doubleValue());
        acCity.setEconrunTgPoint(0);


        //TODO 高负损台区处理及时率 10
        Integer i10s = i7s+i8s;//高负损工单数
        acAll.setLinelossAlls(i10s.toString());//固化数据
        if(i10s==null || i10s==0)i10s=1;
        Integer i10 = collMapper.selectAcCou10();//三天以上未处理工单数
        if(i10==null) i10=0;
        acAll.setLinelossThreehandle(i10.toString());//固化数据
        BigDecimal b10 = new BigDecimal((float) 1-((i10)/ (i10s))).setScale(2, BigDecimal.ROUND_HALF_UP);
        Integer p10= Integer.parseInt(b10.multiply(new BigDecimal("10")).setScale(0).toString());
        acCity.setTgHandleRate(b10.doubleValue()*100);
        acCity.setTgHandlePoint(p10);

        //TODO 电费结零率 11

        BigDecimal a11 = achievementsManagerMapper.selectAcCou11a(ym);//查看该市级发行金额总和
        if (a11==null || a11==BigDecimal.ZERO){
            a11 = new BigDecimal("1");
        }
        acAll.setRcvblAmt(a11.toString());//固化数据
        BigDecimal b11 = achievementsManagerMapper.selectAcCou11b(ym);//查看该市级欠费金额总和
        if (b11==null){
            b11 = BigDecimal.ZERO;
        }
        acAll.setRcvblPenalty(b11.toString());//固化数据
        BigDecimal s11 = new BigDecimal("1").subtract(b11.divide(a11, 4, BigDecimal.ROUND_HALF_UP));
        Integer p11 = s11.divide(new BigDecimal("0.01"), 0, BigDecimal.ROUND_HALF_UP).intValue();
        Integer t11=0;
        if(p11<=10 && p11>=0){
            t11 = 10-p11;
        }else {
            t11 = 0;
        }
        acCity.setPowerfeesZeroRate(s11.doubleValue());
        acCity.setPowerfeesZeroPoint(t11);
        //TODO 异常台区治理 12

        acCity.setExceptTgNum(0);
        acCity.setExceptTgPoint(5);
        acAll.setTgexceNums("0");
        //TODO 现场复电处理及时率 13
        Integer n13 = achievementsManagerMapper.selectAc13(ymd);//复电小于45分钟工单数
        if(n13==null) n13=0;
        acAll.setReply45Nums(n13.toString());//固化数据
        Integer n13a = achievementsManagerMapper.selectAc13a(ymd);//所有复电工单数
        double p13 = 10;
        if (n13a==null || n13a ==0){
            acCity.setPowerbackHandleRate(100.0);
            acCity.setPowerbackHandlePoint((int) p13);
            acAll.setReplyAllnums(n13a.toString());//固化数据
        }else {
            acCity.setPowerbackHandleRate((double) (n13 / n13a));
            p13=(n13 / n13a) * 10;
            acCity.setPowerbackHandlePoint((int) p13);
            acAll.setReplyAllnums(n13a.toString());//固化数据
        }
        //TODO 投诉意见工单数量 14
        //List<String> orgName = collMapper.selectOrgnos(orgNo);
        Integer i14 = 0;
        Integer j14 = 0;
//            for (String orgNo1 : orgName) {
        Integer tempi14 = achievementsManagerMapper.selectAc14tou(ymd);//投诉工单数
        if (tempi14==null) tempi14=0;
        acAll.setComplaintNums(tempi14.toString());//固化数据
        i14+=tempi14;
        Integer tempj14 = achievementsManagerMapper.selectAc14yi(ymd);//意见工单数
        if (tempj14==null) tempj14=0;
        acAll.setOpinionNums(tempj14.toString());//固化数据
        j14+=tempj14;
//            }
        Integer p14 = 5*i14+ j14;
        Integer t14 = 10;
        if(p14<=10) {
            t14 = 10 - p14;
        }else {
            t14 =0;
        }
        acCity.setComplaintWorkorderNum(i14+j14);
        acCity.setComplaintWorkorderPoint(t14);
        //TODO 运维抢修到达现场及时率 15
        acAll.setSceneNums("0");
        acAll.setSceneAllnums("0");//
        acCity.setRepairSceneRate(100.0);
        acCity.setRepairScenePoint(10);
        //TODO 计量异常处理及时率 16
        Integer n16a = achievementsManagerMapper.selectAc16a(ymd);//计量总工单数
        Integer n16 = achievementsManagerMapper.selectAc16(ymd);//计量大于三天未处理工单数
        if (n16==null) n16=0;
        acAll.setMeterThreenums(n16.toString());
        double p16 = 10;
        if (n16a==null || n16a ==0){
            acCity.setMeterHandleRate(100.0);
            acCity.setMeterHandlePoint((int) p16);
            acAll.setMeterAllnums(n16a.toString());//固化数据
        }else {
            acCity.setPowerbackHandleRate((double) (n16 / n16a));
            p16=(n16 / n16a) * 10;
            acCity.setPowerbackHandlePoint((int) p16);
            acAll.setMeterAllnums(n16a.toString());//固化数据
        }
        acAll.setYmd(TimeUtil.getStart5Time());
        acAllMapper.insertSelective(acAll);
        acCity.setMeterHandleRate(100.0);
        acCity.setMeterHandlePoint(10);
        acCity.setToPoint(String.valueOf(t1+(10-p2)+t5+t7+t8+p10+t14+20));
        achievementsManagerMapper.insertAcCity(acCity);
        acAllMapper.insertSelective(acAll);
        return "市级生成绩效";
    }

    @RequestMapping("getAlltgman")
    @Async
    @Scheduled(cron = "01 30 02 * * ? ")
    public String getAlltgman(){
        //user_name1,read_name,org_no,org_name,cons_num,tg_num
        //查询出用户登录名 营销抄表员,抄表员姓名 营销,供电单位编号,供电单位名称,台区经理管辖用户数,台区经理管辖台区数
        List<UserRole> userRoles = achievementsManagerMapper.selectUserRoleAll();
        //List<AcManager> acManagers = new ArrayList<>();

        for (UserRole userRole : userRoles) {
            AcAll acAll = new AcAll();
            BigDecimal i0 = BigDecimal.ZERO;
            String ym = TimeUtil.getStartMon1();
            String userName1 = userRole.getUserName1();
            AcManager acManager = new AcManager();
            String ymd = TimeUtil.getStart5Time();
            String ymd2 = TimeUtil.getStartTwoTime();
            acManager.setYmd(ymd);
            acManager.setDataDate(new DateTime());
            acAll.setDataDate(new DateTime());
            acAll.setAcName(userRole.getReadName());
            acAll.setOrgNo(userRole.getOrgNo());
            acAll.setReadName(userName1);
            acAll.setAcId("1");
            acManager.setTgManager(userRole.getReadName());
            acManager.setAcStationId(userRole.getOrgNo());
            //TODO 采集成功率1
            Integer int1a = achievementsManagerMapper.selecttgd1(userRole.getReadName(), ymd);
            if(int1a==null)int1a=0;
            BigDecimal i1 = new BigDecimal(int1a);//采集失败工单数
            acAll.setFailNums(int1a);////固态数据新增
            Integer int1 = collMapper.selectUserNameConsNum(userName1);
            if(int1==null||int1==0)int1=1;
            BigDecimal j1 = new BigDecimal(int1);//管理的总用户数
            acAll.setAllNums(int1);//固态数据新增
            acAll.setAllNums5(j1.toString());//固态数据新增
            //得出扣分数
            BigDecimal s1 = new BigDecimal("1").subtract(i1.divide(j1, 4, BigDecimal.ROUND_HALF_UP));
            acManager.setColSuccRate(s1.multiply(new BigDecimal("100")).setScale(2));
            Integer p1 = Integer.parseInt(new BigDecimal("0.9997").subtract(s1).divide(new BigDecimal("0.0001")).toString());
            Integer t1 =0;
            if(p1 <= 5 && p1>0){
                t1=5-p1;
            }else if(p1 <= 0){
                t1=5;
            }else {
                t1=0;
            }
            acManager.setColSuccPoint(t1);
            //TODO 采集失败及时处理率2
            Integer int2 = achievementsManagerMapper.selecttgd2(userRole.getReadName(), ymd);
            if(int2==null)int2=0;
            BigDecimal i2 = new BigDecimal(int2);//采集失败未处理数量
            acAll.setNohandleNums(int2);//固态数据新增
            if (i2.compareTo(i0)==0){
                i2= new BigDecimal("1");
            }
            if (i1.compareTo(i0)==0){
                i1= new BigDecimal("1");
            }
            BigDecimal r2 = i2.divide(i1, 4, BigDecimal.ROUND_HALF_UP);
            //得出扣分数
            Integer p2 = Integer.parseInt(r2.divide(new BigDecimal("0.1"),0,BigDecimal.ROUND_HALF_UP).toString());
            acManager.setColFailPoint(10-p2);
            acManager.setColFailRate((new BigDecimal("1").subtract(r2)).multiply(new BigDecimal("100")).setScale(2));
            acManager.setCostconComeRate(new BigDecimal("100"));
            acManager.setCostconStopRate(new BigDecimal("100"));
            //TODO 费控停电成功率和费控复电成功率 3 4
            //collMapper.

            //TODO 自动发行占比5
            acManager.setAutoPublishPoint(5);//建议所站长归档的操作新建一张表记录 工单类型，工单编号，单位，台区经理--要改
            acManager.setAutoPublishRate(BigDecimal.ZERO);
            acAll.setHandNums("0");
            //TODO 低压线损率6
            BigDecimal bi6 = achievementsManagerMapper.selectLossMan61(userRole.getReadName(), ymd2);
            if(bi6==null) bi6=BigDecimal.ZERO;

            BigDecimal i6a = achievementsManagerMapper.selectLossMan61a(userRole.getReadName(), ymd2);
            if(i6a==null)i6a= BigDecimal.ZERO;
            acAll.setLossPqall(i6a.toString());//固态数据新增
            BigDecimal i6b = achievementsManagerMapper.selectLossMan61b(userRole.getReadName(), ymd2);
            if(i6b==null)i6b = BigDecimal.ZERO;
            acAll.setPpqAll(i6b.toString());//固态数据新增
            acManager.setLowLinelossRate(bi6);
            acManager.setLowLinelossPoint(5);
            //TODO 高损台区占比7
            BigDecimal i8 = new BigDecimal(achievementsManagerMapper.selecttgd8(userRole.getReadName(), ymd2));//当日高线损台区数量
            if (i8.compareTo(i0)==0){
                i8= new BigDecimal("1");
            }
            acAll.setLossrateHigh(i8.toString());//固态数据新增
            BigDecimal i9 = new BigDecimal(achievementsManagerMapper.selecttgd9(userRole.getReadName(), ymd2));//当日负线损台区数量
            if (i9.compareTo(i0)==0){
                i9= new BigDecimal("1");
            }
            acAll.setLossrateLow(i9.toString());//固态数据新增
            Integer int8 = collMapper.selectUserNameTgNum(userName1);
            if(int8==0||int8==null)int8=1;
            BigDecimal tgNum = new BigDecimal(int8);//台区经理管辖台区数
            acAll.setTgNums(int8);//固态数据新增
            BigDecimal r8 = i8.divide(tgNum, 2, BigDecimal.ROUND_HALF_UP);
            acManager.setHighlossTgRate(r8);
            //扣分数
            Integer s8 = Integer.parseInt(r8.divide(new BigDecimal("0.05"), 0, BigDecimal.ROUND_HALF_DOWN).toString());
            Integer t8;
            if(s8<=5 && s8 >0){
                t8 = 5-s8;
            }else if(s8 <=0){
                t8 = 5;
            }else {
                t8 = 0;
            }
            acManager.setHighlossTgPoint(t8);
            //TODO 负损台区占比8

            BigDecimal r9 = i9.divide(tgNum, 2, BigDecimal.ROUND_HALF_UP);
            acManager.setHighlossTgRate(r9);
            //扣分数
            Integer s9 = Integer.parseInt(r9.divide(new BigDecimal("0.05"), 0, BigDecimal.ROUND_HALF_DOWN).toString());
            Integer t9 = 5;
            if(s9<=5 && s9 > 0){
                t9 = 5-s9;
            }else if(s9 <= 0){
                t9 = 5;
            }else {
                t9 = 0;
            }
            acManager.setHighlossTgPoint(t9);
            //TODO 经济运行台区占比（计算正常线损率的台区）9
            BigDecimal i89 = new BigDecimal(achievementsManagerMapper.selecttgd89(userRole.getReadName(), ymd2));//当日正常线损台区数量
            if (i89.compareTo(i0)==0){
                i89= new BigDecimal("0");
            }
            acAll.setLossrateNormal(i89.toString());//固态数据新增
            BigDecimal r89 = i89.divide(tgNum, 2, BigDecimal.ROUND_HALF_UP);
            acManager.setEconrunTgRate(r89);

            //TODO 高负损台区消缺及时率10
            BigDecimal i11 = new BigDecimal(achievementsManagerMapper.selecttgd11(userRole.getReadName()));//三天以上未处理工单数
            if (i11.compareTo(i0)==0){
                i11= new BigDecimal("1");
            }
            acAll.setLinelossThreehandle(i11.toString());//固态数据新增
            acAll.setLinelossAlls(i8.add(i9).toString());//固态数据新增
            BigDecimal r11 = i11.divide(i8.add(i9),4,BigDecimal.ROUND_HALF_UP);
            //扣分数
            Integer p11 = Integer.parseInt(r11.divide(new BigDecimal("0.1"),0,BigDecimal.ROUND_HALF_UP).toString());
            acManager.setTgHandlePoint(10-p11);
            acManager.setTgHandleRate((new BigDecimal("1").subtract(r2)).multiply(new BigDecimal("100")).setScale(2));

            //TODO 电费结零率11
            BigDecimal a11 = collMapper.selectAcMan11a(userRole.getReadName(), ym);//查看该台区经理发行金额总和
            if (a11==null || a11==BigDecimal.ZERO){
                a11 = new BigDecimal("1");
            }
            acAll.setRcvblPenalty(a11.toString());//固态数据新增
            BigDecimal b11 = collMapper.selectAcMan11b(userRole.getReadName(),ym);//查看该台区经理欠费金额总和
            if (b11==null){
                b11 = BigDecimal.ZERO;
            }
            acAll.setRcvblAmt(b11.toString());//固态数据新增
            BigDecimal s11 = new BigDecimal("1").subtract(b11.divide(a11, 4, BigDecimal.ROUND_HALF_UP));
            Integer p11a = s11.divide(new BigDecimal("0.01"), 0, BigDecimal.ROUND_HALF_UP).intValue();
            Integer t11=0;
            if(p11a<=10 && p11a>=0){
                t11 = 10-p11a;
            }else {
                t11 = 0;
            }
            acManager.setPowerfeesZeroRate(s11);
            acManager.setPowerfeesZeroPoint(t11);

            //TODO 异常台区治理12
            acManager.setExceptTgNum(0);
            acAll.setTgexceNums("0");//固态数据新增
            acManager.setExceptTgPoint(5);
            //TODO 现场复电处理及时率 13
            Integer n13 = collMapper.selectAcMan13aa(userRole.getReadName(), ymd);//复电小于45分钟工单数
            if(n13==null) n13=0;
            acAll.setReply45Nums(n13.toString());//固态数据新增
            acAll.setFeestartSucnums(n13.toString());//固态数据新增
            Integer n13a = collMapper.selectAcMan13a(userRole.getReadName(),ymd);//所有复电工单数
            double p13 = 10;
            if (n13a==null || n13a ==0){
                acManager.setPowerbackHandleRate(new BigDecimal("100"));
                acManager.setCostconComeRate(new BigDecimal("100"));
                acManager.setPowerbackHandlePoint((int) p13);
                acAll.setReplyAllnums(n13.toString());//固态数据新增
                acAll.setFeestartAllnums(n13.toString());//固态数据新增
            }else {
                acManager.setPowerbackHandleRate(new BigDecimal((double) (n13 / n13a)));
                p13=(n13 / n13a) * 10;
                acManager.setPowerbackHandlePoint((int) p13);
                acManager.setCostconComeRate(new BigDecimal((double) (n13 / n13a)));
                acAll.setReplyAllnums(n13.toString());//固态数据新增
                acAll.setFeestartAllnums(n13.toString());//固态数据新增
            }
            //TODO 投诉意见工单数量14
            Integer i15 = achievementsManagerMapper.selecttgd15(userRole.getReadName(), ymd);//投诉工单数
            acAll.setComplaintNums(i15.toString());//固态数据新增
            Integer i16 = achievementsManagerMapper.selecttgd16(userRole.getReadName(), ymd);//意见工单数
            acAll.setOpinionNums(i16.toString());//固态数据新增
            acManager.setComplaintWorkorderNum(i15+i16);
            Integer p15 = 5*i15+ i16;
            Integer t15 = 10;
            if(p15<=10) {
                t15 = 10 - p15;
            }else {
                t15 =0;
            }
            acManager.setComplaintWorkorderPoint(t15);

            //TODO 运维抢修到达现场及时率 15
            acAll.setSceneNums("0");
            acAll.setSceneAllnums("0");
            //TODO 计量异常处理及时率 16
            Integer n16a = collMapper.selectAcMan16a(userRole.getReadName(), ymd);//计量总工单数

            Integer n16 = collMapper.selectAcMan16(userRole.getReadName(), ymd);//计量大于三天未处理工单数
            if (n16==null) n16=0;
            acAll.setMeterThreenums(n16.toString());//固态数据新增
            double p16 = 10;
            if (n16a==null || n16a ==0){
                acManager.setMeterHandleRate(new BigDecimal("100"));
                acManager.setMeterHandlePoint((int) p16);
                acAll.setMeterAllnums(n16a.toString());//固态数据新增
            }else {
                acManager.setPowerbackHandleRate(new BigDecimal((double) (n16 / n16a)));
                p16=(n16 / n16a) * 10;
                acManager.setPowerbackHandlePoint((int) p16);
                acAll.setMeterAllnums(n16a.toString());//固态数据新增
            }
            acManager.setTotalScore(t1+(10-p2)+t8+t9+t11+t15+(10-p11)+((int)p13)+15+((int)p16));
            acManager.setToPoint(String.valueOf(t1+(10-p2)+t8+t9+t11+t15+(10-p11)+((int)p13)+15+((int)p16)));
//            acManagers.add(acManager);
            achievementsManagerMapper.insertAcman1(acManager);
            acAll.setYmd(TimeUtil.getStart5Time());
            acAllMapper.insertSelective(acAll);
        }

//        for (AcManager acManager : acManagers) {
//            achievementsManagerMapper.insertAcman1(acManager);
//        }
        return "日绩效生成完成";
    }


    @RequestMapping("getAcSta")
    @Async
    @Scheduled(cron = "01 20 00 * * ? ")
    public void getAcSta(){
        String ymd = TimeUtil.getStart5Time();
        List<consTgScm> consTgScms = achievementsManagerMapper.selectAcStationFromOrg();
        //List<consTgScm> consTgScms = achievementsManagerMapper.selectAcStationFromOrg1();
        for (consTgScm consTgScm : consTgScms) {
            String orgNo = consTgScm.getOrgNo();
            AcAll acAll = new AcAll();
            OrgNameNums orgNameNums = new OrgNameNums();//营业站采集数目详情表
            orgNameNums.setYmd(TimeUtil.getStart5Time());//获取采集失败数
            orgNameNums.setOrgNo(orgNo);//获取供电单位编号
            orgNameNums.setPOrgNo(consTgScm.getPOrgNo());
            orgNameNums.setOrgName(consTgScm.getOrgName());//获取供电单位名称
            //TODO 采集成功率 1
            List<String> orgs = new ArrayList<>();
            AcStation acStation = new AcStation();

            //List<AcManager> acManagers = achievementsManagerMapper.selectAcMans(orgNo, TimeUtil.getStartTime());
            acStation.setStationName(consTgScm.getOrgName());

            acAll.setAcName(consTgScm.getOrgName());//固态数据新增
            acAll.setDataDate(new DateTime());//固态数据新增
            acAll.setOrgNo(orgNo);//固态数据新增
            acAll.setAcId("2");//固态数据新增
            acAll.setYmd(TimeUtil.getStart5Time());

            //所站管辖的台区数
            //Integer statgNums = acAllMapper.selectStatgNums(orgNo);

            orgs.add(consTgScm.getOrgName());
            acStation.setOrgNo(consTgScm.getOrgNo());
            acStation.setDataDate(new DateTime());
            acStation.setDateDm(TimeUtil.getStart5Time());
            acStation.setAcCountyId(consTgScm.getPOrgNo());
            acStation.setToPoint("");

            BigDecimal i1;
            BigDecimal i0 = BigDecimal.ZERO;

            Integer int1 = collMapper.selectAcCouzb1(orgs, ymd);
            if(int1==null)int1=0;
            orgNameNums.setCollFailNum(int1);//采集失败数
            i1 = new BigDecimal(int1);

            if (i1 == null) i1=BigDecimal.ZERO;
            acAll.setFailNums(int1);//固化数据
            Integer numAll = collMapper.selectStaconNums(consTgScm.getOrgNo());//TODO 营业站管辖的用户数
            //Integer numAll = acAllMapper.selectStaconsNums(orgNo,TimeUtil.getStart5Time());
            if (numAll == null) numAll=1;
            orgNameNums.setCollAllNum(numAll);//采集总数
            orgNameNums.setCollSuccNum(numAll-int1);
            acAll.setAllNums(numAll);//固化数据
            acAll.setAllNums5(numAll.toString());
            BigDecimal s1 = new BigDecimal("1").subtract((i1).divide(new BigDecimal(numAll), 4, BigDecimal.ROUND_HALF_UP));
            acStation.setColSuccRate(s1.multiply(new BigDecimal("100")).setScale(2));//采集成功率指标
            Integer p1 = Integer.parseInt(new BigDecimal("0.9997").subtract(s1).divide(new BigDecimal("0.0001")).toString());
            Integer t1 =0;
            if(p1 <= 5 && p1>0){
                t1=5-p1;
            }else if(p1 <= 0){
                t1=5;
            }else {
                t1=0;
            }
            acStation.setColSuccPoint(t1);//采集成功率分数
            //TODO 采集失败及时处理率 2
            BigDecimal i2;

            Integer int2 = collMapper.selectAcCouzb2(orgs, ymd);
            if(int2==null)int2=0;
            i2 = new BigDecimal(int2);//采集失败未处理数量
            acAll.setNohandleNums(int2);
            if (i2.compareTo(i0)==0){
                i2= new BigDecimal("1");
            }else i2=BigDecimal.ZERO;
            if (i1 == null || i1.compareTo(i0)==0){
                i1= new BigDecimal("1");
            }
            BigDecimal r2 = i2.divide(i1, 4, BigDecimal.ROUND_HALF_UP);
            Integer p2 = Integer.parseInt(r2.divide(new BigDecimal("0.1"),0,BigDecimal.ROUND_HALF_UP).toString());
            acStation.setColFailPoint(10-p2);
            acStation.setColFailRate((new BigDecimal("1").subtract(r2)).multiply(new BigDecimal("100")).setScale(2));

            //TODO 费控停电成功率和费控复电成功率 3 4
            //List<String> listNos = collMapper.selectOrgnos(orgNo);
            List<String> listNos =new ArrayList<>();
            listNos.add(orgNo);
            Integer i3all = collMapper.selectFee3(listNos, ymd, null);//复电总数
            if (i3all==null ||i3all==0) i3all=1;
            Integer i3succ = collMapper.selectFee3(listNos, ymd, "03");//复电执行成功
            if (i3succ==null) i3succ=0;
            acAll.setFeestartSucnums(i3succ.toString());//固化数据
            acAll.setFeestartAllnums(i3all.toString());//固化数据
            acStation.setCostconComeRate(new BigDecimal((float)(i3succ)/(i3all)).setScale(4,BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("100")));
            Integer i4all = collMapper.selectFee4(listNos, ymd, null);//停电总数
            if (i4all==null || i4all==0) i4all=1;
            Integer i4succ = collMapper.selectFee4(listNos, ymd, "03");//停电执行成功数
            if (i4succ==null) i4succ=0;
            acAll.setFeestopSucnums(i4succ.toString());//固化数据
            acAll.setFeestopAllnums(i4all.toString());//固化数据
            acStation.setCostconStopRate(new BigDecimal((float)(i4succ)/(i4all)).setScale(4,BigDecimal.ROUND_HALF_UP).multiply(new BigDecimal("100")));

            //TODO 自动发行占比 5
            BigDecimal b5 = new BigDecimal((float) 10 / numAll).setScale(4, BigDecimal.ROUND_HALF_UP);
            acStation.setAutoPublishRate(b5);
            acAll.setHandNums("0");
            acAll.setAllNums5(numAll.toString());//固化数据
            Integer t5;
            Integer i5 = Integer.parseInt(b5.divide(new BigDecimal("0.001"), 0, BigDecimal.ROUND_HALF_UP).toString())-1;
            if(i5 <= 5 && i5>0){
                t5=5-i5;
            }else if(i5 <= 0){
                t5=5;
            }else {
                t5=0;
            }
            acStation.setAutoPublishPoint(t5);
            //TODO 低压线损率 6
            BigDecimal bigDecimal = collMapper.selectLoss61(consTgScm.getOrgName(), TimeUtil.getStartTwoTime());//要改
            //BigDecimal bigDecimal = collMapper.selectLoss61(cons.getOrgName(), TimeUtil.getStartThreeTime());
            if (bigDecimal == null) bigDecimal=BigDecimal.ZERO;
            acAll.setLossPqall(bigDecimal.toString());//固化数据
            BigDecimal multiply = bigDecimal.multiply(new BigDecimal("100"));
            acStation.setLowLinelossRate(multiply);
            acStation.setLowLinelossPoint(5);
            //TODO 高损台区占比 7
            //TODO 负损台区占比 8
            //TODO 经济运行台区占比 9

            Integer i7s = collMapper.selectLine8(consTgScm.getOrgName().substring(0,2), TimeUtil.getStartTwoTime());//查询该营业站线损大于6的工单数
            if (i7s == null) i7s=0;
            acAll.setLossrateHigh(i7s.toString());//固化数据
            Integer i7 = collMapper.selectStatgNums(orgNo);//TODO 营业站管辖台区个数
            if (i7==null||i7==0) i7=1;
            acAll.setTgNums(i7);//固化数据
            BigDecimal d7 = new BigDecimal(i7s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
            Integer s7 = Integer.parseInt(d7.divide(new BigDecimal("0.05"), 0, BigDecimal.ROUND_HALF_DOWN).toString());
            Integer t7;
            if(s7<=5 && s7 >0){
                t7 = 5-s7;
            }else if(s7 <=0){
                t7 = 5;
            }else {
                t7 = 0;
            }
            acStation.setHighlossTgPoint(t7);
            acStation.setHighlossTgRate(d7);
            Integer i8s = collMapper.selectLine9(consTgScm.getOrgName().substring(0,2), TimeUtil.getStartTwoTime());//负损台区个数
            if (i8s == null) i8s=0;
            acAll.setLossrateLow(i8s.toString());//固化数据
            BigDecimal d8 = new BigDecimal(i8s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
            Integer s8 = Integer.parseInt(d8.divide(new BigDecimal("0.05"), 0, BigDecimal.ROUND_HALF_DOWN).toString());
            Integer t8;
            if(s8<=5 && s8 >0){
                t8 = 5-s8;
            }else if(s8 <=0){
                t8 = 5;
            }else {
                t8 = 0;
            }
            acStation.setLowlossTgRate(d8);
            acStation.setLowlossTgPoint(t8);
            Integer i9s = collMapper.selectLine10(consTgScm.getOrgName().substring(0,2), TimeUtil.getStartTwoTime());
            if (i9s == null) i9s=0;
            acAll.setLossrateNormal(i9s.toString());//固化数据
            BigDecimal d9 = new BigDecimal(i9s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
            acStation.setEconrunTgRate(d9);
            acStation.setEconrunTgPoint(0);
            //TODO 高负损台区处理及时率 10
            Integer i10s = i7s+i8s;//高负损工单数
            acAll.setLinelossAlls(i10s.toString());//固化数据
            Integer i10 = collMapper.selectAcCou10();//三天以上未处理工单数
            if (i10 == null) i10=0;
            acAll.setLinelossThreehandle(i10.toString());//固化数据
            BigDecimal b10 = new BigDecimal((float) 1-((i10+1)/ (i10s+1))).setScale(2, BigDecimal.ROUND_HALF_UP);
            Integer p10= Integer.parseInt(b10.multiply(new BigDecimal("10")).setScale(0).toString());
            acStation.setTgHandleRate(b10.multiply(new BigDecimal("100")));
            acStation.setTgHandlePoint(p10);
            //TODO 电费结零率 11
            acStation.setPowerfeesZeroRate(new BigDecimal("100"));
            acStation.setPowerfeesZeroPoint(10);
            acAll.setRcvblPenalty("0");
            acAll.setRcvblAmt("0");
            acAll.setTgexceNums("0");
            acAll.setReply45Nums("0");
            acAll.setReplyAllnums("0");
            //TODO 异常台区治理 12
            acStation.setExceptTgNum(0);
            acStation.setExceptTgPoint(5);
            //TODO 现场复电处理及时率 13
            //TODO 投诉意见工单数量 14
            //List<String> orgName = collMapper.selectOrgnos(orgNo);
            Integer i14 = 0;
            Integer j14 = 0;
            Integer i13 = 0;
            //i13 += collMapper.selectAc13(orgNo, ymd);
            Integer integer = collMapper.selectAc14tou(orgs, ymd);
            if (integer==null) integer=0;
            i14 += integer;
//            i14 += collMapper.selectAc14tou(orgs, ymd);
            Integer integer1 = collMapper.selectAc14yi(orgs, ymd);
            if (integer1==null) integer1=0;
            j14 += integer1;

            acAll.setComplaintNums(i14.toString());//固化数据
            acAll.setOpinionNums(j14.toString());//固化数据
//            j14 += collMapper.selectAc14yi(orgs, ymd);
            Integer p14 = 5*i14+ j14;
            Integer t14 = 10;
            if(p14<=10) {
                t14 = 10 - p14;
            }else {
                t14 =0;
            }
            acStation.setPowerbackHandleRate(BigDecimal.ZERO);
            acStation.setPowerbackHandlePoint(0);
            acStation.setComplaintWorkorderNum(i14+j14);
            acStation.setComplaintWorkorderPoint(t14);
            //TODO 运维抢修到达现场及时率 15
            acStation.setRepairSceneRate(new BigDecimal("100"));
            acStation.setRepairScenePoint(10);
            //TODO 计量异常处理及时率 16
            acStation.setMeterHandleRate(new BigDecimal("100"));
            acStation.setMeterHandlePoint(10);
            acStation.setToPoint(String.valueOf(t1+(10-p2)+t5+t7+t8+p10+t14+40));
            acAllMapper.insertSelective(acAll);
            achievementsManagerMapper.insertAcStation(acStation);
            achievementsManagerMapper.insertOrgNameNums(orgNameNums);
        }

    }

    @RequestMapping("getAcCou")
    @Async
    @Scheduled(cron = "01 00 00 * * ? ")
    public void getAcCou(){
        String ymd = TimeUtil.getStart5Time();
        String ym = TimeUtil.getStartMon1();
        List<consTgScm> consTgScms = achievementsManagerMapper.selectAcCountyFromOrgs();
        for (consTgScm cons : consTgScms) {
            AcAll acAll = new AcAll();
            acAll.setAcId("3");//固化数据
            acAll.setDataDate(new DateTime());//固化数据
            acAll.setAcName(cons.getOrgName());//固化数据

            //TODO 采集成功率 1
            BigDecimal i1;
            BigDecimal i0 = BigDecimal.ZERO;
            String orgNo = cons.getOrgNo();
            acAll.setOrgNo(orgNo);
            List<String> orgs = achievementsManagerMapper.selectAcStationFromOrg2(orgNo);
            //List<AcStation> acManagers = achievementsManagerMapper.selectAcStas(orgNo, TimeUtil.getStartTime());
            AcCounty acCounty = new AcCounty();
            acCounty.setCountyName(cons.getOrgName());
            acCounty.setOrgNo(orgNo);
            acCounty.setDataDate(new DateTime());
            acCounty.setDateDm(TimeUtil.getStart5Time());
            Integer numAll = collMapper.selectAcconNums(cons.getOrgNo());//TODO 旗县管辖所有的用户数
            acAll.setAllNums(numAll);//固化数据
            acAll.setAllNums5(numAll.toString());//固化数据
            Integer int1 = collMapper.selectAcCouzb1(orgs, ymd);
            if(int1==null)int1=0;
            acAll.setFailNums(int1);//固化数据
            i1 = new BigDecimal(int1).add(new BigDecimal("1"));
            System.out.println("numAll="+numAll);
            System.out.println("i1="+i1);
            if(numAll==null || numAll==0){
                numAll = 1;
            }
            BigDecimal s1 = new BigDecimal("1").subtract((i1).divide(new BigDecimal(numAll), 4, BigDecimal.ROUND_HALF_UP));
            acCounty.setColSuccRate(s1.multiply(new BigDecimal("100")).setScale(2).doubleValue());//采集成功率指标
            Integer p1 = Integer.parseInt(new BigDecimal("0.9997").subtract(s1).divide(new BigDecimal("0.0001")).toString());
            Integer t1 =0;
            if(p1 <= 5 && p1>0){
                t1=5-p1;
            }else if(p1 <= 0){
                t1=5;
            }else {
                t1=0;
            }
            acCounty.setColSuccPoint(t1);//采集成功率分数            acCounty.setCostconComePoint(0);
            //TODO 采集失败及时处理率 2
            BigDecimal i2;
            Integer int2 = collMapper.selectAcCouzb2(orgs, ymd);
            if (int2==null)int2=0;
            i2 = new BigDecimal(int2);//采集失败未处理数量
            if (i2.compareTo(i0)==0){
                i2= new BigDecimal("1");
            }
            acAll.setNohandleNums(int2);//固化数据
            if (i1==null || i1.compareTo(i0)==0){
                i1= new BigDecimal("1");
            }
            BigDecimal r2 = i2.divide(i1, 4, BigDecimal.ROUND_HALF_UP);
            Integer p2 = Integer.parseInt(r2.divide(new BigDecimal("0.1"),0,BigDecimal.ROUND_HALF_UP).toString());
            acCounty.setColFailPoint(10-p2);
            acCounty.setColFailRate((new BigDecimal("1").subtract(r2)).multiply(new BigDecimal("100")).setScale(2).doubleValue());
            //TODO 费控停电成功率和费控复电成功率 3 4
            List<String> listNos = collMapper.selectOrgnos(orgNo);
            Integer i3all = collMapper.selectFee3(listNos, ymd, null);//复电总数
            Integer i3succ = collMapper.selectFee3(listNos, ymd, "03");//复电执行成功
            acAll.setFeestartSucnums(i3succ.toString());//固化数据
            acAll.setFeestartAllnums(i3all.toString());//固化数据
            acCounty.setCostconComeRate(new BigDecimal((float)(i3succ+1)/(i3all+1)).setScale(4,BigDecimal.ROUND_HALF_UP).doubleValue()*100);
            Integer i4all = collMapper.selectFee4(listNos, ymd, null);//停电总数
            Integer i4succ = collMapper.selectFee4(listNos, ymd, "03");//停电执行成功数
            acAll.setFeestopSucnums(i4succ.toString());//固化数据
            acAll.setFeestopAllnums(i4all.toString());//固化数据
            acCounty.setCostconStopRate(new BigDecimal((float)(i4succ+1)/(i4all+1)).setScale(4,BigDecimal.ROUND_HALF_UP).doubleValue()*100);
            //TODO 自动发行占比 5
            BigDecimal b5 = new BigDecimal((float) 10 / (numAll+1)).setScale(4, BigDecimal.ROUND_HALF_UP);
            acAll.setHandNums("0");//固化数据
            acCounty.setAutoPublishRate(b5);
            Integer t5;
            Integer i5 = Integer.parseInt(b5.divide(new BigDecimal("0.001"), 0, BigDecimal.ROUND_HALF_UP).toString())-1;
            if(i5 <= 5 && i5>0){
                t5=5-i5;
            }else if(i5 <= 0){
                t5=5;
            }else {
                t5=0;
            }
            acCounty.setAutoPublishPoint(t5);
            //TODO 低压线损率 6
            BigDecimal bigDecimal = collMapper.selectLoss6(cons.getOrgName(), TimeUtil.getStartTwoTime());//要改 TWO
            //BigDecimal bigDecimal = collMapper.selectLoss6(cons.getOrgName(), TimeUtil.getStartThreeTime());
            if (bigDecimal==null){
                bigDecimal = BigDecimal.ZERO;
            }
            acAll.setLossPqall(bigDecimal.toString());//固化数据
            BigDecimal multiply = bigDecimal.multiply(new BigDecimal("100"));
            acCounty.setLowLinelossRate(multiply.doubleValue());
            //acCounty.setLowLinelossRate(2.134);
            acCounty.setLowLinelossPoint(5);
            //TODO 高损台区占比 7
            //TODO 负损台区占比 8
            //TODO 经济运行台区占比 9

            Integer i7s = collMapper.selectLine8(cons.getOrgName().substring(0,2), TimeUtil.getStartTwoTime());
            if(i7s == null) i7s=0;
            acAll.setLossrateHigh(i7s.toString());//固化数据
            Integer i7 = collMapper.selectActgNums(orgNo);//TODO 旗县管辖的台区数
            if (i7==null || i7==0) i7=1;
            acAll.setTgNums(i7);//固化数据
            BigDecimal d7 = new BigDecimal(i7s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
            Integer s7 = Integer.parseInt(d7.divide(new BigDecimal("0.05"), 0, BigDecimal.ROUND_HALF_DOWN).toString());
            Integer t7;
            if(s7<=5 && s7 >0){
                t7 = 5-s7;
            }else if(s7 <=0){
                t7 = 5;
            }else {
                t7 = 0;
            }
            acCounty.setHighlossTgPoint(t7);
            acCounty.setHighlossTgRate(d7.doubleValue());
            Integer i8s = collMapper.selectLine9(cons.getOrgName().substring(0,2), TimeUtil.getStartTwoTime());
            if(i8s==null) i8s=0;
            acAll.setLossrateLow(i8s.toString());
            BigDecimal d8 = new BigDecimal(i8s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
            Integer s8 = Integer.parseInt(d8.divide(new BigDecimal("0.05"), 0, BigDecimal.ROUND_HALF_DOWN).toString());
            Integer t8;
            if(s8<=5 && s8 >0){
                t8 = 5-s8;
            }else if(s8 <=0){
                t8 = 5;
            }else {
                t8 = 0;
            }
            acCounty.setLowlossTgRate(d8.doubleValue());
            acCounty.setLowlossTgPoint(t8);

            Integer i9s = collMapper.selectLine10(cons.getOrgName().substring(0,2), TimeUtil.getStartTwoTime());
            if(i9s==null) i9s=0;
            acAll.setLossrateNormal(i9s.toString());
            BigDecimal d9 = new BigDecimal(i9s).divide(new BigDecimal(i7), 2, BigDecimal.ROUND_HALF_UP);
            acCounty.setEconrunTgRate(d9.doubleValue());
            acCounty.setEconrunTgPoint(0);


            //TODO 高负损台区处理及时率 10
            Integer i10s = i7s+i8s;//高负损工单数
            acAll.setLinelossAlls(i10s.toString());//固化数据
            if(i10s==null || i10s==0)i10s=1;
            Integer i10 = collMapper.selectAcCou10();//三天以上未处理工单数
            if(i10==null) i10=0;
            acAll.setLinelossThreehandle(i10.toString());//固化数据
            BigDecimal b10 = new BigDecimal((float) 1-((i10)/ (i10s))).setScale(2, BigDecimal.ROUND_HALF_UP);
            Integer p10= Integer.parseInt(b10.multiply(new BigDecimal("10")).setScale(0).toString());
            acCounty.setTgHandleRate(b10.doubleValue()*100);
            acCounty.setTgHandlePoint(p10);

            //TODO 电费结零率 11

            BigDecimal a11 = collMapper.selectAcCou11a(orgs, ym);//查看该旗县发行金额总和
            if (a11==null || a11==BigDecimal.ZERO){
                a11 = new BigDecimal("1");
            }
            acAll.setRcvblAmt(a11.toString());//固化数据
            BigDecimal b11 = collMapper.selectAcCou11b(orgs,ym);//查看该旗县欠费金额总和
            if (b11==null){
                b11 = BigDecimal.ZERO;
            }
            acAll.setRcvblPenalty(b11.toString());//固化数据
            BigDecimal s11 = new BigDecimal("1").subtract(b11.divide(a11, 4, BigDecimal.ROUND_HALF_UP));
            Integer p11 = s11.divide(new BigDecimal("0.01"), 0, BigDecimal.ROUND_HALF_UP).intValue();
            Integer t11=0;
            if(p11<=10 && p11>=0){
                t11 = 10-p11;
            }else {
                t11 = 0;
            }
            acCounty.setPowerfeesZeroRate(s11.doubleValue());
            acCounty.setPowerfeesZeroPoint(t11);
            //TODO 异常台区治理 12

            acCounty.setExceptTgNum(0);
            acCounty.setExceptTgPoint(5);
            acAll.setTgexceNums("0");
            //TODO 现场复电处理及时率 13
            Integer n13 = collMapper.selectAc13(orgs, ymd);//复电小于45分钟工单数
            if(n13==null) n13=0;
            acAll.setReply45Nums(n13.toString());//固化数据
            Integer n13a = collMapper.selectAc13a(orgs,ymd);//所有复电工单数
            double p13 = 10;
            if (n13a==null || n13a ==0){
                acCounty.setPowerbackHandleRate(100.0);
                acCounty.setPowerbackHandlePoint((int) p13);
                acAll.setReplyAllnums(n13a.toString());//固化数据
            }else {
                acCounty.setPowerbackHandleRate((double) (n13 / n13a));
                p13=(n13 / n13a) * 10;
                acCounty.setPowerbackHandlePoint((int) p13);
                acAll.setReplyAllnums(n13a.toString());//固化数据
            }
            //TODO 投诉意见工单数量 14
            //List<String> orgName = collMapper.selectOrgnos(orgNo);
            Integer i14 = 0;
            Integer j14 = 0;
//            for (String orgNo1 : orgName) {
            Integer tempi14 = collMapper.selectAc14tou(orgs, ymd);//投诉工单数
            if (tempi14==null) tempi14=0;
            acAll.setComplaintNums(tempi14.toString());//固化数据
            i14+=tempi14;
            Integer tempj14 = collMapper.selectAc14yi(orgs, ymd);//意见工单数
            if (tempj14==null) tempj14=0;
            acAll.setOpinionNums(tempj14.toString());//固化数据
            j14+=tempj14;
//            }
            Integer p14 = 5*i14+ j14;
            Integer t14 = 10;
            if(p14<=10) {
                t14 = 10 - p14;
            }else {
                t14 =0;
            }
            acCounty.setComplaintWorkorderNum(i14+j14);
            acCounty.setComplaintWorkorderPoint(t14);
            //TODO 运维抢修到达现场及时率 15
            acAll.setSceneNums("0");
            acAll.setSceneAllnums("0");//
            acCounty.setRepairSceneRate(100.0);
            acCounty.setRepairScenePoint(10);
            //TODO 计量异常处理及时率 16
            Integer n16a = collMapper.selectAc16a(orgs, ymd);//计量总工单数
            Integer n16 = collMapper.selectAc16(orgs, ymd);//计量大于三天未处理工单数
            if (n16==null) n16=0;
            acAll.setMeterThreenums(n16.toString());
            double p16 = 10;
            if (n16a==null || n16a ==0){
                acCounty.setMeterHandleRate(100.0);
                acCounty.setMeterHandlePoint((int) p16);
                acAll.setMeterAllnums(n16a.toString());//固化数据
            }else {
                acCounty.setPowerbackHandleRate((double) (n16 / n16a));
                p16=(n16 / n16a) * 10;
                acCounty.setPowerbackHandlePoint((int) p16);
                acAll.setMeterAllnums(n16a.toString());//固化数据
            }
            acAll.setYmd(TimeUtil.getStart5Time());
            acAllMapper.insertSelective(acAll);
            acCounty.setMeterHandleRate(100.0);
            acCounty.setMeterHandlePoint(10);
            acCounty.setToPoint(String.valueOf(t1+(10-p2)+t5+t7+t8+p10+p13+t14+p16+20));
            achievementsManagerMapper.insertAcCounty(acCounty);
        }
    }



    @RequestMapping("getAcCou1")
    @Async
//    @Scheduled(cron = "0 1 0 * * ? ")
    public void getAcCou1(){
        List<consTgScm> consTgScms = achievementsManagerMapper.selectAcCountyFromOrgs();
        for (consTgScm consTgScm : consTgScms) {
            AcCounty acCounty = new AcCounty();
            acCounty.setCountyName(consTgScm.getOrgName());
            acCounty.setOrgNo(consTgScm.getOrgNo());
            acCounty.setDataDate(new DateTime());
            acCounty.setDateDm(TimeUtil.getStart5Time());
            acCounty.setToPoint("0");
            achievementsManagerMapper.insertAcCounty(acCounty);
        }
    }


    @RequestMapping("getAcSta1")
    @Async
//    @Scheduled(cron = "0 10 4 * * ? ")
    public void getAcSta1(){
        List<consTgScm> consTgScms = achievementsManagerMapper.selectAcStationFromOrg();
        for (consTgScm consTgScm : consTgScms) {
            AcStation acStation = new AcStation();
            String orgNo = consTgScm.getOrgNo();
            acStation.setStationName(consTgScm.getOrgName());
            acStation.setOrgNo(orgNo);
            acStation.setDataDate(new DateTime());
            acStation.setDateDm(TimeUtil.getStart5Time());
            acStation.setAcCountyId(consTgScm.getPOrgNo());
            achievementsManagerMapper.insertAcStation(acStation);
        }

    }

    @RequestMapping("getCouDetails")
    public List<OrgNameNums> getCollNum(@RequestParam String orgNo,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        List<String> orgName = collMapper.selectOrgNos(orgNo);
        List<OrgNameNums> orgNamlist = new ArrayList<>();
        for (String s : orgName) {
            OrgNameNums orgNameNums = new OrgNameNums();
            orgNameNums.setOrgName(s);
            Integer i = collMapper.selecctOrgNameNum(s, ymd);
            orgNameNums.setCollFailNum(i);//采集失败数
            Integer j = collMapper.selectOrgAllNum(s.substring(0, 2));
            orgNameNums.setCollAllNum(j);//采集总数
            orgNameNums.setCollSuccNum(j-i);
            orgNamlist.add(orgNameNums);
        }
        return orgNamlist;
    }

    @RequestMapping("getCouDetails1")
    @Scheduled(cron = "01 30 00 * * ? ")
    public void getCollNum1(){
        List<String> orgName = collMapper.selectOrgNos1();
        for (String s : orgName) {
            OrgNameNums orgNameNums = new OrgNameNums();
            orgNameNums.setOrgName(s);
            Integer i = collMapper.selecctOrgNameNum(s, TimeUtil.getStartTwoTime());
            if (i == null) i = 0;
            orgNameNums.setCollFailNum(i);//采集失败数
            Integer j = collMapper.selectOrgAllNum(s.substring(0, 2));
            if (j == null) j = 0;
            orgNameNums.setCollAllNum(j);//采集总数
            orgNameNums.setCollSuccNum(j - i);
            orgNameNums.setYmd(TimeUtil.getStartTwoTime());
            achievementsManagerMapper.insertOrgNameNums(orgNameNums);
        }
    }

    @RequestMapping("getCouDetails2")
    public List<OrgNameNums> getCollNum2(@RequestParam String orgNo,@RequestParam String ymd){
        List<OrgNameNums> orgNameNums = achievementsManagerMapper.selectOrgNameNums(orgNo, ymd);
        return orgNameNums;

    }


    @RequestMapping("getFee3")//获取绩效费控指标
    public FeeNum getFee3(@RequestParam String orgNo,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        List<String> listNos = collMapper.selectOrgnos(orgNo);
        Integer i3all = collMapper.selectFee3(listNos, ymd, null);//复电总数
        Integer i3succ = collMapper.selectFee3(listNos, ymd, "03");//复电执行成功
        FeeNum feeNum = new FeeNum();
        feeNum.setFeeNumAll(i3all);
        feeNum.setFeeNumSuc(i3succ);
        return feeNum;
    }


    @RequestMapping("getFee4")//获取绩效费控指标
    public FeeNum getFee4(@RequestParam String orgNo,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        List<String> listNos = collMapper.selectOrgnos(orgNo);
        Integer i4all = collMapper.selectFee4(listNos, ymd, null);//停电总数
        Integer i4succ = collMapper.selectFee4(listNos, ymd, "03");//停电执行成功数
        FeeNum feeNum = new FeeNum();
        feeNum.setFeeNumAll(i4all);
        feeNum.setFeeNumSuc(i4succ);
        return feeNum;
    }

    @RequestMapping("getSuper5")//中止发行占比
    @ResponseBody
    public Map<String,String> getSuper5(@RequestParam String orgNo,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        Integer integer = collMapper.selectNum6(orgNo.substring(0, 7));
        Map<String,String> map = new HashMap<>();
        int i = 0;
        map.put("num",String.valueOf(integer));
        return map;
    }

    @RequestMapping("getLineLoss6")//线损率
    @ResponseBody
    public String getLineLoss6(@RequestParam String orgName,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        BigDecimal bigDecimal = collMapper.selectLoss6(orgName, TimeUtil.getStartTwoTime());
        BigDecimal multiply = bigDecimal.multiply(new BigDecimal("100"));
        return multiply.toString();
    }


    @RequestMapping("getLineLoss8")//高损台区数量
    @ResponseBody
    public Map<String,String> getLineLoss8(@RequestParam String orgNo,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        Map<String,String> map = new HashMap<>();
        String orgName = collMapper.selectOrgNo(orgNo);
        Integer integer = collMapper.selectLine8(orgName.substring(0, 2), TimeUtil.getStartTwoTime());
        Integer i8 = collMapper.selectStatgNums(orgNo);//所占管辖的台区数量
        map.put("num1",integer.toString());
        map.put("num2",i8.toString());
        return map;
    }
    @RequestMapping("getLineLoss9")//负损台区数量
    @ResponseBody
    public Map<String,String> getLineLoss9(@RequestParam String orgNo,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        Map<String,String> map = new HashMap<>();
        String orgName = collMapper.selectOrgNo(orgNo);
        Integer integer = collMapper.selectLine9(orgName.substring(0, 2), TimeUtil.getStartTwoTime());
        Integer i9 = collMapper.selectStatgNums(orgNo);//所占管辖的台区数量
        map.put("num1",integer.toString());
        map.put("num2",i9.toString());
        return map;
    }

    @RequestMapping("getLineLoss10")//经济运行台区数量
    @ResponseBody
    public Map<String,String> getLineLoss10(@RequestParam String orgNo,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        Map<String,String> map = new HashMap<>();
        String orgName = collMapper.selectOrgNo(orgNo);
        Integer integer = collMapper.selectLine10(orgName.substring(0, 2), TimeUtil.getStartTwoTime());
        Integer i10 = collMapper.selectStatgNums(orgNo);//所占管辖的台区数量
        map.put("num1",integer.toString());
        map.put("num2",i10.toString());
        return map;
    }

    @RequestMapping("getSuper13")//获取投诉意见工单
    @ResponseBody
    public Map<String,String> getSuper13(@RequestParam String orgNo,@RequestParam String ymd,@RequestParam(required = false) String loName2){
        List<String> orgName = collMapper.selectOrgNos(orgNo);
        Map<String,String> map = new HashMap<>();
        int i = 0;
        for (String orgNa : orgName) {
            Integer integer = collMapper.selectSiperNum(orgNa.substring(0, 2), ymd);
            if (integer == null) integer =0;
            i += integer;
//            i += collMapper.selectSiperNum(orgNa.substring(0, 2), ymd);
        }
        map.put("num",String.valueOf(i));
        return map;
    }


    @RequestMapping("getPcManDetails1")
    @ResponseBody
    public Map<String,String> getPcManDetails1(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i1a = achievementsManagerMapper.selecttgd1(tgManager, ymd);
        if(i1a==null)i1a=0;
        Integer i1b = collMapper.selectUserNameConsNum(collMapper.selectUserRoleName(tgManager));
        if(i1b==null)i1b=0;
        map.put("num1",i1a.toString());
        map.put("num2",i1b.toString());
        return map;
    }

    @RequestMapping("getPcManDetails2")
    @ResponseBody
    public Map<String,String> getPcManDetails2(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i2a = achievementsManagerMapper.selecttgd2(tgManager, ymd);
        if(i2a==null)i2a=0;
        Integer i2b = achievementsManagerMapper.selecttgd1(tgManager, ymd);
        if(i2b==null)i2b=0;
        map.put("num1",i2a.toString());
        map.put("num2",i2b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails3")
    @ResponseBody
    public Map<String,String> getPcManDetails3(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        map.put("num1","0");
        map.put("num2","0");
        return map;
    }
    @RequestMapping("getPcManDetails4")
    @ResponseBody
    public Map<String,String> getPcManDetails4(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        map.put("num1","0");
        map.put("num2","0");
        return map;
    }
    @RequestMapping("getPcManDetails5")
    @ResponseBody
    public Map<String,String> getPcManDetails5(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i5b = collMapper.selectUserNameConsNum(collMapper.selectUserRoleName(tgManager));
        if(i5b==null)i5b=0;
        map.put("num1","0");
        map.put("num2",i5b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails6")
    @ResponseBody
    public Map<String,String> getPcManDetails6(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        BigDecimal i6a = achievementsManagerMapper.selectLossMan61a(tgManager, ymd);
        if(i6a==null)i6a= BigDecimal.ZERO;
        BigDecimal i6b = achievementsManagerMapper.selectLossMan61b(tgManager, ymd);
        if(i6b==null)i6b = BigDecimal.ZERO;
        map.put("num1",i6a.toString());
        map.put("num2",i6b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails7")
    @ResponseBody
    public Map<String,String> getPcManDetails7(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i7a = achievementsManagerMapper.selecttgd8(tgManager, ymd);
        if(i7a==null)i7a=0;
        Integer i7b = collMapper.selectUserNameTgNum(collMapper.selectUserRoleName(tgManager));
        if(i7b==null)i7b=0;
        map.put("num1",i7a.toString());
        map.put("num2",i7b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails8")
    @ResponseBody
    public Map<String,String> getPcManDetails8(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i8a = achievementsManagerMapper.selecttgd9(tgManager, ymd);
        if(i8a==null)i8a=0;
        Integer i8b = collMapper.selectUserNameTgNum(collMapper.selectUserRoleName(tgManager));
        if(i8b==null)i8b=0;
        map.put("num1",i8a.toString());
        map.put("num2",i8b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails9")
    @ResponseBody
    public Map<String,String> getPcManDetails9(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i9b = collMapper.selectUserNameTgNum(collMapper.selectUserRoleName(tgManager));
        if(i9b==null)i9b=0;
        Integer i8a = achievementsManagerMapper.selecttgd9(tgManager, ymd);
        if(i8a==null)i8a=0;
        Integer i7a = achievementsManagerMapper.selecttgd8(tgManager, ymd);
        if(i7a==null)i7a=0;
        Integer i9a = i9b - i8a - i7a;
        map.put("num1",i9a.toString());
        map.put("num2",i9b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails10")
    @ResponseBody
    public Map<String,String> getPcManDetails10(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i8a = achievementsManagerMapper.selecttgd9(tgManager, ymd);
        if(i8a==null)i8a=0;
        Integer i7a = achievementsManagerMapper.selecttgd8(tgManager, ymd);
        if(i7a==null)i7a=0;
        Integer i10a = achievementsManagerMapper.selecttgd11(tgManager);
        if(i10a==null)i10a=0;
        Integer i10b = i8a+i7a;
        map.put("num1",i10a.toString());
        map.put("num2",i10b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails11")
    @ResponseBody
    public Map<String,String> getPcManDetails11(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        String ym = TimeUtil.getStartMon1();
        BigDecimal i11b = collMapper.selectAcMan11a(tgManager, ym);//查看该台区经理发行金额总和
        if (i11b==null || i11b==BigDecimal.ZERO){
            i11b = BigDecimal.ZERO;
        }
        BigDecimal i11a = collMapper.selectAcMan11b(tgManager,ym);//查看该台区经理欠费金额总和
        if (i11a==null){
            i11a = BigDecimal.ZERO;
        }
        map.put("num1",i11a.toString());
        map.put("num2",i11b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails12")
    @ResponseBody
    public Map<String,String> getPcManDetails12(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        map.put("num1","0");
        map.put("num2","0");
        return map;
    }
    @RequestMapping("getPcManDetails13")
    @ResponseBody
    public Map<String,String> getPcManDetails13(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();

        Integer i13a = collMapper.selectAcMan13(tgManager, ymd);//复电小于45分钟工单数
        if(i13a==null) i13a=0;
        Integer i13b = collMapper.selectAcMan13a(tgManager,ymd);//所有复电工单数
        if(i13b==null) i13b=0;
        map.put("num1",i13a.toString());
        map.put("num2",i13b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails14")
    @ResponseBody
    public Map<String,String> getPcManDetails14(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i14a = achievementsManagerMapper.selecttgd15(tgManager, ymd);//投诉工单数
        if(i14a==null)i14a=0;
        Integer i14b = achievementsManagerMapper.selecttgd16(tgManager, ymd);//意见工单数
        if(i14b==null)i14b=0;
        map.put("num1",i14a.toString());
        map.put("num2",i14b.toString());
        return map;
    }
    @RequestMapping("getPcManDetails15")
    @ResponseBody
    public Map<String,String> getPcManDetails15(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        map.put("num1","0");
        map.put("num2","0");
        return map;
    }
    @RequestMapping("getPcManDetails16")
    @ResponseBody
    public Map<String,String> getPcManDetails16(@RequestParam(required = false) String tgManager,@RequestParam(required = false) String ymd){
        Map<String,String> map = new HashMap<>();
        Integer i16a = collMapper.selectAcMan16(tgManager, ymd);//计量大于三天未处理工单数
        if(i16a==null)i16a=0;
        Integer i16b = collMapper.selectAcMan16a(tgManager, ymd);//计量总工单数
        if(i16b==null)i16b=0;
        map.put("num1",i16a.toString());
        map.put("num2",i16b.toString());
        return map;
    }


    @RequestMapping("getAcAll")
    @ResponseBody
    public AcAll getAcAll(@RequestParam(required = false) String orgNo,
                          @RequestParam(required = false) String ymd,
                          @RequestParam(required = false) String acId){
        System.out.println("acId"+acId);
        if("1".equals(acId)){//台区经理详情
            AcAll acAll = acAllMapper.selectAcAllMa(orgNo,ymd,acId);
            return acAll;
        }else if("2".equals(acId)){//营业站详情
            AcAll acAll = acAllMapper.selectAcAll(orgNo,ymd,acId);
            return acAll;
        }else if("3".equals(acId)){//旗县详情
            AcAll acAll = acAllMapper.selectAcAll(orgNo,ymd,acId);
            return acAll;
        }else if("4".equals(acId)){//市级详情
            AcAll acAll = acAllMapper.selectAcAll(orgNo,ymd,acId);
            return acAll;
        }
        return null;
    }
}
