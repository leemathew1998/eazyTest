package org.dfzt.entity.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class LinelossWorkOrder implements Serializable {
    private Integer id;
    @Excel(name = "工单编号",orderNum = "1",width = 20)
    private String workOrderNo;//工单编号
    @Excel(name = "台区经理",orderNum = "2",width = 20)
    private String tgManager;//台区经理
    @Excel(name = "台区编号",orderNum = "3",width = 20)
    private String tgId;//台区编号
    @Excel(name = "供电单位",orderNum = "4",width = 20)
    private String orgName;//供电单位
    @Excel(name = "台区名称",orderNum = "5",width = 20)
    private String tgName;//台区名称
    @Excel(name = "台区容量",orderNum = "6",width = 20)
    private Integer tgCap;//台区容量
    @Excel(name = "线损统计日期",orderNum = "7",width = 20)
    private String statDate;//线损统计日期
    @Excel(name = "供电量",orderNum = "8",width = 20)
    private BigDecimal ppq;//供电量
    @Excel(name = "售电量",orderNum = "9",width = 20)
    private BigDecimal tgSpq;//售电量
    @Excel(name = "损耗电量",orderNum = "10",width = 20)
    private BigDecimal lossPq;//损耗电量
    @Excel(name = "线损率",orderNum = "11",width = 20)
    private BigDecimal linelossRate;//损耗率

    private String meterAssetNo;//电能表资产号

    private String wiringMode;//接线方式

    private BigDecimal tFactor;//综合倍率

    private BigDecimal papE;//正向有功总

    private BigDecimal rapE;//反向有功总
    @Excel(name = "事件类型",orderNum = "12",width = 20)
    private String eventType;

    private Integer comQuesNum;//采集通信问题个数

    private Integer elestealNum;//可能存在窃电个数

    private Integer zeroFireNum;//零线大于火线个数

    private Integer currentNobalNum;//电流不平衡超阈值

    private Integer platOverloadNum;//台区负荷超容

    private Integer userOverloadNum;//用户负荷超容个数

    private String workOrderCycle;//工单周期

    private String workOrderStatus;//工单状态

    private String workOrderCreator;

    @Excel(name = "工单时间",orderNum = "13",format = "yyyy-MM-dd HH:mm:ss",width = 20)
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderCtime;//工单创建时间

    private String workOrderUtime;

    private Date workOrderStime;

    private Date workOrderFtime;

    private String handler;

    private Date handlerRtime;

    private String hworkOrderHandler;

    private Date hworkOrderHandlerRtime;

    private Date hworkOrderHandlerTtime;

    private String userType;//用户类型

    }