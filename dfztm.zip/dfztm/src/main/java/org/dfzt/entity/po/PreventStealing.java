package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.*;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/5
 * @Version: 1.00
 */
@TableName(value = "prevent_stealing")
@Data
public class PreventStealing implements Serializable {
    /**
     * 反窃查违主键
     */
    @TableId(value = "id",type = IdType.AUTO)
    private String id;

    /**
     * 查询时间
     */
//    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
//    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date selectTime;

    /**
     * 台区名称
     */
    private String tgName;

    /**
     * 查询编号
     */
    private String queryNo;

    /**
     * 供电单位
     */
    private String orgName;

    /**
     * 用户编号
     */
    private String consNo;

    /**
     * 用户名称
     */
    private String consName;

    /**
     * 用户地址
     */
    private String consAddr;

    /**
     * 用户电压
     */
    private String consVoltCode;

    /**
     * 违约用电行为
     */
    private String violateCode;

    /**
     * 窃电时长
     */
    private String violateLong;

    /**
     * 窃电小时数
     */
    private String violateHour;

    /**
     * 窃电容量
     */
    private String violateCap;

    /**
     * 窃电现象
     */
    private String alarmDesc;

    /**
     * 图片
     */
    private String vImage;

    /**
     * 视频
     */
    private String vVideo;

    /**
     * 办理地点
     */
    private String handlingAddress;

    /**
     * 联系电话
     */
    private String contactPhone;

    /**
     * 客户签名
     */
    private String userSignature;

    /**
     * 检查人员
     */
    private String checkerName;

    /**
     * 检查证号
     */
    private String checkerNo;

    /**
     * 逻辑删除
     */
    @TableLogic
    private Integer isDelete;

    /**
     * 提交时间
     */

//    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
//    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Timestamp commitTime;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;
}
