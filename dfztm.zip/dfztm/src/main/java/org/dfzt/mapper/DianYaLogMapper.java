package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.dto.DianYaLog;
import org.dfzt.entity.dto.ExecuteLogDetail;


public interface DianYaLogMapper extends BaseMapper<DianYaLog> {

}

