package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import oracle.security.crypto.core.math.BigInt;
import org.dfzt.eunm.MarketTypeEnum;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "CCons对象", description = "")
public class CCons implements Serializable {


    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "用户标识  【主键】本实体记录的唯一标识，产生规则为流水号")
    @TableField("cons_id")
    private BigDecimal consId;

    @ApiModelProperty(value = "客户标识 本实体记录的唯一标识，产生规则为流水号")
    @TableField("cust_id")
    private BigDecimal custId;

    @ApiModelProperty(value = "用户编号 --用电客户的外部标识引用国家电网公司营销管理代码类集:5110.1  用电客户编号规则")
    @TableField("cons_no")
    private String consNo;

    @ApiModelProperty(value = "用户名称  用户的名称，一般等于客户实体中的客户名称，但也允许附加上一些非自然的信息。如 XXX（东城），便于通过用户名称直接识别")
    @TableField("cons_name")
    private String consName;

    @ApiModelProperty(value = "自定义查询号  存储客户提供的自己熟悉的一串标识码，客户通过各种服务渠道可以通过这个查询号来查询自己用电的信息，如客户有多个用电地址，可提供不同的查询号")
    @TableField("cust_query_no")
    private String custQueryNo;

    @ApiModelProperty(value = "临时缴费关系号  方便收费操作，用户间建立的松散的缴费关系的标识，可根据此编号缴费，系统显示该编号的所有客户欠费记录，但用户间不能互相共用余额")
    @TableField("tmp_pay_rela_no")
    private String tmpPayRelaNo;

    @ApiModelProperty(value = "原用户编号  原用户编号，用于系统升级的时候用户编号重新编号可以在一段时间内继续使用原用户编号查询用户信息")
    @TableField("orgn_cons_no")
    private String orgnConsNo;

    @ApiModelProperty(value = "用户分类  用户一种常用的分类方式，方便用户的管理01 高压，02 低压非居民，03 低压居民")
    @TableField("cons_sort_code")
    private String consSortCode;

    @ApiModelProperty(value = "用电地址  用电客户的用电地址")
    @TableField("elec_addr")
    private String elecAddr;

    @ApiModelProperty(value = "行业分类  用电客户的行业分类代码引用国标GB/T 4754-2002")
    @TableField("trade_code")
    private String tradeCode;

    @ApiModelProperty(value = "用电类别  用电客户的用电类别分类引用国家电网公司营销管理代码类集:5110.4 用电类别大工业用电，中小化肥，居民生活用电，农业生产用电，贫困县农业排灌用电")
    @TableField("elec_type_code")
    private String elecTypeCode;

    @ApiModelProperty(value = "合同容量  合同约定的本用户的容量")
    @TableField("contract_cap")
    private BigDecimal contractCap;

    @ApiModelProperty(value = "运行容量  用电客户正在使用的合同容量，如暂停客户，在暂停期间其运行容量等于合同容量减去已暂停的容量")
    @TableField("run_cap")
    private BigDecimal runCap;

    @ApiModelProperty(value = "生产班次  用电客户的生产班次分类引用国家电网公司营销管理代码类集:5110.6用电客户生产班次代码单班，二班，三班，连续生产")
    @TableField("shift_no")
    private String shiftNo;

    @ApiModelProperty(value = "负荷性质  负荷的重要程度分类引用国家电网公司营销管理代码类集:5110.44负荷类别分类与代码一类，二类，三类")
    @TableField("lode_attr_code")
    private String lodeAttrCode;

    @ApiModelProperty(value = "供电电压  用电客户的供电电压等级代码，多路电源时取电压等级最高的供电电压等级代码引用《国家电网公司信息分类与代码体系－综合代码类集－电压等级代码表》")
    @TableField("volt_code")
    private String voltCode;

    @ApiModelProperty(value = "高耗能行业类别  依据国家最新的高耗能行业划分")
    @TableField("hec_industry_code")
    private String hecIndustryCode;

    @ApiModelProperty(value = "厂休日  周休日通过数字连续表示周休哪几天，类似于飞机航班日期表示，如1.2.3,表示星期一星期二和星期三休息。")
    private String holiday;

    @ApiModelProperty(value = "立户日期  电子用户档案的首次建立日期")
    @TableField("build_date")
    private Date buildDate;

    @ApiModelProperty(value = "送电日期  用户的首次送电日期")
    @TableField("ps_date")
    private Date psDate;

    @ApiModelProperty(value = "销户日期  销户业务信息归档的日期")
    @TableField("cancel_date")
    private Date cancelDate;

    @ApiModelProperty(value = "到期日期  临时用电客户约定的用电到期日期")
    @TableField("due_date")
    private Date dueDate;

    @ApiModelProperty(value = "电费通知方式  用户每月电费的通知方式")
    @TableField("notify_mode")
    private String notifyMode;

    @ApiModelProperty(value = "电费结算方式  用于区分是否分期结算 01 分期结算，02 抄表结算")
    @TableField("settle_mode")
    private String settleMode;

    @ApiModelProperty(value = "用户状态  用电客户的状态说明，说明客户是否处于业扩变更中或已销户")
    @TableField("status_code")
    private String statusCode;

    @ApiModelProperty(value = "供电单位编号  供电单位编码，一般是指的用户的直接供电管理单位，也可以是大客户管理中心等由于管理原因产生的客户管理单位")
    @TableField("org_no")
    private String orgNo;

    @ApiModelProperty(value = "重要性等级  该户用电检查管理的重要性等级 01 国家级 02 省级  03  市级  04 县级  05其它")
    @TableField("rrio_code")
    private String rrioCode;

    @ApiModelProperty(value = "检查周期  检查周期(单位：月)：用于存放客户检查周期信息，便于周期检查计划制定时，获取参数。")
    @TableField("chk_cycle")
    private Long chkCycle;

    @ApiModelProperty(value = "上次检查日期  上次检查日期：用于存放客户上次检查日期，默认为客户的开户日期。")
    @TableField("last_chk_date")
    private Date lastChkDate;

    @ApiModelProperty(value = "检查人员编号  人员编号：分管检查人员的人员编号。")
    @TableField("checker_no")
    private String checkerNo;

    @ApiModelProperty(value = "停电标志  停电标志：01 已停电  02 未停电，反映客户当前是否处于停电状态")
    @TableField("poweroff_code")
    private String poweroffCode;

    @ApiModelProperty(value = "转供标志  标识客户是否是转供相关客户，如果涉及转供，是属于转供户还是被转供户")
    @TableField("transfer_code")
    private String transferCode;

    @ApiModelProperty(value = "抄表段编号  抄表段标识,用于表示用电客户所属的抄表段")
    @TableField("mr_sect_no")
    private String mrSectNo;

    @ApiModelProperty(value = "票据类型  用电客户每月电费默认打印的票据类型")
    @TableField("note_type_code")
    private String noteTypeCode;

    @ApiModelProperty(value = "临时用电标志  表示是否是临时用电的用电客户，且属于哪种临时用电")
    @TableField("tmp_flag")
    private String tmpFlag;

    @ApiModelProperty(value = "临时用电到期日期  临时用电用户临时用电的到期日期")
    @TableField("tmp_date")
    private Date tmpDate;

    @ApiModelProperty(value = "计量方式")
    @TableField("meas_mode")
    private String measMode;

    @ApiModelProperty(value = "数据变更时间 当数据发生变更时候记录变更时间，在往辅助决策中导数据时候使用")
    @TableField("db_timestamp")
    private Date dbTimestamp;

    @ApiModelProperty(value = "磁卡号")
    @TableField("card_no")
    private String cardNo;

    @ApiModelProperty(value = "收费次数")
    @TableField("charge_num")
    private BigDecimal chargeNum;

    @ApiModelProperty(value = "重要性等级")
    @TableField("prio_code")
    private String prioCode;

    @ApiModelProperty(value = "催费段编号")
    @TableField("remind_sect_no")
    private String remindSectNo;

    @ApiModelProperty(value = "结算计算标识")
    @TableField("amt_calc_id")
    private BigDecimal amtCalcId;

    @ApiModelProperty(value = "城乡类别 城乡类别:01 城市,02 农村,03 特殊边远山区")
    @TableField("urban_rural_flag")
    private String urbanRuralFlag;

    @ApiModelProperty(value = "表中字段记录标识 01是，02否")
    @TableField("open_cap_flag")
    private String openCapFlag;

    @ApiModelProperty(value = "用户对应负荷特性 包含：一般负荷、连续性负荷")
    @TableField("load_feature_code")
    private String loadFeatureCode;

    @ApiModelProperty(value = "用户保安设施对应负荷容量")
    @TableField("security_cap")
    private BigDecimal securityCap;

    @ApiModelProperty(value = "市场化用户类型 0101市场化直购用户、0102市场化零售客户、0103部分市场化零售客户、0201非市场化客户、0202放弃选择权的客户，空值认为是非市场化用户。")
    @TableField("market_prop_sort")
    private String marketPropSort;

    @ApiModelProperty(value = "频繁停电用户")
    @TableField("often_power_cut")
    private Integer oftenPowerCut;

    @ApiModelProperty(value = "敏感用户")
    @TableField("sensitive_user")
    private Integer sensitiveUser;

    //是否敏感用户，1.是，2.否
    private String whetherSensitivity;



}
