package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "RunWorderDeal对象", description = "")
public class RunWorderDeal implements Serializable {


    @ApiModelProperty(value = "主键")
    @TableId(value = "gd_deal_id", type = IdType.AUTO)
    private Integer gdDealId;

    @ApiModelProperty(value = "工单编号")
    @TableField("gd_no")
    private String gdNo;

    @ApiModelProperty(value = "工单处理时间")
    @TableField("gd_deal_date")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Date gdDealDate;

    @ApiModelProperty(value = "未抄回（针对于彻底抄不回的用户，需要站长手动归档）")
    @TableField("gd_deal_state")
    private String gdDealState;

    @ApiModelProperty(value = "工单处理现场情况，输入描述现场处理情况")
    @TableField("gd_event_situation")
    private String gdEventSituation;

    @ApiModelProperty(value = "现场情况照片，最多三张")
    @TableField("gd_event_photo")
    private String gdEventPhoto;

    @ApiModelProperty(value = "现场视频")
    @TableField("gd_event_video")
    private String gdEventVideo;

    @ApiModelProperty(value = "扫描条形码获取，进行校验")
    @TableField("gd_meter_id")
    private Integer gdMeterId;

    @ApiModelProperty(value = "文本输入")
    @TableField("gd_display")
    private String gdDisplay;

    @ApiModelProperty(value = "电能表示数")
    @TableField("meter_number")
    private String meterNumber;


}
