package org.dfzt.mapper;

import org.dfzt.entity.po.EMpVolCurve;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 李木
* @description 针对表【e_mp_vol_curve】的数据库操作Mapper
* @createDate 2023-02-25 14:24:13
* @Entity org.afzt.entity.po.EMpVolCurve
*/
public interface EMpVolCurveMapper extends BaseMapper<EMpVolCurve> {

}




