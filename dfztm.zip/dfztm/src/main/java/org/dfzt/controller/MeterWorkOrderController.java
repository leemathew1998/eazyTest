package org.dfzt.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.dfzt.annotation.CurrentUser;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.MeterData;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.eunm.meterEventType;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.mapper.MeterWorkOrderMapper;
import org.dfzt.service.CollectInformaService;
import org.dfzt.service.CollectWorkOrderInforService;
import org.dfzt.service.MeterWorkOrderService;
import org.dfzt.util.ExcelUtils;
import org.dfzt.util.TimeUtil;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * (MeterWorkOrder)表控制层
 *
 * @author dfzt-dyy
 * @since 2022-06-13 14:56:02
 */
@RestController
@RequestMapping("/mwo")
@CrossOrigin
public class MeterWorkOrderController extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private MeterWorkOrderService meterWorkOrderService;
    @Resource
    private MeterWorkOrderMapper meterWorkOrderMapper;
    @Resource
    private CollectInformaService collectInformaService;

    @Resource
    private CollectWorkOrderMapper collectWorkOrderMapper;
    @Resource
    private CollectWorkOrderInforService collectWorkOrderInforService;

    /**
     * 模拟获取数据
     */
    @PostMapping("/getMeter")
    //@Scheduled(cron = "0 0 4 * * ? ")
    public String obtain(){
        List<CollectInforma> collectInformas = collectWorkOrderMapper.selectCollInfo(TimeUtil.getStartTime());
        collectInformaService.meterWorkOrder(collectInformas);
        return "计量生成工单";
    }

    /**
     * 修改工单状态
     */
    @ResponseBody
    @PostMapping(value = "/updateastu2",produces = "application/json;charset=utf-8")
    public String updateastu2(@RequestParam String workOrderNo){
        meterWorkOrderMapper.updateWorkOrderStu2(workOrderNo);
        return "修改成功";
    }

    /**
     * 修改工单状态
     */
    @ResponseBody
    @PostMapping(value = "/updateastu4",produces = "application/json;charset=utf-8")
    public String updateastu4(@RequestParam String workOrderNo){
        meterWorkOrderMapper.updateWorkOrderStu4(workOrderNo);
        return "修改成功";
    }


    /**
     * 上传视频和图片信息
     */
    @ResponseBody
    @PostMapping(value = "/upload",produces = "application/json;charset=utf-8")
    public String upload(CollectWorkOrderInfor collectWorkOrderInfor){
        //接收到的图片视频等处理信息存放
        collectWorkOrderInforService.insertSelective(collectWorkOrderInfor);
        meterWorkOrderMapper.updateWorkOrderStu3(collectWorkOrderInfor.getWorkOrderNo());
        return "执行成功";
    }


    /**
     * 回显工单处理表的图片和视频
     */
    @ResponseBody
    @PostMapping("/loadwkoreder")
    public CollectWorkOrderInfor loadwkoreder(String workOrderNo){
        CollectWorkOrderInfor collectWorkOrderInfor = collectWorkOrderInforService.selectlineVandP(workOrderNo);
        return collectWorkOrderInfor;
    }

    @RequestMapping("exportAll")  //excel/export
    public void exportExcel2All(HttpServletResponse response, @RequestParam(required = false) String ids,MeterWorkOrder m,
                                @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,
                                @RequestParam(required = false) String loName2) throws IOException {
        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<MeterWorkOrder> meterWorkOrders = meterWorkOrderMapper.selectExcelList(m, orgName, status);
        ExcelUtils.exportExcel(meterWorkOrders, "计量运维工单列表", "计量运维", MeterWorkOrder.class, "计量运维工单文件", response);
    }


    @RequestMapping("export")  //excel/export
    public void exportExcel2(HttpServletResponse response, @RequestParam String ids) throws IOException {
        List<MeterWorkOrder> meterWorkOrders = collectWorkOrderMapper.selectExcel2(ids);
        ExcelUtils.exportExcel(meterWorkOrders, "计量运维工单列表", "计量运维", MeterWorkOrder.class, "计量运维工单文件", response);
    }


    /**
     * 分页查询所有数据   pc 模糊查询
     * @param //page           分页对象
     * @param meterWorkOrder 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll")
    public R selectAll( MeterWorkOrder meterWorkOrder,@RequestParam(name = "pageNo",defaultValue = "1") String pageNo,
                        @RequestParam(name = "pageSize",defaultValue = "10") String pageSize,
                        @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String loName2) {
        Page<MeterWorkOrder> page = new Page<>();
        //page.setCurrent((Long.parseLong(pageNo)-1)*Long.parseLong(pageSize));
        page.setCurrent(Long.parseLong(pageNo));
        page.setSize(Long.parseLong(pageSize));
        //通过用户名查询角色信息（2： 台区经理  1：所站长）
        int role =2;// meterWorkOrderService.selRole(user.getLoginName());
        if (role == 2){
            return success(meterWorkOrderService.page(page, meterWorkOrderService.queryWrapper1(meterWorkOrder,status)));
        }
        return success(meterWorkOrderService.page(page, meterWorkOrderService.queryWrapper(meterWorkOrder)));
    }




    /**
     * app 模糊查询
     * @param
     * @param str
     * @return
     */
    @PostMapping("selectAppAll")
    public R selectAppAll(@RequestParam String loName2,@RequestParam(name = "pageNo",defaultValue = "0") String pageNo,
                          @RequestParam(name = "pageSize",defaultValue = "10") String pageSize
            ,@RequestParam String workOrderStatus, @RequestParam(required = false) String str,@RequestParam(required = false) String role,
            @RequestParam(required = false) String loginName) {
        List<String> orgName = new ArrayList<>();
        List<String> readNames = collectWorkOrderMapper.selectReadNames(loginName);
        Page<MeterWorkOrder> page = new Page<>();
        page.setCurrent(Long.parseLong(pageNo));
        page.setSize(Long.parseLong(pageSize));
        //通过用户名查询角色信息（2： 台区经理  1：所站长）
        if ("2".equals(role)){
            return success(meterWorkOrderService.page(page, meterWorkOrderService.Wrapper1(readNames,str,workOrderStatus,loName2)));
        }
        return success(meterWorkOrderService.page(page,meterWorkOrderService.Wrapper(str,workOrderStatus,loName2)));
    }

    /**
     * TODO 查询工单研判原因参与计算的值
     * @return
     */
    @PostMapping("selectOne")
    public MeterData select1(@RequestParam String workOrderNo) throws ParseException {
        MeterWorkOrder meterWo = meterWorkOrderMapper.selectOne(workOrderNo);
        String consNo = meterWo.getConsNo();
        MeterData meterData = new MeterData();
        CollectInformation collImation = meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartTime());
        meterEventType s = meterWo.getEventType();
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String time = sdf.format(date);
        meterData.setDateTime(sdf.parse(time));
        if(s==meterEventType.EVENT_TYPE_ONE){
            //尖峰平谷之和
            BigDecimal rateall = collImation.getRateOne().add(collImation.getRateTwo()).add(collImation.getRateThree()).add(collImation.getRateFour());//系统报错
            meterData.setRateAll(rateall);
            //正向有功总
            meterData.setPositiveActive(collImation.getTotalPositiveActivePower());
            //两者之差
            meterData.setDiff(rateall.subtract(collImation.getTotalPositiveActivePower()).abs());
        }else if(s==meterEventType.EVENT_TYPE_TWO){
            //近一天的反向有功
            meterData.setOneReverseActive(meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartTime()).getTotalReverseActivePower());
            //近两天的反向有功
            meterData.setTwoReverseActive(meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartTwoTime()).getTotalReverseActivePower());
            //近三天的反向有功
            meterData.setThreeReverseActive(meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartThreeTime()).getTotalReverseActivePower());
        }else if(s==meterEventType.EVENT_TYPE_THREE){
            meterData.setNinesix1("15点45时");
            meterData.setVoltageValue1("196V");
        }else if(s==meterEventType.EVENT_TYPE_FOUR){
            meterData.setNinesix2("19点15时");
            meterData.setVoltageValue2("143V");
        }else if(s==meterEventType.EVENT_TYPE_FIVE){
            //零点冻结电能示值
            meterData.setNowPositiveActive(meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartTime()).getTotalPositiveActivePower());
            //前一天零点冻结电能示值
            meterData.setBeforePositiveActive(meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartTwoTime()).getTotalPositiveActivePower());
            //所有相中电压最大值
            meterData.setMaxVoltage(new BigDecimal("183"));
            //表计额定电压
            meterData.setEdVoltage(new BigDecimal("220"));
            //前一天A相电流平均值
            meterData.setBeforeavgCurrentA(new BigDecimal("0.25"));
            meterData.setBeforeavgCurrentB(new BigDecimal("0.14"));
            meterData.setBeforeavgCurrentC(new BigDecimal("0.07"));
            //当天A相电流平均值
            meterData.setNowavgCurrentA(new BigDecimal("0.15"));
            meterData.setNowavgCurrentB(new BigDecimal("0.08"));
            meterData.setNowavgCurrentC(new BigDecimal("0.11"));
//        }else if(s==meterEventType.EVENT_TYPE_SIX){
//            //零点冻结电能示值
//            meterData.setNowPositiveActive(meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartTime()).getTotalPositiveActivePower());
//            //前一天零点冻结电能示值
//            meterData.setBeforePositiveActive(new BigDecimal("3211.12"));
//            meterData.setRatedVoltage("220V");
//            meterData.setMaxCurrent("60A");
//            meterData.setResultValue("633.6");
//        }else if(s==meterEventType.EVENT_TYPE_SEVEN){
//            meterData.setNowPositiveActive(meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartTime()).getTotalPositiveActivePower());
//            meterData.setBeforePositiveActive(meterWorkOrderMapper.selectByUsercode1(consNo,TimeUtil.getStartTwoTime()).getTotalPositiveActivePower());
        }
        return meterData;
    }

    /**
     * 修改数据
     *
     * @param meterWorkOrder 实体对象
     * @return 修改结果
     */
    @PostMapping("update")
    public R update(@RequestBody MeterWorkOrder meterWorkOrder) {
        return success(this.meterWorkOrderService.updateById(meterWorkOrder));
    }



    //计量绩效计算
    @PostMapping("meterperformance")
    public String meterperformance(){
        meterWorkOrderService.meterperformance();
        return "OK";
    }

    /**
     * 计量失败工单详情
     */
    @PostMapping("feilmeterAll")
    public R findfeilmeterAll(){
        return success(this.meterWorkOrderMapper.findfeilmeterAll());
    }

    /**
     * 查看原始数据电能示值
     * @param elecmeterAssetNum
     */
    @PostMapping("selEleVal")
    public R selEleVal(String elecmeterAssetNum){
        return success(this.meterWorkOrderMapper.selEleVal(elecmeterAssetNum));
    }

    @PostMapping("selectAllByAppType")
    public R selectAllByAppType(){
        return success(this.meterWorkOrderService.selectAllByAppType());
    }
}
