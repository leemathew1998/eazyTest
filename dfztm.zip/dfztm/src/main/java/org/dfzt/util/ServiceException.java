package org.dfzt.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName ServiceException
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/8/10 18:45
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ServiceException extends Exception{

    private Integer code;
    private String message;

    public ServiceException(BaseException exceptionEnum) {
        this.code = exceptionEnum.getCode();
        this.message = exceptionEnum.getMessage();
    }

}
