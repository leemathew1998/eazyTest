package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/7
 * @Version: 1.00
 */
@Data
public class CSp implements Serializable {
    private BigDecimal spId;//受电点编号
    private String spName;//受电点名称
    private String psNumCode;//电源数目
    private BigDecimal consId;//用户编号
}
