package com.exam.modules.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.exam.modules.entity.ExamManage;
import com.exam.modules.entity.vo.ExamManageVo;

/**
 * 考试管理(ExamManage)表服务接口
 *
 * @author dyy
 * @since 2022-11-08 17:16:06
 */
public interface ExamManageService extends IService<ExamManage> {

    /**
     * 分页查询考试列表
     * @param page
     * @param examManageVo
     * @return
     */
    IPage<ExamManage> findExamManageList(IPage<ExamManage> page, ExamManageVo examManageVo);

//    IPage<ExamManage> select(IPage<ExamManage> page,ExamManageVo manageVo);
}

