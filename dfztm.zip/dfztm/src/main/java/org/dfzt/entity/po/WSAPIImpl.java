//package org.dfzt.entity.po;
//
//
//import org.dfzt.entity.xmlDemoReal.*;
//import org.dfzt.util.XStreamUtils;
//
//import javax.jws.WebService;
//import java.util.ArrayList;
//import java.util.List;
//
//
///**
// * @ClassName WSAPIImpl
// * @Description TODO
// * @Author 邢俊豪
// * @Date 2022/12/8 13:16
// */
//@WebService(targetNamespace = "http://po.entity.dfzt.org/",
//        endpointInterface = "org.dfzt.entity.po.WSAPI")
///*targetNamespace命名空间需要在实现类 路劲反向*/
///*endpointInterface是服务接口全路径, 指定做SEI（Service EndPoint Interface）服务端点接口*/
///*endpointInterface路径一定要写正确，不然启动会一直报错）*/
//public class WSAPIImpl implements WSAPI {
//    @Override
//    public String getInfo() {
//        return "每天学Java";
//    }
//
//
//    @Override
//    public CollectFailure getInfoGood() {
//        return new CollectFailure("hello1","Hello2");
//    }
//
//
//    @Override
//    public String getInfoBad(String message) {
//        Demo1 demo1 = new Demo1();
//        Demo2 demo2 =new Demo2();
//        List<General> generals =new ArrayList<>();
//        General general5 = new General();
//        general5.setN("setRLT_FLAG");
//        general5.setValue("false");
//        generals.add(general5);
//        General general6 = new General();
//        general6.setN("setRLT_MEMO");
//        general6.setValue("111");
//        generals.add(general6);
//        demo2.setGeneral(generals);
//        demo1.setDemo2(demo2);
//
//
//        Demo3 demo3 =new Demo3();
//        demo1.setDemo2(demo2);
//
//        List<General> list =new ArrayList<>();
//        General general = new General("P_ORG_NAME", "国网内蒙古东部电力有限公司红山区供电分公司");
//        General general1 = new General("ORG_NAME", "铁南供电所");
//        General general2 = new General("CONS_NO", "1820");
//        General general3= new General("CONS_NAME", "jkl");
//        General general4 = new General("ELEC_ADDR", "jkl");
//        General general7 = new General("METER_ASSET_NO", "jkl");
//        General general8 = new General("TG_NO", "9802011328");
//        General general9 = new General("TG_NAME", "三道井子村养殖小区变台");
//        General general10 = new General("TERMINAL_ADDR", "jkl");
//        General general11 = new General("FACTORY_CODE", "jkl");
//        General general12 = new General("STATUS_CODE", "jkl");
//        General general13 = new General("MP_SN", "1234");
//        General general14 = new General("MR_DATE", "2022-12-15");
//        General general15 = new General("T_FACTOR", "123123");
//        General general16 = new General("READER_NAME", "jkl");
//        General general17 = new General("READER_NO", "jkl");
//
//
//        list.add(general);
//        list.add(general1);
//        list.add(general2);
//        list.add(general3);
//        list.add(general4);
//        list.add(general7);
//        list.add(general8);
//        list.add(general9);
//        list.add(general10);
//        list.add(general11);
//        list.add(general12);
//        list.add(general13);
//        list.add(general14);
//        list.add(general15);
//        list.add(general16);
//        list.add(general17);
//
//
//        demo3.setGeneral(list);
//        demo1.setDemo3(demo3);
//        String s = XStreamUtils.objectToXml(demo1,new DemoConverter());
//        String xml = s.replaceAll("__", "_");
//        xml="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"+xml;
//        System.err.println(xml);
//        return xml;
//    }
//
//}
