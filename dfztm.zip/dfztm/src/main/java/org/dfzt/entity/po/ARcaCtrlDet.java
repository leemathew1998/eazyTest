package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@ApiModel(value="a_rca_ctrl_det")
@Data
@TableName(value = "a_rca_ctrl_det")
public class ARcaCtrlDet {

    private Integer id;
    /**
     * 本实体记录唯一标识，产生规则为流水号
     */
    @TableId(value = "ctrl_id", type = IdType.INPUT)
    @ApiModelProperty(value="本实体记录唯一标识，产生规则为流水号")
    private BigDecimal ctrlId;

    /**
     * 用户编号
     */
    @TableField(value = "cons_no")
    @ApiModelProperty(value="用户编号")
    private String consNo;

    /**
     * 供电单位
     */
    @TableField(value = "org_no")
    @ApiModelProperty(value="供电单位")
    private String orgNo;

    /**
     * 采集反馈指令执行情况的时间
     */
    @TableField(value = "remote_rt_date")
    @ApiModelProperty(value="采集反馈指令执行情况的时间")
    private Date remoteRtDate;

    /**
     * 开关轮次号
     */
    @TableField(value = "switch_no")
    @ApiModelProperty(value="开关轮次号")
    private Integer switchNo;

    /**
     * 指令下发时间
     */
    @TableField(value = "remote_date")
    @ApiModelProperty(value="指令下发时间")
    private Date remoteDate;

    /**
     * 指令执行状态，通过采集反馈更新实际状态，01未执行、02执行中、03执行成功、04执行失败。对照《CD02-SGPMSS营销代码标准设计说明书（第二篇第二册）》中标准码“费控指令执行状态”。
     */
    @TableField(value = "remote_rslt")
    @ApiModelProperty(value="指令执行状态，通过采集反馈更新实际状态，01未执行、02执行中、03执行成功、04执行失败。对照《CD02-SGPMSS营销代码标准设计说明书（第二篇第二册）》中标准码“费控指令执行状态”。")
    private String remoteRslt;

    /**
     * 电能表标识
     */
    @TableField(value = "meter_id")
    @ApiModelProperty(value="电能表标识")
    private BigDecimal meterId;

    /**
     * 计量点标识
     */
    @TableField(value = "mp_id")
    @ApiModelProperty(value="计量点标识")
    private BigDecimal mpId;

    /**
     * 0否1是
     */
    @TableField(value = "switch_flag")
    @ApiModelProperty(value="0否1是")
    private String switchFlag;

    /**
     * 01自动下发、02掌机
     */
    @TableField(value = "remote_type")
    @ApiModelProperty(value="01自动下发、02掌机")
    private String remoteType;

    /**
     * 指令下发的人员工号，也可为系统自动编号
     */
    @TableField(value = "remote_opr")
    @ApiModelProperty(value="指令下发的人员工号，也可为系统自动编号")
    private String remoteOpr;

    /**
     * MAC地址
     */
    @TableField(value = "mac")
    @ApiModelProperty(value="MAC地址")
    private String mac;

    /**
     * 描述单户一次下发多个表计指令的批次号，如一个用户拥有多个表计，则一次下发的多条记录中此标识唯一
     */
    @TableField(value = "crtl_batch_id")
    @ApiModelProperty(value="描述单户一次下发多个表计指令的批次号，如一个用户拥有多个表计，则一次下发的多条记录中此标识唯一")
    private BigDecimal crtlBatchId;

    /**
     * 采集点编号
     */
    @TableField(value = "cp_no")
    @ApiModelProperty(value="采集点编号")
    private String cpNo;

    /**
     * 终端标识
     */
    @TableField(value = "terminal_id")
    @ApiModelProperty(value="终端标识")
    private BigDecimal terminalId;

    /**
     * 本实体记录的唯一标识，产生规则为流水号
     */
    @TableField(value = "tactic_det_id")
    @ApiModelProperty(value="本实体记录的唯一标识，产生规则为流水号")
    private BigDecimal tacticDetId;

    /**
     * 下发的控制指令类别，01预警、02停电、03复电、04取消预警、05保电、06取消保电。
     */
    @TableField(value = "ctrl_type")
    @ApiModelProperty(value="下发的控制指令类别，01预警、02停电、03复电、04取消预警、05保电、06取消保电。")
    private String ctrlType;

    /**
     * 记录采集反馈时的执行详细信息，包括失败信息。
     */
    @TableField(value = "remark")
    @ApiModelProperty(value="记录采集反馈时的执行详细信息，包括失败信息。")
    private String remark;

    //private String moveStatus;

    /**
     * 费控复电工单编号
     */
    @TableField(exist = false)
    private String workerOrderNo;
}