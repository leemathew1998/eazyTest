package com.exam.modules.controller;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.config.redis.RedisService;
import com.exam.modules.entity.*;
import com.exam.modules.entity.dto.UserRoleDTO;
import com.exam.modules.entity.vo.RouterVo;
import com.exam.modules.entity.vo.TokenVo;
import com.exam.modules.entity.vo.UserQueryVo;
import com.exam.modules.mapper.ExamInfoMapper;
import com.exam.modules.mapper.SysUserMapper;
import com.exam.modules.service.ExamInfoService;
import com.exam.modules.service.ISysRoleService;
import com.exam.modules.service.ISysUserRoleService;
import com.exam.modules.service.ISysUserService;
import com.exam.modules.utils.JwtUtils;
import com.exam.modules.utils.MenuTree;
import com.exam.modules.utils.MyLong;
import com.exam.modules.utils.Result;
import com.google.code.kaptcha.Producer;
import io.jsonwebtoken.Jwts;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.util.FastByteArrayOutputStream;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@RestController
@RequestMapping("/api/user")
public class SysUserController {
    @Resource
    private ISysUserService sysUserService;
    @Resource
    private PasswordEncoder passwordEncoder;
    @Resource
    private RedisService redisService;
    @Resource
    private JwtUtils jwtUtils;
    @Resource
    Producer producer;
    @Resource
    private SysUserMapper userMapper;
    @Resource
    private ISysRoleService roleService;
    @Resource
    private SysUserMapper sysUserMapper;
    @Resource
    private ExamInfoService examInfoService;
    @Resource
    private ExamInfoMapper examInfoMapper;
    @Resource
    private ISysUserRoleService userRoleService;
    /**
     * 查询所有用户列表（测试接口）
     * @return
     */
    @PostMapping("/listAll")
    public Result listAll(){
        return Result.ok(sysUserService.list());
    }

    /**
     * 获取用户信息
     *
     * @return
     */
    @PostMapping("/getInfo")
    public Result getInfo() {
        //从Spring Security上下文获取用户信息
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        //判断authentication对象是否为空
        if (authentication == null) {
            return Result.error().message("用户信息查询失败");
        }
        //获取用户信息
        SysUser user = (SysUser) authentication.getPrincipal();
        //用户权限集合
        List<SysMenu> sysMenusList = user.getSysMenusList();
        //获取角色权限编码字段
        Object[] roles = sysMenusList
                        .stream()
                        .filter(Objects::nonNull)
                        .map(SysMenu::getPerms).toArray();
        //创建用户信息对象
        UserInfo userInfo = new UserInfo(user.getUserId(), user.getUsername(),roles);
        //返回数据
        return Result.ok(userInfo).message("用户信息查询成功");
    }


    /**
     * 刷新token
     *
     * @param request
     * @return
     */
    @PostMapping("/refreshToken")
    public Result refreshToken(HttpServletRequest request) {
        //从header中获取前端提交的token
        String token = request.getHeader("token");
        //如果header中没有token，则从参数中获取
        if (ObjectUtils.isEmpty(token)) {
            token = request.getParameter("token");
        }
        //从Spring Security上下文获取用户信息
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        //获取身份信息
        UserDetails details = (UserDetails) authentication.getPrincipal();
        //重新生成token
        String reToken = "";
        //验证原来的token是否合法
        if (jwtUtils.validateToken(token, details)) {
        //生成新的token
            reToken = jwtUtils.refreshToken(token);
        }
        //获取本次token的到期时间，交给前端做判断
        long expireTime = Jwts.parser().setSigningKey(jwtUtils.getSecret())
                .parseClaimsJws(reToken.replace("jwt_", ""))
                .getBody().getExpiration().getTime();
        //清除原来的token信息
        String oldTokenKey = "token_" + token;
        redisService.del(oldTokenKey);
        //存储新的token
        String newTokenKey = "token_" + reToken;
        redisService.set(newTokenKey, reToken, jwtUtils.getExpiration() / 1000);
        //创建TokenVo对象
        TokenVo tokenVo = new TokenVo(expireTime, reToken);
        //返回数据
        return Result.ok(tokenVo).message("token生成成功");
    }

    /**
     * 获取菜单数据
     *
     * @return
     */
    @PostMapping("/getMenuList")
    public Result getMenuList() {
        //从Spring Security上下文获取用户信息
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        //获取用户信息
        SysUser user = (SysUser) authentication.getPrincipal();
        //获取相应的权限
        List<SysMenu> sysMenuList = user.getSysMenusList();
        //筛选目录和菜单
        List<SysMenu> collect = sysMenuList.stream()
                .filter(item -> item != null && item.getType() !=2) //2—>按钮
                .collect(Collectors.toList());
        //生成路由数据
        List<RouterVo> routerVoList = MenuTree.makeRouter(collect, 0L);
        //返回数据
        return Result.ok(routerVoList).message("菜单数据获取成功");
    }

    /**
     * 用户退出
     * @param request
     * @param response
     * @return
     */
    @PostMapping("/logout")
    public Result logout(HttpServletRequest request, HttpServletResponse response) {
        //获取token
        String token = request.getParameter("token");
        //如果没有从头部获取token，那么从参数里面获取
        if (ObjectUtils.isEmpty(token)) {
            token = request.getHeader("token");
        }
        //获取用户相关信息
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            //清空用户信息
            new SecurityContextLogoutHandler().logout(request, response, authentication);
            //清空redis里面的token
            String key = "token_" + token;
            redisService.del(key);
        }
        return Result.ok().message("用户退出成功");
    }

    /**
     * 验证码
     * @param resp
     * @param session
     * @return
     * @throws IOException
     */
    @PostMapping("/vc.jpg")
    public String getVerifyCode(HttpServletResponse resp,HttpSession session) throws IOException {
        resp.setContentType("image/jpeg");
        // 1 生成验证码
        String text = producer.createText();
        // 2 放入redis 实现
        System.out.println("生成验证码："+text);
//        session.setAttribute("captcha",text);
        redisService.set("captcha",text,60L);//设置验证码60秒过期
        // 3 生成图片
        BufferedImage bi = producer.createImage(text);
        FastByteArrayOutputStream fos = new FastByteArrayOutputStream();
        ImageIO.write(bi,"jpg",fos);
        // 4 返回base64
        return Base64.encodeBase64String(fos.toByteArray());
    }

    /**
     * 查询用户列表
     * @param userQueryVo
     * @return
     */
    @PostMapping("/list")
    public Result list(@RequestBody UserQueryVo userQueryVo) {
        //创建分页信息
        IPage<SysUser> page = new Page<SysUser>(userQueryVo.getPageNo(), userQueryVo.getPageSize());
        //调用分页查询方法
        IPage<SysUser> userListByPage = sysUserService.findUserListByPage(page, userQueryVo);
        //存储返回用户信息
        List<SysUser> list = new ArrayList<>();
        //通过用户id查询角色
        for (SysUser record : userListByPage.getRecords()) {
            SysUser user = new SysUser();
            //通过用户ID查询角色ID
            List<Long> roleIds = userRoleService.list()
                    .stream()
                    .filter(Objects::nonNull)
                    .filter(item -> item.getUserId().equals(record.getUserId()))
                    .map(SysUserRole::getRoleId)
                    .collect(Collectors.toList());
            //通过角色ID查询角色名称
            for (Long rid : roleIds) {
                List<String> roleNames = roleService.list()
                        .stream()
                        .filter(Objects::nonNull)
                        .filter(r -> r.getRoleId().equals(rid))
                        .map(SysRole::getRoleName)
                        .collect(Collectors.toList());
                //角色名称赋值
                for (String roleName : roleNames) {
                    user.setRoleName(roleName);
                }
                //角色id赋值
                user.setRoleId(rid);
                user.setUserId(record.getUserId());
            }
            //user存储集合
            list.add(user);
            for (SysUser userListByPageRecord : userListByPage.getRecords()) {
                for (SysUser sysUser : list) {
                    if (Objects.equals(sysUser.getUserId(), userListByPageRecord.getUserId())){
                        userListByPageRecord.setRoleId(sysUser.getRoleId());
                        userListByPageRecord.setRoleName(sysUser.getRoleName());
                    }
                }
            }
        }
        //返回数据
        return Result.ok(userListByPage);
    }

    /**
     * 添加用户
     * @param user
     * @return
     */
    @PostMapping("/add")
    public Result add(@RequestBody SysUser user) {
        //查询用户
        SysUser item = sysUserService.findUserByUserName(user.getUsername());
        //判断对象是否为空
        if (item != null) {
            return Result.error().message("该登录名称已被使用，请重新输入！");
        }
        //密码加密
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setUserId(MyLong.getRand());
        //创建用户是否为管理员
        user.setIsAdmin(user.getIsAdmin());
        //调用保存用户信息的方法
        if(sysUserService.save(user)){
            return Result.ok().message("用户添加成功");
        }
        return Result.error().message("用户添加失败");
    }

    /**
     * 修改用户
     *
     * @param user
     * @return
     */
    @PostMapping("/update")
    public Result update(@RequestBody SysUser user) {
        //查询用户
        SysUser item = sysUserService.findUserByUserName(user.getUsername());
        //判断对象是否为空,且查询到的用户ID不等于当前编辑的用户ID，表示该名称被占用
        if (!ObjectUtils.isEmpty(item) && !Objects.equals(item.getUserId(), user.getUserId())) {
            return Result.error().message("登录名称已被占用！");
        }
        //密码加密
        if (StrUtil.isNotBlank(user.getPassword())){
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        }
        //调用修改用户信息的方法
        if(sysUserService.updateById(user)){
            return Result.ok().message("用户修改成功");
        }
        return Result.error().message("用户修改失败");
    }

    /**
     * 删除用户
     * @param id
     * @return
     */
    @PostMapping("/delete")
    public Result delete(@RequestParam Long id) {
        //查询
        SysUser user = userMapper.selectById(id);
        if (user!=null){
            //调用删除用户信息的方法
            if(sysUserService.deleteById(id)){
                return Result.ok().message("用户删除成功");
            }
        }
        return Result.error().message("用户删除失败");
    }

    /**
     * 根据用户ID查询该用户拥有的角色列表
     * @param userId
     * @return
     */
    @PostMapping("/getRoleByUserId")
    public Result getRoleByUserId(@RequestParam Long userId){
        //调用根据用户ID查询该用户拥有的角色ID的方法
        List<Long> roleIds = roleService.findRoleIdByUserId(userId);
        return Result.ok(roleIds);
    }

    /**
     * 分配角色
     * @param userRoleDTO
     * @return
     */
    @PostMapping("/saveUserRole")
    public Result saveUserRole(@RequestBody UserRoleDTO userRoleDTO){
        if (sysUserService.saveUserRole(userRoleDTO.getUserId(), userRoleDTO.getRoleIds())) {
            return Result.ok().message("角色分配成功");
        }
        return Result.error().message("角色分配失败");
    }

    /**
     * 根据用户id查询用户信息
     * @param user
     * @return
     */
    @PostMapping("selgroup")
    public Result selgroup(@RequestBody SysUser user){
        List<SysUser> collect = sysUserService.list().stream()
                .filter(Objects::nonNull)
                .filter(s -> s.getUserId().equals(user.getUserId()))
                .collect(Collectors.toList());
        return Result.ok(collect).message("查询成功");
    }

    /**
     * 根据用户id查询考试信息
     * @param user
     * @return
     */
    @PostMapping("selectExamInfo")
    public Result selectExamInfo(@RequestBody SysUser user){
        return Result.ok(sysUserMapper.selectExamInfo(user.getUserId(),user.getPageStart(),user.getPageEnd())).message("查询成功");
    }

    /**
     * 根据用户id查询用户个人公告
     * @param user
     * @return
     */
    @PostMapping("examInfo")
    public Result examInfo(@RequestBody UserQueryVo user){
        //接收分页
        Page<ExamInfo> page = new Page<>(user.getPageNo(), user.getPageSize());
        //构造条件
        LambdaQueryWrapper<ExamInfo> queryWrapper = examInfoService.wrapper(user);
        //分页查询
        IPage<ExamInfo> pageList = examInfoService.page(page,queryWrapper);
        //存储信息
        List<ExamInfo> list = new ArrayList<>();
        //操作查询
        for (ExamInfo record : pageList.getRecords()) {
            //考试信息对象
            ExamInfo examInfo = new ExamInfo();
            //通过考试id查询参加考试人数
            long examNum = examInfoService.list().stream()
                    .filter(s -> s.getExamId().equals(record.getExamId()))
                    .filter(s->s.getIsTrue().equals("2"))
                    .map(ExamInfo::getUserId)
                    .count();
            System.out.println("examNum::"+examNum);
            examInfo.setExamNum(examNum);
            //本场考试总分
            double Examsum = examInfoService.list()
                    .stream()
                    .filter(s -> s.getExamId().equals(record.getExamId()))
                    .mapToDouble(ExamInfo::getScoreSum).sum();
            System.out.println("Examsum::"+Examsum);
            //本次考试平均分
            if (examNum!=0){
                double examAvg = Examsum / (double) examNum;

                System.out.println("examAvg::"+examAvg);

                examInfo.setExamAvg(examAvg);
            }else {
                examInfo.setExamAvg(0);
            }

            //查询本场考试排名信息
            List<ExamInfo> ranks = examInfoMapper.ranks(record.getExamId());
            System.out.println("ranks：："+ranks);
            List<Long> collect = ranks.stream()
                    .filter(item -> item.getUserId().equals(user.getUserId()))
                    .map(ExamInfo::getRank).collect(Collectors.toList());
            for (Long aLong : collect) {
                System.out.println("aLong::"+aLong);
                examInfo.setRank(aLong);
            }
            examInfo.setExamId(record.getExamId());
            list.add(examInfo);
            System.out.println(list+"======list");
        }
        //返回查询的相应数据
        for (ExamInfo listRecord : pageList.getRecords()) {
            for (ExamInfo info : list) {
                    if (info.getExamId().equals(listRecord.getExamId())){
                        listRecord.setExamNum(info.getExamNum());
                        listRecord.setExamAvg(info.getExamAvg());
                        listRecord.setRank(info.getRank());
                    }
            }
        }

        return Result.ok(pageList);
    }
}
