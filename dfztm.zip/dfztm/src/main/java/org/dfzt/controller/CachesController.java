package org.dfzt.controller;

import com.baomidou.mybatisplus.extension.api.ApiController;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.po.CollectWorkOrder;
import org.dfzt.mapper.AchievementsManagerMapper;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.service.CachesService;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author: 14259 zhangsheng 绩效详情页
 * @Date: 2023/6/1
 * @Version: 1.00
 */
@Slf4j
@RestController
@RequestMapping("/cache")
@CrossOrigin
@Component
public class CachesController extends ApiController {

    @Resource
    private CachesService cachesService;

    @RequestMapping("testRedis")
    @ResponseBody
    public String getOrgNameRedis(){
        String orgName = cachesService.getOrgNameRedis("154212102");
        System.out.println(orgName);
        return orgName;
    }

    @RequestMapping("testCacheOrgName")
    @ResponseBody
    public List<String> getOrgName(){
        List<String> businessPlace = cachesService.getBusinessPlace();
        System.out.println(businessPlace);
        return businessPlace;
    }

    @RequestMapping("testCacheConsName")
    @ResponseBody
    public String getConsName(){
        String consName = cachesService.getConsName("3447670746");
        System.out.println(consName);
        return consName;
    }

}
