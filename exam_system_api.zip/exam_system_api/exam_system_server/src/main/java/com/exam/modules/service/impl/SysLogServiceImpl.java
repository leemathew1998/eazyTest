package com.exam.modules.service.impl;

import com.exam.modules.entity.SysLog;
import com.exam.modules.entity.vo.LogVo;
import com.exam.modules.entity.vo.UserQueryVo;
import com.exam.modules.mapper.SysLogMapper;
import com.exam.modules.service.ISysLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * <p>
 * 登录日志 服务实现类
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Service
public class SysLogServiceImpl extends ServiceImpl<SysLogMapper, SysLog> implements ISysLogService {


    //登录失败日志信息
    @Override
    public List<LogVo> loglFailure() {
        return baseMapper.loglFailure();
    }
}
