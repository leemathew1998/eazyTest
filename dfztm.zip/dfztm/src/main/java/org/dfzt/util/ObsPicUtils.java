package org.dfzt.util;

import com.obs.services.ObsClient;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/22
 * @Version: 1.00 Obs上传图片工具类
 */
@Slf4j
@RestController
@RequestMapping("/file1")
@CrossOrigin
public class ObsPicUtils {


    @RequestMapping("/upload1")
    public String uploadFile(@RequestParam("file") MultipartFile file) throws Exception {
        if (file.isEmpty()) {
            System.out.printf("文件上传失败");
        }
        String fileName = file.getOriginalFilename(); // 得到上传的文件名
        File tem = new File("D:/"+fileName);
        file.transferTo(tem);
        System.out.println(tem);
        String endPoints = "https://obs.im-region-1.sgic.sgcc.com.cn";
        String ak = "FJKCAJIHHXNBTSWG0QN3";
        String sk = "D3Gtp3rz59WT9EpZ1RxBEDcvIjWrLcbXOzivv6gY";
        String bucketName = "tqgl-upload-product";
        log.info("*******************************");
        //创建ObsClient实例
        ObsClient obsClient = new ObsClient(ak, sk, endPoints);
        obsClient.putObject(bucketName, "obs-pv",tem);
        obsClient.close();
        return "Obs执行成功";
    }
}
