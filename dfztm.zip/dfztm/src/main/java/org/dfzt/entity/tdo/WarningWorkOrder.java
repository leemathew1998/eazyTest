package org.dfzt.entity.tdo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 待办、预警工单
 */
@Data
public class WarningWorkOrder {
    //站名称 人名称
    private String name;
    //计量采集工单
    private int meteringCollection;
    //线损治理工单
    private int lineLossManagement;
    //费控复电工单
    private int costControlRecovery;
    //电费工单
    private int electricityBill;
    //服务工单
    private int service;
    //运维抢修工单
    private int operationAndMaintenance;

}
