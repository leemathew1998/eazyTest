package org.dfzt.util;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/3/29
 * @Version: 1.00
 */
public class OrgNameUtil {
    public static String getOrgName(String orgNo){
        if(orgNo.equals("1542121")){
            return "河西供电服务中心";
        }else if (orgNo.equals("1542122")){
            return "河东供电服务中心";
        }else if (orgNo.equals("154212101")){
            return "兴华供电营业站";
        }else if (orgNo.equals("154212102")){
            return "木兰供电营业站";
        }else if (orgNo.equals("154212103")){
            return "西山供电营业站";
        }else if (orgNo.equals("154212104")){
            return "松山供电营业站";
        }else if (orgNo.equals("154212105")){
            return "友好供电营业站";
        }else if (orgNo.equals("154212201")){
            return "绿园供电营业站";
        }else if (orgNo.equals("154212203")){
            return "龙辰供电营业站";
        }else if (orgNo.equals("154212204")){
            return "园丁供电营业站";
        }else if (orgNo.equals("154212205")){
            return "哈克供电营业站";
        }else if (orgNo.equals("154212206")){
            return "光明供电营业站";
        }
        return orgNo;
    }
}
