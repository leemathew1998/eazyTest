package org.dfzt.mapper;

import org.dfzt.entity.dto.WorkOSumDto;
import org.dfzt.entity.po.WorkOrderSum;

import java.util.List;

public interface WorkOrderSumMapper {
    int deleteByPrimaryKey(String id);

    int insertSelective(WorkOrderSum record);

    WorkOrderSum selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(WorkOrderSum record);

    List<WorkOrderSum> selectWorkSumBymon1(String mon);//查询工单概述为待处理
    List<WorkOrderSum> selectWorkSumBymon2(String mon);//查询工单概述为处理中
    List<WorkOrderSum> selectWorkSumBymon3(String mon);//查询工单概述为已处理

    List<WorkOSumDto> selectAllStatus1();//查询所有工单中待处理的个数，统计概述
    List<WorkOSumDto> selectAllStatus2();//查询所有工单中处理中的个数，统计概述
    List<WorkOSumDto> selectAllStatus3();//查询所有工单中已处理的个数，统计概述

    WorkOrderSum selectTgNameexist(String tgName,String NowMonY);

    void updateStaonenum1(int Staone, String tgName);//对状态为待处理的加1
    void updateStaonenum2(int Staone, String tgName);//对状态为处理中的加1
    void updateStaonenum3(int Staone, String tgName);//对状态为已处理的加1



}