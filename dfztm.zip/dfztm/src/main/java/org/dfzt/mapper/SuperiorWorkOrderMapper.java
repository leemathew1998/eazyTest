package org.dfzt.mapper;

import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.vo.SuperiorSensitivity;
import org.dfzt.entity.vo.SuperiorWorkOrder;


/**
 * (SuperiorWorkOrder)表数据库访问层
 *
 * @author makejava
 * @since 2022-07-11 14:51:01
 */
public interface SuperiorWorkOrderMapper extends BaseMapper<SuperiorWorkOrder> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<SuperiorWorkOrder> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<SuperiorWorkOrder> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<SuperiorWorkOrder> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<SuperiorWorkOrder> entities);

    /**
     * 状态扭转
     * @param map
     * @return
     */
    int updateSuperiorWordOrder(org.dfzt.entity.po.SuperiorWorkOrder map);

    /**
     * 查询历史数据
     * @param workOrderNo
     * @return
     */
    org.dfzt.entity.vo.SuperiorWorkOrder selectSuperiorWordOrderNo(String workOrderNo);


    List<org.dfzt.entity.po.SuperiorWorkOrder> selectSupewoExcel(String ids);

    List<SuperiorWorkOrder> selectCountAll();


    //修改敏感用户状态
    Integer updateSen(String appNo,String whetherSensitivity);
    //查看敏感用户状态
    String selectSen(String workOrderNo);
    //修改敏感用户状态
    Integer updateexamineStatus(String appNo,String examineStatus);
    //查看敏感用户状态
    //String selectexamineStatus(String workorderId);

    //String selectLabelCause(String relationId);//根据用户id查询labelCause描述

    /**
     * 查询登录人员
     * @param loginName
     * @return
     */
    String selectRole(String loginName);//根据用户id差找所对应的权限

    SuperiorSensitivity selectByRid(String relationId);//查询描述中是否有该用户

    Integer updateLase(String relationId,String labelCause);//如果有则更新描述

    Integer insertSen(SuperiorSensitivity sSensitivity);//没有则新增字段并添加描述

    SuperiorWorkOrder selectByWorkO(String relationId);
    String selectLabelCause(String relationId);//根据用户id查询labelCause描述


    List<org.dfzt.entity.po.SuperiorWorkOrder> selectSuperiorList(@Param("s") org.dfzt.entity.po.SuperiorWorkOrder s,@Param("pageNo") Integer pageNo,@Param("pageSize") Integer pageSize,@Param("status") String status,@Param("orgName") String orgName);
}

