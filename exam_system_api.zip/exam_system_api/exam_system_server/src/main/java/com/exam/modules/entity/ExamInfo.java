package com.exam.modules.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * 考试信息(ExamInfo)表实体类
 *
 * @author dyy
 * @since 2022-11-09 15:05:39
 */
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.EXAM_INFO")
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExamInfo implements Serializable{
    //考试信息id
    @TableId(value = "EID",type = IdType.AUTO)
    private Long eid;
    //考生id
    @TableField("USER_ID")
    private Long userId;
    //试卷id
    @TableField("EXAM_PAPER_ID")
    private Long examPaperId;
    //试卷名称
    @TableField("EXAM_PAPER_NAME")
    private String examPaperName;
    //考试id
    @TableField("EXAM_ID")
    private Long examId;
    //考试名称
    @TableField("EXAM_NAME")
    private String examName;
    //考生姓名
    @TableField("USER_NAME")
    private String userName;
    //所属组别
    @TableField("THE_GROUP")
    private String theGroup;
    //出题人
    @TableField("THE_AUTHOR")
    private String theAuthor;
    //试卷总分
    @TableField("P_SUM")
    private String pSum;
    //成绩
    @TableField("SCORE_SUM")
    private Long scoreSum;
    //异常行为
    @TableField("ABNORMAL")
    private String abnormal;
    //阅卷状态(1.已阅卷 2.未完成 3.未阅卷)
    @TableField("MARK_STATUS")
    private String markStatus;
    //阅卷人
    @TableField("MARK_BY")
    private String markBy;
    //阅卷时间
    @TableField("MARK_TIME")
    private Date markTime;
    //考试时间
    @TableField("EXAM_TIME")
    private Date examTime;
    //是否参加考试（1-否,2-是）
    @TableField("IS_TRUE")
    private String isTrue;

    /*非此表字段*/
    @TableField(exist = false)
    private String tids;
    @TableField(exist = false)
    private String examLongTime;
    @TableField(exist = false)
    private String paperId;
    //考试人数
    @TableField(exist = false)
    private long ExamNum;
    //平均分
    @TableField(exist = false)
    private double examAvg;
    //排名
    @TableField(exist = false)
    private long rank;

    @TableField(exist = false)
    private Date examBeginTime;
    @TableField(exist = false)
    private Date examEndTime;
    @TableField(exist = false)
    private String examType;
    //应考人数
    @TableField(exist = false)
    private long sunNum;
    //实考人数
    @TableField(exist = false)
    private long perNum;
    //试卷难度
    @TableField(exist = false)
    private String diff;
}
