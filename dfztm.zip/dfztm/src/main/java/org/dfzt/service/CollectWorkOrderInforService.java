package org.dfzt.service;

import org.dfzt.entity.po.CollectWorkOrderInfor;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/6/7
 * @Version: 1.00
 */
public interface CollectWorkOrderInforService {
    int insertSelective(CollectWorkOrderInfor record);

    CollectWorkOrderInfor SelectVandP(String workOrderNo);//采集运维表中回显图片视频数据

    CollectWorkOrderInfor selectlineVandP(String workOrderNo);//线损表中回显图片视频数据（计量代用）
}
