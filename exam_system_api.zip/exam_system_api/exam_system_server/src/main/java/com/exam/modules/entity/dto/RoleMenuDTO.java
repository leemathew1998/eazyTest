package com.exam.modules.entity.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * @Author dyy
 * @Date 2022/11/4 11:04
 * @PackageName:com.exam.modules.entity.dto
 * @ClassName: RoleMenuDTO
 * @Description: TODO 用于给角色分配权限时保存 选中的权限数据
 * @Version 1.0
 */
@Data
public class RoleMenuDTO {
        private Long roleId;//角色编号
        private List<Long> list;//权限菜单ID集合
        private String createBy;//创建人
        private Date createTime;//创建时间
}
