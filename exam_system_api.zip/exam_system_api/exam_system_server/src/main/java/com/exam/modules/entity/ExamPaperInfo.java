package com.exam.modules.entity;



import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * (ExamPaperInfo)表实体类
 *
 * @author dyy
 * @since 2022-11-0715:32:47
 */
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.EXAM_PAPER_INFO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExamPaperInfo implements Serializable {
    //试卷id
    @TableId("EXAM_PAPER_ID")
    private Long examPaperId;
    //试卷名称
    @TableField("EXAM_PAPER_NAME")
    private String examPaperName;
    //创建人
    @TableField("CREATE_BY")
    private String createBy;
    //创建时间
    @TableField("CREATE_TIME")
    private Date createTime;
    //更新人
    @TableField("UPDATE_BY")
    private String updateBy;
    //更新时间
    @TableField("UPDATE_TIME")
    private Date updateTime;
    //知识分类（1.前端 2.后端 3.设计 4.测试）
    @TableField("KNOW_GORY")
    private String knowGory;
    //单选题数量
    @TableField("SINGLE_TNUM")
    private String singleTnum;
    //多选题数量
    @TableField("MORE_TNUM")
    private String moreTnum;
    //判断题数量
    @TableField("JUDGE_TNUM")
    private String judgeTnum;
    //简答题数量
    @TableField("ANS_TNUM")
    private String ansTnum;
    //编程题数量
    @TableField("PROGRAM_TNUM")
    private String programTnum;
    //题目id(逗号分割)
    @TableField("TIDS")
    private String tids;
    //总分
    @TableField("P_SUM")
    private String sum;
    //难度
    @TableField("DIFF")
    private String diff;
    //使用次数
    @TableField("USE_NUM")
    private String userNum;
}
