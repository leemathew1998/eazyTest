package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.AcManager;
import org.dfzt.entity.po.AcStation;
import org.dfzt.entity.vo.AcManagerSp;
import org.dfzt.entity.vo.AcStationSp;

import java.util.List;
import java.util.Map;

/**
 * (AcStation)表服务接口
 *
 * @author makejava
 * @since 2022-07-15 15:19:50
 */
public interface AcStationService extends IService<AcStation> {
    List<AcStation> selectAllStation(String ymd,String orgNo,String id);

    List<AcManager> selectByStation(String ymd,String orgNo,String id,String tgManager);//根据营业站id查询该营业站下所有台区信息

    List<AcStation> selectByCounty(Integer id);//根据旗县id查询该营业站下所有台区信息

    List<Map> selectFailure();

    List<AcManager> selectStationP(String acStationId);//通过营业站id查询该营业站下所有台区经理的信息

    int updateSnum(String AcStationId, int stanum);//根据营业站id修改营业站总失败条数

    AcStation selectOneStation(String acStationId);//根据营业站id查看修改后的所有指标和积分
    //int updatestaPR(String AcStationId, BigDecimal colSuccR, int colSuccP);//根据营业站id修改采集成功率指标和积分

    //List<Map> selectBusiness(int business);// 费控复电停电复电失败数


    Map<String,List<AcManagerSp>> selectpBySid(String id);//查询营业站近七天台区经理曲线

    Map<String,List<AcStationSp>> selectpByCid(String id);//查询旗县近七天营业站曲线


}

