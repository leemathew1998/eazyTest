package org.dfzt.controller;


import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.dfzt.entity.po.CMp;
import org.dfzt.service.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * (CMp)表控制层
 * 计量点档案
 *
 * @author makejava
 * @since 2022-07-29 14:51:16
 */
@RestController
@RequestMapping("cMp")
public class CMpController extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private CMpService cMpService;


    /**
     * 分页查询所有数据
     *
     * @param page 分页对象
     * @param cMp  查询实体
     * @return 所有数据
     */
    //pc
    @PostMapping("selectAll")
    public R selectAll(Page<CMp> page, CMp cMp) {
        System.out.println(cMp.getTlShareFlag());
        return success(this.cMpService.page(page, cMpService.queryWrapper(cMp)));
    }

    //app

    /**
     * 模糊查询
     *
     * @param page
     * @param str
     * @return
     */
    @PostMapping("selectWrapper")
    public R selectWrapper(Page<CMp> page, String str) {
        return success(this.cMpService.page(page, cMpService.wrapper(str)));
    }

    /**
     * 全局模糊搜索
     * 表1：CMpItRela
     * 表2：rCp
     * 表3：DMeter2
     *
     * @return 计算点对象
     */
    @PostMapping("selectLiSTByParam")
    public List<CMp> selectByLike(String str) {

        List<CMp> cMps = cMpService.selectListByMany(str);
        if(cMps==null){
            return null;
        }
        return cMps;
    }

    /**
     * 用户档案-查询计量多个对象
     *
     */
    @PostMapping("/selectCmpByUser")
    public R selectCmpByUser(Page<CMp> page, CMp cMp) {
        System.out.println(cMp.getTlShareFlag());
        return success(this.cMpService.page(page, cMpService.selectCmpByUser(cMp)));
    }

}
