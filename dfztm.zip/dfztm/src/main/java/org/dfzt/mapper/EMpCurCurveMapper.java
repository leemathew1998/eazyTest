package org.dfzt.mapper;

import org.dfzt.entity.po.EMpCurCurve;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dfzt
 * @since 2022-07-11
 */
public interface EMpCurCurveMapper extends BaseMapper<EMpCurCurve> {

}
