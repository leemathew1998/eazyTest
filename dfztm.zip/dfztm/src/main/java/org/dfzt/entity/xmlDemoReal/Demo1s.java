package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import lombok.Getter;
import lombok.Setter;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/28
 * @Version: 1.00
 */
@Getter
@Setter
@XStreamAlias("DBSET")
public class Demo1s {
    @XStreamAlias("RETURN_STATUS")
    private Demo2 demo2;

    @XStreamAlias("DATA_CONTENT")
    private Demo4 demo4;

    @Override
    public String toString() {
        return "Demo1{" +
                "demo2=" + demo2 +
                ", demo4=" + demo4 +
                '}';
    }
}
