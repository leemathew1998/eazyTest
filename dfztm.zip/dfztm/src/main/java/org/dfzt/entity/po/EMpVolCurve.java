package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Data;

/**
 * 
 * @TableName e_mp_vol_curve
 */
@TableName(value ="e_mp_vol_curve")
@Data
public class EMpVolCurve implements Serializable {
    /**
     * 标识
     */
    private Long id;

    /**
     * 供电单位
     */
    private String orgNo;

    /**
     * 数据日期
     */
    private Date dataDate;

    /**
     * pt变比
     */
    private Integer pt;

    /**
     * 标记
     */
    private Integer mark;

    /**
     * 0,功率总电流零序/功率因数总1.A相2，B相，C相
     */
    private Integer phaseFlag;

    /**
     * 1.96点，2.48点，3.24点
     */
    private Integer dataPointFlag;

    /**
     * 用96点个1或者0来表示96点数据的完整性标志
     */
    private String dataWholeFlag;

    /**
     * 电压
     */
    private BigDecimal u1;

    /**
     * 电压
     */
    private BigDecimal u2;

    /**
     * 电压
     */
    private BigDecimal u3;

    /**
     * 电压
     */
    private BigDecimal u4;

    /**
     * 电压
     */
    private BigDecimal u5;

    /**
     * 电压
     */
    private BigDecimal u6;

    /**
     * 电压
     */
    private BigDecimal u7;

    /**
     * 电压
     */
    private BigDecimal u8;

    /**
     * 电压
     */
    private BigDecimal u9;

    /**
     * 电压
     */
    private BigDecimal u10;

    /**
     * 电压
     */
    private BigDecimal u11;

    /**
     * 电压
     */
    private BigDecimal u12;

    /**
     * 电压
     */
    private BigDecimal u13;

    /**
     * 电压
     */
    private BigDecimal u14;

    /**
     * 电压
     */
    private BigDecimal u15;

    /**
     * 电压
     */
    private BigDecimal u16;

    /**
     * 电压
     */
    private BigDecimal u17;

    /**
     * 电压
     */
    private BigDecimal u18;

    /**
     * 电压
     */
    private BigDecimal u19;

    /**
     * 电压
     */
    private BigDecimal u20;

    /**
     * 电压
     */
    private BigDecimal u21;

    /**
     * 电压
     */
    private BigDecimal u22;

    /**
     * 电压
     */
    private BigDecimal u23;

    /**
     * 电压
     */
    private BigDecimal u24;

    /**
     * 电压
     */
    private BigDecimal u25;

    /**
     * 电压
     */
    private BigDecimal u26;

    /**
     * 电压
     */
    private BigDecimal u27;

    /**
     * 电压
     */
    private BigDecimal u28;

    /**
     * 电压
     */
    private BigDecimal u29;

    /**
     * 电压
     */
    private BigDecimal u30;

    /**
     * 电压
     */
    private BigDecimal u31;

    /**
     * 电压
     */
    private BigDecimal u32;

    /**
     * 电压
     */
    private BigDecimal u33;

    /**
     * 电压
     */
    private BigDecimal u34;

    /**
     * 电压
     */
    private BigDecimal u35;

    /**
     * 电压
     */
    private BigDecimal u36;

    /**
     * 电压
     */
    private BigDecimal u37;

    /**
     * 电压
     */
    private BigDecimal u38;

    /**
     * 电压
     */
    private BigDecimal u39;

    /**
     * 电压
     */
    private BigDecimal u40;

    /**
     * 电压
     */
    private BigDecimal u41;

    /**
     * 电压
     */
    private BigDecimal u42;

    /**
     * 电压
     */
    private BigDecimal u43;

    /**
     * 电压
     */
    private BigDecimal u44;

    /**
     * 电压
     */
    private BigDecimal u45;

    /**
     * 电压
     */
    private BigDecimal u46;

    /**
     * 电压
     */
    private BigDecimal u47;

    /**
     * 电压
     */
    private BigDecimal u48;

    /**
     * 电压
     */
    private BigDecimal u49;

    /**
     * 电压
     */
    private BigDecimal u50;

    /**
     * 电压
     */
    private BigDecimal u51;

    /**
     * 电压
     */
    private BigDecimal u52;

    /**
     * 电压
     */
    private BigDecimal u53;

    /**
     * 电压
     */
    private BigDecimal u54;

    /**
     * 电压
     */
    private BigDecimal u55;

    /**
     * 电压
     */
    private BigDecimal u56;

    /**
     * 电压
     */
    private BigDecimal u57;

    /**
     * 电压u
     */
    private BigDecimal u58;

    /**
     * 电压
     */
    private BigDecimal u59;

    /**
     * 电压
     */
    private BigDecimal u60;

    /**
     * 电压u
     */
    private BigDecimal u61;

    /**
     * 电压
     */
    private BigDecimal u62;

    /**
     * 电压
     */
    private BigDecimal u63;

    /**
     * 电压
     */
    private BigDecimal u64;

    /**
     * 电压
     */
    private BigDecimal u65;

    /**
     * 电压
     */
    private BigDecimal u66;

    /**
     * 电压
     */
    private BigDecimal u67;

    /**
     * 电压
     */
    private BigDecimal u68;

    /**
     * 电压
     */
    private BigDecimal u69;

    /**
     * 电压
     */
    private BigDecimal u70;

    /**
     * 电压
     */
    private BigDecimal u71;

    /**
     * 电压
     */
    private BigDecimal u72;

    /**
     * 电压
     */
    private BigDecimal u73;

    /**
     * 电压
     */
    private BigDecimal u74;

    /**
     * 电压
     */
    private BigDecimal u75;

    /**
     * 电压
     */
    private BigDecimal u76;

    /**
     * 电压
     */
    private BigDecimal u77;

    /**
     * 电压
     */
    private BigDecimal u78;

    /**
     * 电压
     */
    private BigDecimal u79;

    /**
     * 电压
     */
    private BigDecimal u80;

    /**
     * 电压
     */
    private BigDecimal u81;

    /**
     * 电压
     */
    private BigDecimal u82;

    /**
     * 电压
     */
    private BigDecimal u83;

    /**
     * 电压
     */
    private BigDecimal u84;

    /**
     * 电压
     */
    private BigDecimal u85;

    /**
     * 电压
     */
    private BigDecimal u86;

    /**
     * 电压
     */
    private BigDecimal u87;

    /**
     * 电压
     */
    private BigDecimal u88;

    /**
     * 电压
     */
    private BigDecimal u89;

    /**
     * 电压
     */
    private BigDecimal u90;

    /**
     * 电压
     */
    private BigDecimal u91;

    /**
     * 电压
     */
    private BigDecimal u92;

    /**
     * 电压
     */
    private BigDecimal u93;

    /**
     * 电压
     */
    private BigDecimal u94;

    /**
     * 电压
     */
    private BigDecimal u95;

    /**
     * 电压
     */
    private BigDecimal u96;

    /**
     * 记录时间
     */
    private Date recTime;

    /**
     * 电表标识
     */
    private String meterId;

    /**
     * 数据来源
     */
    private String dataSrc;

    /**
     * 是否有效
     */
    private Integer isValid;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        EMpVolCurve other = (EMpVolCurve) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getOrgNo() == null ? other.getOrgNo() == null : this.getOrgNo().equals(other.getOrgNo()))
            && (this.getDataDate() == null ? other.getDataDate() == null : this.getDataDate().equals(other.getDataDate()))
            && (this.getPt() == null ? other.getPt() == null : this.getPt().equals(other.getPt()))
            && (this.getMark() == null ? other.getMark() == null : this.getMark().equals(other.getMark()))
            && (this.getPhaseFlag() == null ? other.getPhaseFlag() == null : this.getPhaseFlag().equals(other.getPhaseFlag()))
            && (this.getDataPointFlag() == null ? other.getDataPointFlag() == null : this.getDataPointFlag().equals(other.getDataPointFlag()))
            && (this.getDataWholeFlag() == null ? other.getDataWholeFlag() == null : this.getDataWholeFlag().equals(other.getDataWholeFlag()))
            && (this.getU1() == null ? other.getU1() == null : this.getU1().equals(other.getU1()))
            && (this.getU2() == null ? other.getU2() == null : this.getU2().equals(other.getU2()))
            && (this.getU3() == null ? other.getU3() == null : this.getU3().equals(other.getU3()))
            && (this.getU4() == null ? other.getU4() == null : this.getU4().equals(other.getU4()))
            && (this.getU5() == null ? other.getU5() == null : this.getU5().equals(other.getU5()))
            && (this.getU6() == null ? other.getU6() == null : this.getU6().equals(other.getU6()))
            && (this.getU7() == null ? other.getU7() == null : this.getU7().equals(other.getU7()))
            && (this.getU8() == null ? other.getU8() == null : this.getU8().equals(other.getU8()))
            && (this.getU9() == null ? other.getU9() == null : this.getU9().equals(other.getU9()))
            && (this.getU10() == null ? other.getU10() == null : this.getU10().equals(other.getU10()))
            && (this.getU11() == null ? other.getU11() == null : this.getU11().equals(other.getU11()))
            && (this.getU12() == null ? other.getU12() == null : this.getU12().equals(other.getU12()))
            && (this.getU13() == null ? other.getU13() == null : this.getU13().equals(other.getU13()))
            && (this.getU14() == null ? other.getU14() == null : this.getU14().equals(other.getU14()))
            && (this.getU15() == null ? other.getU15() == null : this.getU15().equals(other.getU15()))
            && (this.getU16() == null ? other.getU16() == null : this.getU16().equals(other.getU16()))
            && (this.getU17() == null ? other.getU17() == null : this.getU17().equals(other.getU17()))
            && (this.getU18() == null ? other.getU18() == null : this.getU18().equals(other.getU18()))
            && (this.getU19() == null ? other.getU19() == null : this.getU19().equals(other.getU19()))
            && (this.getU20() == null ? other.getU20() == null : this.getU20().equals(other.getU20()))
            && (this.getU21() == null ? other.getU21() == null : this.getU21().equals(other.getU21()))
            && (this.getU22() == null ? other.getU22() == null : this.getU22().equals(other.getU22()))
            && (this.getU23() == null ? other.getU23() == null : this.getU23().equals(other.getU23()))
            && (this.getU24() == null ? other.getU24() == null : this.getU24().equals(other.getU24()))
            && (this.getU25() == null ? other.getU25() == null : this.getU25().equals(other.getU25()))
            && (this.getU26() == null ? other.getU26() == null : this.getU26().equals(other.getU26()))
            && (this.getU27() == null ? other.getU27() == null : this.getU27().equals(other.getU27()))
            && (this.getU28() == null ? other.getU28() == null : this.getU28().equals(other.getU28()))
            && (this.getU29() == null ? other.getU29() == null : this.getU29().equals(other.getU29()))
            && (this.getU30() == null ? other.getU30() == null : this.getU30().equals(other.getU30()))
            && (this.getU31() == null ? other.getU31() == null : this.getU31().equals(other.getU31()))
            && (this.getU32() == null ? other.getU32() == null : this.getU32().equals(other.getU32()))
            && (this.getU33() == null ? other.getU33() == null : this.getU33().equals(other.getU33()))
            && (this.getU34() == null ? other.getU34() == null : this.getU34().equals(other.getU34()))
            && (this.getU35() == null ? other.getU35() == null : this.getU35().equals(other.getU35()))
            && (this.getU36() == null ? other.getU36() == null : this.getU36().equals(other.getU36()))
            && (this.getU37() == null ? other.getU37() == null : this.getU37().equals(other.getU37()))
            && (this.getU38() == null ? other.getU38() == null : this.getU38().equals(other.getU38()))
            && (this.getU39() == null ? other.getU39() == null : this.getU39().equals(other.getU39()))
            && (this.getU40() == null ? other.getU40() == null : this.getU40().equals(other.getU40()))
            && (this.getU41() == null ? other.getU41() == null : this.getU41().equals(other.getU41()))
            && (this.getU42() == null ? other.getU42() == null : this.getU42().equals(other.getU42()))
            && (this.getU43() == null ? other.getU43() == null : this.getU43().equals(other.getU43()))
            && (this.getU44() == null ? other.getU44() == null : this.getU44().equals(other.getU44()))
            && (this.getU45() == null ? other.getU45() == null : this.getU45().equals(other.getU45()))
            && (this.getU46() == null ? other.getU46() == null : this.getU46().equals(other.getU46()))
            && (this.getU47() == null ? other.getU47() == null : this.getU47().equals(other.getU47()))
            && (this.getU48() == null ? other.getU48() == null : this.getU48().equals(other.getU48()))
            && (this.getU49() == null ? other.getU49() == null : this.getU49().equals(other.getU49()))
            && (this.getU50() == null ? other.getU50() == null : this.getU50().equals(other.getU50()))
            && (this.getU51() == null ? other.getU51() == null : this.getU51().equals(other.getU51()))
            && (this.getU52() == null ? other.getU52() == null : this.getU52().equals(other.getU52()))
            && (this.getU53() == null ? other.getU53() == null : this.getU53().equals(other.getU53()))
            && (this.getU54() == null ? other.getU54() == null : this.getU54().equals(other.getU54()))
            && (this.getU55() == null ? other.getU55() == null : this.getU55().equals(other.getU55()))
            && (this.getU56() == null ? other.getU56() == null : this.getU56().equals(other.getU56()))
            && (this.getU57() == null ? other.getU57() == null : this.getU57().equals(other.getU57()))
            && (this.getU58() == null ? other.getU58() == null : this.getU58().equals(other.getU58()))
            && (this.getU59() == null ? other.getU59() == null : this.getU59().equals(other.getU59()))
            && (this.getU60() == null ? other.getU60() == null : this.getU60().equals(other.getU60()))
            && (this.getU61() == null ? other.getU61() == null : this.getU61().equals(other.getU61()))
            && (this.getU62() == null ? other.getU62() == null : this.getU62().equals(other.getU62()))
            && (this.getU63() == null ? other.getU63() == null : this.getU63().equals(other.getU63()))
            && (this.getU64() == null ? other.getU64() == null : this.getU64().equals(other.getU64()))
            && (this.getU65() == null ? other.getU65() == null : this.getU65().equals(other.getU65()))
            && (this.getU66() == null ? other.getU66() == null : this.getU66().equals(other.getU66()))
            && (this.getU67() == null ? other.getU67() == null : this.getU67().equals(other.getU67()))
            && (this.getU68() == null ? other.getU68() == null : this.getU68().equals(other.getU68()))
            && (this.getU69() == null ? other.getU69() == null : this.getU69().equals(other.getU69()))
            && (this.getU70() == null ? other.getU70() == null : this.getU70().equals(other.getU70()))
            && (this.getU71() == null ? other.getU71() == null : this.getU71().equals(other.getU71()))
            && (this.getU72() == null ? other.getU72() == null : this.getU72().equals(other.getU72()))
            && (this.getU73() == null ? other.getU73() == null : this.getU73().equals(other.getU73()))
            && (this.getU74() == null ? other.getU74() == null : this.getU74().equals(other.getU74()))
            && (this.getU75() == null ? other.getU75() == null : this.getU75().equals(other.getU75()))
            && (this.getU76() == null ? other.getU76() == null : this.getU76().equals(other.getU76()))
            && (this.getU77() == null ? other.getU77() == null : this.getU77().equals(other.getU77()))
            && (this.getU78() == null ? other.getU78() == null : this.getU78().equals(other.getU78()))
            && (this.getU79() == null ? other.getU79() == null : this.getU79().equals(other.getU79()))
            && (this.getU80() == null ? other.getU80() == null : this.getU80().equals(other.getU80()))
            && (this.getU81() == null ? other.getU81() == null : this.getU81().equals(other.getU81()))
            && (this.getU82() == null ? other.getU82() == null : this.getU82().equals(other.getU82()))
            && (this.getU83() == null ? other.getU83() == null : this.getU83().equals(other.getU83()))
            && (this.getU84() == null ? other.getU84() == null : this.getU84().equals(other.getU84()))
            && (this.getU85() == null ? other.getU85() == null : this.getU85().equals(other.getU85()))
            && (this.getU86() == null ? other.getU86() == null : this.getU86().equals(other.getU86()))
            && (this.getU87() == null ? other.getU87() == null : this.getU87().equals(other.getU87()))
            && (this.getU88() == null ? other.getU88() == null : this.getU88().equals(other.getU88()))
            && (this.getU89() == null ? other.getU89() == null : this.getU89().equals(other.getU89()))
            && (this.getU90() == null ? other.getU90() == null : this.getU90().equals(other.getU90()))
            && (this.getU91() == null ? other.getU91() == null : this.getU91().equals(other.getU91()))
            && (this.getU92() == null ? other.getU92() == null : this.getU92().equals(other.getU92()))
            && (this.getU93() == null ? other.getU93() == null : this.getU93().equals(other.getU93()))
            && (this.getU94() == null ? other.getU94() == null : this.getU94().equals(other.getU94()))
            && (this.getU95() == null ? other.getU95() == null : this.getU95().equals(other.getU95()))
            && (this.getU96() == null ? other.getU96() == null : this.getU96().equals(other.getU96()))
            && (this.getRecTime() == null ? other.getRecTime() == null : this.getRecTime().equals(other.getRecTime()))
            && (this.getMeterId() == null ? other.getMeterId() == null : this.getMeterId().equals(other.getMeterId()))
            && (this.getDataSrc() == null ? other.getDataSrc() == null : this.getDataSrc().equals(other.getDataSrc()))
            && (this.getIsValid() == null ? other.getIsValid() == null : this.getIsValid().equals(other.getIsValid()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getOrgNo() == null) ? 0 : getOrgNo().hashCode());
        result = prime * result + ((getDataDate() == null) ? 0 : getDataDate().hashCode());
        result = prime * result + ((getPt() == null) ? 0 : getPt().hashCode());
        result = prime * result + ((getMark() == null) ? 0 : getMark().hashCode());
        result = prime * result + ((getPhaseFlag() == null) ? 0 : getPhaseFlag().hashCode());
        result = prime * result + ((getDataPointFlag() == null) ? 0 : getDataPointFlag().hashCode());
        result = prime * result + ((getDataWholeFlag() == null) ? 0 : getDataWholeFlag().hashCode());
        result = prime * result + ((getU1() == null) ? 0 : getU1().hashCode());
        result = prime * result + ((getU2() == null) ? 0 : getU2().hashCode());
        result = prime * result + ((getU3() == null) ? 0 : getU3().hashCode());
        result = prime * result + ((getU4() == null) ? 0 : getU4().hashCode());
        result = prime * result + ((getU5() == null) ? 0 : getU5().hashCode());
        result = prime * result + ((getU6() == null) ? 0 : getU6().hashCode());
        result = prime * result + ((getU7() == null) ? 0 : getU7().hashCode());
        result = prime * result + ((getU8() == null) ? 0 : getU8().hashCode());
        result = prime * result + ((getU9() == null) ? 0 : getU9().hashCode());
        result = prime * result + ((getU10() == null) ? 0 : getU10().hashCode());
        result = prime * result + ((getU11() == null) ? 0 : getU11().hashCode());
        result = prime * result + ((getU12() == null) ? 0 : getU12().hashCode());
        result = prime * result + ((getU13() == null) ? 0 : getU13().hashCode());
        result = prime * result + ((getU14() == null) ? 0 : getU14().hashCode());
        result = prime * result + ((getU15() == null) ? 0 : getU15().hashCode());
        result = prime * result + ((getU16() == null) ? 0 : getU16().hashCode());
        result = prime * result + ((getU17() == null) ? 0 : getU17().hashCode());
        result = prime * result + ((getU18() == null) ? 0 : getU18().hashCode());
        result = prime * result + ((getU19() == null) ? 0 : getU19().hashCode());
        result = prime * result + ((getU20() == null) ? 0 : getU20().hashCode());
        result = prime * result + ((getU21() == null) ? 0 : getU21().hashCode());
        result = prime * result + ((getU22() == null) ? 0 : getU22().hashCode());
        result = prime * result + ((getU23() == null) ? 0 : getU23().hashCode());
        result = prime * result + ((getU24() == null) ? 0 : getU24().hashCode());
        result = prime * result + ((getU25() == null) ? 0 : getU25().hashCode());
        result = prime * result + ((getU26() == null) ? 0 : getU26().hashCode());
        result = prime * result + ((getU27() == null) ? 0 : getU27().hashCode());
        result = prime * result + ((getU28() == null) ? 0 : getU28().hashCode());
        result = prime * result + ((getU29() == null) ? 0 : getU29().hashCode());
        result = prime * result + ((getU30() == null) ? 0 : getU30().hashCode());
        result = prime * result + ((getU31() == null) ? 0 : getU31().hashCode());
        result = prime * result + ((getU32() == null) ? 0 : getU32().hashCode());
        result = prime * result + ((getU33() == null) ? 0 : getU33().hashCode());
        result = prime * result + ((getU34() == null) ? 0 : getU34().hashCode());
        result = prime * result + ((getU35() == null) ? 0 : getU35().hashCode());
        result = prime * result + ((getU36() == null) ? 0 : getU36().hashCode());
        result = prime * result + ((getU37() == null) ? 0 : getU37().hashCode());
        result = prime * result + ((getU38() == null) ? 0 : getU38().hashCode());
        result = prime * result + ((getU39() == null) ? 0 : getU39().hashCode());
        result = prime * result + ((getU40() == null) ? 0 : getU40().hashCode());
        result = prime * result + ((getU41() == null) ? 0 : getU41().hashCode());
        result = prime * result + ((getU42() == null) ? 0 : getU42().hashCode());
        result = prime * result + ((getU43() == null) ? 0 : getU43().hashCode());
        result = prime * result + ((getU44() == null) ? 0 : getU44().hashCode());
        result = prime * result + ((getU45() == null) ? 0 : getU45().hashCode());
        result = prime * result + ((getU46() == null) ? 0 : getU46().hashCode());
        result = prime * result + ((getU47() == null) ? 0 : getU47().hashCode());
        result = prime * result + ((getU48() == null) ? 0 : getU48().hashCode());
        result = prime * result + ((getU49() == null) ? 0 : getU49().hashCode());
        result = prime * result + ((getU50() == null) ? 0 : getU50().hashCode());
        result = prime * result + ((getU51() == null) ? 0 : getU51().hashCode());
        result = prime * result + ((getU52() == null) ? 0 : getU52().hashCode());
        result = prime * result + ((getU53() == null) ? 0 : getU53().hashCode());
        result = prime * result + ((getU54() == null) ? 0 : getU54().hashCode());
        result = prime * result + ((getU55() == null) ? 0 : getU55().hashCode());
        result = prime * result + ((getU56() == null) ? 0 : getU56().hashCode());
        result = prime * result + ((getU57() == null) ? 0 : getU57().hashCode());
        result = prime * result + ((getU58() == null) ? 0 : getU58().hashCode());
        result = prime * result + ((getU59() == null) ? 0 : getU59().hashCode());
        result = prime * result + ((getU60() == null) ? 0 : getU60().hashCode());
        result = prime * result + ((getU61() == null) ? 0 : getU61().hashCode());
        result = prime * result + ((getU62() == null) ? 0 : getU62().hashCode());
        result = prime * result + ((getU63() == null) ? 0 : getU63().hashCode());
        result = prime * result + ((getU64() == null) ? 0 : getU64().hashCode());
        result = prime * result + ((getU65() == null) ? 0 : getU65().hashCode());
        result = prime * result + ((getU66() == null) ? 0 : getU66().hashCode());
        result = prime * result + ((getU67() == null) ? 0 : getU67().hashCode());
        result = prime * result + ((getU68() == null) ? 0 : getU68().hashCode());
        result = prime * result + ((getU69() == null) ? 0 : getU69().hashCode());
        result = prime * result + ((getU70() == null) ? 0 : getU70().hashCode());
        result = prime * result + ((getU71() == null) ? 0 : getU71().hashCode());
        result = prime * result + ((getU72() == null) ? 0 : getU72().hashCode());
        result = prime * result + ((getU73() == null) ? 0 : getU73().hashCode());
        result = prime * result + ((getU74() == null) ? 0 : getU74().hashCode());
        result = prime * result + ((getU75() == null) ? 0 : getU75().hashCode());
        result = prime * result + ((getU76() == null) ? 0 : getU76().hashCode());
        result = prime * result + ((getU77() == null) ? 0 : getU77().hashCode());
        result = prime * result + ((getU78() == null) ? 0 : getU78().hashCode());
        result = prime * result + ((getU79() == null) ? 0 : getU79().hashCode());
        result = prime * result + ((getU80() == null) ? 0 : getU80().hashCode());
        result = prime * result + ((getU81() == null) ? 0 : getU81().hashCode());
        result = prime * result + ((getU82() == null) ? 0 : getU82().hashCode());
        result = prime * result + ((getU83() == null) ? 0 : getU83().hashCode());
        result = prime * result + ((getU84() == null) ? 0 : getU84().hashCode());
        result = prime * result + ((getU85() == null) ? 0 : getU85().hashCode());
        result = prime * result + ((getU86() == null) ? 0 : getU86().hashCode());
        result = prime * result + ((getU87() == null) ? 0 : getU87().hashCode());
        result = prime * result + ((getU88() == null) ? 0 : getU88().hashCode());
        result = prime * result + ((getU89() == null) ? 0 : getU89().hashCode());
        result = prime * result + ((getU90() == null) ? 0 : getU90().hashCode());
        result = prime * result + ((getU91() == null) ? 0 : getU91().hashCode());
        result = prime * result + ((getU92() == null) ? 0 : getU92().hashCode());
        result = prime * result + ((getU93() == null) ? 0 : getU93().hashCode());
        result = prime * result + ((getU94() == null) ? 0 : getU94().hashCode());
        result = prime * result + ((getU95() == null) ? 0 : getU95().hashCode());
        result = prime * result + ((getU96() == null) ? 0 : getU96().hashCode());
        result = prime * result + ((getRecTime() == null) ? 0 : getRecTime().hashCode());
        result = prime * result + ((getMeterId() == null) ? 0 : getMeterId().hashCode());
        result = prime * result + ((getDataSrc() == null) ? 0 : getDataSrc().hashCode());
        result = prime * result + ((getIsValid() == null) ? 0 : getIsValid().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", orgNo=").append(orgNo);
        sb.append(", dataDate=").append(dataDate);
        sb.append(", pt=").append(pt);
        sb.append(", mark=").append(mark);
        sb.append(", phaseFlag=").append(phaseFlag);
        sb.append(", dataPointFlag=").append(dataPointFlag);
        sb.append(", dataWholeFlag=").append(dataWholeFlag);
        sb.append(", u1=").append(u1);
        sb.append(", u2=").append(u2);
        sb.append(", u3=").append(u3);
        sb.append(", u4=").append(u4);
        sb.append(", u5=").append(u5);
        sb.append(", u6=").append(u6);
        sb.append(", u7=").append(u7);
        sb.append(", u8=").append(u8);
        sb.append(", u9=").append(u9);
        sb.append(", u10=").append(u10);
        sb.append(", u11=").append(u11);
        sb.append(", u12=").append(u12);
        sb.append(", u13=").append(u13);
        sb.append(", u14=").append(u14);
        sb.append(", u15=").append(u15);
        sb.append(", u16=").append(u16);
        sb.append(", u17=").append(u17);
        sb.append(", u18=").append(u18);
        sb.append(", u19=").append(u19);
        sb.append(", u20=").append(u20);
        sb.append(", u21=").append(u21);
        sb.append(", u22=").append(u22);
        sb.append(", u23=").append(u23);
        sb.append(", u24=").append(u24);
        sb.append(", u25=").append(u25);
        sb.append(", u26=").append(u26);
        sb.append(", u27=").append(u27);
        sb.append(", u28=").append(u28);
        sb.append(", u29=").append(u29);
        sb.append(", u30=").append(u30);
        sb.append(", u31=").append(u31);
        sb.append(", u32=").append(u32);
        sb.append(", u33=").append(u33);
        sb.append(", u34=").append(u34);
        sb.append(", u35=").append(u35);
        sb.append(", u36=").append(u36);
        sb.append(", u37=").append(u37);
        sb.append(", u38=").append(u38);
        sb.append(", u39=").append(u39);
        sb.append(", u40=").append(u40);
        sb.append(", u41=").append(u41);
        sb.append(", u42=").append(u42);
        sb.append(", u43=").append(u43);
        sb.append(", u44=").append(u44);
        sb.append(", u45=").append(u45);
        sb.append(", u46=").append(u46);
        sb.append(", u47=").append(u47);
        sb.append(", u48=").append(u48);
        sb.append(", u49=").append(u49);
        sb.append(", u50=").append(u50);
        sb.append(", u51=").append(u51);
        sb.append(", u52=").append(u52);
        sb.append(", u53=").append(u53);
        sb.append(", u54=").append(u54);
        sb.append(", u55=").append(u55);
        sb.append(", u56=").append(u56);
        sb.append(", u57=").append(u57);
        sb.append(", u58=").append(u58);
        sb.append(", u59=").append(u59);
        sb.append(", u60=").append(u60);
        sb.append(", u61=").append(u61);
        sb.append(", u62=").append(u62);
        sb.append(", u63=").append(u63);
        sb.append(", u64=").append(u64);
        sb.append(", u65=").append(u65);
        sb.append(", u66=").append(u66);
        sb.append(", u67=").append(u67);
        sb.append(", u68=").append(u68);
        sb.append(", u69=").append(u69);
        sb.append(", u70=").append(u70);
        sb.append(", u71=").append(u71);
        sb.append(", u72=").append(u72);
        sb.append(", u73=").append(u73);
        sb.append(", u74=").append(u74);
        sb.append(", u75=").append(u75);
        sb.append(", u76=").append(u76);
        sb.append(", u77=").append(u77);
        sb.append(", u78=").append(u78);
        sb.append(", u79=").append(u79);
        sb.append(", u80=").append(u80);
        sb.append(", u81=").append(u81);
        sb.append(", u82=").append(u82);
        sb.append(", u83=").append(u83);
        sb.append(", u84=").append(u84);
        sb.append(", u85=").append(u85);
        sb.append(", u86=").append(u86);
        sb.append(", u87=").append(u87);
        sb.append(", u88=").append(u88);
        sb.append(", u89=").append(u89);
        sb.append(", u90=").append(u90);
        sb.append(", u91=").append(u91);
        sb.append(", u92=").append(u92);
        sb.append(", u93=").append(u93);
        sb.append(", u94=").append(u94);
        sb.append(", u95=").append(u95);
        sb.append(", u96=").append(u96);
        sb.append(", recTime=").append(recTime);
        sb.append(", meterId=").append(meterId);
        sb.append(", dataSrc=").append(dataSrc);
        sb.append(", isValid=").append(isValid);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}