package com.exam.modules.entity;

import java.math.BigDecimal;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;
import java.time.LocalDateTime;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Date;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 用户角色关联表
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.SYS_USER_ROLE")
public class SysUserRole implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 用户角色关联表id
     */
    @TableId("USER_ROLE_ID")
    private Long userRoleId;

    /**
     * 用户id

     */
    @TableField("USER_ID")
    private Long userId;

    /**
     * 角色id

     */
    @TableField("ROLE_ID")
    private Long roleId;

    /**
     * 创建人

     */
    @TableField("CREATE_BY")
    private String createBy;

    /**
     * 创建时间

     */
    @TableField("CREATE_TIME")
    private Date createTime;

    /**
     * 更新人

     */
    @TableField("UPDATE_BY")
    private String updateBy;

    /**
     * 更新时间

     */
    @TableField("UPDATE_TIME")
    private Date updateTime;


}
