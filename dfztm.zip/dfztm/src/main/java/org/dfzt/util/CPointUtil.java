package org.dfzt.util;

import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.po.MeterCurrent;
import org.dfzt.entity.po.MeterCurrentVoltage;

import java.math.BigDecimal;

@Slf4j
public class CPointUtil {
    public static int CPoint(MeterCurrentVoltage meterCurrentVoltage , BigDecimal ds, MeterCurrent metc){
        //额定电压70%
        BigDecimal multiply = meterCurrentVoltage.getVoltage().multiply(ds);
        //判断96点电流值是否为0
        boolean a = metc.getI1().compareTo(BigDecimal.ZERO) == 0;
        boolean a1 = metc.getI2().compareTo(BigDecimal.ZERO) == 0;
        boolean a2 = metc.getI3().compareTo(BigDecimal.ZERO) == 0;
        boolean a3 = metc.getI4().compareTo(BigDecimal.ZERO) == 0;
        boolean b = metc.getI5().compareTo(BigDecimal.ZERO) == 0;
        boolean b1 = metc.getI6().compareTo(BigDecimal.ZERO) == 0;
        boolean b2 = metc.getI7().compareTo(BigDecimal.ZERO) == 0;
        boolean b3 = metc.getI8().compareTo(BigDecimal.ZERO) == 0;
        boolean c = metc.getI9().compareTo(BigDecimal.ZERO) == 0;
        boolean c1 = metc.getI10().compareTo(BigDecimal.ZERO) == 0;
        boolean c2 = metc.getI11().compareTo(BigDecimal.ZERO) == 0;
        boolean c3 = metc.getI12().compareTo(BigDecimal.ZERO) == 0;
        boolean d = metc.getI13().compareTo(BigDecimal.ZERO) == 0;
        boolean d1 = metc.getI14().compareTo(BigDecimal.ZERO) == 0;
        boolean d2 = metc.getI15().compareTo(BigDecimal.ZERO) == 0;
        boolean d3 = metc.getI16().compareTo(BigDecimal.ZERO) == 0;
        boolean e = metc.getI17().compareTo(BigDecimal.ZERO) == 0;
        boolean e1 = metc.getI18().compareTo(BigDecimal.ZERO) == 0;
        boolean e2 = metc.getI19().compareTo(BigDecimal.ZERO) == 0;
        boolean e3 = metc.getI20().compareTo(BigDecimal.ZERO) == 0;
        boolean f = metc.getI21().compareTo(BigDecimal.ZERO) == 0;
        boolean f1 = metc.getI22().compareTo(BigDecimal.ZERO) == 0;
        boolean f2 = metc.getI23().compareTo(BigDecimal.ZERO) == 0;
        boolean f3 = metc.getI24().compareTo(BigDecimal.ZERO) == 0;
        boolean g = metc.getI25().compareTo(BigDecimal.ZERO) == 0;
        boolean g1 = metc.getI26().compareTo(BigDecimal.ZERO) == 0;
        boolean g2 = metc.getI27().compareTo(BigDecimal.ZERO) == 0;
        boolean g3 = metc.getI28().compareTo(BigDecimal.ZERO) == 0;
        boolean h = metc.getI29().compareTo(BigDecimal.ZERO) == 0;
        boolean h1 = metc.getI30().compareTo(BigDecimal.ZERO) == 0;
        boolean h2 = metc.getI31().compareTo(BigDecimal.ZERO) == 0;
        boolean h3 = metc.getI32().compareTo(BigDecimal.ZERO) == 0;
        boolean i = metc.getI33().compareTo(BigDecimal.ZERO) == 0;
        boolean i1 = metc.getI34().compareTo(BigDecimal.ZERO) == 0;
        boolean i2 = metc.getI35().compareTo(BigDecimal.ZERO) == 0;
        boolean i3 = metc.getI36().compareTo(BigDecimal.ZERO) == 0;
        boolean j = metc.getI37().compareTo(BigDecimal.ZERO) == 0;
        boolean j1 = metc.getI38().compareTo(BigDecimal.ZERO) == 0;
        boolean j2 = metc.getI39().compareTo(BigDecimal.ZERO) == 0;
        boolean j3 = metc.getI40().compareTo(BigDecimal.ZERO) == 0;
        boolean k = metc.getI41().compareTo(BigDecimal.ZERO) == 0;
        boolean k1 = metc.getI42().compareTo(BigDecimal.ZERO) == 0;
        boolean k2 = metc.getI43().compareTo(BigDecimal.ZERO) == 0;
        boolean k3 = metc.getI44().compareTo(BigDecimal.ZERO) == 0;
        boolean l = metc.getI45().compareTo(BigDecimal.ZERO) == 0;
        boolean l1 = metc.getI46().compareTo(BigDecimal.ZERO) == 0;
        boolean l2 = metc.getI47().compareTo(BigDecimal.ZERO) == 0;
        boolean l3 = metc.getI48().compareTo(BigDecimal.ZERO) == 0;
        boolean m = metc.getI49().compareTo(BigDecimal.ZERO) == 0;
        boolean m1 = metc.getI50().compareTo(BigDecimal.ZERO) == 0;
        boolean m2 = metc.getI51().compareTo(BigDecimal.ZERO) == 0;
        boolean m3 = metc.getI52().compareTo(BigDecimal.ZERO) == 0;
        boolean n = metc.getI53().compareTo(BigDecimal.ZERO) == 0;
        boolean n1 = metc.getI54().compareTo(BigDecimal.ZERO) == 0;
        boolean n2 = metc.getI55().compareTo(BigDecimal.ZERO) == 0;
        boolean n3 = metc.getI56().compareTo(BigDecimal.ZERO) == 0;
        boolean o = metc.getI57().compareTo(BigDecimal.ZERO) == 0;
        boolean o1 = metc.getI58().compareTo(BigDecimal.ZERO) == 0;
        boolean o2 = metc.getI59().compareTo(BigDecimal.ZERO) == 0;
        boolean o3 = metc.getI60().compareTo(BigDecimal.ZERO) == 0;
        boolean p = metc.getI61().compareTo(BigDecimal.ZERO) == 0;
        boolean p1 = metc.getI62().compareTo(BigDecimal.ZERO) == 0;
        boolean p2 = metc.getI63().compareTo(BigDecimal.ZERO) == 0;
        boolean p3 = metc.getI64().compareTo(BigDecimal.ZERO) == 0;
        boolean q = metc.getI65().compareTo(BigDecimal.ZERO) == 0;
        boolean q1 = metc.getI66().compareTo(BigDecimal.ZERO) == 0;
        boolean q2 = metc.getI67().compareTo(BigDecimal.ZERO) == 0;
        boolean q3 = metc.getI68().compareTo(BigDecimal.ZERO) == 0;
        boolean r = metc.getI69().compareTo(BigDecimal.ZERO) == 0;
        boolean r1 = metc.getI70().compareTo(BigDecimal.ZERO) == 0;
        boolean r2 = metc.getI71().compareTo(BigDecimal.ZERO) == 0;
        boolean r3 = metc.getI72().compareTo(BigDecimal.ZERO) == 0;
        boolean s = metc.getI73().compareTo(BigDecimal.ZERO) == 0;
        boolean s1 = metc.getI74().compareTo(BigDecimal.ZERO) == 0;
        boolean s2 = metc.getI75().compareTo(BigDecimal.ZERO) == 0;
        boolean s3 = metc.getI76().compareTo(BigDecimal.ZERO) == 0;
        boolean t = metc.getI77().compareTo(BigDecimal.ZERO) == 0;
        boolean t1 = metc.getI78().compareTo(BigDecimal.ZERO) == 0;
        boolean t2 = metc.getI79().compareTo(BigDecimal.ZERO) == 0;
        boolean t3 = metc.getI80().compareTo(BigDecimal.ZERO) == 0;
        boolean u = metc.getI81().compareTo(BigDecimal.ZERO) == 0;
        boolean u1 = metc.getI82().compareTo(BigDecimal.ZERO) == 0;
        boolean u2 = metc.getI83().compareTo(BigDecimal.ZERO) == 0;
        boolean u3 = metc.getI84().compareTo(BigDecimal.ZERO) == 0;
        boolean v = metc.getI85().compareTo(BigDecimal.ZERO) == 0;
        boolean v1 = metc.getI86().compareTo(BigDecimal.ZERO) == 0;
        boolean v2 = metc.getI87().compareTo(BigDecimal.ZERO) == 0;
        boolean v3 = metc.getI88().compareTo(BigDecimal.ZERO) == 0;
        boolean w = metc.getI89().compareTo(BigDecimal.ZERO) == 0;
        boolean w1 = metc.getI90().compareTo(BigDecimal.ZERO) == 0;
        boolean w2 = metc.getI91().compareTo(BigDecimal.ZERO) == 0;
        boolean w3 = metc.getI92().compareTo(BigDecimal.ZERO) == 0;
        boolean x = metc.getI93().compareTo(BigDecimal.ZERO) == 0;
        boolean x1 = metc.getI94().compareTo(BigDecimal.ZERO) == 0;
        boolean x2 = metc.getI95().compareTo(BigDecimal.ZERO) == 0;
        boolean x3 = metc.getI96().compareTo(BigDecimal.ZERO) == 0;
        //电压小于额定电压70% ，并电流不为0
        if ((meterCurrentVoltage.getV1().compareTo(multiply) == -1) && a==false){
            return 1;
        }else if (meterCurrentVoltage.getV2().compareTo(multiply) == -1 && a1==false){
            return 1;
        }else if (meterCurrentVoltage.getV3().compareTo(multiply) == -1 && a2==false){
            return 1;
        }else if (meterCurrentVoltage.getV4().compareTo(multiply) == -1 && a3==false){
            return 1;
        }else if (meterCurrentVoltage.getV5().compareTo(multiply) == -1 && b==false){
            return 1;
        }else if (meterCurrentVoltage.getV6().compareTo(multiply) == -1 && b1==false){
            return 1;
        }else if (meterCurrentVoltage.getV7().compareTo(multiply) == -1 && b2==false){
            return 1;
        }else if (meterCurrentVoltage.getV8().compareTo(multiply) == -1 && b3==false){
            return 1;
        }else if (meterCurrentVoltage.getV9().compareTo(multiply) == -1 && c==false){
            return 1;
        }else if (meterCurrentVoltage.getV10().compareTo(multiply) == -1 && c1==false){
            return 1;
        }else if (meterCurrentVoltage.getV11().compareTo(multiply) == -1 && c2==false){
            return 1;
        }else if (meterCurrentVoltage.getV12().compareTo(multiply) == -1 && c3==false){
            return 1;
        }else if (meterCurrentVoltage.getV13().compareTo(multiply) == -1 && d==false){
            return 1;
        }else if (meterCurrentVoltage.getV14().compareTo(multiply) == -1 && d1==false){
            return 1;
        }else if (meterCurrentVoltage.getV15().compareTo(multiply) == -1 && d2==false){
            return 1;
        }else if (meterCurrentVoltage.getV16().compareTo(multiply) == -1 && d3==false){
            return 1;
        }else if (meterCurrentVoltage.getV17().compareTo(multiply) == -1 && e==false){
            return 1;
        }else if (meterCurrentVoltage.getV18().compareTo(multiply) == -1 && e1==false){
            return 1;
        }else if (meterCurrentVoltage.getV19().compareTo(multiply) == -1 && e2==false){
            return 1;
        }else if (meterCurrentVoltage.getV20().compareTo(multiply) == -1 && e3==false){
            return 1;
        }else if (meterCurrentVoltage.getV21().compareTo(multiply) == -1 && f==false){
            return 1;
        }else if (meterCurrentVoltage.getV22().compareTo(multiply) == -1 && f1==false){
            return 1;
        }else if (meterCurrentVoltage.getV23().compareTo(multiply) == -1 && f2==false){
            return 1;
        }else if (meterCurrentVoltage.getV24().compareTo(multiply) == -1 && f3==false){
            return 1;
        }else if (meterCurrentVoltage.getV25().compareTo(multiply) == -1 && g==false){
            return 1;
        }else if (meterCurrentVoltage.getV26().compareTo(multiply) == -1 && g1==false){
            return 1;
        }else if (meterCurrentVoltage.getV27().compareTo(multiply) == -1 && g2==false){
            return 1;
        }else if (meterCurrentVoltage.getV28().compareTo(multiply) == -1 && g3==false){
            return 1;
        }else if (meterCurrentVoltage.getV29().compareTo(multiply) == -1 && h==false){
            return 1;
        }else if (meterCurrentVoltage.getV30().compareTo(multiply) == -1 && h1==false){
            return 1;
        }else if (meterCurrentVoltage.getV31().compareTo(multiply) == -1 && h2==false){
            return 1;
        }else if (meterCurrentVoltage.getV32().compareTo(multiply) == -1 && h3==false){
            return 1;
        }else if (meterCurrentVoltage.getV33().compareTo(multiply) == -1 && i==false){
            return 1;
        }else if (meterCurrentVoltage.getV34().compareTo(multiply) == -1 && i1==false){
            return 1;
        }else if (meterCurrentVoltage.getV35().compareTo(multiply) == -1 && i2==false){
            return 1;
        }else if (meterCurrentVoltage.getV36().compareTo(multiply) == -1 && i3==false){
            return 1;
        }else if (meterCurrentVoltage.getV37().compareTo(multiply) == -1 && j==false){
            return 1;
        }else if (meterCurrentVoltage.getV38().compareTo(multiply) == -1 && j1==false){
            return 1;
        }else if (meterCurrentVoltage.getV39().compareTo(multiply) == -1 && j2==false){
            return 1;
        }else if (meterCurrentVoltage.getV40().compareTo(multiply) == -1 && j3==false){
            return 1;
        }else if (meterCurrentVoltage.getV41().compareTo(multiply) == -1 && k==false){
            return 1;
        }else if (meterCurrentVoltage.getV42().compareTo(multiply) == -1 && k1==false){
            return 1;
        }else if (meterCurrentVoltage.getV43().compareTo(multiply) == -1 && k2==false){
            return 1;
        }else if (meterCurrentVoltage.getV44().compareTo(multiply) == -1 && k3==false){
            return 1;
        }else if (meterCurrentVoltage.getV45().compareTo(multiply) == -1 && l==false){
            return 1;
        }else if (meterCurrentVoltage.getV46().compareTo(multiply) == -1 && l1==false){
            return 1;
        }else if (meterCurrentVoltage.getV47().compareTo(multiply) == -1 && l2==false){
            return 1;
        }else if (meterCurrentVoltage.getV48().compareTo(multiply) == -1 && l3==false){
            return 1;
        }else if (meterCurrentVoltage.getV49().compareTo(multiply) == -1 && m==false){
            return 1;
        }else if (meterCurrentVoltage.getV50().compareTo(multiply) == -1 && m1==false){
            return 1;
        }else if (meterCurrentVoltage.getV51().compareTo(multiply) == -1 && m2==false){
            return 1;
        }else if (meterCurrentVoltage.getV52().compareTo(multiply) == -1 && m3==false){
            return 1;
        }else if (meterCurrentVoltage.getV53().compareTo(multiply) == -1 && n==false){
            return 1;
        }else if (meterCurrentVoltage.getV54().compareTo(multiply) == -1 && n1==false){
            return 1;
        }else if (meterCurrentVoltage.getV55().compareTo(multiply) == -1 && n2==false){
            return 1;
        }else if (meterCurrentVoltage.getV56().compareTo(multiply) == -1 && n3==false){
            return 1;
        }else if (meterCurrentVoltage.getV57().compareTo(multiply) == -1 && o==false){
            return 1;
        }else if (meterCurrentVoltage.getV58().compareTo(multiply) == -1 && o1==false){
            return 1;
        }else if (meterCurrentVoltage.getV59().compareTo(multiply) == -1 && o2==false){
            return 1;
        }else if (meterCurrentVoltage.getV60().compareTo(multiply) == -1 && o3==false){
            return 1;
        }else if (meterCurrentVoltage.getV61().compareTo(multiply) == -1 && p==false){
            return 1;
        }else if (meterCurrentVoltage.getV62().compareTo(multiply) == -1 && p1==false){
            return 1;
        }else if (meterCurrentVoltage.getV63().compareTo(multiply) == -1 && p2==false){
            return 1;
        }else if (meterCurrentVoltage.getV64().compareTo(multiply) == -1 && p3==false){
            return 1;
        }else if (meterCurrentVoltage.getV65().compareTo(multiply) == -1 && q==false){
            return 1;
        }else if (meterCurrentVoltage.getV66().compareTo(multiply) == -1 && q1==false){
            return 1;
        }else if (meterCurrentVoltage.getV67().compareTo(multiply) == -1 && q2==false){
            return 1;
        }else if (meterCurrentVoltage.getV68().compareTo(multiply) == -1 && q3==false){
            return 1;
        }else if (meterCurrentVoltage.getV69().compareTo(multiply) == -1 && r==false){
            return 1;
        }else if (meterCurrentVoltage.getV70().compareTo(multiply) == -1 && r1==false){
            return 1;
        }else if (meterCurrentVoltage.getV71().compareTo(multiply) == -1 && r2==false){
            return 1;
        }else if (meterCurrentVoltage.getV72().compareTo(multiply) == -1 && r3==false){
            return 1;
        }else if (meterCurrentVoltage.getV73().compareTo(multiply) == -1 && s==false){
            return 1;
        }else if (meterCurrentVoltage.getV74().compareTo(multiply) == -1 && s1==false){
            return 1;
        }else if (meterCurrentVoltage.getV75().compareTo(multiply) == -1 && s2==false){
            return 1;
        }else if (meterCurrentVoltage.getV76().compareTo(multiply) == -1 && s3==false){
            return 1;
        }else if (meterCurrentVoltage.getV77().compareTo(multiply) == -1 && t==false){
            return 1;
        }else if (meterCurrentVoltage.getV78().compareTo(multiply) == -1 && t1==false){
            return 1;
        }else if (meterCurrentVoltage.getV79().compareTo(multiply) == -1 && t2==false){
            return 1;
        }else if (meterCurrentVoltage.getV80().compareTo(multiply) == -1 && t3==false){
            return 1;
        }else if (meterCurrentVoltage.getV81().compareTo(multiply) == -1 && u==false){
            return 1;
        }else if (meterCurrentVoltage.getV82().compareTo(multiply) == -1 && u1==false){
            return 1;
        }else if (meterCurrentVoltage.getV83().compareTo(multiply) == -1 && u2==false){
            return 1;
        }else if (meterCurrentVoltage.getV84().compareTo(multiply) == -1 && u3==false){
            return 1;
        }else if (meterCurrentVoltage.getV85().compareTo(multiply) == -1 && v==false){
            return 1;
        }else if (meterCurrentVoltage.getV86().compareTo(multiply) == -1 && v1==false){
            return 1;
        }else if (meterCurrentVoltage.getV87().compareTo(multiply) == -1 && v2==false){
            return 1;
        }else if (meterCurrentVoltage.getV88().compareTo(multiply) == -1 && v3==false){
            return 1;
        }else if (meterCurrentVoltage.getV89().compareTo(multiply) == -1 && w==false){
            return 1;
        }else if (meterCurrentVoltage.getV90().compareTo(multiply) == -1 && w1==false){
            return 1;
        }else if (meterCurrentVoltage.getV91().compareTo(multiply) == -1 && w2==false){
            return 1;
        }else if (meterCurrentVoltage.getV92().compareTo(multiply) == -1 && w3==false){
            return 1;
        }else if (meterCurrentVoltage.getV93().compareTo(multiply) == -1 && x==false){
            return 1;
        }else if (meterCurrentVoltage.getV94().compareTo(multiply) == -1 && x1==false){
            return 1;
        }else if (meterCurrentVoltage.getV95().compareTo(multiply) == -1 && x2==false){
            return 1;
        }else if (meterCurrentVoltage.getV96().compareTo(multiply) == -1 &&x3==false){
            return 1;
        }
        return 0;
    }
}
