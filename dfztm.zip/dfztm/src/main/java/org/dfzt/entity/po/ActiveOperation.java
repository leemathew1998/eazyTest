package org.dfzt.entity.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.dfzt.eunm.WorkOrderStatusEnum;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "ActiveOperation对象", description = "")
public class ActiveOperation implements Serializable {

    @ApiModelProperty(value = "主动运维id(主动运维工单表)")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;


    @TableField("work_order_no")
    @Excel(name = "工单编号",orderNum = "1",width = 20)
    private String workOrderNo;

    @TableField("work_order_date")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @Excel(name = "工单日期",orderNum = "2",width = 20,format = "yyyy-MM-dd HH:mm:ss")
    private Date workOrderDate;

    @TableField("work_order_status")
   // @Excel(name = "工单状态",orderNum = "3",width = 20)
    private WorkOrderStatusEnum workOrderStatus;
    //ActiveOperationEunm

    @TableField("user_name")
    @Excel(name = "用户名称",orderNum = "3",width = 20)
    private String userName;

    @TableField("tg_manager")
    @Excel(name = "台区经理",orderNum = "4",width = 20)
    private String tgManager;

    @TableField("tg_no")
    @Excel(name = "台区编号",orderNum = "5",width = 20)
    private String tgNo;

    @TableField("tg_name")
    @Excel(name = "台区名称",orderNum = "6",width = 20)
    private String tgName;

    @TableField("excp_type")
    @Excel(name = "异常分类",orderNum = "7",width = 20)
    private String excpType;

    @TableField("excp_add")
    @Excel(name = "异常地点",orderNum = "8",width = 20)
    private String excpAdd;

    @TableField("excp_date")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @Excel(name = "异常时间",orderNum = "9",width = 20,format = "yyyy-MM-dd HH:mm:ss")
    private String excpDate;

    @TableField("analysis_result")
    @Excel(name = "研判分析结果",orderNum = "10",width = 20)
    private String analysisResult;

    @ApiModelProperty(value = "工单流转时间")
    @TableField("wander_time")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date wanderTime;

    @ApiModelProperty(value = "误报工单表述")
    private String reserve1;

    @ApiModelProperty(value = "工单周期")
    private String workOrderCycle;

    @ApiModelProperty(value = "备用字段3")
    private String reserve3;

    @ApiModelProperty(value = "备用字段4")
    private Integer reserve4;

    //是否有敏感工单用户
    private String appType;
    //工单处理时间
    private Integer handleTime;



    //图片
    @TableField(exist = false)
    private String photo;

    //下面三个图片整和在同一行
    @TableField(exist = false)
    @Excel(name = "图片1",orderNum = "11",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoOne;

    @TableField(exist = false)
    @Excel(name = "图片2",orderNum = "12",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoTwo;

    @TableField(exist = false)
    @Excel(name = "图片3",orderNum = "13",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoThree;
    /*@TableField(exist = false)
    @Excel(name = "处理后照片",orderNum = "11",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoOne;

    @TableField(exist = false)
    @Excel(name = "工作票照片",orderNum = "12",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoTwo;

    @TableField(exist = false)
    @Excel(name = "监控班许可照片",orderNum = "13",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoThree;

    @TableField(exist = false)
    @Excel(name = "安全措施照片",orderNum = "14",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoFour;

    @TableField(exist = false)
    @Excel(name = "到岗到位许可检查安全措施是否完备照片并同意开工照片",orderNum = "15",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoFive;

    @TableField(exist = false)
    @Excel(name = "缺陷缺陷处理后照片",orderNum = "16",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoSix;

    @TableField(exist = false)
    @Excel(name = "安全措施拆除照片",orderNum = "17",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String photoSeven;
*/

//    private List<RepairsWorkOrder> repairsWorkOrder;
//    private RepairsWorkOrder repairsWorkOrder;

    //工单状态 枚举
    /*public void setWorkOrderStatus(String workOrderStatus) {
        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
    }*/


}
