package com.exam.modules.mapper;

import com.exam.modules.entity.SysRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Select;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 角色表 Mapper 接口
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface SysRoleMapper extends BaseMapper<SysRole> {
    /**
     * 查询角色数量
     * @param id
     * @return
     */
    @Select("SELECT COUNT(1) FROM EXAM.SYS_USER_ROLE WHERE ROLE_ID = #{roleId}")
    int getRoleCountByRoleId(Long id);
    //删除角色权限关系
    @Delete("DELETE FROM EXAM.SYS_ROLE_MENU WHERE ROLE_ID = #{id}")
    void deleteRoleMenuByRoleId(Long id);

    /**
     * 保存角色权限关系
     * @param roleId
     * @param menuIds
     * @return
     */
    int saveRoleMenu(Long roleId, List<Long> menuIds);

    /**
     * 根据用户ID查询该用户拥有的角色ID
     * @param userId
     * @return
     */
    @Select("SELECT ROLE_ID FROM EXAM.SYS_USER_ROLE WHERE USER_ID = #{userId}")
    List<Long> findRoleIdByUserId(Long userId);
}
