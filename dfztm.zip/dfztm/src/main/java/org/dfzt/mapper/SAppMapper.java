package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.dfzt.entity.po.SApp;

/**
* @author 李木
* @description 针对表【s_app】的数据库操作Mapper
* @createDate 2023-05-29 10:15:10
* @Entity org.afzt.entity.po.SApp
*/
@DS("mpg")
@Mapper
public interface SAppMapper extends BaseMapper<SApp> {

}




