package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @ClassName General
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/14 20:56
 */
@Data
@XStreamAlias("C")
@NoArgsConstructor
@AllArgsConstructor
//@XStreamAlias("MaxBenefitDurPeriod")
//@XStreamConverter(value = ToAttributedValueConverter.class, strings = { "value" })
public class General {
    //// 将name作为Cat属性输出在父节点
//    @XStreamAsAttribute()
    private String N;
    private String value;

}
