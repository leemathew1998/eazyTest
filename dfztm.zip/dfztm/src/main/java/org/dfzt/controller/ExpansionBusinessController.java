package org.dfzt.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.dfzt.entity.po.NetmuWorkOrder;
import org.dfzt.entity.po.PicmaWorkOrder;
import org.dfzt.service.NetmuWorkOrderService;
import org.dfzt.service.PicmaWorkOrderService;
import org.dfzt.service.SAppService;
import org.quartz.SchedulerException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("expansionBusiness")
public class ExpansionBusinessController {

    @Autowired
    private NetmuWorkOrderService netmuWorkOrderService;

    @Autowired
    private PicmaWorkOrderService picmaWorkOrderService;

    @Autowired
    private SAppService appService;


    @PostMapping("selectNetmuWorkOrder")
    public R<Page<NetmuWorkOrder>> selectNetmuWorkOrder(@RequestBody NetmuWorkOrder workOrderVO) {
        LambdaQueryWrapper<NetmuWorkOrder> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(ObjectUtils.isNotEmpty(workOrderVO.getConsName()), NetmuWorkOrder::getConsName, workOrderVO.getConsName())
                .like(ObjectUtils.isNotEmpty(workOrderVO.getAppNo()), NetmuWorkOrder::getAppNo, workOrderVO.getAppNo())
                .like(ObjectUtils.isNotEmpty(workOrderVO.getConsNo()), NetmuWorkOrder::getConsNo, workOrderVO.getConsNo())
                .eq(ObjectUtils.isNotEmpty(workOrderVO.getWorkOrderStatus()), NetmuWorkOrder::getWorkOrderStatus, workOrderVO.getWorkOrderStatus());
        if (!"04".equals(workOrderVO.getWorkOrderStatus())) {
            queryWrapper.ne(NetmuWorkOrder::getWorkOrderStatus, "04");
        }
        Page<NetmuWorkOrder> page = netmuWorkOrderService.page(new Page<>(workOrderVO.getPageNo(), workOrderVO.getPageSize()), queryWrapper);
        List<NetmuWorkOrder> records = page.getRecords();
        for (NetmuWorkOrder record : records) {
            parseContactInfo(record);
        }
        return R.ok(page);
    }

    @PostMapping("selectNetmuWorkOrderDetail")
    public R<NetmuWorkOrder> selectNetmuWorkOrderDetail(@RequestBody NetmuWorkOrder netmuWorkOrder) {
        Integer id = netmuWorkOrder.getId();
        if ("01".equals(netmuWorkOrder.getWorkOrderStatus())) {
            netmuWorkOrder.setWorkOrderStatus("02");
            netmuWorkOrder.setCountStatus("1");
        }
        parseContactInfo(netmuWorkOrder);
        netmuWorkOrderService.updateById(netmuWorkOrder);
        NetmuWorkOrder order = netmuWorkOrderService.getById(id);
        return R.ok(order);
    }

    @PostMapping("submmitNetmuWorkOrder")
    public R<?> submmitNetmuWorkOrder(@RequestBody NetmuWorkOrder netmuWorkOrder) {
        netmuWorkOrder.setWorkOrderStatus("03");
        return R.ok(netmuWorkOrderService.updateNetmuWorkOrder(netmuWorkOrder) != 0);
    }

    @PostMapping("selectPicmaWorkOrder")
    public R<?> selectPicmaWorkOrder(@RequestBody PicmaWorkOrder workOrderVO) {
        LambdaQueryWrapper<PicmaWorkOrder> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.like(ObjectUtils.isNotEmpty(workOrderVO.getConsName()), PicmaWorkOrder::getConsName, workOrderVO.getConsName())
                .like(ObjectUtils.isNotEmpty(workOrderVO.getAppNo()), PicmaWorkOrder::getAppNo, workOrderVO.getAppNo())
                .like(ObjectUtils.isNotEmpty(workOrderVO.getConsNo()), PicmaWorkOrder::getConsNo, workOrderVO.getConsNo());
        Page<PicmaWorkOrder> page = picmaWorkOrderService.page(new Page<>(workOrderVO.getPageNo(), workOrderVO.getPageSize()), queryWrapper);
        return R.ok(page);
    }

    @PostMapping("selectPicmaWorkOrderDetail")
    public R<PicmaWorkOrder> selectPicmaWorkOrderDetail(@RequestBody PicmaWorkOrder picmaWorkOrder) {
        Integer id = picmaWorkOrder.getId();
        if ("01".equals(picmaWorkOrder.getWorkOrderStatus())) {
            picmaWorkOrder.setWorkOrderStatus("02");
        }
        picmaWorkOrderService.updateById(picmaWorkOrder);
        PicmaWorkOrder order = picmaWorkOrderService.getById(id);
        return R.ok(order);
    }

    private void parseContactInfo(NetmuWorkOrder record) {
        String contactName = record.getContactName();
        if (ObjectUtils.isNotEmpty(contactName)) {
            String[] split = contactName.split(",");
            List<String> contactNames = Arrays.asList(split);
            record.setContactNames(contactNames);
        }
        String contactMode = record.getContactMode();
        if (ObjectUtils.isNotEmpty(contactMode)) {
            String[] split = contactMode.split(",");
            List<String> contactModes = Arrays.asList(split);
            record.setContactModes(contactModes);
        }
        String mobile = record.getMobile();
        if (ObjectUtils.isNotEmpty(mobile)) {
            String[] split = mobile.split(",");
            List<String> mobiles = Arrays.asList(split);
            record.setMobiles(mobiles);
        }
    }


    //系统每15分钟（暂定）从S_APP表中获取申请业务类型（APP_TYPE_CODE）为销户或批量销户的数据以及新换装标识为新装的数据
    @GetMapping("insertUserRepairOrder")
    public void insertUserRepairOrder() {
        appService.insertUserRepairOrder();
    }

    //每15分钟将待归档的工单编号和营销系统中的表进行校验，判断是否完成，完成则同步已归档。
    @GetMapping("updateUserRepairOrder")
    public void updateUserRepairOrder() {
        appService.updateUserRepairOrder();
    }

    //每15分钟从S_APP表获取申请方式（APP_MODE）为政务WEB端且申请业务类型（APP_TYPE_CODE）为过户的数据
    @GetMapping("insertPicmaWorkOrder")
    public void insertPicmaWorkOrder() {
        appService.insertPicmaWorkOrder();
    }
}
