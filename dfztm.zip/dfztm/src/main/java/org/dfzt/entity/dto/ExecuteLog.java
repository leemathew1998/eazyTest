package org.dfzt.entity.dto;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/19
 * @Version: 1.00
 * 实时透抄实体类
 */
@Data
public class ExecuteLog {

    @TableId(value = "id",type = IdType.AUTO)
    private String id;
    private String thread;
    private String address;
    private String code;
    private String parentCode;
private String object;
private String object1;
private String object2;
    private DateTime serviceBegin;
    private DateTime serviceEnd;

    private DateTime computerBegin;
    private DateTime computerEnd;
    private DateTime qytBegin;
    private DateTime qytEnd;

    private BigInteger userCount;
}
