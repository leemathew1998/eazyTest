package org.dfzt.mapper;

import org.dfzt.entity.po.WorkOrderInfor;
import org.springframework.stereotype.Repository;

import java.util.Map;

@Repository
public interface WorkOrderInforMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(WorkOrderInfor record);

    int insertSelective(WorkOrderInfor record);

    WorkOrderInfor selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(WorkOrderInfor record);

    int updateByPrimaryKeyWithBLOBs(WorkOrderInfor record);

    int updateByPrimaryKey(WorkOrderInfor record);

    WorkOrderInfor SelectVandP(String workOrderNo);//采集运维表中回显图片视频数据 根据工单编号

    /**
     * 添加图片视频数据(费控复电)
     * @param workOrderInfor
     * @return
     */
    int insertWorkOrderInforMapper(WorkOrderInfor workOrderInfor);



}
