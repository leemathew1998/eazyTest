package com.exam.modules.entity.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Author dyy
 * @Date 2022/10/31 17:48
 * @PackageName:com.exam.modules.entity.vo
 * @ClassName: TokenVo
 * @Description: TODO 保存token信息
 * @Version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TokenVo {
    //过期时间
    private Long expireTime;
    //token
    private String token;
}
