package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import nonapi.io.github.classgraph.json.Id;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/14
 * @Version: 1.00
 */
@ApiModel(value="c_acct")
@Data
@TableName(value = "c_acct")
public class CAcct {

    /**
     * 账户标识
     */
    @TableId(value = "acct_id", type = IdType.INPUT)
    @ApiModelProperty(value="账户标识")
    private Long acctId;

    /**
     * 缴费账户名称
     */
    @TableField(value = "cust_acct_name")
    @ApiModelProperty(value="缴费账户名称")
    private String custAcctName;

    /**
     * 集团户标识
     */
    @TableField(value = "croup_tag")
    @ApiModelProperty(value="集团户标识")
    private String croupTag;

    /**
     * 客户标识
     */
    @TableField(value = "cust_id")
    @ApiModelProperty(value="客户标识")
    private Long custId;

    /**
     * (缴费方式)引用国家电网公司营销管理代码类集：5110.105收费方式与代码。包括01电力机构、0101坐收、0102走收、0103自助缴费终端、02金融机构、0201代收、0202特约委托、0203代扣、0204自助缴费终端、03非金融机构、0301代收、0302充值卡、0303自主缴费终端
     */
    @TableField(value = "pay_mode")
    @ApiModelProperty(value="(缴费方式)引用国家电网公司营销管理代码类集：5110.105收费方式与代码。包括01电力机构、0101坐收、0102走收、0103自助缴费终端、02金融机构、0201代收、0202特约委托、0203代扣、0204自助缴费终端、03非金融机构、0301代收、0302充值卡、0303自主缴费终端")
    private String payMode;

    /**
     * 多方协议号
     */
    @TableField(value = "more_agreement_no")
    @ApiModelProperty(value="多方协议号")
    private String moreAgreementNo;

    /**
     * 缴费标识
     */
    @TableField(value = "pay_no")
    @ApiModelProperty(value="缴费标识")
    private String payNo;

    /**
     * 主用户号
     */
    @TableField(value = "main_cons_no")
    @ApiModelProperty(value="主用户号")
    private String mainConsNo;
}