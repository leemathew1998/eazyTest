package org.dfzt.controller;


import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.annotation.CurrentUser;
import org.dfzt.entity.dto.ExecuteLog;
import org.dfzt.entity.po.ARcvblFlow;
import org.dfzt.entity.po.CCons;
import org.dfzt.entity.po.GTg;
import org.dfzt.entity.po.RecycleMobile;
import org.dfzt.entity.vo.RecycleWorkOrder;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.mapper.*;
import org.dfzt.response.ResultCode;
import org.dfzt.service.RecycleWorkOrderService;
import org.dfzt.util.DateUtil;
import org.dfzt.util.ExcelUtils;
import org.dfzt.util.TimeUtil;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * (RecycleWorkOrder)表控制层
 *
 * @author makejava
 * @since 2022-07-11 15:38:15
 */
@Slf4j
@RestController
@RequestMapping("recycleWorkOrder")
public class RecycleWorkOrderController extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private RecycleWorkOrderService recycleWorkOrderService;

    @Resource
    private RecycleWorkOrderMapper recycleWorkOrderMapper;

    @Resource
    private FeecontrolWorkOrderMapper feecontrolWorkOrderMapper;
    @Resource
    private ARcvblFlowMapper aRcvblFlowMapper;
    @Resource
    private CollectWorkOrderMapper collectWorkOrderMapper;
    @Resource
    ExecuteLogMapper executeLogMapper;

    /**
     * 级别
     */
    private final static String ONE_GRADE = "1";
    private final static String TWO_GRADE = "2";

    /**
     * 工单状态
     */
    private final static String ONE_STATUS = "1";
    private final static String TWO_STATUS = "2";
    private final static String THREE_STATUS = "3";
    private final static String FOUR_STATUS = "4";

    /**
     * 电费回收工单生成及工单预警
     * @return
     */
    //每月一号从营销系统中获取电费回收数据
    @RequestMapping("getArcvbl1")
    @Async
//    @Scheduled(cron = "0 0 1/6 1-10 * ?")
    public String getArcvbl(){
        Integer i = 0;
        Integer j = 0;
        String startMon1 = TimeUtil.getStartMon1();
        System.out.println("TimeUtil.getStartMon1()==="+startMon1);
//        ExecuteLog executeLog = new ExecuteLog();
//        executeLog.setServiceBegin(cn.hutool.core.date.DateUtil.date());
//        executeLogMapper.insert(executeLog);

        List<String> lists = collectWorkOrderMapper.selectOrgList1();
//        executeLog.setServiceEnd(cn.hutool.core.date.DateUtil.date());
//        System.out.println("dianfeihuishou1:"+lists.toString());
//        executeLog.setObject(lists.toString());
//        executeLogMapper.updateById(executeLog);
        for (String list : lists) {
            List<ARcvblFlow> aRcvblFlows = aRcvblFlowMapper.selectARcvbl1(TimeUtil.getStartMon1(),list);
            j = recycleWorkOrderService.selectArcByYM(startMon1,aRcvblFlows);
        }

        //List<ARcvblFlow> aRcvblFlows = aRcvblFlowMapper.selectARcvbl(TimeUtil.getStartMon1(),lists);

//        System.out.println("dianfeihuishou2:"+aRcvblFlows.toString());
//        executeLog.setObject1(aRcvblFlows.toString());
//        executeLogMapper.updateById(executeLog);
//        for (ARcvblFlow aRcvblFlow : aRcvblFlows) {
//            i += aRcvblFlowMapper.insertARcvbl(aRcvblFlow);
//        }
//        executeLog.setComputerBegin(cn.hutool.core.date.DateUtil.date());
//        executeLogMapper.updateById(executeLog);

      //  Integer j = recycleWorkOrderService.selectArcByYM(startMon1,aRcvblFlows);

//        executeLog.setComputerEnd(cn.hutool.core.date.DateUtil.date());
//        executeLogMapper.updateById(executeLog);

        return "数据导入完成"+i+"工单完成"+j;
    }

    @RequestMapping("getRWOOneCycle")
    @ResponseBody
    @Async
    @Scheduled(cron = "59 59 23 16 * ?")
    public String getRWOOneCycle() throws ParseException {

        Calendar dateTime = Calendar.getInstance();
        dateTime.add(Calendar.MONTH, -1);
        Date time = dateTime.getTime();
        String beginTime = DateUtil.dateToStr(time, "yyyy-MM-01");
        String endDateOfMonth = DateUtil.getEndDateOfMonth(beginTime);
        String endTime = DateUtil.dateToStr(time, "yyyy-MM-" + endDateOfMonth);

        List<RecycleWorkOrder> list = recycleWorkOrderService.list(
                new LambdaQueryWrapper<RecycleWorkOrder>()
                        .ne(RecycleWorkOrder::getWorkOrderStatus, FOUR_STATUS)
                        .between(RecycleWorkOrder::getWorkOrderTime, beginTime, endTime)

        );

        if (list.size() < 1) {
            return "电费回收预警数据";
        }

        for (RecycleWorkOrder recycleWorkOrder : list) {
            recycleWorkOrder.setWorkOrderCycle(1);
            recycleWorkOrderService.updateById(recycleWorkOrder);
        }

        return "电费回收预警数据";
    }

    @RequestMapping("getCycleMobile")
    @ResponseBody
    @Async
    public void getCycleMobile(){
        String ym = TimeUtil.getStartMon1();
        List<String> consNos = aRcvblFlowMapper.selectCycleMobile1(ym);
        for (String consNo : consNos) {
            List<String> mobiles = aRcvblFlowMapper.selectMobiAddr(consNo);
            if(mobiles==null||mobiles.size()==0)mobiles.set(0,"");
            String mobile = mobiles.get(0);
            List<GTg> gTgs = aRcvblFlowMapper.selectTgNoName(consNo);
            String tgNo="";
            String tgName="";
            if(gTgs==null||gTgs.size()==0){
                tgNo="";
                tgName="";
            }else {
                tgNo = gTgs.get(0).getTgNo();
                tgName = gTgs.get(0).getTgName();
            }
            String manager = collectWorkOrderMapper.selectTgManage1(consNo);
            if (manager==null)manager="";
            CCons cCons = aRcvblFlowMapper.selectConsName(consNo);
            String consName;
            String elecAddr;
            if(cCons==null){
                consName ="";
                elecAddr ="";
            }else {
                consName = cCons.getConsName();//获取用户名称
                elecAddr = cCons.getElecAddr();//获取用户地址
            }

            aRcvblFlowMapper.updateMobile(mobile,consNo,tgNo,tgName,manager,consName,elecAddr,ym);
        }

        System.out.println("回收电话关联完成");
    }


    @RequestMapping("getRWOTwoCycle")
    @ResponseBody
    @Async
    @Scheduled(cron = "59 59 23 17 * ? ")
    public String getRWOTwoCycle(){

        Calendar dateTime = Calendar.getInstance();
        dateTime.add(Calendar.MONTH, -1);
        Date time = dateTime.getTime();
        String beginTime = DateUtil.dateToStr(time, "yyyy-MM-01");
        String endDateOfMonth = DateUtil.getEndDateOfMonth(beginTime);
        String endTime = DateUtil.dateToStr(time, "yyyy-MM-" + endDateOfMonth);

        List<RecycleWorkOrder> list = recycleWorkOrderService.list(
                new LambdaQueryWrapper<RecycleWorkOrder>()
//                Wrappers.lambdaQuery(RecycleWorkOrder.class)
                        .ne(RecycleWorkOrder::getWorkOrderStatus, FOUR_STATUS)
                        .between(RecycleWorkOrder::getWorkOrderTime, beginTime, endTime)

        );

        if (list.size() < 1) {
            return "电费回收预警数据";
        }

        for (RecycleWorkOrder recycleWorkOrder : list) {
            recycleWorkOrder.setWorkOrderCycle(2);
            recycleWorkOrderService.updateById(recycleWorkOrder);
        }

        return "电费回收预警数据";
    }

    //0 0/15 * * * ? * 每15分钟获取一次
    //@Scheduled(cron = "0 15 0 * * ?")
    @RequestMapping("getArcvbl2")
    @Async
    public String getRecData(){
        //从应缴电费信息中抽取电费信息
        int i = 0;
        int j = 0;
        String startMon1 = TimeUtil.getStartMon1();
        List<BigDecimal> Lists = aRcvblFlowMapper.selectWorkOrder(startMon1);
        for (BigDecimal s : Lists) {
            String settleflag = aRcvblFlowMapper.selectArfcon(s, startMon1);
            if(settleflag.equals("03")){
                 i +=aRcvblFlowMapper.UpdateStatus(s);
            }else if(settleflag.equals("02")){
                ARcvblFlow aRcvblFlow = aRcvblFlowMapper.selectRecycleupdate(s);
                BigDecimal sr = aRcvblFlow.getRcvblPenalty().subtract(aRcvblFlow.getRcvedPenalty());
                j +=aRcvblFlowMapper.updateRecWorkOrder(aRcvblFlow.getRcvblAmt().subtract(aRcvblFlow.getRcvedAmt()).add(sr),aRcvblFlow.getRcvblPenalty(),s);
            }
        }
        System.out.println("电费回收数据更改数量"+i+"--"+j);

//        consList.forEach(con->{
//            if(aRcvblFlowMapper.selectArfcon(con,startMon1).equals("03")){
//                 aRcvblFlowMapper.UpdateStatus(con,startMon1);
//            }
//        });
        return "清空";
    }



    /**
     * TODO 一级工单生成
     * 每月19号23:59:59没有清零的工单对其设置一级预警
     */
    @Async
    //@Scheduled(cron = "59 59 23 19 * ?")
    public void selectCycle1(){
        List<RecycleWorkOrder> recycleWOs = recycleWorkOrderService.selectByNoSta4();
        for (RecycleWorkOrder recycleWO : recycleWOs) {
            recycleWorkOrderMapper.updateCycle1(recycleWO.getWorkOrderNo());
        }
    }


    /**
     * TODO 二级工单生成
     * 每月22号23:59:59没有清零的工单对其设置二级预警
     */
    @Async
    //@Scheduled(cron = "59 59 23 22 * ?")
    public void selectCycle2(){
        List<RecycleWorkOrder> recycleWOs = recycleWorkOrderService.selectByNoSta4();
        for (RecycleWorkOrder recycleWO : recycleWOs) {
            recycleWorkOrderMapper.updateCycle2(recycleWO.getWorkOrderNo());
        }
    }

    /**
     * TODO 提交电费回收工单的描述
     * @param workOrderDes 描述信息 根据工单编号添加描述信息
     * @param workOrderNo 工单编号
     */
    @PostMapping("commitdes")
    public void commitDes(@RequestParam String workOrderDes,@RequestParam String workOrderNo){
        System.out.println("电费回收提交接口commitdes");
        int i = recycleWorkOrderService.updateDes(workOrderDes, workOrderNo);
        int i1 = recycleWorkOrderMapper.updateStatus3(workOrderNo);
        log.info("提交条数为"+i+"条");
        log.info("状态修改待归档为"+i1+"条");
    }

    /**
     *TODO 点击工单 状态改为2处理中
     */
    @PostMapping("updateSta2")
    public void updateStatus2(@RequestParam String workOrderNo){
        int i = recycleWorkOrderMapper.updateStatus2(workOrderNo);
        log.info("状态修改处理中为"+i+"条");
    }

    /**
     *TODO 召测成功后 状态改为4已归档
     */
    @PostMapping("updateSta4")
    public void updateStatus4(@RequestParam String workOrderNo){
        int i = recycleWorkOrderMapper.updateStatus4(workOrderNo);
        log.info("状态修改已归档为"+i+"条");
    }

    /**
     * 分页查询所有数据
     *
     * @param page             分页对象
     * @param recycleWorkorder 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll11")
    public R selectAll11(@CurrentUser SysUser user, Page<RecycleWorkOrder> page, RecycleWorkOrder recycleWorkorder) {
        //通过用户名查询角色信息（2： 台区经理  1：所站长）
        String role = feecontrolWorkOrderMapper.selectRole(user.getLoginName());
        R<Page<RecycleWorkOrder>> success = success(recycleWorkOrderService.page(page,recycleWorkOrderService.queryWrapper(recycleWorkorder,role)));
        if(success.getData().getRecords().size()>0){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }


    @RequestMapping("export")  //excel/export
    public void exportExcel2(HttpServletResponse response, @RequestParam String ids) throws IOException {
        List<org.dfzt.entity.po.RecycleWorkOrder> recycleWorkOrders = collectWorkOrderMapper.selectExcel5(ids);
        ExcelUtils.exportExcel(recycleWorkOrders, "电费回收工单列表", "电费回收", org.dfzt.entity.po.RecycleWorkOrder.class, "电费回收工单文件", response);
    }


    @RequestMapping("exportAll")  //excel/export
    public void exportExcel2All(HttpServletResponse response, @RequestParam(required = false) String ids,org.dfzt.entity.po.RecycleWorkOrder r,
                                @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,
                                @RequestParam(required = false) String loName2) throws IOException {
        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<org.dfzt.entity.po.RecycleWorkOrder> recycleWorkorders = recycleWorkOrderMapper.selectRecyclerList(r,0,999999999,status,orgName);
        ExcelUtils.exportExcel(recycleWorkorders, "电费回收工单列表", "电费回收", org.dfzt.entity.po.RecycleWorkOrder.class, "电费回收工单文件", response);
    }

    @PostMapping("selectAll")
    public R selectAll(org.dfzt.entity.po.RecycleWorkOrder recycleWorkorder,@RequestParam(name = "pageNo",defaultValue = "1") String pageNo,
                       @RequestParam(name = "pageSize",defaultValue = "10") String pageSize,
                       @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String loName2){

        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<org.dfzt.entity.po.RecycleWorkOrder> recycleWorkorders = recycleWorkOrderMapper.selectRecyclerList(recycleWorkorder,(Integer.parseInt(pageNo)-1)*Integer.parseInt(pageSize),Integer.parseInt(pageSize),status,orgName);
        int size = recycleWorkOrderMapper.selectRecyclerList(recycleWorkorder, 0, 999999999, status,orgName).size();
        Map<Integer,List<org.dfzt.entity.po.RecycleWorkOrder>> map = new HashMap<>();
        map.put(size,recycleWorkorders);
        R<Map<Integer,List<org.dfzt.entity.po.RecycleWorkOrder>>> success = success(map);
        if (success.getData().size() > 0){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }


    @PostMapping("selectWrapper")
    public R selectWrapper(@RequestParam String loName2,@RequestParam(name = "pageNo",defaultValue = "0") String pageNo,
                           @RequestParam(name = "pageSize",defaultValue = "10") String pageSize, String str,@RequestParam String workOrderStatus,@RequestParam String elecType,
                           @RequestParam(required = false) String role,@RequestParam(required = false) String loginName) {
        Page<RecycleWorkOrder> page = new Page<>();
        page.setCurrent(Long.parseLong(pageNo));
        page.setSize(Long.parseLong(pageSize));
        List<String> readNames = collectWorkOrderMapper.selectReadNames(loginName);
        //通过用户名查询角色信息（2： 台区经理  1：所站长）
        //feecontrolWorkOrderMapper.selectRole(loName2);
//        if (role.equals("1")){
//            return success(this.recycleWorkOrderService.page(page, recycleWorkOrderService.wrapper(str,role,workOrderStatus,elecType,loName2)));
//        }
        return success(this.recycleWorkOrderService.page(page, recycleWorkOrderService.wrapper(readNames,str,role,workOrderStatus,elecType,loName2)));
    }




    /**
     * 分页查询所有数据
     *
     * @param page             分页对象
     * @param recycleWorkOrder 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll1")
    public R selectAll(Page<RecycleWorkOrder> page, RecycleWorkOrder recycleWorkOrder) {
        R<Page<RecycleWorkOrder>> success = success(
                this.recycleWorkOrderService.page(page, new QueryWrapper<>(recycleWorkOrder))
        );
        if (success.getData().getRecords().size() > 0){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }

    /**
     * 状态扭转
     * @param
     * @return
     */
    @PostMapping("updateStatus")
    public R updateRecycleWordOrder(@RequestParam String workOrderStatus,@RequestParam String workOrderNo){
        // map.put("workOrderStatus", WorkOrderStatusEnum.getNameByValue(String.valueOf(map.get("workOrderStatus"))));

        R<Integer> success = success(recycleWorkOrderService.updateRecycleWorkOrder(workOrderStatus,workOrderNo));
        if (success.getData() == 1){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }


    /**
     * 查询历史数据
     * @param workOrderId
     * @return
     */
    @PostMapping("selectWordOrderId")
    public R selectRecycleWordOrderId(@RequestParam String workOrderId){
        R<org.dfzt.entity.vo.RecycleWorkOrder> success = success(recycleWorkOrderService.selectRecycleWordOrderId(workOrderId));
        if (success.getData() != null){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }

    /**
     * 电费回收导出
     *
     * @param ids
     * @return
     */
    @PostMapping("export")  //excel/export
    public void export(HttpServletResponse response, @RequestParam List<String> ids) throws IOException {
        List<RecycleWorkOrder> list = new ArrayList<>();
        for (String id : ids) {
            RecycleWorkOrder recycleWorkOrder = recycleWorkOrderService.selectRecycleWordOrderId(id);
            list.add(recycleWorkOrder);
        }
        ExcelUtils.exportExcel(list, "电费回收工单列表", "电费回收", RecycleWorkOrder.class, "电费回收工单文件", response);
    }



    /**
     * 查询敏感用户工单数据
     * @param recycleWorkorder
     * @return
     */
    @PostMapping("selectWorkOrderList")
    public R selectWorkOrderList(RecycleWorkOrder recycleWorkorder) {
        return success(recycleWorkOrderService.selectWorkOrderList(recycleWorkorder));
    }
}
