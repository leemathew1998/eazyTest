package org.dfzt.entity.po;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.Date;

/**
 * (MeterCurrent)表实体类
 *
 * @author makejava
 * @since 2022-06-17 19:53:08
 */
@SuppressWarnings("serial")
@TableName("meter_current")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MeterCurrent extends Model<MeterCurrent> {
    private Integer id;
    //供电单位
    private String orgName;
    //用户编码
    private String consNo;
    //用户名称
    private String consName;
    //电能表资产号
    private String meterAssetNo;
    //电能表厂家
    private String metManufacturer;
    //终端厂家
    private String factoryCode;
    //台区编号
    private String tgNo;
    //台区名称
    private String tgName;
    //抄表日期
    private Date mrDate;
    //数据来源
    private String dataSrc;
    //综合倍率
    private BigDecimal tFactor;
    //相序
    private String phaseFlag;
    //点数
    private String dataPointFlag;
    //1点
    private BigDecimal i1;
    //2点
    private BigDecimal i2;

    private BigDecimal i3;

    private BigDecimal i4;

    private BigDecimal i5;

    private BigDecimal i6;

    private BigDecimal i7;

    private BigDecimal i8;

    private BigDecimal i9;

    private BigDecimal i10;

    private BigDecimal i11;

    private BigDecimal i12;

    private BigDecimal i13;

    private BigDecimal i14;

    private BigDecimal i15;

    private BigDecimal i16;

    private BigDecimal i17;

    private BigDecimal i18;

    private BigDecimal i19;

    private BigDecimal i20;

    private BigDecimal i21;

    private BigDecimal i22;

    private BigDecimal i23;

    private BigDecimal i24;

    private BigDecimal i25;

    private BigDecimal i26;

    private BigDecimal i27;

    private BigDecimal i28;

    private BigDecimal i29;

    private BigDecimal i30;

    private BigDecimal i31;

    private BigDecimal i32;

    private BigDecimal i33;

    private BigDecimal i34;

    private BigDecimal i35;

    private BigDecimal i36;

    private BigDecimal i37;

    private BigDecimal i38;

    private BigDecimal i39;

    private BigDecimal i40;

    private BigDecimal i41;

    private BigDecimal i42;

    private BigDecimal i43;

    private BigDecimal i44;

    private BigDecimal i45;

    private BigDecimal i46;

    private BigDecimal i47;

    private BigDecimal i48;

    private BigDecimal i49;

    private BigDecimal i50;

    private BigDecimal i51;

    private BigDecimal i52;

    private BigDecimal i53;

    private BigDecimal i54;

    private BigDecimal i55;

    private BigDecimal i56;

    private BigDecimal i57;

    private BigDecimal i58;

    private BigDecimal i59;

    private BigDecimal i60;

    private BigDecimal i61;

    private BigDecimal i62;

    private BigDecimal i63;

    private BigDecimal i64;

    private BigDecimal i65;

    private BigDecimal i66;

    private BigDecimal i67;

    private BigDecimal i68;

    private BigDecimal i69;

    private BigDecimal i70;

    private BigDecimal i71;

    private BigDecimal i72;

    private BigDecimal i73;

    private BigDecimal i74;

    private BigDecimal i75;

    private BigDecimal i76;

    private BigDecimal i77;

    private BigDecimal i78;

    private BigDecimal i79;

    private BigDecimal i80;

    private BigDecimal i81;

    private BigDecimal i82;

    private BigDecimal i83;

    private BigDecimal i84;

    private BigDecimal i85;

    private BigDecimal i86;

    private BigDecimal i87;

    private BigDecimal i88;

    private BigDecimal i89;

    private BigDecimal i90;

    private BigDecimal i91;

    private BigDecimal i92;

    private BigDecimal i93;

    private BigDecimal i94;

    private BigDecimal i95;
    //96点
    private BigDecimal i96;
    //用电地址
    private String elecAddr;
    //电能表地址
    private String commAddr;
    //终端地址
    private String terminalAddr;
    //上送时间
    private Date recTime;
    //测量点号
    private String mpSn;
    //终端资产号
    private String tmnlAssetNo;
    //类型
    private String type;
    //用户类型
    private String userType;
    private Date createTime;
}
