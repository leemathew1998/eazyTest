package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.ARcaCtrlDet;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface ARcaCtrlDetMapper extends BaseMapper<ARcaCtrlDet> {
}