package org.dfzt.util;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @ClassName WorkOrderEnum
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/6/28 13:39
 */

//@JSONType(serializeEnumAsJavaBean = true)
//@JsonFormat(shape = JsonFormat.Shape.OBJECT)
    @Getter
    @AllArgsConstructor
public enum WorkOrderEnum {

    WORK_ORDER_ENUM_ONE(1, "待处理"),
    WORK_ORDER_ENUM_TWO(2, "处理中"),
    WORK_ORDER_ENUM_THREE(3, "待归档"),
    WORK_ORDER_ENUM_FOUR(4, "已归档");

    @EnumValue
    private Integer code;
    @JsonValue
    private String message;

}
