package org.dfzt.api;

import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.po.*;
import org.dfzt.entity.tdo.*;
import org.dfzt.entity.vo.DocumentInfoVo;
import org.dfzt.entity.vo.LoadRateVo;
import org.dfzt.mapper.*;
import org.dfzt.service.ThDapiService;
import org.dfzt.util.TimeUtil;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/7
 * @Version: 1.00
 */
@Slf4j
@RestController
@CrossOrigin
@RequestMapping("/tdapi")
@Api(tags = "三维系统接口")
public class ThreeDapiController extends ApiController {
    @Resource
    ThDapiService thDapiService;

//    @Resource
//    AcCountyMapper acCountyMapper;

    @Resource
    CollectWorkOrderMapper collMapper;
//    @Resource
//    AcManagerMapper acManagerMapper;
//    @Resource
//    AchievementsManagerMapper achMapper;
    @Resource
    AcStationMapper acstaMapper;


    /**
     * 接口调用频率：每天24点调用1次
     * @param id 可以作为单位编号或者台区经理编号上传
     * @param type 类型(1:所 2:站 3:人)
     * @return
     */
    @GetMapping("/person-place-station-statistics")
    @ResponseBody
    @ApiOperation(value = "2.1 获取人、所、站统计")
    public Object PersonPlaceStationStatistics(@RequestParam(required = false) String id,@RequestParam(required = false) int type){
        PlaceStation place = new PlaceStation();
        if (type==1){
            List<String> orgNos = new ArrayList<>();
            if("1".equals(id)) {//id为1表示河东
                place.setName("河东供电服务中心");
                orgNos.add("154212201");
                orgNos.add("154212203");
                orgNos.add("154212204");
                orgNos.add("154212205");
                orgNos.add("154212206");
                orgNos.add("1542122");
                place.setScopeOfServices("绿园供电所，龙辰供电所，园丁供电所，哈克供电所，光明供电所");
                List<StatisticsList> lists = new ArrayList<>();
                StatisticsList list1 = new StatisticsList();
                list1.setType(1);
                list1.setTypeName("低电压用户数量");
                list1.setValue(collMapper.selectCons2(orgNos));
                list1.setTypeUnit("户");
                lists.add(list1);
                StatisticsList list2 = new StatisticsList();
                list2.setType(2);
                list2.setTypeName("高压用户数量");
                list2.setValue(collMapper.selectCons1(orgNos));
                list2.setTypeUnit("户");
                lists.add(list2);
                StatisticsList list3 = new StatisticsList();
                list3.setType(3);
                list3.setTypeName("0.4kV线路长度");
                list3.setValue(collMapper.selectLine2(orgNos));
                list3.setTypeUnit("千米");
                lists.add(list3);
                StatisticsList list4 = new StatisticsList();
                list4.setType(4);
                list4.setTypeName("10kV线路长度");
                list4.setValue(collMapper.selectLine1(orgNos));
                list4.setTypeUnit("千米");
                lists.add(list4);
                StatisticsList list5 = new StatisticsList();
                list5.setType(5);
                list5.setTypeName("在运专变数量");
                list5.setValue(collMapper.selectPub1(orgNos));
                list5.setTypeUnit("个");
                lists.add(list5);
                StatisticsList list6 = new StatisticsList();
                list6.setType(6);
                list6.setTypeName("在运公变数量");
                list6.setValue(collMapper.selectPub2(orgNos));
                list6.setTypeUnit("个");
                lists.add(list6);
                StatisticsList list7 = new StatisticsList();
                list7.setType(7);
                list7.setTypeName("在运电能表数量");
                list7.setValue(collMapper.selectCMeter1(orgNos));
                list7.setTypeUnit("个");
                lists.add(list7);
                StatisticsList list8 = new StatisticsList();
                list8.setType(8);
                list8.setTypeName("在运采集终端设备");
                list8.setValue(collMapper.selectCMeter2(orgNos));
                list8.setTypeUnit("个");
                lists.add(list8);
                place.setStatisticsList(lists);
            }else {
                place.setName("河西供电服务中心");
                orgNos.add("154212103");
                orgNos.add("154212104");
                orgNos.add("154212105");
                orgNos.add("154212102");
                orgNos.add("1542121");
                place.setScopeOfServices("西山供电所，松山供电所，友好供电所，木兰供电所");
                List<StatisticsList> lists = new ArrayList<>();
                StatisticsList list1 = new StatisticsList();
                list1.setType(1);
                list1.setTypeName("低电压用户数量");
                list1.setValue(collMapper.selectCons2(orgNos));
                list1.setTypeUnit("户");
                lists.add(list1);
                StatisticsList list2 = new StatisticsList();
                list2.setType(2);
                list2.setTypeName("高压用户数量");
                list2.setValue(collMapper.selectCons1(orgNos));
                list2.setTypeUnit("户");
                lists.add(list2);
                StatisticsList list3 = new StatisticsList();
                list3.setType(3);
                list3.setTypeName("0.4kV线路长度");
                list3.setValue(collMapper.selectLine2(orgNos));
                list3.setTypeUnit("千米");
                lists.add(list3);
                StatisticsList list4 = new StatisticsList();
                list4.setType(4);
                list4.setTypeName("10kV线路长度");
                list4.setValue(collMapper.selectLine1(orgNos));
                list4.setTypeUnit("千米");
                lists.add(list4);
                StatisticsList list5 = new StatisticsList();
                list5.setType(5);
                list5.setTypeName("在运专变数量");
                list5.setValue(collMapper.selectPub1(orgNos));
                list5.setTypeUnit("个");
                lists.add(list5);
                StatisticsList list6 = new StatisticsList();
                list6.setType(6);
                list6.setTypeName("在运公变数量");
                list6.setValue(collMapper.selectPub2(orgNos));
                list6.setTypeUnit("个");
                lists.add(list6);
                StatisticsList list7 = new StatisticsList();
                list7.setType(7);
                list7.setTypeName("在运电能表数量");
                list7.setValue(collMapper.selectCMeter1(orgNos));
                list7.setTypeUnit("个");
                lists.add(list7);
                StatisticsList list8 = new StatisticsList();
                list8.setType(8);
                list8.setTypeName("在运采集终端设备");
                list8.setValue(collMapper.selectCMeter2(orgNos));
                list8.setTypeUnit("个");
                lists.add(list8);
                place.setStatisticsList(lists);
            }
        }else if(type==2){
            List<String> orgNos = new ArrayList<>();
            if("1".equals(id)){
                orgNos.add("154212201");
                place.setName("绿园供电营业站");
            }else if("2".equals(id)){
                orgNos.add("154212203");
                place.setName("龙辰供电营业站");
            }else if("3".equals(id)){
                orgNos.add("154212204");
                place.setName("园丁供电营业站");
            }else if("4".equals(id)){
                orgNos.add("154212205");
                place.setName("哈克供电营业站");
            }else{
                orgNos.add("154212206");
                place.setName("光明供电营业站");
            }
            place.setScopeOfServices("null");
            List<StatisticsList> lists = new ArrayList<>();
            StatisticsList list1 = new StatisticsList();
            list1.setType(1);
            list1.setTypeName("低电压用户数量");
            list1.setValue(collMapper.selectCons2(orgNos));
            list1.setTypeUnit("户");
            lists.add(list1);
            StatisticsList list2 = new StatisticsList();
            list2.setType(2);
            list2.setTypeName("高压用户数量");
            list2.setValue(collMapper.selectCons1(orgNos));
            list2.setTypeUnit("户");
            lists.add(list2);
            StatisticsList list3 = new StatisticsList();
            list3.setType(3);
            list3.setTypeName("0.4kV线路长度");
            list3.setValue(collMapper.selectLine2(orgNos));
            list3.setTypeUnit("千米");
            lists.add(list3);
            StatisticsList list4 = new StatisticsList();
            list4.setType(4);
            list4.setTypeName("10kV线路长度");
            list4.setValue(collMapper.selectLine1(orgNos));
            list4.setTypeUnit("千米");
            lists.add(list4);
            StatisticsList list5 = new StatisticsList();
            list5.setType(5);
            list5.setTypeName("在运专变数量");
            list5.setValue(collMapper.selectPub1(orgNos));
            list5.setTypeUnit("个");
            lists.add(list5);
            StatisticsList list6 = new StatisticsList();
            list6.setType(6);
            list6.setTypeName("在运公变数量");
            list6.setValue(collMapper.selectPub2(orgNos));
            list6.setTypeUnit("个");
            lists.add(list6);
            StatisticsList list7 = new StatisticsList();
            list7.setType(7);
            list7.setTypeName("在运电能表数量");
            list7.setValue(collMapper.selectCMeter1(orgNos));
            list7.setTypeUnit("个");
            lists.add(list7);
            StatisticsList list8 = new StatisticsList();
            list8.setType(8);
            list8.setTypeName("在运采集终端设备");
            list8.setValue(collMapper.selectCMeter2(orgNos));
            list8.setTypeUnit("个");
            lists.add(list8);
            place.setStatisticsList(lists);
        }
        return place;
    }

    /**
     *
     * @param id
     * @param type 类型(1:所 2:站) 表中获取
     * @return
     */
    @GetMapping("/synthesis-ranking")
    @ResponseBody
    @ApiOperation(value = "2.2 综合排名")
    public Object SynthesisRanking(@RequestParam(required = false) String id,@RequestParam(required = false) int type){
        List<Synthesis> synthesis = new ArrayList<>();

        if(type==1) {
            List<AcCounty> acCounties = acstaMapper.selectAllAcCounty(TimeUtil.getStartTime(), null);
            for (int i=0;i<acCounties.size();i++) {
                Synthesis synthesis1 = new Synthesis();
                synthesis1.setId(acCounties.get(i).getOrgNo());
                synthesis1.setName(acCounties.get(i).getCountyName());
                synthesis1.setSort(i+1);
                synthesis1.setCurrentDayIntegrate(Integer.parseInt(acCounties.get(i).getToPoint()));
                synthesis1.setCurrentMonthIntegrate(Integer.parseInt(acCounties.get(i).getToPoint()));
                synthesis.add(synthesis1);
            }
            return synthesis;
        }else if(type==2){
            List<AcStation> acStations = acstaMapper.selectAllStation(TimeUtil.getStartTime(), null, null);
            for (int i = 0; i < acStations.size(); i++) {
                Synthesis synthesis1 = new Synthesis();
                synthesis1.setId(acStations.get(i).getOrgNo());
                synthesis1.setName(acStations.get(i).getStationName());
                synthesis1.setSort(i+1);
                synthesis1.setCurrentDayIntegrate(Integer.parseInt(acStations.get(i).getToPoint()));
                synthesis1.setCurrentMonthIntegrate(Integer.parseInt(acStations.get(i).getToPoint()));
                synthesis.add(synthesis1);
            }
        }
        return synthesis;
    }

    /**
     *
     * @param id
     * @param type 类型 1:所 2:站
     * @param workorderType 工单类型 1:待办 2:预警
     * @return
     */
    @ApiOperation(value = "2.3 待办、预警工单", notes = "导入")
    @GetMapping("/upcoming-warning-workOrder")
    @ResponseBody
    public Object QueryAllWarningWorkOrder(@RequestParam(required = false) String id,@RequestParam(required = false) Integer type,
                                           @RequestParam String workorderType){
        List<WarningWorkOrder> list=new ArrayList<>();
        if(type == 1){
            WarningWorkOrder wW=new WarningWorkOrder();
            wW.setName("河东供电服务中心");
            wW.setMeteringCollection(212);//采集 和计量工单数
            wW.setLineLossManagement(35);//线损治理的工单数
            wW.setCostControlRecovery(157);//费控复电工单数
            wW.setElectricityBill(25);//电费回收工单数
            wW.setService(45);//服务工单数（优质服务）
            wW.setOperationAndMaintenance(12);//运维抢修工单数//           wW.setMeteringCollection(thDapiService.selectUpcomingWarning1(id, type, workorderType));//采集 和计量工单数
//            wW.setLineLossManagement(thDapiService.selectUpcomingWarning2(id, type, workorderType));//线损治理的工单数
//            wW.setCostControlRecovery(thDapiService.selectUpcomingWarning3(id, type, workorderType));//费控复电工单数
//            wW.setElectricityBill(thDapiService.selectUpcomingWarning4(id, type, workorderType));//电费回收工单数
//            wW.setService(thDapiService.selectUpcomingWarning5(id, type, workorderType));//服务工单数（优质服务）
//            wW.setOperationAndMaintenance(thDapiService.selectUpcomingWarning6(id, type, workorderType));//运维抢修工单数
            WarningWorkOrder wW1=new WarningWorkOrder();
            wW1.setName("河西供电服务中心");
            wW1.setMeteringCollection(241);//采集 和计量工单数
            wW1.setLineLossManagement(45);//线损治理的工单数
            wW1.setCostControlRecovery(163);//费控复电工单数
            wW1.setElectricityBill(33);//电费回收工单数
            wW1.setService(51);//服务工单数（优质服务）
            wW1.setOperationAndMaintenance(17);//运维抢修工单数
            list.add(wW);
            list.add(wW1);
        }else {
            WarningWorkOrder wW=new WarningWorkOrder();
            wW.setName("光明供电营业站");
            wW.setMeteringCollection(48);//采集 和计量工单数
            wW.setLineLossManagement(4);//线损治理的工单数
            wW.setCostControlRecovery(34);//费控复电工单数
            wW.setElectricityBill(5);//电费回收工单数
            wW.setService(9);//服务工单数（优质服务）
            wW.setOperationAndMaintenance(4);//运维抢修工单数
//            wW.setMeteringCollection(thDapiService.selectUpcomingWarning1(id, type, workorderType));//采集 和计量工单数
//            wW.setLineLossManagement(thDapiService.selectUpcomingWarning2(id, type, workorderType));//线损治理的工单数
//            wW.setCostControlRecovery(thDapiService.selectUpcomingWarning3(id, type, workorderType));//费控复电工单数
//            wW.setElectricityBill(thDapiService.selectUpcomingWarning4(id, type, workorderType));//电费回收工单数
//            wW.setService(thDapiService.selectUpcomingWarning5(id, type, workorderType));//服务工单数（优质服务）
//            wW.setOperationAndMaintenance(thDapiService.selectUpcomingWarning6(id, type, workorderType));//运维抢修工单数
            WarningWorkOrder wW1=new WarningWorkOrder();
            wW1.setName("哈克供电营业站");
            wW1.setMeteringCollection(54);//采集 和计量工单数
            wW1.setLineLossManagement(7);//线损治理的工单数
            wW1.setCostControlRecovery(31);//费控复电工单数
            wW1.setElectricityBill(5);//电费回收工单数
            wW1.setService(8);//服务工单数（优质服务）
            wW1.setOperationAndMaintenance(4);//运维抢修工单数
            WarningWorkOrder wW2=new WarningWorkOrder();
            wW1.setName("绿园供电营业站");
            wW1.setMeteringCollection(39);//采集 和计量工单数
            wW1.setLineLossManagement(5);//线损治理的工单数
            wW1.setCostControlRecovery(33);//费控复电工单数
            wW1.setElectricityBill(24);//电费回收工单数
            wW1.setService(7);//服务工单数（优质服务）
            wW1.setOperationAndMaintenance(5);//运维抢修工单数
            WarningWorkOrder wW3=new WarningWorkOrder();
            wW1.setName("园丁供电营业站");
            wW1.setMeteringCollection(60);//采集 和计量工单数
            wW1.setLineLossManagement(6);//线损治理的工单数
            wW1.setCostControlRecovery(39);//费控复电工单数
            wW1.setElectricityBill(8);//电费回收工单数
            wW1.setService(13);//服务工单数（优质服务）
            wW1.setOperationAndMaintenance(6);//运维抢修工单数
            WarningWorkOrder wW4=new WarningWorkOrder();
            wW1.setName("龙辰供电营业站");
            wW1.setMeteringCollection(44);//采集 和计量工单数
            wW1.setLineLossManagement(6);//线损治理的工单数
            wW1.setCostControlRecovery(28);//费控复电工单数
            wW1.setElectricityBill(6);//电费回收工单数
            wW1.setService(10);//服务工单数（优质服务）
            wW1.setOperationAndMaintenance(4);//运维抢修工单数
            list.add(wW);
        }


        return list;
    }

    @ApiOperation(value = "2.4 所业绩指标 ")
    @GetMapping("/place-performance-indicators")
    @ResponseBody
    public Object QueryAllPlaceperForMance(@RequestParam(required = false) String id,@RequestParam(required = false) Integer type){
        PlaceperForMance pm=new PlaceperForMance();
        if(type==1) {
            List<AcCounty> acCounties = acstaMapper.selectAllAcCounty(TimeUtil.getStartTime(), null);
            if("1".equals(id)) {
                pm.setTheCompanyTotalPointsForTheDay(Integer.parseInt(acCounties.get(0).getToPoint()));//总积分
                pm.setCompanyRankingOfTheDay(1);//排名
                List<Indicators> list1 = new ArrayList<>();
                pm.setIndicators(TdApiUtil.getTdCountPoint(list1, acCounties.get(0)));
            }else {
                pm.setTheCompanyTotalPointsForTheDay(Integer.parseInt(acCounties.get(1).getToPoint()));//总积分
                pm.setCompanyRankingOfTheDay(2);//排名
                List<Indicators> list1 = new ArrayList<>();
                pm.setIndicators(TdApiUtil.getTdCountPoint(list1, acCounties.get(1)));
            }
        }else {
            List<AcCounty> acCounties = acstaMapper.selectAllAcCounty(TimeUtil.getStartTime(), null);
            if("1".equals(id)) {
                pm.setTheCompanyTotalPointsForTheDay(Integer.parseInt(acCounties.get(0).getToPoint()));//总积分
                pm.setCompanyRankingOfTheDay(1);//排名
                List<Indicators> list1 = new ArrayList<>();
                pm.setIndicators(TdApiUtil.getTdCountPoint(list1, acCounties.get(0)));
            }else {
                pm.setTheCompanyTotalPointsForTheDay(Integer.parseInt(acCounties.get(1).getToPoint()));//总积分
                pm.setCompanyRankingOfTheDay(2);//排名
                List<Indicators> list1 = new ArrayList<>();
                pm.setIndicators(TdApiUtil.getTdCountPoint(list1, acCounties.get(1)));
            }
        }
        return pm;
    }

    @GetMapping("/station-performance-indicators")
    @ResponseBody
    @ApiOperation(value = "2.5 站业绩指标")
    public Object StationPerformanceIndicators(@RequestParam(required = false) String id, @RequestParam(required = false) int type){
        List<AcStation> acStations = acstaMapper.selectAllStation(TimeUtil.getStartTime(), null, null);

        Performance performance = new Performance();
        //AcStation acStation = acStationMapper.selectTdStation("友好供电营业", TimeUtil.getTodayTime());
        performance.setPowerStationTodayTotalIntegrate(Integer.parseInt(acStations.get(0).getToPoint()));
        performance.setQiCountyCompanyTodayRanking(11);//旗县公司当日排名
        performance.setCityCompanyTodayRanking(11);//市公司当日排名
        List<Indicators> lists = new ArrayList<>();
        performance.setIndicators(TdApiUtil.getTdStationPoint(lists,acStations.get(0)));
        return performance;
    }

    @GetMapping("/district-performance-indicators")
    @ResponseBody
    @ApiOperation(value = "2.6 区业绩指标")
    public Object DistrictPerformanceIndicators(@RequestParam(required = false) String id, @RequestParam(required = false) int type){
        Performance1 performance = new Performance1();
        //AcManager acManager = acManagerMapper.selectTdManager("刘月焱", TimeUtil.getTodayTime());
        List<AcManager> acManagers = acstaMapper.selectByStation(TimeUtil.getStartTime(), null, null,null);
        performance.setAccountManagerTodayTotalIntegrate(Integer.parseInt(acManagers.get(0).getToPoint()));
        performance.setQiCountyCompanyTodayRanking(7);//旗县公司当日排名
        performance.setPowerStationTodayRanking(8);//市公司当日排名
        List<Indicators> lists = new ArrayList<>();
        performance.setIndicators(TdApiUtil.getTdManagerPoint(lists,acManagers.get(0)));
        return performance;
    }

    @GetMapping("/district-work-order-completion")
    @ResponseBody
    @ApiOperation(value = "2.7 区工单完成情况")
    public Object threeDimensional(@RequestParam(required = false) String id, @RequestParam(required = false) int type){
        WorkOrderCompletion workOrderCompletion = new WorkOrderCompletion();
        workOrderCompletion.setCurrentMonthGrandTotal(96);//当月累计工单
        workOrderCompletion.setToBeProcessed(14);//待处理
        workOrderCompletion.setProcessing(11);//处理中
        workOrderCompletion.setProcessed("11");//已处理
        List<DetailList> detailLists = new ArrayList<>();
        DetailList detailList = new DetailList();
        detailList.setWorkOrderType(1);
        detailList.setCurrentMonthTotal(98);
        detailList.setToBeProcessed(14);
        detailList.setToBeProcessed(10);
        detailList.setToBeProcessed(12);
        detailList.setToBeProcessed(67);
        detailLists.add(detailList);
        DetailList detailList1 = new DetailList();
        detailList1.setWorkOrderType(2);
        detailList1.setCurrentMonthTotal(112);
        detailList1.setToBeProcessed(19);
        detailList1.setToBeProcessed(11);
        detailList1.setToBeProcessed(12);
        detailList1.setToBeProcessed(71);
        detailLists.add(detailList1);
        workOrderCompletion.setDetailList(detailLists);
        return workOrderCompletion;
    }

    @GetMapping("/district-no-one-tour")
    @ResponseBody
    @ApiOperation(value = "2.8 区无人巡视况")
    public Object completionl(@RequestParam String id){
        return null;
    }

    @GetMapping("/token-parse")
    @ResponseBody
    @ApiOperation(value = "2.9 token解析")
    public Object TokenParse(@RequestParam String type){
        return null;
    }

    @GetMapping("/users")
    @ResponseBody
    @ApiOperation(value = "2.10 获取所有用户列表(用于同步用户信息)")
    public Object Users(){
        return null;
    }

    //TODO =============================================================

    @RequestMapping("/getAcCountyList")
    @ResponseBody
    @ApiOperation(value = "获取旗县级别列表供电单位列表")
    public List<OrgNoName> getAcCountyList(){
        List<OrgNoName> orgNoNames = collMapper.selectCounty();
        return orgNoNames;
    }


    @RequestMapping("/getAcStation")
    @ResponseBody
    @ApiOperation(value = "获取旗县级别下营业站供电单位")
    public List<OrgNoName> getAcStation(@RequestParam String orgNo){
        List<OrgNoName> orgNoNames = collMapper.selectStation1(orgNo);
        return orgNoNames;
    }


    @RequestMapping("/getAcManager")
    @ResponseBody
    @ApiOperation(value = "获取营业站下台区经理")
    public List<TdTgManager> getAcManager(@RequestParam String orgNo){
        List<TdTgManager> list = collMapper.selectAcManager(orgNo);
        return list;
    }

    @CrossOrigin
    @GetMapping("/person-place-station-statistics1")
    @ResponseBody
    @ApiOperation(value = "2.1 获取人、所、站统计")
    public Object PersonPlaceStationStatistics1(@RequestParam(required = false) String orgNo,@RequestParam(required = false) int type){
        PlaceStation place = new PlaceStation();
        if (type==1){//获取所站层级
            List<String> orgNos = new ArrayList<>();
            StringBuffer orgNameString =new StringBuffer();
            List<OrgNoName> orgNoNames = collMapper.selectStation1(orgNo);
            for (OrgNoName orgNoName : orgNoNames) {
                orgNos.add(orgNoName.getOrgNo());
                orgNameString.append(orgNoName.getOrgName());
            }
                place.setScopeOfServices(orgNameString.toString());
                List<StatisticsList> lists = new ArrayList<>();
                StatisticsList list1 = new StatisticsList();
                list1.setType(1);
                list1.setTypeName("低电压用户数量");
                list1.setValue(collMapper.selectCons2(orgNos));
                list1.setTypeUnit("户");
                lists.add(list1);
                StatisticsList list2 = new StatisticsList();
                list2.setType(2);
                list2.setTypeName("高压用户数量");
                list2.setValue(collMapper.selectCons1(orgNos));
                list2.setTypeUnit("户");
                lists.add(list2);
                StatisticsList list3 = new StatisticsList();
                list3.setType(3);
                list3.setTypeName("0.4kV线路长度");
                list3.setValue(collMapper.selectLine2(orgNos));
                list3.setTypeUnit("千米");
                lists.add(list3);
                StatisticsList list4 = new StatisticsList();
                list4.setType(4);
                list4.setTypeName("10kV线路长度");
                list4.setValue(collMapper.selectLine1(orgNos));
                list4.setTypeUnit("千米");
                lists.add(list4);
                StatisticsList list5 = new StatisticsList();
                list5.setType(5);
                list5.setTypeName("在运专变数量");
                list5.setValue(collMapper.selectPub1(orgNos));
                list5.setTypeUnit("个");
                lists.add(list5);
                StatisticsList list6 = new StatisticsList();
                list6.setType(6);
                list6.setTypeName("在运公变数量");
                list6.setValue(collMapper.selectPub2(orgNos));
                list6.setTypeUnit("个");
                lists.add(list6);
                StatisticsList list7 = new StatisticsList();
                list7.setType(7);
                list7.setTypeName("在运电能表数量");
                list7.setValue(collMapper.selectCMeter1(orgNos));
                list7.setTypeUnit("个");
                lists.add(list7);
                StatisticsList list8 = new StatisticsList();
                list8.setType(8);
                list8.setTypeName("在运采集终端设备");
                list8.setValue(collMapper.selectCMeter2(orgNos));
                list8.setTypeUnit("个");
                lists.add(list8);
                place.setStatisticsList(lists);
        }else if(type==2){
            List<String> orgNos = new ArrayList<>();
            orgNos.add(orgNo);
            place.setScopeOfServices("null");
            List<StatisticsList> lists = new ArrayList<>();
            StatisticsList list1 = new StatisticsList();
            list1.setType(1);
            list1.setTypeName("低电压用户数量");
            list1.setValue(collMapper.selectCons2(orgNos));
            list1.setTypeUnit("户");
            lists.add(list1);
            StatisticsList list2 = new StatisticsList();
            list2.setType(2);
            list2.setTypeName("高压用户数量");
            list2.setValue(collMapper.selectCons1(orgNos));
            list2.setTypeUnit("户");
            lists.add(list2);
            StatisticsList list3 = new StatisticsList();
            list3.setType(3);
            list3.setTypeName("0.4kV线路长度");
            list3.setValue(collMapper.selectLine2(orgNos));
            list3.setTypeUnit("千米");
            lists.add(list3);
            StatisticsList list4 = new StatisticsList();
            list4.setType(4);
            list4.setTypeName("10kV线路长度");
            list4.setValue(collMapper.selectLine1(orgNos));
            list4.setTypeUnit("千米");
            lists.add(list4);
            StatisticsList list5 = new StatisticsList();
            list5.setType(5);
            list5.setTypeName("在运专变数量");
            list5.setValue(collMapper.selectPub1(orgNos));
            list5.setTypeUnit("个");
            lists.add(list5);
            StatisticsList list6 = new StatisticsList();
            list6.setType(6);
            list6.setTypeName("在运公变数量");
            list6.setValue(collMapper.selectPub2(orgNos));
            list6.setTypeUnit("个");
            lists.add(list6);
            StatisticsList list7 = new StatisticsList();
            list7.setType(7);
            list7.setTypeName("在运电能表数量");
            list7.setValue(collMapper.selectCMeter1(orgNos));
            list7.setTypeUnit("个");
            lists.add(list7);
            StatisticsList list8 = new StatisticsList();
            list8.setType(8);
            list8.setTypeName("在运采集终端设备");
            list8.setValue(collMapper.selectCMeter2(orgNos));
            list8.setTypeUnit("个");
            lists.add(list8);
            place.setStatisticsList(lists);
        }else {
            List<String> orgNos = new ArrayList<>();
            orgNos.add(orgNo);
            place.setScopeOfServices("null");
            List<StatisticsList> lists = new ArrayList<>();
            StatisticsList list1 = new StatisticsList();
            list1.setType(1);
            list1.setTypeName("低电压用户数量");
            list1.setValue(collMapper.selectCons2(orgNos));
            list1.setTypeUnit("户");
            lists.add(list1);
            StatisticsList list2 = new StatisticsList();
            list2.setType(2);
            list2.setTypeName("高压用户数量");
            list2.setValue(collMapper.selectCons1(orgNos));
            list2.setTypeUnit("户");
            lists.add(list2);
            StatisticsList list3 = new StatisticsList();
            list3.setType(3);
            list3.setTypeName("0.4kV线路长度");
            list3.setValue(collMapper.selectLine2(orgNos));
            list3.setTypeUnit("千米");
            lists.add(list3);
            StatisticsList list4 = new StatisticsList();
            list4.setType(4);
            list4.setTypeName("10kV线路长度");
            list4.setValue(collMapper.selectLine1(orgNos));
            list4.setTypeUnit("千米");
            lists.add(list4);
            StatisticsList list5 = new StatisticsList();
            list5.setType(5);
            list5.setTypeName("在运专变数量");
            list5.setValue(collMapper.selectPub1(orgNos));
            list5.setTypeUnit("个");
            lists.add(list5);
            StatisticsList list6 = new StatisticsList();
            list6.setType(6);
            list6.setTypeName("在运公变数量");
            list6.setValue(collMapper.selectPub2(orgNos));
            list6.setTypeUnit("个");
            lists.add(list6);
            StatisticsList list7 = new StatisticsList();
            list7.setType(7);
            list7.setTypeName("在运电能表数量");
            list7.setValue(collMapper.selectCMeter1(orgNos));
            list7.setTypeUnit("个");
            lists.add(list7);
            StatisticsList list8 = new StatisticsList();
            list8.setType(8);
            list8.setTypeName("在运采集终端设备");
            list8.setValue(collMapper.selectCMeter2(orgNos));
            list8.setTypeUnit("个");
            lists.add(list8);
            place.setStatisticsList(lists);
        }
        return place;
    }

    /**
     *
     * @param orgNo
     * @param type 类型(1:所 2:站) 表中获取
     * @return
     */
    @GetMapping("/synthesis-ranking1")
    @ResponseBody
    @ApiOperation(value = "2.2 综合排名")
    public Object SynthesisRanking1(@RequestParam(required = false) String orgNo,@RequestParam(required = false) int type){
        List<Synthesis> synthesis = new ArrayList<>();

        if(type==1) {
            List<AcCounty> acCounties = acstaMapper.selectAllAcCounty(TimeUtil.getStartTime(), null);
            for (int i=0;i<acCounties.size();i++) {
                Synthesis synthesis1 = new Synthesis();
                synthesis1.setId(acCounties.get(i).getOrgNo());
                synthesis1.setName(acCounties.get(i).getCountyName());
                synthesis1.setSort(i+1);
                synthesis1.setCurrentDayIntegrate(Integer.parseInt(acCounties.get(i).getToPoint()));
                synthesis1.setCurrentMonthIntegrate(Integer.parseInt(acCounties.get(i).getToPoint()));
                synthesis.add(synthesis1);
            }
            return synthesis;
        }else if(type==2){
            List<AcStation> acStations = acstaMapper.selectAllStation(TimeUtil.getStartTime(), orgNo, null);
            for (int i = 0; i < acStations.size(); i++) {
                Synthesis synthesis1 = new Synthesis();
                synthesis1.setId(acStations.get(i).getOrgNo());
                synthesis1.setName(acStations.get(i).getStationName());
                synthesis1.setSort(i+1);
                synthesis1.setCurrentDayIntegrate(Integer.parseInt(acStations.get(i).getToPoint()));
                synthesis1.setCurrentMonthIntegrate(Integer.parseInt(acStations.get(i).getToPoint()));
                synthesis.add(synthesis1);
            }
        }
        return synthesis;
    }


    /**
     *
     * @param orgNo 供电单位编号
     * @param type 类型 1:所 2:站
     * @param workorderType 工单类型 1:待办 2:预警
     * @return
     */
    @ApiOperation(value = "2.3 待办、预警工单", notes = "导入")
    @GetMapping("/upcoming-warning-workOrder1")
    @ResponseBody
    public Object QueryAllWarningWorkOrder1(@RequestParam(required = false) String orgNo,@RequestParam(required = false) Integer type,
                                           @RequestParam String workorderType){
        List<WarningWorkOrder> list=new ArrayList<>();
        List<String> orgNames = new ArrayList<>();
        List<OrgNoName> orgNoNames = collMapper.selectStation1(orgNo);
        for (OrgNoName orgNoName : orgNoNames) {
            orgNames.add(orgNoName.getOrgName());
        }
        if(type == 1){
            WarningWorkOrder wW = new WarningWorkOrder();
            wW.setMeteringCollection(thDapiService.selectUpcomingWarning1(orgNames,workorderType));//采集 和计量工单数
            wW.setLineLossManagement(thDapiService.selectUpcomingWarning2(orgNames,workorderType));//线损治理的工单数
            wW.setCostControlRecovery(thDapiService.selectUpcomingWarning3(orgNames,workorderType));//费控复电工单数
            wW.setElectricityBill(thDapiService.selectUpcomingWarning4(orgNames,workorderType));//电费回收工单数
            wW.setService(thDapiService.selectUpcomingWarning5(orgNames,workorderType));//服务工单数（优质服务）
            wW.setOperationAndMaintenance(thDapiService.selectUpcomingWarning6(orgNames,workorderType));//运维抢修工单数
            list.add(wW);
        }else {
            WarningWorkOrder wW=new WarningWorkOrder();
            wW.setMeteringCollection(thDapiService.selectUpcomingWarning1(orgNames,workorderType));//采集 和计量工单数
            wW.setLineLossManagement(thDapiService.selectUpcomingWarning2(orgNames, workorderType));//线损治理的工单数
            wW.setCostControlRecovery(thDapiService.selectUpcomingWarning3(orgNames, workorderType));//费控复电工单数
            wW.setElectricityBill(thDapiService.selectUpcomingWarning4(orgNames, workorderType));//电费回收工单数
            wW.setService(thDapiService.selectUpcomingWarning5(orgNames, workorderType));//服务工单数（优质服务）
            wW.setOperationAndMaintenance(thDapiService.selectUpcomingWarning6(orgNames, workorderType));//运维抢修工单数
            list.add(wW);
        }
        return list;
    }


    @ApiOperation(value = "2.4 所业绩指标 ")
    @GetMapping("/place-performance-indicators1")
    @ResponseBody
    public Object QueryAllPlaceperForMance1(@RequestParam(required = false) String orgNo,@RequestParam(required = false) Integer type){
        PlaceperForMance pm=new PlaceperForMance();
        if(type==1) {
            List<AcCounty> acCounties = acstaMapper.selectAllAcCounty(TimeUtil.getStartTime(), orgNo);
            pm.setTheCompanyTotalPointsForTheDay(Integer.parseInt(acCounties.get(0).getToPoint()));//总积分
            pm.setCompanyRankingOfTheDay(Integer.parseInt(acCounties.get(0).getRanking()));//排名
            List<Indicators> list1 = new ArrayList<>();
            pm.setIndicators(TdApiUtil.getTdCountPoint(list1, acCounties.get(0)));
        }else {
            List<AcCounty> acCounties = acstaMapper.selectAllAcCounty(TimeUtil.getStartTime(), orgNo);
            pm.setTheCompanyTotalPointsForTheDay(Integer.parseInt(acCounties.get(0).getToPoint()));//总积分
            pm.setCompanyRankingOfTheDay(Integer.parseInt(acCounties.get(0).getRanking()));//排名
            List<Indicators> list1 = new ArrayList<>();
            pm.setIndicators(TdApiUtil.getTdCountPoint(list1, acCounties.get(0)));
        }
        return pm;
    }

    @GetMapping("station-performance-indicators1")
    @ResponseBody
    @ApiOperation(value = "2.5 站业绩指标")
    public Object StationPerformanceIndicators1(@RequestParam(required = false) String orgNo, @RequestParam(required = false) int type){
        Performance performance = new Performance();
        if(type==1) {
            List<AcStation> acStations = acstaMapper.selectAllStation(TimeUtil.getStartTime(), orgNo, null);
            performance.setPowerStationTodayTotalIntegrate(Integer.parseInt(acStations.get(0).getToPoint()));
            performance.setQiCountyCompanyTodayRanking(null);//旗县公司当日排名
            performance.setCityCompanyTodayRanking(null);//市公司当日排名
            List<Indicators> lists = new ArrayList<>();
            performance.setIndicators(TdApiUtil.getTdStationPoint(lists, acStations.get(0)));
        }else {
            List<AcStation> acStations = acstaMapper.selectAllStation(TimeUtil.getStartTime(), orgNo, null);
            performance.setPowerStationTodayTotalIntegrate(Integer.parseInt(acStations.get(0).getToPoint()));
            performance.setQiCountyCompanyTodayRanking(null);//旗县公司当日排名
            performance.setCityCompanyTodayRanking(null);//市公司当日排名
            List<Indicators> lists = new ArrayList<>();
            performance.setIndicators(TdApiUtil.getTdStationPoint(lists, acStations.get(0)));
        }
        return performance;
    }

    @GetMapping("district-performance-indicators1")
    @ResponseBody
    @ApiOperation(value = "2.6 区业绩指标")
    public Object DistrictPerformanceIndicators1(@RequestParam(required = false) String userName, @RequestParam(required = false) int type){
        Performance1 performance = new Performance1();
        if(type==1) {
            List<AcManager> acManagers = acstaMapper.selectByStation(TimeUtil.getStartTime(), null, null, userName);
            performance.setAccountManagerTodayTotalIntegrate(Integer.parseInt(acManagers.get(0).getToPoint()));
            performance.setQiCountyCompanyTodayRanking(null);//旗县公司当日排名
            performance.setPowerStationTodayRanking(null);//市公司当日排名
            List<Indicators> lists = new ArrayList<>();
            performance.setIndicators(TdApiUtil.getTdManagerPoint(lists, acManagers.get(0)));
        }else {
            List<AcManager> acManagers = acstaMapper.selectByStation(TimeUtil.getStartTime(), null, null, userName);
            performance.setAccountManagerTodayTotalIntegrate(Integer.parseInt(acManagers.get(0).getToPoint()));
            performance.setQiCountyCompanyTodayRanking(null);//旗县公司当日排名
            performance.setPowerStationTodayRanking(null);//市公司当日排名
            List<Indicators> lists = new ArrayList<>();
            performance.setIndicators(TdApiUtil.getTdManagerPoint(lists, acManagers.get(0)));
        }
        return performance;
    }

    @GetMapping("/district-work-order-completion1")
    @ResponseBody
    @ApiOperation(value = "2.7 区工单完成情况")
    public Object threeDimensional1(@RequestParam(required = false) String userName, @RequestParam(required = false) int type){
        WorkOrderCompletion workOrderCompletion = new WorkOrderCompletion();
        workOrderCompletion.setCurrentMonthGrandTotal(96);//当月累计工单0
        workOrderCompletion.setToBeProcessed(14);//待处理
        workOrderCompletion.setProcessing(11);//处理中
        workOrderCompletion.setProcessed("11");//已处理
        List<DetailList> detailLists = new ArrayList<>();
        DetailList detailList = new DetailList();
        detailList.setWorkOrderType(1);
        detailList.setCurrentMonthTotal(98);
        detailList.setToBeProcessed(14);
        detailList.setToBeProcessed(10);
        detailList.setToBeProcessed(12);
        detailList.setToBeProcessed(67);
        detailLists.add(detailList);
        DetailList detailList1 = new DetailList();
        detailList1.setWorkOrderType(2);
        detailList1.setCurrentMonthTotal(112);
        detailList1.setToBeProcessed(19);
        detailList1.setToBeProcessed(11);
        detailList1.setToBeProcessed(12);
        detailList1.setToBeProcessed(71);
        detailLists.add(detailList1);
        workOrderCompletion.setDetailList(detailLists);
        return workOrderCompletion;
    }



    @RequestMapping("getUserRole")
    @ResponseBody
    @ApiOperation(value = "获取用户权限信息")
    private Map<String,String> getUserRole(HttpServletRequest request){
        Map<String,String> map = new HashMap<>();
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
        for (int i = 0; i < cookies.length; i++) {
            Cookie ck = cookies[i];
//            if (ck.getName().equals("role")) {
//                map.put("role",ck.getValue());
                map.put(ck.getName(),ck.getValue());
//            }
        }
    }
        return map;
    }


    @RequestMapping("getTgLineName")
    @ResponseBody
    @ApiOperation(value = "获取台区高压线路名称")
    private R<?> getTgLineName(@RequestParam String districtNumber){
        //使用SQL根据台区id查询台区下面的线路名称
        List<DocumentInfoVo> loadNames = collMapper.selectTgLoad(districtNumber);
        return R.ok(loadNames);
    }


    @RequestMapping("getUserDoc")
    @ResponseBody
    @ApiOperation(value = "获取文档信息")
    private R<?> getUserdoc(@RequestParam String documentField){

        //使用SQL对传递的字段进行多字段模糊查询
        List<DocumentInfoVo> documentInfoVos = collMapper.selectDocumentInfo(documentField);
        /*//如果集合中有数据的话,将集合中的tradeCode字段码值转换成文字
        if (documentInfoVos.size() > 0) {
            conversionTradeCode(documentInfoVos);
        }*/
        return R.ok(documentInfoVos);
    }



    @RequestMapping("/getLoadRate")
    @ResponseBody
    @ApiOperation(value = "获取负载率")
    public R<LoadRateVo> getLoadRate(@RequestParam String tgNo) {


        String beforeTwoDay = TimeUtil.getTodayTime2();

        //查询出台区变压容量
        LoadRateVo loadRateVo = collMapper.selectLoadRate(tgNo, beforeTwoDay);

        if (loadRateVo == null) {
            return R.ok(loadRateVo);
        }else {
            //计算出I1
            BigDecimal I1 = BigDecimal.valueOf(loadRateVo.getTgCap())
                    .divide(BigDecimal.valueOf(1.732), 4, RoundingMode.HALF_UP)
                    .divide(BigDecimal.valueOf(0.4), 2, RoundingMode.HALF_UP);

            //计算I2,I2=(A+B+C)/3 * t_factor
            BigDecimal I2 = BigDecimal.valueOf(30).divide(BigDecimal.valueOf(3), 4, RoundingMode.HALF_UP)
                    .multiply(BigDecimal.valueOf(1));

            //求可用容量,负载率=I1/I2*100% ,可用容量 = tg_cap * 负载率
            if (BigDecimal.ZERO.equals(I2)) {
                //如果I2为空
                LoadRateVo load = new LoadRateVo();
                load.setTgCap(loadRateVo.getTgCap());
                return R.ok(load);
            }else {
                //如果I2不为空
                BigDecimal variableCap = I1.multiply(BigDecimal.valueOf(loadRateVo.getTgCap()))
                        .divide(I2, 2, RoundingMode.HALF_UP);
                LoadRateVo loadRate = new LoadRateVo();
                loadRate.setTgCap(loadRateVo.getTgCap());
                loadRate.setVariableCap(variableCap);

                return R.ok(loadRate);
            }
        }
    }


    /**
     * 根据上级id查询下级的id和name
     * @param id
     * @return
     */
    @RequestMapping("/getNameForId")
    @ResponseBody
    @ApiOperation(value = "根据上级id查询下级的id和name")
    public R<List<LoadRateVo>> getNameForId(@RequestParam String id) {

        List<LoadRateVo> list = collMapper.getNameForId(id);
        return R.ok(list);
    }

    /**
     * 根据台区经理获取用户的id和name
     */
    @RequestMapping("/getUserNameForId")
    @ResponseBody
    @ApiOperation(value = "获取用户信息")
    public R<List<LoadRateVo>> getUserNameForId(@RequestParam String id) {
        List<LoadRateVo> list = collMapper.getUserNameForId(id);
        return R.ok(list);
    }
}
