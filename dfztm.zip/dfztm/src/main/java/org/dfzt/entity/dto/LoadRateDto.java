package org.dfzt.entity.dto;

import lombok.Data;

@Data
public class LoadRateDto {

    /**
     * 市id
     */
    private String cityId;

    /**
     * 所id
     */
    private String placeId;

    /**
     * 站id
     */
    private String stationId;

}
