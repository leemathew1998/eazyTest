package com.exam.modules.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.exam.modules.entity.ExamInfo;
import com.exam.modules.entity.ExamManage;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @Author dyy
 * @Date 2022/11/8 17:28
 * @PackageName:com.exam.modules.entity.vo
 * @ClassName: ExamManageVo
 * @Description: TODO
 * @Version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExamManageVo extends ExamManage{
    private Long pageNo = 1L;//当前页码
    private Long pageSize = 10L;//每页显示数量
    //考试信息id
    private Long eid;
    //考生id
    private Long userId;
    //试卷id
    private Long examPaperId;
    //试卷名称
    private String examPaperName;
    //考试id
    private Long examId;
    //考试名称
    private String examName;
    //考生姓名
    private String userName;
    //所属组别
    private String theGroup;
    //出题人
    private String theAuthor;
    //试卷总分
    private String pSum;
    //成绩
    private String scoreSum;
    //异常行为
    private String abnormal;
    //阅卷状态(1.已阅卷 2.未完成 3.未阅卷)
    private String markStatus;
    //阅卷人
    private String markBy;
    //阅卷时间
    private Date markTime;
    //考试时间
    private Date examTime;
    //是否参加考试（1-是,2-否）
    private String isTrue;
//    //应考人数
//    private long sumNum;
private Date beginTime;
private Date endTime;
}
