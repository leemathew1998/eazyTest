package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.dto.ExecuteLog;
import org.dfzt.entity.dto.ExecuteLogDetail;


public interface ExecuteLogDetailMapper extends BaseMapper<ExecuteLogDetail> {

}

