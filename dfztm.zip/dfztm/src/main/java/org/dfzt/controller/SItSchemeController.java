package org.dfzt.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.dfzt.entity.po.SItScheme;
import org.dfzt.service.SItSchemeService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.io.Serializable;

/**
 * (SItScheme)表控制层
 *
 * @author makejava
 * @since 2022-08-01 10:11:26
 */
@RestController
@RequestMapping("sItScheme")
public class SItSchemeController extends ApiController {
    /**
     * 服务对象
     */
    @Resource
    private SItSchemeService sItSchemeService;

    /**
     * 分页查询所有数据
     *
     * @param page      分页对象
     * @param sItScheme 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll")
    public R selectAll(Page<SItScheme> page, SItScheme sItScheme) {
        return success(this.sItSchemeService.page(page, new QueryWrapper<>(sItScheme)));
    }

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @PostMapping("/selectOne/{id}")
    public R selectOne(@PathVariable Serializable id) {
        return success(this.sItSchemeService.getById(id));
    }

    /**
     * 新增数据
     *
     * @param sItScheme 实体对象
     * @return 新增结果
     */
    @PostMapping("insert")
    public R insert(@RequestBody SItScheme sItScheme) {
        return success(this.sItSchemeService.save(sItScheme));
    }

    /**
     * 修改数据
     *
     * @param sItScheme 实体对象
     * @return 修改结果
     */
    @PostMapping("update")
    public R update(@RequestBody SItScheme sItScheme) {
        return success(this.sItSchemeService.updateById(sItScheme));
    }

    /**
     * 删除数据
     *
     * @param id 主键
     * @return 删除结果
     */
    @PostMapping("delete")
    public R delete(Integer id) {
        return success(this.sItSchemeService.removeById(id));
    }
}
