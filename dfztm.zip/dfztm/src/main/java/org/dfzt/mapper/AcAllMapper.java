package org.dfzt.mapper;

import org.dfzt.entity.po.AcAll;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AcAllMapper {

    int insertSelective(AcAll record);

    AcAll selectByPrimaryKey(Integer id);


    Integer selectStaconsNums(String orgNo,String ymd);//营业站管辖用户数
    Integer selectStatgNums(String orgNo,String ymd);//营业站管辖台区数

    Integer selectCouconsNums(String orgNo,String ymd);//所站管辖用户数
    Integer selectCoutgNums(String orgNo,String ymd);//所站管辖台区数

    AcAll selectAcAll(String orgNo,String ymd,String acId);//旗县所站
    AcAll selectAcAllMa(String orgNo,String ymd,String acId);//台区经理



    //List<String> selectStaNums(String orgNo);//查询营业站用户数
}