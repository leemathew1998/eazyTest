package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/15
 * @Version: 1.00
 */
@Data
public class consTgScm implements Serializable {
    private String realName;
    private String orgName;
    private String orgNo;
    private String pOrgName;
    private String pOrgNo;
    private String orgType;

}
