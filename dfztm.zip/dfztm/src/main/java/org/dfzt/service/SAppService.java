package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.SApp;

import java.util.List;

/**
* @author 李木
* @description 针对表【s_app】的数据库操作Service
* @createDate 2023-05-29 10:15:10
*/
public interface SAppService extends IService<SApp> {

    void insertUserRepairOrder();

    void updateUserRepairOrder();

    void insertPicmaWorkOrder();
}
