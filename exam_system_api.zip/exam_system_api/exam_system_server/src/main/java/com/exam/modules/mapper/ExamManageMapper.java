package com.exam.modules.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import com.exam.modules.entity.ExamManage;
import org.apache.ibatis.annotations.SelectKey;

/**
 * 考试管理(ExamManage)表数据库访问层
 *
 * @author makejava
 * @since 2022-11-08 17:16:06
 */
public interface ExamManageMapper extends BaseMapper<ExamManage> {

}


