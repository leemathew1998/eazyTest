package org.dfzt.entity.vo;

import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "OverhaulInfor对象", description = "")
public class OverhaulInfor implements Serializable {


    @ApiModelProperty(value = "id（检修信息")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "消耗运维材料")
    @TableField("consume_material")
    private String consumeMaterial;

    @ApiModelProperty(value = "处理后照片")
    //@Excel(name = "处理后照片",orderNum = "11",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    @TableField("handle_photo")
    private String handlePhoto;

    @ApiModelProperty(value = "工作票照片")
    //@Excel(name = "工作票照片",orderNum = "12",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    @TableField("work_photo")
    private String workPhoto;

    @ApiModelProperty(value = "监控班许可照片")
    //@Excel(name = "监控班许可照片",orderNum = "13",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    @TableField("monitor_photo")
    private String monitorPhoto;

    @ApiModelProperty(value = "安全措施照片")
    //@Excel(name = "安全措施照片",orderNum = "14",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    @TableField("safe_photo")
    private String safePhoto;

    @ApiModelProperty(value = "到岗到位许可检查安全措施是否完备照片并同意开工照片")
    //@Excel(name = "到岗到位许可检查安全措施是否完备照片并同意开工照片",orderNum = "15",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    @TableField("agree_start_photo")
    private String agreeStartPhoto;

    @ApiModelProperty(value = "缺陷缺陷处理后照片")
    //@Excel(name = "缺陷缺陷处理后照片",orderNum = "16",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    @TableField("defect_photo")
    private String defectPhoto;

    @ApiModelProperty(value = "安全措施拆除照片")
    //@Excel(name = "安全措施拆除照片",orderNum = "17",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    @TableField("safe_dismantle_photo")
    private String safeDismantlePhoto;

    @ApiModelProperty(value = "关联工单编号")
    @TableField("work_order_no")
    private String workOrderNo;


}
