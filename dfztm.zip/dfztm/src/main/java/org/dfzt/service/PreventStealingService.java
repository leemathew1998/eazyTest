package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.PreventStealing;

import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/5
 * @Version: 1.00
 */
public interface PreventStealingService extends IService<PreventStealing> {

    List<PreventStealing> PreventStealingServiceSelect();


    List<PreventStealing> selectNo();

    List<PreventStealing> selectAllStatus(PreventStealing p);

    List<Map<String, Object>> statusNumber();
}
