package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.RCp;

/**
 * (RCp)表服务接口
 *
 * @author makejava
 * @since 2022-07-29 16:39:48
 */
public interface RCpService extends IService<RCp> {

}

