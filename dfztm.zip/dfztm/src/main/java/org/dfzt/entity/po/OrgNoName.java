package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/17
 * @Version: 1.00 供电单位和供电名称
 */
@Data
public class OrgNoName implements Serializable {
    private String orgNo;
    private String orgName;
}
