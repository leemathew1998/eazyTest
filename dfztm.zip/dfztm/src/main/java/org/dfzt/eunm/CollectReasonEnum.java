package org.dfzt.eunm;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/11
 * @Version: 1.00
 */
public enum CollectReasonEnum {
    REASON_ONE("1","采集设备掉线"),
    REASON_TWO("2","485线问题"),
    REASON_THREE("3","表前开关掉线，时钟错误"),
    REASON_FOUR("4","模块、表计故障"),
    REASON_FIVE("5","采集异常，需要补抄"),
    REASON_SIX("6","采集未接入");

    private final String name;
    private final String value;

    CollectReasonEnum(String name,String value){
        this.name = name;
        this.value = value;
    }

    // 将数据缓存到map中
    private static final Map<String, String> map = new HashMap<>();

    static {
        for (CollectReasonEnum color : CollectReasonEnum.values()) {
            map.put(color.getName(), color.getValue());
        }
    }

    // 根据name查询value值
    public static String getValueByName(String name) {
        return map.get(name);
    }

    // 根据name查询value值
    public static String getNameByValue(String value) {
        switch (value){
            case "采集设备掉线": {
                return "1";
            }
            case "485线问题": {
                return "2";
            }
            case "表前开关掉线，时钟错误": {
                return "3";
            }
            case "模块、表计故障": {
                return "4";
            }
            case "采集异常，需要补抄": {
                return "5";
            }
            case "采集未接入": {
                return "6";
            }
        }
        return "错误";
    }

    public String getName() {
        return name;
    }

    public String getValue() {
        return value;
    }
}
