package org.dfzt.job;

import org.dfzt.service.SAppService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

@Component
public class InternetAndInternetOffice extends QuartzJobBean {

    @Autowired
    private SAppService appService;

    /**
     * 每15分钟从S_APP表获取申请方式（APP_MODE）为政务WEB端且申请业务类型（APP_TYPE_CODE）为过户的数据
     *
     * @param context
     * @throws JobExecutionException
     */
    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

        try {
            appService.insertUserRepairOrder();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            appService.updateUserRepairOrder();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
