package org.dfzt.mapper;

import java.util.List;
import java.util.Map;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.dfzt.entity.po.ARcvblFlow;
import org.dfzt.entity.po.SuperiorWorkOrder;
import org.dfzt.entity.vo.RecycleWorkOrder;

/**
 * (RecycleWorkOrder)表数据库访问层
 *
 * @author makejava
 * @since 2022-07-11 15:38:15
 */
@Mapper
public interface RecycleWorkOrderMapper extends BaseMapper<RecycleWorkOrder> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<RecycleWorkOrder> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<RecycleWorkOrder> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<RecycleWorkOrder> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<RecycleWorkOrder> entities);

    /**
     * 状态扭转
     * @param
     * @return
     */
    int updateRecycleWorkOrder(String workOrderStatus,String workOrderNo);

    /**
     * 查询历史工单
     * @param workOrderId
     * @return
     */
    RecycleWorkOrder selectRecycleWordOrderId(String workOrderId);

    int insertSelective(org.dfzt.entity.po.RecycleWorkOrder recwo);

    List<RecycleWorkOrder> selectByNoSta4();//查询当月没有完成的工单（状态4）

    int updateCycle1(String workorderNo); //根据工单编号 将查询没有清空的工单设置为一级预警
    int updateCycle2(String workorderNo); //根据工单编号 将查询没有清空的工单设置为二级预警

    int updateDes(String workOrderDes,String workorderNo);//根据工单编号 添加工单处理描述信息

    int updateStatus2(String workorderNo);//根据工单编号修改工单状态 2
    int updateStatus3(String workorderNo);//根据工单编号修改工单状态 3
    int updateStatus4(String workorderNo);//根据工单编号修改工单状态 4


    /**
     * 查询登录人员
     * @param loginName
     * @return
     */
//    @Select("SELECT user_role FROM sys_user WHERE login_name = #{loginName}")
//    String selRole(String loginName);

    /**
     * 敏感用户工单查询
     * @return
     */
    List<SuperiorWorkOrder> selectWorkOrderList(RecycleWorkOrder recycleWorkorder);


    List<org.dfzt.entity.po.RecycleWorkOrder> selectRecyclerList(@Param("r") org.dfzt.entity.po.RecycleWorkOrder r,@Param("pageNo") Integer pageNo,@Param("pageSize") Integer pageSize,@Param("status") String status,@Param("orgName") String orgName);
}

