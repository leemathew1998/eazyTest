package com.exam.modules.entity.vo;

import com.exam.modules.entity.SysMenu;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author dyy
 * @Date 2022/11/3 19:27
 * @PackageName:com.exam.modules.entity.vo
 * @ClassName: RoleMenuVo
 * @Description: TODO 封装权限菜单数据回显
 * @Version 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoleMenuVo {
    /**
     * 菜单数据
     */
    private List<SysMenu> menuList = new ArrayList<SysMenu>();
    /**
     * 该角色原有分配的菜单数据
     */
    private Object [] checkList;
}
