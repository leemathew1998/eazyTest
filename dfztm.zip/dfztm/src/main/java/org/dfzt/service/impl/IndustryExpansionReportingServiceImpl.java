package org.dfzt.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.IndustryExpansionReporting;

import org.dfzt.mapper.IndustryExpansionReportingMapper;
import org.dfzt.service.IndustryExpansionReportingService;
import org.springframework.stereotype.Service;

/**
* @author luo
* @description 针对表【Industry_expansion_reporting(业扩报装)】的数据库操作Service实现
* @createDate 2022-08-03 10:30:03
*/
@Service
public class IndustryExpansionReportingServiceImpl extends ServiceImpl<IndustryExpansionReportingMapper, IndustryExpansionReporting>
    implements IndustryExpansionReportingService {

}




