package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.AcCity;
import org.dfzt.entity.po.AcCounty;
import org.dfzt.entity.po.AcManager;
import org.dfzt.entity.po.AcStation;
import org.dfzt.entity.vo.AcManagerSp;
import org.dfzt.entity.vo.AcStationSp;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * (AcStation)表数据库访问层
 *
 * @author makejava
 * @since 2022-07-15 09:21:04
 */
@Repository
public interface AcStationMapper extends BaseMapper<AcStation> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<AcStation> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<AcStation> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<AcStation> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<AcStation> entities);

    List<AcStation> selectAllStation(String ymd,String orgNo,String id);
    List<AcStation> selectAllStation1(String ymd,String orgNo,String id);

    List<AcManager> selectByStation(String ymd,String orgNo,String id,String tgManager);//根据营业站id查询该营业站下所有台区信息

    List<AcStation> selectByCounty(Integer id);//根据旗县id查询该营业站下所有台区信息

    List<Map> selectFailure();//查询旗县下营业站采集失败总数

    List<AcManager> selectStationP(String acStationId);//通过营业站id查询该营业站下所有台区经理的信息

    int updateSnum(String acStationId, int stanum);//根据营业站id修改营业站总失败条数

    int updatestaPR(String AcStationId, BigDecimal colSuccR, int colSuccP);//根据营业站id修改采集成功率指标和积分

    AcStation selectOneStation(String acStationId);//根据营业站id查看修改后的所有指标和积分

    AcCounty selectOneCounty(String acCountyId);//根据营业站id查看修改后的所有指标和积分
//    AcStation selectOneStation(Integer id);

    List<AcCounty> selectAllAcCounty(String ymd,String orgNo);//查询旗县的积分和排名
    List<AcCounty> selectAllAcCounty1(String ymd,String id);//查询旗县的积分和排名

    List<AcManagerSp> selectacManagerSp(String id, String sevenday, String endday, String tgManager);//查询台区经理近七天的数据

    List<AcManager> selectManagerGroupBy(String id,String sevenday, String endday);//查询营业站的台区经理有哪些


    List<AcStationSp> selectacStationSp(String id, String sevenday, String endday, String stationName);//查询台区经理近七天的数据

    List<AcStation> selectStationGroupBy(String id,String sevenday, String endday);//查询营业站的台区经理有哪些

    AcStation selectTdStation(String stationName,String datedm);

    Integer selectWorkO1(@Param("tgManager") String tgManager,@Param("ym") String ym,@Param("status") String status,@Param("cycle") String cycle);//采集当月台区经理个数
    Integer selectWorkO2(@Param("tgManager") String tgManager,@Param("ym") String ym);//计量当月台区经理个数
    Integer selectWorkO3(@Param("tgManager") String tgManager,@Param("ym") String ym);//线损当月台区经理个数
    Integer selectWorkO4(@Param("tgManager") String tgManager,@Param("ym") String ym);//费控当月台区经理个数
    Integer selectWorkO5(@Param("tgManager") String tgManager,@Param("ym") String ym);//回收当月台区经理个数
    Integer selectWorkO6(@Param("tgManager") String tgManager,@Param("ym") String ym);//补抄当月台区经理个数
    Integer selectWorkO7(@Param("tgManager") String tgManager,@Param("ym") String ym);//服务当月台区经理个数

    List<AcCity> selectAllAcCity(@Param("ymd") String ymd, @Param("orgNo") String orgNo);
}

