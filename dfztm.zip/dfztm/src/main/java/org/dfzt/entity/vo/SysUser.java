package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import nonapi.io.github.classgraph.json.Id;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class SysUser {
  @Id
  @TableId(value = "id",type = IdType.AUTO)
  private Long id;
  private String loginName;
  private String passWord;
  private String userRole;
  private String userStation;
  private String reserveOne;
  private String pNo;
  private String reserveThree;
}
