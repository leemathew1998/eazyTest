package org.dfzt.service;


import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.vo.ActiveOperation;
import org.dfzt.entity.vo.DefectRepair;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
public interface DefectRepairService extends IService<DefectRepair> {
  /**
   * 主动运维-处理缺陷-添加成功
   *
   * @param defectRepair
   * @return
   */
   R add(DefectRepair defectRepair);


    int insertDefectRepair(DefectRepair defectRepair);//缺陷立行立改修复录入信息

    R updateDefectRepair(ActiveOperation activeOperation);
}
