package org.dfzt.util;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/5/26
 * @Version: 1.00
 */
public class FailTypeUtil {

    public static String CollectFail(String terminalState,int count,String userType) {
            if (terminalState.equals("中断")) {
                //采集设备掉线，将数据存到工单表里
                //工单表进行添加操作，给研判原因赋值 1;
                //采集失败 工单编号开头可以赋值给f+时间
                return "1";
            } else if (terminalState.equals("运行")) {//通信状态为正常
                if (userType.contains("A")||userType.contains("B")||userType.contains("F")) {//用户类型为A类 B类 F类
                    //485线问题 任务，将数据存到工单表里
                    //工单表进行添加操作，给研判原因赋值 2;
                    return "2";
                } else if (userType.contains("C")||userType.contains("D")||userType.contains("E")) {//用户类型为C D E类
                    //查询终端数据相同的数据
                    if (count >= 10) {
                        //表前开关掉线 时钟错误
                        //工单表进行添加操作，给研判原因赋值 3
                        return "3";
                    } else if (count < 10) {
                        //模块、表计故障，表前开关掉线，时钟错误
                        //工单表进行添加操作，给研判原因赋值 4
                        return "4";
                    }
                }
            }
            return "0";
    }
}
