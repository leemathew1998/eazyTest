package org.dfzt.util;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.converters.Converter;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;
import org.dfzt.entity.xmlDemoReal.DemoConverter;


/**
 * @ClassName XStreamUtils
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/14 18:58
 */
public class XStreamUtils {
    /**
     * 将Object转换为xml
     * @param obj 转换的bean
     * @return bean转换为xml
     */
    public static String objectToXml(Object obj) {
        XStream xStream = new XStream();
        xStream.autodetectAnnotations(true);
        //xstream使用注解转换
        xStream.processAnnotations(obj.getClass());
        return xStream.toXML(obj);
    }

    public static String objectToXml(Object obj,Converter converter) {
        XStream xStream = new XStream();
        xStream.autodetectAnnotations(true);
        xStream.registerConverter(new DemoConverter());
        //xstream使用注解转换
        xStream.processAnnotations(obj.getClass());
        return xStream.toXML(obj);
    }

    /**
     * 将xml转换为T
     * @param <T> 泛型
     * @param xml 要转换为T的xml
     * @param cls T对应的Class
     * @return xml转换为T
     */
    public static <T> T xmlToObject(String xml, Class<T> cls) {
        XStream xstream = new XStream(new DomDriver());
        xstream.autodetectAnnotations(true);
        xstream.addPermission(AnyTypePermission.ANY);
        //xstream使用注解转换
        xstream.processAnnotations(cls);
        xstream.setClassLoader(cls.getClassLoader());
        @SuppressWarnings("unchecked")
        T t = (T) xstream.fromXML(xml);
        /*后加入*/
        return t ;
    }


    public static <T> T xmlToObject(String xml, Class cls, Converter converter) {
        XStream xstream = new XStream();
        xstream.autodetectAnnotations(true);
        xstream.addPermission(AnyTypePermission.ANY);
        xstream.registerConverter(converter);
        //xstream使用注解转换
        xstream.processAnnotations(cls);
        xstream.setClassLoader(cls.getClassLoader());
        @SuppressWarnings("unchecked")
        T t = (T) xstream.fromXML(xml);
        /*后加入*/
        return t ;
    }
}
