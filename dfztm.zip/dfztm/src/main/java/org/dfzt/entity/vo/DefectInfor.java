package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "DefectInfor对象", description = "")
public class DefectInfor implements Serializable {


    @ApiModelProperty(value = "id(缺陷信息录入表)")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "缺陷序号")
    @TableField("defect_no")
    private String defectNo;

    @ApiModelProperty(value = "缺陷定级 一般、严重、危急(危急需要关联主动抢修)")
    @TableField("defect_grade")
    private String defectGrade;

    @ApiModelProperty(value = "缺陷位置")
    @TableField("defect_add")
    private String defectAdd;

    @ApiModelProperty(value = "缺陷描述")
    @TableField("defect_describe")
    private String defectDescribe;

    @ApiModelProperty(value = "缺陷照片")
    @TableField("defect_photo")
    private String defectPhoto;

    @ApiModelProperty(value = "缺陷整改后的照片")
    @TableField("reform_photo")
    private String reformPhoto;

    @ApiModelProperty(value = "缺陷发现时间")
    @TableField("defect_date")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    private Date defectDate;

    @ApiModelProperty(value = "计划消缺时间 制定检修计划(检修计划在别的系统确定后，人为录入，没有时间限制，非必填项)后再填写")
    @TableField("defect_plan_time")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
//    @JsonFormat(pattern = "yyyy-MM-dd  HH:mm:ss",timezone = "GMT+8")
    private Date defectPlanTime;

    @ApiModelProperty(value = "缺陷消除时间")
    @TableField("remove_time")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    //@JsonFormat(pattern = "yyyy-MM-dd  HH:mm:ss",timezone = "GMT+8")
    private Date removeTime;

    @ApiModelProperty(value = "缺陷消缺时限预警 一般缺陷3个月(缺陷录入超过3个月还未消除预警)，严重缺陷一个月，危急缺陷24小时")
    @TableField("defect_warn")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    //@JsonFormat(pattern = "yyyy-MM-dd  HH:mm:ss",timezone = "GMT+8")
    private Date defectWarn;

    @ApiModelProperty(value = "关联的工单编号")
    @TableField("work_order_no")
    private String workOrderNo;


}
