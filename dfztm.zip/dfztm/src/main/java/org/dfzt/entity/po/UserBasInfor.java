package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "UserBasInfor对象", description = "")
public class UserBasInfor implements Serializable {


    @ApiModelProperty(value = "ID(用户基础信息)")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "用户编号")
    @TableField("cons_no")
    private String consNo;

    @ApiModelProperty(value = "用户名称")
    @TableField("cons_name")
    private String consName;

    @ApiModelProperty(value = "用户地址")
    @TableField("cons_addr")
    private String consAddr;

    @ApiModelProperty(value = "用户分类")
    @TableField("cons_sort_code")
    private String consSortCode;

    @ApiModelProperty(value = "行业分类")
    @TableField("trade_code")
    private String tradeCode;

    @ApiModelProperty(value = "供电电压")
    @TableField("volt_code")
    private String voltCode;

    @ApiModelProperty(value = "合同容量")
    @TableField("contract_cap")
    private BigDecimal contractCap;

    @ApiModelProperty(value = "用电标志")
    @TableField("elec_code")
    private String elecCode;

    @ApiModelProperty(value = "供电单位")
    @TableField("org_name")
    private String orgName;

    @ApiModelProperty(value = "抄表段编号")
    @TableField("mr_sect_no")
    private String mrSectNo;

    @ApiModelProperty(value = "用电类别")
    @TableField("elec_type_code")
    private String elecTypeCode;

    @ApiModelProperty(value = "运行容量")
    @TableField("run_cap")
    private BigDecimal runCap;

    @ApiModelProperty(value = "抄表员姓名")
    @TableField("reader_name")
    private String readerName;

    @ApiModelProperty(value = "催费员姓名")
    @TableField("remind_name")
    private String remindName;

    @ApiModelProperty(value = "用户状态")
    @TableField("cons_state")
    private String consState;

    @ApiModelProperty(value = "资产编号")
    @TableField("asset_number")
    private String assetNumber;

    @ApiModelProperty(value = "总条数")
    @TableField(exist = false)
    private Integer total;

    private String appType;//是否是敏感用户
}
