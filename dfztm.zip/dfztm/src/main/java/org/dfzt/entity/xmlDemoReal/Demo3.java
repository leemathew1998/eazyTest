package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.checkerframework.common.aliasing.qual.NonLeaked;
//import sun.security.jca.GetInstance;

import java.util.List;

/**
 * @ClassName Demo3
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/15 18:41
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Demo3 {

    //@XStreamAlias("R")
    @XStreamImplicit(itemFieldName="R")
    private List<List<General>> general;
}
