package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/17
 * @Version: 1.00
 */
@Data
public class LinelossSynana {
    private Integer id;
    //上级供电单位
    private String upOrgName;
    //供电单位
    private String orgName;
    //台区名称
    private String tgName;
    //台区编号
    private String tgNo;
    //台区容量
    private Integer tgCap;
    //考核单元名称
    private String chkunitName;
    //日期
    private Date dataDate;
    //供电量
    private BigDecimal ppq;
    //售电量
    private BigDecimal tgSpq;
    //自用电
    private BigDecimal spq;
    //损耗电量
    private BigDecimal lossPq;
    //线损率
    private BigDecimal linelossRate;
    //线损指标上限
    private BigDecimal llIdxUp;
    //线损指标下限
    private BigDecimal llIdxLow;
    //差异值
    private BigDecimal differValue;
    //星级台区
    private BigDecimal starTg;
    //用户抄表成功率
    private BigDecimal readSuccCnt;
    //抄读成功率
    private BigDecimal readSuccRate;
    //安装率
    private BigDecimal instRate;
    //功率因数
    private BigDecimal pfFlag;
    //理论线损
    private BigDecimal linelossTheory;
    //电压三相不平衡
    private BigDecimal uRate;
    //电流三相不平衡
    private BigDecimal iRate;
    //负载率
    private BigDecimal loadRate;

    private String factoryCode;
    //负责人
    private String chargePerson;
    //组合标志
    private String composeSign;
    //修复供电量
    private BigDecimal ppqRepair;
    //修复售电量
    private BigDecimal spqRepair;
    //台区标签
    private String tgLabel;

    private String synchroUserName;

    private String synchroUserDeptno;

    private Date synchroUserTime;

    private String synchroUserType;
}
