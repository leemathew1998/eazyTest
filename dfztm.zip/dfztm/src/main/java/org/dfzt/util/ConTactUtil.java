package org.dfzt.util;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.dfzt.entity.po.UserBasInfor;
import org.dfzt.entity.po.CContact;
import org.dfzt.entity.po.CInformation;
import org.dfzt.entity.po.ElectricityPrice;
import org.dfzt.entity.po.UserBasInfor;

import java.util.List;

/**
 * @ClassName ConTactUtil
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/8/16 16:44
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConTactUtil {

    private UserBasInfor userBasInfor;
    private List<CInformation> cInformation;
    private List<CContact> cContact;
    private List<ElectricityPrice> electricityPrice;
}
