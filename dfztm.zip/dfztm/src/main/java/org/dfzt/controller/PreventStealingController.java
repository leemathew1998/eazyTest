package org.dfzt.controller;

import org.dfzt.entity.po.PreventStealing;
import org.dfzt.service.PreventStealingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/5
 * @Version: 1.00
 */
@RestController
@ResponseBody
@RequestMapping("/pi")
@Transactional
public class PreventStealingController {

    @Resource
    PreventStealingService preventStealingService;


    /**
     * 查询所有未删除
     * @return
     */
    @PostMapping("/se")
    public List<PreventStealing> preventStealingselect() {
        List<PreventStealing> select = preventStealingService.PreventStealingServiceSelect();
        return select;

    }

    /**
     * 查询所有逻辑删除
     * @return
     */
    @PostMapping("/selectNo")
    public List<PreventStealing> selectNo() {
        List<PreventStealing> selectNo = preventStealingService.selectNo();
        return selectNo;
    }

    /**
     * 更新并且逻辑删除
     * @param preventStealing
     * @return
     */
    @PostMapping("/alterpre")
    public boolean preventStealingsUpdate(PreventStealing preventStealing) {
        boolean update = preventStealingService.updateById(preventStealing);
        preventStealingService.removeById(preventStealing.getId());
        return update;

    }

    /**
     * 查询所有数据（已逻辑删除和未删除的）PC端
     * @return
     */
    @PostMapping("/AllStatus")
    public List<PreventStealing> selectALLStatus(@RequestBody PreventStealing p) {
        System.out.println(p.getQueryNo());
        List<PreventStealing> allStatus = preventStealingService.selectAllStatus(p);
        return allStatus;
    }


    /**
     * 点击按钮接收数据
     */
    @PostMapping("/insert")
    public boolean preventStealingsInsert(PreventStealing preventStealing) {
        if (preventStealing != null) {
            preventStealingService.save(preventStealing);
            return true;
        } else {
            return false;
        }

    }

    /**
     * 各状态的个数
     */
    @PostMapping("statusNumber")
    public List<Map<String, Object>> statusNumber(){
        List<Map<String, Object>> list = preventStealingService.statusNumber();
        return list;
    }


}
