package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Date:2023/5/31-16:46
 * @User:chengchuanlin
 * @Name:MdHEMpCurCurve
 * @Message:
 */
@Data
public class MdHEMpCurCurve {
    /**
     * 主键
     */
    private Integer  id;
    /**
     * 供电单位编号
     */
    private String orgNo;
    /**
     * 数据时间
     */
    private Date dataDate;
    /**
     * 电流
     */
    private Integer ct;
    /**
     * 数据补全标志
     */
    private Integer mark;
    /**
     * 相序标志
     */
    private Integer phaseFlag;
    /**
     * 数据完整性标志  ( 用96个1或0来表示96点数据的完整性标志（左第一位表示第1点） )  ( 用96个1或0来表示96点数据的完整性标志（左第一位表示第1点） )
     */
    private String dataWholeFlag;
    /**
     * 数据点标志 (1：96点 2: 48点 3: 24点) (1：96点 2: 48点 3: 24点)
     */
    private BigDecimal dataPointFlag;
    /**
     * 电流
     */
    private BigDecimal i1;
    /**
     * 电流
     */
    private BigDecimal i2;
    /**
     * 电流
     */
    private BigDecimal i3;
    /**
     * 电流
     */
    private BigDecimal i4;
    /**
     * 电流
     */
    private BigDecimal i5;
    /**
     * 电流
     */
    private BigDecimal i6;
    /**
     * 电流
     */
    private BigDecimal i7;
    /**
     * 电流
     */
    private BigDecimal i8;
    /**
     * 电流
     */
    private BigDecimal i9;
    /**
     * 电流
     */
    private BigDecimal i10;
    /**
     * 电流
     */
    private BigDecimal i11;
    /**
     * 电流
     */
    private BigDecimal i12;
    /**
     * 电流
     */
    private BigDecimal i13;
    /**
     * 电流
     */
    private BigDecimal i14;
    /**
     * 电流
     */
    private BigDecimal i15;
    /**
     * 电流
     */
    private BigDecimal i16;
    /**
     * 电流
     */
    private BigDecimal i17;
    /**
     * 电流
     */
    private BigDecimal i18;
    /**
     * 电流
     */
    private BigDecimal i19;
    /**
     * 电流
     */
    private BigDecimal i20;
    /**
     * 电流
     */
    private BigDecimal i21;
    /**
     * 电流
     */
    private BigDecimal i22;
    /**
     * 电流
     */
    private BigDecimal i23;
    /**
     * 电流
     */
    private BigDecimal i24;
    /**
     * 电流
     */
    private BigDecimal i25;
    /**
     * 电流
     */
    private BigDecimal i26;
    /**
     * 电流
     */
    private BigDecimal i27;
    /**
     * 电流
     */
    private BigDecimal i28;
    /**
     * 电流
     */
    private BigDecimal i29;
    /**
     * 电流
     */
    private BigDecimal i30;
    /**
     * 电流
     */
    private BigDecimal i31;
    /**
     * 电流
     */
    private BigDecimal i32;
    /**
     * 电流
     */
    private BigDecimal i33;
    /**
     * 电流
     */
    private BigDecimal i34;
    /**
     * 电流
     */
    private BigDecimal i35;
    /**
     * 电流
     */
    private BigDecimal i36;
    /**
     * 电流
     */
    private BigDecimal i37;
    /**
     * 电流
     */
    private BigDecimal i38;
    /**
     * 电流
     */
    private BigDecimal i39;
    /**
     * 电流
     */
    private BigDecimal i40;
    /**
     * 电流
     */
    private BigDecimal i41;
    /**
     * 电流
     */
    private BigDecimal i42;
    /**
     * 电流
     */
    private BigDecimal i43;
    /**
     * 电流
     */
    private BigDecimal i44;
    /**
     * 电流
     */
    private BigDecimal i45;
    /**
     * 电流
     */
    private BigDecimal i46;
    /**
     * 电流
     */
    private BigDecimal i47;
    /**
     * 电流
     */
    private BigDecimal i48;
    /**
     * 电流
     */
    private BigDecimal i49;
    /**
     * 电流
     */
    private BigDecimal i50;
    /**
     * 电流
     */
    private BigDecimal i51;
    /**
     * 电流
     */
    private BigDecimal i52;
    /**
     * 电流
     */
    private BigDecimal i53;
    /**
     * 电流
     */
    private BigDecimal i54;
    /**
     * 电流
     */
    private BigDecimal i55;
    /**
     * 电流
     */
    private BigDecimal i56;
    /**
     * 电流
     */
    private BigDecimal i57;
    /**
     * 电流
     */
    private BigDecimal i58;
    /**
     * 电流
     */
    private BigDecimal i59;
    /**
     * 电流
     */
    private BigDecimal i60;
    /**
     * 电流
     */
    private BigDecimal i61;
    /**
     * 电流
     */
    private BigDecimal i62;
    /**
     * 电流
     */
    private BigDecimal i63;
    /**
     * 电流
     */
    private BigDecimal i64;
    /**
     * 电流
     */
    private BigDecimal i65;
    /**
     * 电流
     */
    private BigDecimal i66;
    /**
     * 电流
     */
    private BigDecimal i67;
    /**
     * 电流
     */
    private BigDecimal i68;
    /**
     * 电流
     */
    private BigDecimal i69;
    /**
     * 电流
     */
    private BigDecimal i70;
    /**
     * 电流
     */
    private BigDecimal i71;
    /**
     * 电流
     */
    private BigDecimal i72;
    /**
     * 电流
     */
    private BigDecimal i73;
    /**
     * 电流
     */
    private BigDecimal i74;
    /**
     * 电流
     */
    private BigDecimal i75;
    /**
     * 电流
     */
    private BigDecimal i76;
    /**
     * 电流
     */
    private BigDecimal i77;
    /**
     * 电流
     */
    private BigDecimal i78;
    /**
     * 电流
     */
    private BigDecimal i79;
    /**
     * 电流
     */
    private BigDecimal i80;
    /**
     * 电流
     */
    private BigDecimal i81;
    /**
     * 电流
     */
    private BigDecimal i82;
    /**
     * 电流
     */
    private BigDecimal i83;
    /**
     * 电流
     */
    private BigDecimal i84;
    /**
     * 电流
     */
    private BigDecimal i85;
    /**
     * 电流
     */
    private BigDecimal i86;
    /**
     * 电流
     */
    private BigDecimal i87;
    /**
     * 电流
     */
    private BigDecimal i88;
    /**
     * 电流
     */
    private BigDecimal i89;
    /**
     * 电流
     */
    private BigDecimal i90;
    /**
     * 电流
     */
    private BigDecimal i91;
    /**
     * 电流
     */
    private BigDecimal i92;
    /**
     * 电流
     */
    private BigDecimal i93;
    /**
     * 电流
     */
    private BigDecimal i94;
    /**
     * 电流
     */
    private BigDecimal i95;
    /**
     * 电流
     */
    private BigDecimal i96;
    /**
     * 数据入库时间
     */
    private Date recTime;
    /**
     * 电表标识
     */
    private Integer meterId;
    /**
     * 数据来源
     */
    private String dataSrc;
    /**
     * 是否有效
     */
    private Integer isValid;
}
