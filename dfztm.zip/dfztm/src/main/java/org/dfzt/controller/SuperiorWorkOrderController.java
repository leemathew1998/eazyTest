package org.dfzt.controller;


import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.dfzt.annotation.CurrentUser;
import org.dfzt.entity.po.CCons;
import org.dfzt.entity.po.CollectWorkOrder;
import org.dfzt.entity.po.S95598Wkst;
import org.dfzt.entity.vo.SuperiorSensitivity;
import org.dfzt.entity.vo.SuperiorWorkOrder;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.mapper.FeecontrolWorkOrderMapper;
import org.dfzt.mapper.S95598WkstMapper;
import org.dfzt.mapper.SuperiorWorkOrderMapper;
import org.dfzt.response.ResultCode;
import org.dfzt.service.CConsService;
import org.dfzt.service.S95598WkstService;
import org.dfzt.service.SuperiorWorkOrderService;
import org.dfzt.util.ExcelUtils;
import org.dfzt.util.TimeUtil;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Time;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * (SuperiorWorkOrder)表控制层
 *
 * @author makejava
 * @since 2022-07-11 14:51:00
 */
@RestController
@RequestMapping("superiorWorkOrder")
public class SuperiorWorkOrderController extends ApiController {
    /**
     * 服务对象
     */

    @Resource
    private SuperiorWorkOrderService superiorWorkOrderService;
    @Resource
    private SuperiorWorkOrderMapper superiorWorkOrderMapper;
    @Resource
    private FeecontrolWorkOrderMapper feecontrolWorkOrderMapper;
    @Resource
    private S95598WkstMapper s95598WkstMapper;
    @Resource
    private CollectWorkOrderMapper collectWorkOrderMapper;
    @Resource
    private CConsService cConsService;

    @Resource
    private S95598WkstService s95598WkstService;





    /**
     * 分页查询所有数据
     *
     * @param page              分页对象
     * @param superiorWorkOrder 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll1")
    public R selectAll1(@CurrentUser SysUser user,Page<SuperiorWorkOrder> page, SuperiorWorkOrder superiorWorkOrder) {
        String role = superiorWorkOrderService.selectRole(user.getLoginName());
        R<Page<SuperiorWorkOrder>> success = success(superiorWorkOrderService.page(page, superiorWorkOrderService.queryWrapper(superiorWorkOrder,role)));
        if (success.getData().getRecords().size() > 0){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }



    /**
     * 状态扭转
     * @param map
     * @return
     */
    @PostMapping("updateStatus")
    @ResponseBody
    public R updateSuperiorWordOrder(org.dfzt.entity.po.SuperiorWorkOrder map){
//        if (map.get("userId") != null && !map.get("userId").equals("")){
//            CCons relationId = cConsService.getOne(
//                    new LambdaQueryWrapper<CCons>()
//                            .eq(CCons::getConsNo, map.get("userId"))
//            );
//            if (map.get("whetherOutage").equals("是") && map.get("whetherSensitivity").equals("是")){
//                relationId.setOftenPowerCut(1);
//                relationId.setSensitiveUser(1);
//                cConsService.updateById(relationId);
//            }else if (map.get("whetherOutage").equals("是") && map.get("whetherSensitivity").equals("不是")){
//                relationId.setOftenPowerCut(1);
//                relationId.setSensitiveUser(0);
//                cConsService.updateById(relationId);
//            }else if (map.get("whetherOutage").equals("不是") && map.get("whetherSensitivity").equals("是")){
//                relationId.setOftenPowerCut(0);
//                relationId.setSensitiveUser(1);
//                cConsService.updateById(relationId);
//            }else {
//                relationId.setOftenPowerCut(0);
//                relationId.setSensitiveUser(0);
//                cConsService.updateById(relationId);
//            }
//        }
        R<Integer> success = success(superiorWorkOrderService.updateSuperiorWordOrder(map));
        //R<Integer> success = success(0);
        if (success.getData() == 1){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }



    /**
     * 查询历史数据
     * @param workOrderNo
     * @return
     */
    @PostMapping("selectWordOrderId")
    public R selectSuperiorWordOrderId(@RequestParam String workOrderNo){
        R<org.dfzt.entity.vo.SuperiorWorkOrder> success = success(superiorWorkOrderService.selectSuperiorWordOrderNo(workOrderNo));
        if (success.getData() != null){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }



    @PostMapping("selectCountAll")
    public R selectCountAll(){
        return success(superiorWorkOrderService.selectCountAll());
    }


    /**
     * TODO 修改敏感用户的状态
     * @return
     */
//
//    @RequestMapping("updatesen")
//    public Boolean updateSen(String workOrderNo){
//        Boolean a = superiorWorkOrderService.updateSen(workOrderNo);
//        if(a==true){
//            superiorWorkOrderMapper.updateexamineStatus(workOrderNo,"1");
//        }else{
//            superiorWorkOrderMapper.updateexamineStatus(workOrderNo,"0");
//        }
//        return a;
//    }

    @PostMapping("selectExamineStatus")
    public R selectExamineStatus(){
        List<SuperiorWorkOrder> list = superiorWorkOrderService.list(
                new LambdaQueryWrapper<SuperiorWorkOrder>()
                        .eq(SuperiorWorkOrder::getExamineStatus, 0)
        );
        return success(list);
    }

    /**
     * TODO 修改敏感用户的状态
     * @return
     */
    @PostMapping("updatesen")
    public Boolean updateSen(@RequestBody Map map){
        if (map.get("userId") != null && !map.get("userId").equals("")){
            CCons relationId = cConsService.getOne(
                    new LambdaQueryWrapper<CCons>()
                            .eq(CCons::getConsNo, map.get("userId"))
            );
            if (relationId != null){
                if (map.get("whetherSensitivity").equals("是")){
                    relationId.setSensitiveUser(1);
                    superiorWorkOrderMapper.updateexamineStatus(String.valueOf(map.get("workOrderNo")), "1");
                    boolean b = cConsService.updateById(relationId);
                    return b;
                }else if (map.get("whetherSensitivity").equals("否")){
                    relationId.setSensitiveUser(0);
                    superiorWorkOrderMapper.updateexamineStatus(String.valueOf(map.get("workOrderNo")), "1");
                    boolean b = cConsService.updateById(relationId);
                    return b;
                }
            }
        }
        return false;
    }

    /**
     * TODO 添加labelCause描述
     */
    @PostMapping("updateLabel")
    public Integer updatelabel(String relationId,String labelCause){
        SuperiorSensitivity superiorSensitivity = superiorWorkOrderMapper.selectByRid(relationId);
        if(superiorSensitivity!=null){
            return superiorWorkOrderMapper.updateLase(relationId,labelCause);
        }else {
            SuperiorSensitivity sSensitivity = new SuperiorSensitivity();
            SuperiorWorkOrder sWorkOrder = superiorWorkOrderMapper.selectByWorkO(relationId);
            sSensitivity.setLabelCause(labelCause);
            sSensitivity.setConsName(sWorkOrder.getContactName());
            sSensitivity.setConsNo(sWorkOrder.getRelationId());
            return superiorWorkOrderService.insertSen(sSensitivity);
        }
    }


    /**
     * TODO 查询回显labelCause描述
     */
    @PostMapping(value = "selectLabel")

    public String selectLabel(String relationId){
        return superiorWorkOrderMapper.selectLabelCause(relationId);
    }





    /**
     * 优质服务导出
     * @param ids
     * @return ids
     */
    @RequestMapping("export")  //excel/export
    public void exportExcel2(HttpServletResponse response, @RequestParam String ids) throws IOException {
        List<org.dfzt.entity.po.SuperiorWorkOrder> superiorWorkOrders = superiorWorkOrderMapper.selectSupewoExcel(ids);
        ExcelUtils.exportExcel(superiorWorkOrders, "优质服务工单列表", "优质服务", org.dfzt.entity.po.SuperiorWorkOrder.class, "优质服务工单文件", response);
    }


    /**
     * 优质服务全部导出
     * @param ids
     * @return ids
     */
    @RequestMapping("exportAll")  //excel/export
    public void exportExcel2All(HttpServletResponse response, @RequestParam(required = false) String ids,org.dfzt.entity.po.SuperiorWorkOrder superiorWorkOrder,
                                @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,
                                @RequestParam(required = false) String loName2) throws IOException {
        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<org.dfzt.entity.po.SuperiorWorkOrder> superiorWorkOrders = superiorWorkOrderMapper.selectSuperiorList(superiorWorkOrder,0, 999999999,status,orgName);
        ExcelUtils.exportExcel(superiorWorkOrders, "优质服务工单列表", "优质服务", org.dfzt.entity.po.SuperiorWorkOrder.class, "优质服务工单文件", response);
    }



    @PostMapping("selectAll")
    public R selectAll(org.dfzt.entity.po.SuperiorWorkOrder superiorWorkOrder,@RequestParam(name = "pageNo",defaultValue = "1") String pageNo,
                       @RequestParam(name = "pageSize",defaultValue = "10") String pageSize,
                       @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String loName2){

        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<org.dfzt.entity.po.SuperiorWorkOrder> superiorWorkOrders = superiorWorkOrderMapper.selectSuperiorList(superiorWorkOrder,(Integer.parseInt(pageNo)-1)*Integer.parseInt(pageSize),Integer.parseInt(pageSize),status,orgName);
        int size = superiorWorkOrderMapper.selectSuperiorList(superiorWorkOrder, 0, 999999999, status,orgName).size();
        Map<Integer,List<org.dfzt.entity.po.SuperiorWorkOrder>> map = new HashMap<>();
        map.put(size,superiorWorkOrders);
        R<Map<Integer,List<org.dfzt.entity.po.SuperiorWorkOrder>>> success = success(map);
        if (success.getData().size() > 0){
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }




    @PostMapping("selectWrapper")
    public R selectWrapper(@RequestParam String loName2, @RequestParam(name = "pageNo",defaultValue = "0") String pageNo,
                           @RequestParam(name = "pageSize",defaultValue = "10") String pageSize, String str,
                           @RequestParam String workOrderStatus,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String role
            ,@RequestParam(required = false) String loginName) {
        Page<SuperiorWorkOrder> page = new Page<>();
        page.setCurrent(Long.parseLong(pageNo));
        page.setSize(Long.parseLong(pageSize));
        System.out.println("workOrderStatus"+workOrderStatus);
        //通过用户名查询角色信息（2： 台区经理  1：所站长）
        List<String> orgName = new ArrayList<>();
        List<String> readNames = collectWorkOrderMapper.selectReadNames(loginName);
        System.out.println("orgName"+orgName);
        return success(this.superiorWorkOrderService.page(page, superiorWorkOrderService.wrapper(readNames,str,role,workOrderStatus,loName2,orgName)));
    }

    //        if (collectWorkOrders.size()==0){
//            if (orgNo.length()==9){//展示营业站
//                orgName.add(collectWorkOrderMapper.selectOrgNo(orgNo));
//            }else{
//                orgName = collectWorkOrderMapper.selectOrgNos(orgNo);
//            }
//        }else {
//            loName = loName2;
//        }
//        if (role.equals("1")){
//            return success(this.superiorWorkOrderService.page(page, superiorWorkOrderService.wrapper(str,role,workOrderStatus,loName,orgName)));
//        }

}
