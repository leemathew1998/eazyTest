package org.dfzt.entity.po;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;

/**
 * (RCp)表实体类
 *
 * @author makejava
 * @since 2022-07-29 16:39:48
 */
@SuppressWarnings("serial")
@TableName("r_cp")
@Data
public class RCp extends Model<RCp> {
    //id（终端基本信息
    private Integer id;
    //终端地址码
    private String terminalAddr;
    //终端类型
    private String terminalTypeCode;
    //通信规约
    private String protocolCode;
    //生产厂家
    private String factoryCode;

    //计量点编号
    private String mpNo;
}
