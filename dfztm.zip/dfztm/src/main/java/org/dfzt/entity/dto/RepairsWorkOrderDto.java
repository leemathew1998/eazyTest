package org.dfzt.entity.dto;


import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.dfzt.entity.po.RepairsWorkOrder;
import org.dfzt.eunm.WorkOrderEnum;
import org.dfzt.eunm.WorkOrderStatusEnum;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * (RepairsWorkOrder)表实体类
 *
 * @author makejava
 * @since 2022-07-28 09:29:26
 */
@SuppressWarnings("serial")
@TableName("repairs_work_order")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RepairsWorkOrderDto extends Model<RepairsWorkOrder> {
    //ID
    @Excel(name = "ID",orderNum = "0")
    @TableId(value = "id",type = IdType.AUTO)
    private Integer id;
    //工单编号
    @Excel(name = "工单编号",orderNum = "1")
    private String workOrderNo;
    //台区经理
    @Excel(name = "台区经理",orderNum = "2")
    private String tgManager;
    //台区编号
    @Excel(name = "台区编号",orderNum = "3")
    private String tgNo;
    //台区名称
    @Excel(name = "台区名称",orderNum = "4")
    private String tgName;
    //故障设备
    @Excel(name = "故障设备",orderNum = "5")
    private String failureEquipment;
    //电压
    @Excel(name = "电压",orderNum = "6")
    private String voltCode;
    //电流
    @Excel(name = "电流",orderNum = "7")
    private String ratedCurrent;
    //本体温度
    @Excel(name = "本体温度",orderNum = "8")
    private String tgTemperature;
    //故障区域
    @Excel(name = "故障区域",orderNum = "9")
    private String failureArea;
    //异常开关状态
    @Excel(name = "异常开关状态",orderNum = "10")
    private String errorStatus;
    //抢修类型
    @Excel(name = "抢修类型",orderNum = "11")
    private String repairsType;
    //故障描述
    @Excel(name = "故障描述",orderNum = "12")
    private String faultDescribe;
    //处理时间
    @Excel(name = "处理时间",orderNum = "13")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date disposeTime;
    //处理结果
    @Excel(name = "处理结果",orderNum = "14")
    private String disposeResult;
    //消耗材料
    @Excel(name = "消耗材料",orderNum = "15")
    private String consumeMaterials;
    //地点
    @Excel(name = "地点",orderNum = "16")
    private String location;
    //故障点/危机缺陷照片（顺序1）
    @Excel(name = "故障点/危机缺陷照片",type = 2,width = 50.0 ,height = 50.0 ,imageType = 1,orderNum = "17")
    private String faultPoint;
    //抢修单照片(顺序2)
    @Excel(name = "抢修单照片",type = 2,width = 50.0 ,height = 50.0 ,imageType = 1,orderNum = "18")
    private String repairList;
    //监控班许可照片（顺序3）
    @Excel(name = "监控班许可照片",type = 2,width = 50.0 ,height = 50.0 ,imageType = 1,orderNum = "19")
    private String monShiftPer;
    //安全措施照片(顺序4)
    @Excel(name = "安全措施照片",type = 2,width = 50.0 ,height = 50.0 ,imageType = 1,orderNum = "20")
    private String secuMeas;
    //到岗位置许可检查安全措施是否完备照片并同意开工照片（顺序5）
    @Excel(name = "到岗位置许可检查安全措施是否完备照片并同意开工照片",type = 2,width = 50.0 ,height = 50.0 ,imageType = 1,orderNum = "21")
    private String iscompSecuMeas;
    //故障/危急缺陷处理后照片（顺序6）
    @Excel(name = "故障/危急缺陷处理后照片",type = 2,width = 50.0 ,height = 50.0 ,imageType = 1,orderNum = "22")
    private String afterTrou;
    //安全措施拆除照片（顺序7）
    @Excel(name = "安全措施拆除照片",type = 2,width = 50.0 ,height = 50.0 ,imageType = 1,orderNum = "23")
    private String secuMeasRem;
    //1.待处理，2.处理中，3.待归档，4.已归档
    private String workOrderStatus;
    //工单创建时间
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderCtime;

    //是否有敏感工单用户
    private String appType;

//    public void setWorkOrderStatus(String workOrderStatus) {
//        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
//    }
}
