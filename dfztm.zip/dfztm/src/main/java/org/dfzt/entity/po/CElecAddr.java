package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@ApiModel(value="c_elec_addr")
@Data
@TableName(value = "c_elec_addr")
public class CElecAddr {
    @TableId(value = "id", type = IdType.INPUT)
    @ApiModelProperty(value="")
    private Integer id;

    /**
     * 用电地址标识 本实体记录的唯一标识，产生规则为流水号
     */
    @TableField(value = "csa_id")
    @ApiModelProperty(value="用电地址标识 本实体记录的唯一标识，产生规则为流水号")
    private BigDecimal csaId;

    /**
     * 用户标识 本实体记录的唯一标识，产生规则为流水号
     */
    @TableField(value = "cons_id")
    @ApiModelProperty(value="用户标识 本实体记录的唯一标识，产生规则为流水号")
    private BigDecimal consId;

    /**
     * 省码 用户地址省码，说明用户地址属于哪个省，引用国家标准GB T 2260-2002
     */
    @TableField(value = "province_code")
    @ApiModelProperty(value="省码 用户地址省码，说明用户地址属于哪个省，引用国家标准GB T 2260-2002")
    private String provinceCode;

    /**
     * 市码 用户地址市码，说明用户地址属于哪个市(地区),,引用国家标准GB T 2260-2002
     */
    @TableField(value = "city_code")
    @ApiModelProperty(value="市码 用户地址市码，说明用户地址属于哪个市(地区),,引用国家标准GB T 2260-2002")
    private String cityCode;

    /**
     * 区县码 用户地址区县码，说明用户地址属于哪个市直辖区或市直属县，引用国家标准GB T 2260-2002
     */
    @TableField(value = "county_code")
    @ApiModelProperty(value="区县码 用户地址区县码，说明用户地址属于哪个市直辖区或市直属县，引用国家标准GB T 2260-2002")
    private String countyCode;

    /**
     * 街道码（乡镇） 用户地址街道码（乡镇），根据各地情况编码
     */
    @TableField(value = "street_code")
    @ApiModelProperty(value="街道码（乡镇） 用户地址街道码（乡镇），根据各地情况编码")
    private String streetCode;

    /**
     * 居委会码（村） 用户地址居委会（村），根据各地情况编码
     */
    @TableField(value = "village_code")
    @ApiModelProperty(value="居委会码（村） 用户地址居委会（村），根据各地情况编码")
    private String villageCode;

    /**
     * 道路码 用户地址所在道路码，根据各地情况编码
     */
    @TableField(value = "road_code")
    @ApiModelProperty(value="道路码 用户地址所在道路码，根据各地情况编码")
    private String roadCode;

    /**
     * 小区码 用户地址小区码，根据各地情况编码
     */
    @TableField(value = "community_code")
    @ApiModelProperty(value="小区码 用户地址小区码，根据各地情况编码")
    private String communityCode;

    /**
     * 用户地址的门牌号
     */
    @TableField(value = "plate_no")
    @ApiModelProperty(value="用户地址的门牌号")
    private String plateNo;

    /**
     * 街道（乡镇）名称
     */
    @TableField(value = "street_name")
    @ApiModelProperty(value="街道（乡镇）名称")
    private String streetName;

    /**
     * 居委会（村）名称
     */
    @TableField(value = "village_name")
    @ApiModelProperty(value="居委会（村）名称")
    private String villageName;

    /**
     * 道路名称
     */
    @TableField(value = "road_name")
    @ApiModelProperty(value="道路名称")
    private String roadName;

    /**
     * 小区名称
     */
    @TableField(value = "community_name")
    @ApiModelProperty(value="小区名称")
    private String communityName;

    /**
     * 供电单位
     */
    @TableField(value = "org_no")
    @ApiModelProperty(value="供电单位")
    private String orgNo;

    /**
     * 地标
     */
    @TableField(value = "building")
    @ApiModelProperty(value="地标")
    private String building;

    private String posX;
    private String posY;
    private String posZ;
}