package org.dfzt.entity.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
public class CollectWorkOrder implements Serializable {
    private Integer id;//id

    private Integer notConnectId;//采集未接入关联id

    private Integer colInforId;//采集异常关联id

    private Integer failDetailsId;//采集失败关联id
    @Excel(name = "工单编号",orderNum = "1",width = 20)
    private String workOrderNo;//工单编号
    @Excel(name = "台区经理",orderNum = "2",width = 20)
    private String tgManager;//台区经理名称
    @Excel(name = "台区编号",orderNum = "3",width = 20)
    private String tgId;//台区编号
    @Excel(name = "台区名称",orderNum = "4",width = 20)
    private String tgName;//台区名称
    @Excel(name = "供电单位",orderNum = "5",width = 20)
    private String orgName;//供电单位
    // @Excel(name = "供电单位",orderNum = "5",width = 20)
    private String pOrgName;//供电单位
    @Excel(name = "用户名称",orderNum = "6",width = 20)
    private String consName;//用户名称
    @Excel(name = "用户编号",orderNum = "7",width = 20)
    private String consNo;//用户编号
    @Excel(name = "用户地址",orderNum = "8",width = 20)
    private String elecAddr;//用户地址

    private BigDecimal gpsLongitude;//用户GPS经度

    private BigDecimal gpsLatitude;//用户GPS纬度
    @Excel(name = "用户电话",orderNum = "9",width = 20)
    private String mobile;//用户电话
    @Excel(name = "电能表资产号",orderNum = "10",width = 20)
    private String meterAssetNo;//电能表资产号

    private String meterBarCode;//电能表条码

    private String metManufacturer;//电能表厂家
    @Excel(name = "终端地址",orderNum = "11",width = 20)
    private String terminalAddr;//终端地址码terminal_addr
    @Excel(name = "事件类型",orderNum = "12",width = 20,replace = {"采集失败_1","采集异常_2","采集未接入_3"})
    private String eventType;//事件类型
    @Excel(name = "事件类型",orderNum = "13",width = 20,replace = {"采集设备掉线_1",
            "485线问题_2","表前开关掉线 时钟错误_3",
            "模块、表计故障、表前开关掉线、时钟错误_4","采集异常 需要补抄_5","采集未接入_6"})
    private String eventReason;//事件原因

    private String workOrderStatus;//工单状态

    private String workOrderCreator;//工单创建人

    private Date workOrderCtime;//工单创建时间
    @Excel(name = "工单创建时间",orderNum = "14",width = 20)
    private String workOrderCtime1;//
    private String workOrderUtime;//工单耗时

    private Date workOrderStime;//工单解决时间

    private Date workOrderFtime;//工单归档时间

    private String handler;//处理人

    private Date handlerRtime;//处理人接收时间

    private String hworkOrderHandler;//历史工单处理人

    private Date hworkOrderHandlerRtime;//历史工单处理人接收工单时间

    private Date hworkOrderHandlerTtime;//历史工单处理人转出流转时间

    private String workOrderCycle;//工单周期 是连续几天的工单

    private String appType;//是否是敏感用户

    private String consType;//用户类型

    private String addrNum;//终端地址相同的用户数量

}