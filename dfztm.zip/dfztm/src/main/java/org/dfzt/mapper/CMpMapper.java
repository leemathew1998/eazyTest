package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.CMp;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * (CMp)表数据库访问层
 *
 * @author makejava
 * @since 2022-07-29 14:51:17
 */
@Repository
public interface CMpMapper extends BaseMapper<CMp> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<CMp> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<CMp> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<CMp> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<CMp> entities);

    @DS("mpg")
    List<CMp> selectCMpList();



}

