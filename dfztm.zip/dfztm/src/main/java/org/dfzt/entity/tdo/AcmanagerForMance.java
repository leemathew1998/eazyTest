package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 区业绩指标
 */
@Data
public class AcmanagerForMance {
    //客户经理当日积分
    private int accountManagerTodayTotallIntegrate;
    //旗县公司当日排名
    private int qiCountyCompanyTOdayRanking;
    //供电所当日排名
    private int powerStationTodayRanking;
    //指标列表
    private List<Indicators> indicators;
}
