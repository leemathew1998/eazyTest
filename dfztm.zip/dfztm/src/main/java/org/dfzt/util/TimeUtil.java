package org.dfzt.util;

import cn.hutool.core.date.DateTime;
import org.checkerframework.checker.units.qual.A;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/5/31
 * @Version: 1.00
 */

public class TimeUtil {
    static Date startdate = new Date();//取时间
    static Calendar calendar = new GregorianCalendar();

    public static List<String> getDays(String startTime, String endTime) {
        // 返回的日期集合
        List<String> days = new ArrayList<String>();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date start = dateFormat.parse(startTime);
            Date end = dateFormat.parse(endTime);
            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(start);
            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(end);
            tempEnd.add(Calendar.DATE, +1);
            while (tempStart.before(tempEnd)) {
                days.add(dateFormat.format(tempStart.getTime()));
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return days;
    }



    public static String getTime(DateTime date){
        String areacode = "150702";
        SimpleDateFormat sdf = new SimpleDateFormat("YYYYMMdd");
        String time = sdf.format(date);
        return areacode+time;
        //return time;
    }

    public static String getTomday(Date today){//获取第二天日期
        calendar.setTime(today);
        calendar.add(calendar.DATE, 1);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        String startTime = sdf.format(startdate);
        String tomorr = sdf.format(enddate);
//        String startTime = "2022-06-07";
        return tomorr;
    }

    public static String getStartTime(){//获取昨天时间
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -1);//正数往后推n天,负数往前推n天
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//        String startTime = sdf.format(startdate);
        String endTime = sdf.format(enddate);
//        String startTime = "2022-05-07";
        return endTime;
    }

    public static String getStartTwoTime(){//获取前天时间
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -2);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String endTime = sdf.format(enddate);
        return endTime;
    }

    public static String getStartThreeTime(){//获取三天前时间
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -3);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String endTime = sdf.format(enddate);
        return endTime;
    }

    public static String getStart4Time(){//获取4天前时间
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -4);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String endTime = sdf.format(enddate);
        return endTime;
    }

    public static String getStart5Time(){//
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, 0);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String endTime = sdf.format(enddate);
        return endTime;
    }


    public static List<String> get30days(){//获取前30填的的日期数据
        List<String> thdays = new ArrayList<>();
        for (int i=1;i<=30;i++) {
            calendar.setTime(startdate);
            calendar.add(calendar.DATE, -i);//把日期往后增加一天.整数往后推,负数往前移动
            Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String endTime = sdf.format(enddate);
            thdays.add(endTime);
        }
        return thdays;
    }

    public static String getStart30Time(){//获取30天前时间
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -30);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String endTime = sdf.format(enddate);
        return endTime;
    }

    public static String getSevenDay(){//获取7天前日期时间
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -6);//把日期往后增加一天.整数往后推,负数往前移动
        Date sevendate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String sevenday = sdf.format(sevendate);
//        String endTime = sdf.format(enddate);
//        String sevenday = "2022-05-07";
        return sevenday;
    }

    public static String getTodayTime(){//获取今天时间
        Date startdate = new Date();//取时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, 1);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startTime = sdf.format(startdate);
        return startTime;
    }


    public static String getTodayTimes(){//获取今天时间
        Date startdate = new Date();//取时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, 1);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String startTime = sdf.format(startdate);
        return startTime;
    }


    public static String getTodayTime1(){//获取前一天时间
        Date startdate = new Date();//取时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -1);//把日期往后增加一天.整数往后推,负数往前移动
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startTime = sdf.format(startdate);
        return startTime;
    }

    public static String getTodayTime2(){//获取前两天时间
        Date startdate = new Date();//取时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -2);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startTime = sdf.format(startdate);
//        String endTime = sdf.format(enddate);
//        String endTime = "2022-08-15";
        return startTime;
    }

    public static String getTodayTime3(){//获取前三天时间
        Date startdate = new Date();//取时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, -3);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String startTime = sdf.format(startdate);
//        String endTime = sdf.format(enddate);
//        String endTime = "2022-08-15";
        return startTime;
    }


    public static String getTomDay() {//获取明天时间
        Date startdate = new Date();//取时间
        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startdate);
        calendar.add(calendar.DATE, 1);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String endTime = sdf.format(enddate);
        return endTime;
    }


    public static String getStartMon(){//获取上个月
        calendar.setTime(startdate);
        calendar.add(calendar.MONTH, -1);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        String startMon = sdf.format(enddate);
        return startMon;
    }

    public static String getStartMon1(){//获取上个月
        calendar.setTime(startdate);
        calendar.add(calendar.MONTH, -1);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
        String startMon = sdf.format(enddate);
        return startMon;
    }

    public static String getNowMonY(){//获取当月和年
        calendar.setTime(startdate);
        calendar.add(calendar.MONTH, 0);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM");
        String nowMonY = sdf.format(enddate);
        return nowMonY;
    }

    public static String getEndMon(){//获取当月份
//        Date startdate = new Date();//取时间
//        Calendar calendar = new GregorianCalendar();
        calendar.setTime(startdate);
        calendar.add(calendar.MONTH, 1);//把日期往后增加一天.整数往后推,负数往前移动
        Date enddate = calendar.getTime(); //这个时间就是日期往后推一天的结果
        SimpleDateFormat sdf = new SimpleDateFormat("MM");
//        String startMon = sdf.format(startdate);
        String endMon = sdf.format(enddate);
//        String endMon = "2022-06-08";
        return endMon;
    }

    public static BigDecimal getMinValue(Map<String, BigDecimal> map){//获取map中最小的value
        //Collection<BigDecimal> c = map.values();
        List<BigDecimal> c = new ArrayList<>();
        map.forEach((key,value)->{
            c.add(value);
        });
        System.out.println(c);
        BigDecimal minValue = Collections.min(c);
//        Object[] obj = c.toArray();
//        Arrays.sort(obj);
//        //最小value
//        BigDecimal minValue = (BigDecimal) obj[0];
        return minValue;
    }


    public static Map<String,Integer> getWarnNumUtil(Map<String, Integer> map){//获取各工单预警个数
        Map<String, Integer> map1 = new HashMap<>();
        Integer s1 = 0;
        Integer s2 = 0;
        Integer s3 = 0;

        if (map.get("1")!=null){
            s1 = Integer.valueOf(org.apache.commons.lang3.StringUtils.substringBetween(String.valueOf(map.get("1")), "=", ","));
        }
        if (map.get("2")!=null){
            s2 = Integer.valueOf(org.apache.commons.lang3.StringUtils.substringBetween(String.valueOf(map.get("2")), "=", ","));
        }
        if (map.get("3")!=null){
            s3 = Integer.valueOf(org.apache.commons.lang3.StringUtils.substringBetween(String.valueOf(map.get("3")), "=", ","));
        }
        map1.put("1",s1);
        map1.put("2",s2);
        map1.put("3",s3);
        return map1;
    }

    public static String getPorgName(String pOrgNo){
        if ("1542110".equals(pOrgNo)){
            return "国网内蒙古东部电力有限公司陈巴尔虎旗供电分公司";
        }else if("1542105".equals(pOrgNo)){
            return "国网伊敏供电公司";
        }else if("1542112".equals(pOrgNo)){
            return "国网内蒙古东部电力有限公司鄂温克族自治旗供电公司";
        }else if("1542104".equals(pOrgNo)){
            return "国网满洲里市供电公司";
        }else if("1542121".equals(pOrgNo)){
            return "河西供电服务中心";
        }else if("1542113".equals(pOrgNo)){
            return "国网内蒙古东部电力有限公司额尔古纳供电分公司";
        }else if("1542109".equals(pOrgNo)){
            return "国网内蒙古东部电力有限公司莫力达瓦达斡尔族自治旗供电分公司";
        }else if("1542111".equals(pOrgNo)){
            return "国网内蒙古东部电力有限公司鄂伦春自治旗供电分公司";
        }else if("1542106".equals(pOrgNo)){
            return "国网根河市供电公司";
        }else if("1542114".equals(pOrgNo)){
            return "国网内蒙古东部电力有限公司新巴尔虎左旗供电分公司";
        }else if("1542102".equals(pOrgNo)){
            return "国网牙克石供电公司";
        }else if("1542115".equals(pOrgNo)){
            return "国网内蒙古东部电力有限公司新巴尔虎右旗供电分公司";
        }else if("1542122".equals(pOrgNo)){
            return "河东供电服务中心";
        }else if("1542108".equals(pOrgNo)){
            return "国网内蒙古东部电力有限公司阿荣旗供电分公司";
        }else if("1542103".equals(pOrgNo)){
            return "国网扎兰屯市供电公司";
        }
        return "";
    }


    public static Cookie getCookieByName(HttpServletRequest request, String name) {
        Map<String, Cookie> cookieMap = ReadCookieMap(request);
        if (cookieMap.containsKey(name)) {
            Cookie cookie = (Cookie) cookieMap.get(name);
            return cookie;
        } else {
            return null;
        }
    }

    private static Map<String, Cookie> ReadCookieMap(HttpServletRequest request) {
        Map<String, Cookie> cookieMap = new HashMap<String, Cookie>();
        Cookie[] cookies = request.getCookies();
        if (null != cookies) {
            for (Cookie cookie : cookies) {
                cookieMap.put(cookie.getName(), cookie);
            }
        }
        return cookieMap;
    }
}
