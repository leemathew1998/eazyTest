package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/3
 * @Version: 1.00 组织架构
 */
@Data
public class consTg implements Serializable {
    private Integer id;
    private String consNo;//用户编号
    private String consName;//用户名称
    private String mrSectNo;//抄表段编号
    private String mrSectName;//抄表段名称
    private String orgNo;//供电单位编号
    private String pOrgNo;//上級供电单位编号
    private String orgName;//供电单位名称
    private String pOrgName;//上级供电单位名称
    private String tgId;//台区标识
    private String tgNo;//台区编号
    private String tgName;//台区名称
    private String pubPrivFlag;//01公变 02专变
    private String realName;//台区经理名称
}
