package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import java.util.Date;
import com.baomidou.mybatisplus.annotation.TableId;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.dfzt.eunm.WorkOrderStatusEnum;

/**
 * <p>
 * 实体类
 * </p>
 *
 * @author dfzt-dyy
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="MeterWorkOrder对象", description="")
public class MeterWorkOrder implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "ID")
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "工单编号")
    private String workOrderNo;

    @ApiModelProperty(value = "台区经理")
    private String tgManagerDesk;

    @ApiModelProperty(value = "台区编号")
    private String tgNo;

    @ApiModelProperty(value = "台区名称")
    private String tgName;

    @ApiModelProperty(value = "供电单位")
    private String orgName;

    @ApiModelProperty(value = "用户名称")
    private String consName;

    @ApiModelProperty(value = "用户编码")
    private String consNo;

    @ApiModelProperty(value = "用户地址")
    private String consAddr;

    @ApiModelProperty(value = "用户电话")
    private String mobile;

    @ApiModelProperty(value = "电能表资产号")
    private String assetNo;

    @ApiModelProperty(value = "电能表条形码号")
    private String barCode;

    @ApiModelProperty(value = "终端厂家")
    private String factoryCode;

    @ApiModelProperty(value = "事件类型")
    private String eventType;

    @ApiModelProperty(value = "工单状态")
    private String workOrderStatus;

    @ApiModelProperty(value = "工单创建人")
    private String workOrderCreator;

    @ApiModelProperty(value = "工单创建时间")
    private Date workOrderCtime;

    @ApiModelProperty(value = "工单耗时")
    private String workOrderUtime;

    @ApiModelProperty(value = "工单解决时间")
    private Date workOrderStime;

    @ApiModelProperty(value = "工单归档时间")
    private Date workOrderFtime;

    @ApiModelProperty(value = "工单周期")
    private Integer workOrderCycle;

    @ApiModelProperty(value = "处理人")
    private String handler;

    @ApiModelProperty(value = "处理人接收时间")
    private Date handlerRtime;

    @ApiModelProperty(value = "历史工单处理人")
    private String hworkOrderHandler;

    @ApiModelProperty(value = "历史工单处理人接收工单时间")
    private Date hworkOrderHandlerRtime;

    @ApiModelProperty(value = "历史工单处理人转出流转时间")
    private Date hworkOrderHandlerTtime;

    //工单状态 枚举
    public void setWorkOrderStatus(String workOrderStatus) {
        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
    }
}
