package org.dfzt.util;

import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class MeterYcUtils {

    public static List<String> meterYc(BigDecimal subtract,BigDecimal ds,BigDecimal d,
                                 List<Integer> vto,List<Integer> cto,String p,String ras,String runs){
        BigDecimal num= new BigDecimal("0.05");
        BigDecimal num1= new BigDecimal("0");
        List<String> list = new ArrayList<>();
        //尖峰平谷示数之和与正向有功总的差值为
        log.info("尖峰平谷示数之和与正向有功总的差值为；"+subtract);
        if (subtract.compareTo(num) > 0){
            list.add("1");//总示数与各费率之和不等——(研判原因存放入list集合)
        }
        if (ds.compareTo(num1) > 0 && d.compareTo(num1) > 0){
            list.add("2");//反向有功示值大于0——(研判原因存放入list集合)
        }
        for (int i=0;i<vto.size();i++){
            if (vto.get(i) == 1){
                list.add("3");  //低电压——(研判原因存放入list集合)
                break;
            }
        }
        for (int i=0;i<cto.size();i++){
            if (cto.get(i) == 1){
                list.add("4");//失压——(研判原因存放入list集合)
                break;
            }
        }
        if (p != null &&p.equals("5")){
            list.add("5");  //电能表停走——(研判原因存放入list集合)
        }
        if (ras != null &&ras.equals("6")){
            list.add("6");  //电能表飞走——(研判原因存放入list集合)
        }
        if (runs != null &&runs.equals("7")){
            list.add("7");  //电能表倒走——(研判原因存放入list集合)
        }
        return list;
    }
}
