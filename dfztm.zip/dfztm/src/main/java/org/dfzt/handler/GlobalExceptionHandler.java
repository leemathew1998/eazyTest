package org.dfzt.handler;

import org.dfzt.response.Result;
import org.dfzt.response.ResultCode;
import org.omg.CosNaming.NamingContextPackage.NotFound;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.HttpClientErrorException;

/**
 * @Author dyy
 * @Date 2022/7/11 17:25
 * @PackageName:org.dfzt.handler
 * @ClassName: GlobalExceptionHandler
 * @Description: TODO 统一异常处理
 * @Version 1.0
 */

@ControllerAdvice
public class GlobalExceptionHandler {

    /**
     * 全局异常
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    public Result error(Exception e){
        e.printStackTrace();
        return Result.error();
    }

    /**
     * 算术异常
     * @param e
     * @return
     */
    @ExceptionHandler(ArithmeticException.class)
    @ResponseBody
    public Result error(ArithmeticException e){
        e.printStackTrace();
        return Result.error().code(ResultCode.ARITHMETIC_EXCEPTION.getCode())
                .message(ResultCode.ARITHMETIC_EXCEPTION.getMessage());
    }

    /**
     * 404
     * @param e
     * @return
     */
    @ExceptionHandler(ClassNotFoundException.class)
    @ResponseBody
    public Result error(ClassNotFoundException e){
        e.printStackTrace();
        return Result.error().code(ResultCode.PAGE_NOT_FOUND.getCode())
                .message(ResultCode.PAGE_NOT_FOUND.getMessage());
    }

    /**
     * 业务异常
     * @param e
     * @return
     */
    @ExceptionHandler(BusinessException.class)
    @ResponseBody
    public Result error(BusinessException e) {
        e.printStackTrace();
        return Result.error().code(e.getCode()).message(e.getErrMsg());
    }
}
