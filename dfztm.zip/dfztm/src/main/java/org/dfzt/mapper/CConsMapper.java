package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Mapper
public interface CConsMapper extends BaseMapper<CCons> {
    String selectone(String cons_no);

    String selectByid(Integer cust_id);

    int queryone(String orgid, String startime, String endtime);

    //Page<CCons> selectUserAll(@Param("page") Page<CCons> page, @Param("one") String one);//查看敏感用户档案所有内容
    List<CCons> selectUserAll(String one);//查看敏感用户档案所有内容



    List<OStaff> selectCcon(String empOn);//查看用户联系信息表
    List<ElectricityPrice> selectElec(String consNo);//查看定价策略及电价表
    List<CInformation> selectInfor(String consNo);//查看受电点基础信息


}
