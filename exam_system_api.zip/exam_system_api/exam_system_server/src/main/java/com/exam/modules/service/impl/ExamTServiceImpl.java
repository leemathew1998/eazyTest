package com.exam.modules.service.impl;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.exam.modules.entity.vo.ExamTVo;
import com.exam.modules.mapper.ExamTMapper;
import com.exam.modules.entity.ExamT;
import com.exam.modules.service.ExamTService;
import org.springframework.stereotype.Service;

/**
 * (ExamT)表服务实现类
 *
 * @author makejava
 * @since 2022-11-08 09:58:14
 */
@Service("examTService")
public class ExamTServiceImpl extends ServiceImpl<ExamTMapper, ExamT> implements ExamTService {

    @Override
    public IPage<ExamT> findExamTList(IPage<ExamT> page, ExamTVo examTVo) {
        //创建条件构造器
        QueryWrapper<ExamT> queryWrapper = new QueryWrapper<ExamT>();
        //题库类型
        queryWrapper.like(StrUtil.isNotBlank(examTVo.getTtype()),"TTYPE",examTVo.getTtype());
        //题目难度
        queryWrapper.like(StrUtil.isNotBlank(examTVo.getTdiff()),"TDIFF",examTVo.getTdiff());
        //题目内容问题
        queryWrapper.like(StrUtil.isNotBlank(examTVo.getTproblem()),"TPROBLEM",examTVo.getTproblem());
        //知识分类
        queryWrapper.like(StrUtil.isNotBlank(examTVo.getKnowGory()),"KNOW_GORY",examTVo.getKnowGory());
        //使用次数
        queryWrapper.like(StrUtil.isNotBlank(examTVo.getUseNum()),"USE_NUM",examTVo.getUseNum());
        //分数
        queryWrapper.like(StrUtil.isNotBlank(examTVo.getScore()),"SCORE",examTVo.getScore());
        return baseMapper.selectPage(page,queryWrapper);
    }
}
