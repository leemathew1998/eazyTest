package org.dfzt.controller;



import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.annotation.CurrentUser;
import org.dfzt.entity.vo.*;
import org.dfzt.mapper.ActiveOperationMapper;
import org.dfzt.service.ActiveOperationService;
import org.dfzt.service.DefectInforService;
import org.dfzt.service.DefectRepairService;
import org.dfzt.service.OverhaulInforService;
import org.dfzt.util.ExcelUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



@RestController
@Slf4j
@RequestMapping("/activeOperation")
public class ActiveOperationController extends ApiController {
    @Autowired
    private ActiveOperationService activeOperationService;

    @Resource
    private ActiveOperationMapper activeOperationMapper;
    @Autowired
    private DefectInforService defectInforService;
    @Autowired
    private DefectRepairService defectRepairService;
    @Autowired
    private OverhaulInforService overhaulInforService;


    //TODO 定时从断路器获取数据


    //TODO 断路器获取电压数据
    @RequestMapping("/getEmpVol")
    public List<Object> getEmpVol(){
        return activeOperationMapper.selectEMpVolCurve();
    }

    //TODO 断路器获取电流数据
    @RequestMapping("/getEmpCur")
    public List<Object> getEmpCur(){
        return activeOperationMapper.selectEMpCurCurve();
    }

    //TODO 断路器获取功率数据
    @RequestMapping("/getEmpPow")
    public List<Object> getEmpPow(){
        return activeOperationMapper.selectEMpPowCurve();
    }


    /**
     * TODO 工单列表
     */


    @PostMapping("/list")
    public R aOperationList(){
        List<ActiveOperation> activeOperation = activeOperationService.selectAll();
        if (activeOperation.size() < 1){
            return success("列表为空").setMsg("查询失败").setCode(500);
        }
        return success(activeOperation).setMsg("查询成功").setCode(200);
    }


    /**
     * TODO 工单列表 权限以及模糊查询
     */
   /* @RequestMapping("/list1")
    public List<ActiveOperation> aOperationList1(ActiveOperation a,@CurrentUser SysUser user){
        List<ActiveOperation> activeOperations = activeOperationService.selectList1(a,user.getLoginName());
        return activeOperations;
    }*/

    @PostMapping("/list1")
    public R aOperationList1(ActiveOperation a,@CurrentUser SysUser user){
        List<ActiveOperation> activeOperations = activeOperationService.selectList1(a,user.getLoginName());
        if (activeOperations.size() < 1){
            return success("列表为空").setMsg("查询失败").setCode(500);
        }
        return success(activeOperations).setMsg("查询成功").setCode(200);
    }


        /**
         * TODO 工单列表 单个条件查询
         */
    @PostMapping("/list2")
    public List<ActiveOperation> aOperationList2(String one,@CurrentUser SysUser user){
        List<ActiveOperation> activeOperations = activeOperationService.selectList2(one,user.getLoginName());
        return activeOperations;
    }


        /**
         * TODO 点击主动运维列表查看详情 --检修录入信息
         */
    @PostMapping("/selHandle")
    public OverhaulInfor selHandle(@RequestParam String workOrderNo){
        return overhaulInforService.selectOne(workOrderNo);
    }


    /**
     * TODO 提交工单信息 （一般工单，转抢修，误报工单）
     */
    @PostMapping("/details")
    public String details(@RequestBody String workOrderNo,DefectInfor defectInfor,@RequestParam int a){
        if (a == 5) {
            defectInforService.insertDefectInfor(defectInfor);
            Integer i = activeOperationService.upStatus5(workOrderNo);//修改工单状态
            log.info("工单状态修改为误报工单条数是,{}",i);
            return "误报工单生成";
        }else if(a == 6){
            Integer i1 = activeOperationService.upStatus6(defectInfor.getWorkOrderNo());//转抢修工单
            defectInforService.insertDefectInfor(defectInfor);
            return "转抢修工单";
        }else {
            int i = defectInforService.insertDefectInfor(defectInfor);
            Integer i1 = activeOperationService.upStatus2(defectInfor.getWorkOrderNo());
            log.info(String.valueOf(i));
            log.info("工单状态修改为处理中,{}",i1);
            return "提交成功";
        }
    }

    /**
     * TODO 对工单状态改为5 误判工单
     */
    @PostMapping("/upStatus5")
    @ResponseBody
    public Integer upStatus5(@RequestParam String workOrderNo){
        Integer i = activeOperationService.upStatus5(workOrderNo);//修改工单状态
        log.info("工单状态修改为已处理工单条数是,{}",i);
        return i;
    }

    /**
     * TODO 对工单状态改为6 转抢修
     */
    @PostMapping("/upStatus6")
    @ResponseBody
    public Integer upStatus6(@RequestParam String workOrderNo){
        Integer i = activeOperationService.upStatus6(workOrderNo);//修改工单状态
        log.info("工单状态修改为转抢修工单条数是,{}",i);
        return i;
    }

    /**
     * TODO 对工单状态改为4 已归档
     */
    @PostMapping("/upStatus4")
    @ResponseBody
    public Integer upStatus4(@RequestParam String workOrderNo){
        Integer i = activeOperationService.upStatus4(workOrderNo);//修改工单状态
        log.info("工单状态修改为已归档工单条数是,{}",i);
        return i;
    }


    /**
         * TODO 根据工单编号进行缺陷录入回显
         * @return
         */
    @PostMapping("/load")
    public DefectInfor load(@RequestParam String workOrderNo){

        return activeOperationService.selectload(workOrderNo);
    }


    /**
     * TODO 点击处理按钮 处理信息 提交按钮
     */
    @PostMapping("/dcommit")
    public String dcommit(DefectRepair defectRepair){
        int i = defectRepairService.insertDefectRepair(defectRepair);
        Integer i1 = activeOperationService.upStatus3(defectRepair.getWorkOrderNo());
        log.info(String.valueOf(i));
        log.info("工单状态修改为处理中,{}",i1);
        return "提交成功";
    }

    /**
     * TODO 根据工单编号对误报工单的录入回显
     */
    @PostMapping("/fload")
    public DefectInfor rload(@RequestParam String workOrderNo){
        return activeOperationService.selectload(workOrderNo);
    }
    /**
     * TODO 根据工单编号进行立行立改回显
     * @return
     */
    @PostMapping("/dload")
    public DefectRepair dload(@RequestParam String workOrderNo){
        return activeOperationService.selectdload(workOrderNo);
    }



    /**
     * TODO 根据工单编号进行检修回显
     * @return
     */
    @PostMapping("/oload")
    public OverhaulInfor oload(@RequestParam String workOrderNo){
        return activeOperationService.selectoload(workOrderNo);
    }


    /**
     * 主动运维导出
     *
     * @param ids
     * @return
     */
    @PostMapping("export")  //excel/export
    public void export(HttpServletResponse response, @RequestParam List<String> ids) throws IOException {
        List<org.dfzt.entity.po.ActiveOperation> list = new ArrayList<>();
        for (String id : ids) {
            org.dfzt.entity.po.ActiveOperation activeOperation = activeOperationService.selectByActiveOperationNo(id);
            if (StrUtil.isNotBlank(activeOperation.getPhoto())){
                String[] split = activeOperation.getPhoto().split(",");
                if (split.length > 0) {
                    activeOperation.setPhotoOne(split[0]);
                }
                if (split.length > 1) {
                    activeOperation.setPhotoTwo(split[1]);
                }
                if (split.length > 2) {
                    activeOperation.setPhotoThree(split[2]);
                }
            }
            list.add(activeOperation);
        }
        ExcelUtils.exportExcel(list, "主动运维工单列表", "主动运维", org.dfzt.entity.po.ActiveOperation.class, "主动运维工单文件", response);
    }

    /**
     * TODO 主动运维工单 包含敏感用户
     */
    @PostMapping("/listapp")
    public List<ActiveOperation> aOperationListapp(){
        List<ActiveOperation> activeOperations = activeOperationService.selectAllYWOapp();
        return activeOperations;
    }

    /**
     * TODO 点击处理按钮 处理信息 提交按钮
     */
    @PostMapping("/ocommit")
    public String ocommit(OverhaulInfor overhaulInfor){
        int i = overhaulInforService.insertOverhaul(overhaulInfor);
        Integer i1 = activeOperationService.upStatus3(overhaulInfor.getWorkOrderNo());
        log.info(String.valueOf(i));
        log.info("工单状态修改为处理中,{}",i1);
        return "提交成功";
    }

}