package org.dfzt.annotation;

import java.lang.annotation.*;

/**
 * @ClassName CurrentUser
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/8/10 17:32
 */
@Target({ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CurrentUser {

}
