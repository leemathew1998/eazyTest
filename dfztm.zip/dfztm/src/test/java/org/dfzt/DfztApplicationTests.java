package org.dfzt;



import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.obs.services.ObsClient;
import com.sgcc.isc.ualogin.client.IscServiceTicketValidator;
import org.apache.commons.lang3.StringUtils;
import org.checkerframework.checker.units.qual.C;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.ConsConMobile;
import org.dfzt.entity.xmlDemoReal.Demo1;
import org.dfzt.entity.xmlDemoReal.DemoConverter;
import org.dfzt.entity.xmlDemoReal.General;
import org.dfzt.mapper.*;
import org.dfzt.service.ThDapiService;
import org.dfzt.util.Base64Util;
import org.dfzt.util.ObsUtil;
import org.dfzt.util.TimeUtil;
import org.dfzt.util.XStreamUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.w3c.dom.Document;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SpringBootTest
class DfztApplicationTests {

    @Resource
    RecycleWorkOrderMapper recycleWorkOrderMapper;
    @Resource
    CollectWorkOrderMapper collectWorkOrderMapper;
    @Resource
    FeecontrolWorkOrderMapper feecontrolWorkOrderMapper;

    @Test
    void XQcontextLoads() throws IOException, ParseException {
        BigDecimal i1 = new BigDecimal("1");
        BigDecimal j1 = new BigDecimal("5676");

        BigDecimal s1 = new BigDecimal("1").subtract(i1.divide(j1, 4, BigDecimal.ROUND_HALF_UP));
        System.out.println(s1);
        BigDecimal bigDecimal = s1.multiply(new BigDecimal("100")).setScale(2);
        System.out.println(bigDecimal);
        Integer p1 = Integer.parseInt(new BigDecimal("0.9997").subtract(s1).divide(new BigDecimal("0.0001")).toString());
        System.out.println(p1);
        Integer t1 =5;

        if(p1 <= 5 && p1>0){
            t1=5-p1;
        }else if(p1 <= 0){
            t1=5;
        }else {
            t1=0;
        }
        System.out.println(t1);

    }

    @Test
    void test1() throws IOException, ParseException {
        double d = 114.00;

        d= (double) Math.round(d * 100) / 100.0;

        System.out.println(d);
    }

    @Test
    void test2() throws IOException, ParseException {

    }



//    String getValue1 = null;
//    Cookie[] cookies = request.getCookies();
//        if (cookies != null) {
//        for (int i = 0; i < cookies.length; i++) {
//            Cookie ck = cookies[i];
//            if (ck.getName().equals("loName2")) {
//                getValue1 = ck.getValue();
//            }
//        }
//    }
}
