package com.exam.modules.service;

import com.exam.modules.entity.SysRoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色菜单表 服务类
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface ISysRoleMenuService extends IService<SysRoleMenu> {

}
