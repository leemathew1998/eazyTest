package com.exam.modules.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.exam.modules.entity.ExamPaperInfo;
import com.exam.modules.entity.ExamT;
import com.exam.modules.entity.dto.ExamPaperInfoDTO;
import com.exam.modules.entity.vo.ExamPaperInfoVo;

import java.util.Map;

/**
 * (ExamPaperInfo)表服务接口
 *
 * @author dyy
 * @since 2022-11-08 15:32:48
 */
public interface ExamPaperInfoService extends IService<ExamPaperInfo> {

    IPage<ExamPaperInfo> findPaperInfoList(IPage<ExamPaperInfo> page, ExamPaperInfoVo examPaperInfoVo);

    /**
     * 自动出卷
     * @param examPaperInfo
     * @return
     */
    boolean savePaper(ExamPaperInfoDTO examPaperInfo);

    boolean updateUseNum(ExamPaperInfo examPaperInfo);
}

