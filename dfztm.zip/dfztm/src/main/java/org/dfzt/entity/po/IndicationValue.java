package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/20
 * @Version: 1.00 示值曲线实体类
 */
@Data
public class IndicationValue {
    private Integer id;
    //供电单位
    private String orgName;
    //用户编码
    private String consNo;
    //用户名称
    private String consName;
    //电能表资产号
    private String meterAssetNo;
    //电能表厂家
    private String metManufacturer;
    //终端厂家
    private String factoryCode;
    //台区编号
    private String tgNo;
    //台区名称
    private String tgName;
    //抄表日期
    private Date mrDate;
    //数据来源
    private String dataSrc;
    //综合倍率
    private BigDecimal tFactor;
    //相序
    private String phaseFlag;
    //点数
    private String dataPointFlag;
    //1点
    private BigDecimal r1;
    //2点
    private BigDecimal r2;

    private BigDecimal r3;

    private BigDecimal r4;

    private BigDecimal r5;

    private BigDecimal r6;

    private BigDecimal r7;

    private BigDecimal r8;

    private BigDecimal r9;

    private BigDecimal r10;

    private BigDecimal r11;

    private BigDecimal r12;

    private BigDecimal r13;

    private BigDecimal r14;

    private BigDecimal r15;

    private BigDecimal r16;

    private BigDecimal r17;

    private BigDecimal r18;

    private BigDecimal r19;

    private BigDecimal r20;

    private BigDecimal r21;

    private BigDecimal r22;

    private BigDecimal r23;

    private BigDecimal r24;

    private BigDecimal r25;

    private BigDecimal r26;

    private BigDecimal r27;

    private BigDecimal r28;

    private BigDecimal r29;

    private BigDecimal r30;

    private BigDecimal r31;

    private BigDecimal r32;

    private BigDecimal r33;

    private BigDecimal r34;

    private BigDecimal r35;

    private BigDecimal r36;

    private BigDecimal r37;

    private BigDecimal r38;

    private BigDecimal r39;

    private BigDecimal r40;

    private BigDecimal r41;

    private BigDecimal r42;

    private BigDecimal r43;

    private BigDecimal r44;

    private BigDecimal r45;

    private BigDecimal r46;

    private BigDecimal r47;

    private BigDecimal r48;

    private BigDecimal r49;

    private BigDecimal r50;

    private BigDecimal r51;

    private BigDecimal r52;

    private BigDecimal r53;

    private BigDecimal r54;

    private BigDecimal r55;

    private BigDecimal r56;

    private BigDecimal r57;

    private BigDecimal r58;

    private BigDecimal r59;

    private BigDecimal r60;

    private BigDecimal r61;

    private BigDecimal r62;

    private BigDecimal r63;

    private BigDecimal r64;

    private BigDecimal r65;

    private BigDecimal r66;

    private BigDecimal r67;

    private BigDecimal r68;

    private BigDecimal r69;

    private BigDecimal r70;

    private BigDecimal r71;

    private BigDecimal r72;

    private BigDecimal r73;

    private BigDecimal r74;

    private BigDecimal r75;

    private BigDecimal r76;

    private BigDecimal r77;

    private BigDecimal r78;

    private BigDecimal r79;

    private BigDecimal r80;

    private BigDecimal r81;

    private BigDecimal r82;

    private BigDecimal r83;

    private BigDecimal r84;

    private BigDecimal r85;

    private BigDecimal r86;

    private BigDecimal r87;

    private BigDecimal r88;

    private BigDecimal r89;

    private BigDecimal r90;

    private BigDecimal r91;

    private BigDecimal r92;

    private BigDecimal r93;

    private BigDecimal r94;

    private BigDecimal r95;
    //96点
    private BigDecimal r96;
    //用电地址
    private String elecAddr;
    //电能表地址
    private String commAddr;
    //终端地址
    private String terminalAddr;
    //上送时间
    private Date recTime;
    //测量点号
    private String mpSn;
    //终端资产号
    private String tmnlAssetNo;
    //主用途类型
    private String usageTypeCode;
}
