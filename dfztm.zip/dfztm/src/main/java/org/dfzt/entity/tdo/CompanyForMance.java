package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 所业绩指标
 */
@Data
public class CompanyForMance {
    //公司当日总积分
    private int theCompanyTotalPointsForTheDay;
    //公司当日排名
    private int companyRankingOfTheDay;
    //指标列表
    private List<Indicators> indicators;
}
