package org.dfzt.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.*;
import org.dfzt.mapper.*;
import org.dfzt.response.ResultCode;
import org.dfzt.service.*;
import org.dfzt.service.impl.RunWorderDealServiceImpl;
import org.dfzt.util.ExcelUtils;
import org.dfzt.util.OrderWarnUtil;
import org.dfzt.util.TimeUtil;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Api(tags = "电费补抄")
@RestController
@RequestMapping("/runWorkOrder")
public class RunWorkOrderController extends ApiController {
    @Resource
    RunWorkOrderService runWorkOrderService;
    @Resource
    CConsService cConsService;
    @Resource
    RunWorkOrderMapper runWorkOrderMapper;
    @Resource
    RunWorderDealServiceImpl runWorderDealServiceImpl;
    @Resource
    FeecontrolWorkOrderService feecontrolWorkOrderService;
    @Resource
    RunSupplementaryCopyService runSupplementaryCopyService;
    @Resource
    private ARcvblFlowMapper aRcvblFlowMapper;
    @Resource
    private CollectWorkOrderMapper collectWorkOrderMapper;
    @Resource
    AsyncTaskExecutor asyncTaskExecutor;
    @Resource
    CachesService cachesService;

    /**
     * 级别
     */
    private final static String ONE_GRADE = "1";
    private final static String TWO_GRADE = "2";

    /**
     * 电费补抄工单生成及工单预警
     * @return
     */
//    @Scheduled(cron = "0 0 7-17 1,2,3 * ?")
    @Async
    @RequestMapping("testpg1")
    public void pgTest1(){
//        List<String> lists = collectWorkOrderMapper.selectOrgList();
        //获取全域营业所
        List<String> lists = cachesService.getBusinessPlace();

        //获取上月采集失败需要本月补抄的用户电表数据
        List<EAmtVerifyResult> eAmtVerifyResults = runWorkOrderMapper.selectRunwo1(TimeUtil.getStartMon1(),lists);
        List<String> resultIdList = runWorkOrderMapper.getResultId(TimeUtil.getStartMon1());
        int i = 0;
        int j = 0;
        List<RunWorkOrder> runlists= new ArrayList<>();
        List<EAmtVerifyResult> eamts= new ArrayList<>();

        //定义任务数量
        CountDownLatch latch = new CountDownLatch(eAmtVerifyResults.size());
        for (EAmtVerifyResult eAmtVerifyResult : eAmtVerifyResults) {
           Runnable runnabler = ()->{
               buChaoDetail(eAmtVerifyResult,runlists,eamts,resultIdList);
               latch.countDown();
            };
            asyncTaskExecutor.submit(runnabler);
        }

        try {
            latch.await();
            for (RunWorkOrder runlist : runlists) {
                i += runWorkOrderMapper.insertRunwork(runlist);
            }
            for (EAmtVerifyResult eamt : eamts) {
                j += runWorkOrderMapper.insertEamtver(eamt);
            }
            //工单表的生成和源表的生成
            System.out.println("补抄工单数量为:"+i+"条<>源表数量生成为"+j+"条");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void buChaoDetail(EAmtVerifyResult eAmtVerifyResult,List<RunWorkOrder> runlists,List<EAmtVerifyResult> eamts,
                             List<String> resultIdList){
        //查询前几日的未归档工单并修改成预警工单
        String s = runWorkOrderMapper.selectByConsNo(eAmtVerifyResult.getConsNo());
        if (StrUtil.isNotBlank(s)){
            runWorkOrderMapper.updateRWOCycle(ONE_GRADE, s);
        }

        boolean b = resultIdList.stream().anyMatch(i -> i.equals(eAmtVerifyResult.getResultId()));
        if (!b){
//        if (runWorkOrderMapper.selectByResultId(eAmtVerifyResult.getResultId())==0){
            //新增该条数据到源表 并且生成到工单表
            eamts.add(eAmtVerifyResult);
            CCons cCons = runWorkOrderMapper.selectConsmarketSort(eAmtVerifyResult.getConsNo());
            String market = "";
    //                if(!"".equals(cCons.getMarketPropSort())|| cCons.getMarketPropSort()!=null){
    //                    market=cCons.getMarketPropSort();
    //                }
            if(!StringUtils.isEmpty(cCons)){
                market=cCons.getMarketPropSort();
            }
            System.out.println(market);
            String voltCode = eAmtVerifyResult.getVoltCode();
            if ("".equals(voltCode)|| voltCode ==null){
                voltCode = cCons.getVoltCode();
            }
            if (voltCode.equals("AC02202") && (market.equals("02") || market.equals("0201"))) {//为非市场化用户
                System.out.println("非市场化用户并且电压等级为220V不生成工单");
            } else {
                RunWorkOrder runwo = new RunWorkOrder();
                runwo.setWorkOrderNo(TimeUtil.getTime(new DateTime()) + "06" + OrderWarnUtil.OrderNum());
                runwo.setAppNo(eAmtVerifyResult.getAppNo());//工单编号
                runwo.setConsNo(eAmtVerifyResult.getConsNo());//用户编号
//                String mrsect = collectWorkOrderMapper.selectMrSectNo(eAmtVerifyResult.getConsNo());
//                String operatorNo = collectWorkOrderMapper.selectOperatorMpg(mrsect);
                runwo.setArcEmpName(collectWorkOrderMapper.selectTgManage1(eAmtVerifyResult.getConsNo()));
                runwo.setWorkOrderCtime(new DateTime());//工单创建时间
                runwo.setWorkOrderCtime1(TimeUtil.getTodayTime());
                runwo.setMrStatusCode1(eAmtVerifyResult.getCollectStatus());
                runwo.setElecTypeCode(cachesService.getPropName("elec_type_code", eAmtVerifyResult.getElecTypeCode()));
//                runwo.setElecTypeCode(collectWorkOrderMapper.selectElecName("elec_type_code",eAmtVerifyResult.getElecTypeCode()));
                runwo.setWorkOrderStatus1("1");
                //runwo.setWorkOrderStatus("1");
                List<GTg> gTgs = aRcvblFlowMapper.selectTgNoName(eAmtVerifyResult.getConsNo());
                if(gTgs.size()!=0){
                    for (int i1 = 0; i1 < gTgs.size(); i1++) {
                        if(gTgs.get(i1)!=null) {
                            runwo.setTgNo(gTgs.get(i1).getTgNo());//台区编号
                            runwo.setTgName(gTgs.get(i1).getTgName());//台区名称
                            break;
                        }
                    }
                }

//                runwo.setOrgName(collectWorkOrderMapper.selectOrgNo(eAmtVerifyResult.getOrgNo()));//供电单位名称
                runwo.setOrgName(cachesService.getOrgName(eAmtVerifyResult.getOrgNo()));
//                runwo.setVoltCode(collectWorkOrderMapper.selectElecName("volt_code", voltCode));//电压等级
                runwo.setVoltCode(cachesService.getPropName("volt_code", voltCode));
                CCons cCons2 = aRcvblFlowMapper.selectConsName(eAmtVerifyResult.getConsNo());
                if (!StringUtils.isEmpty(cCons2)){
                    runwo.setConsName(cCons2.getConsName());//用户名称
                }
                List<String> mobiles = aRcvblFlowMapper.selectMobiAddr(eAmtVerifyResult.getConsNo());
                if (mobiles.size()!=0){
                    runwo.setMobile(mobiles.get(0));//用户电话
                }
                CCons cCons1 = aRcvblFlowMapper.selectConsName(eAmtVerifyResult.getConsNo());
                if (!StringUtils.isEmpty(cCons1)){
                    runwo.setElecAddr(cCons1.getElecAddr());//用户地址
                    runwo.setConsName(cCons1.getConsName());
                }
                runlists.add(runwo);
            }
        }
    }


    @RequestMapping("getEAmtVer")
    @ResponseBody
    public void getEAmtVer(){
        List<EAmtVerifyResult> eAmtVerifyResults = runWorkOrderMapper.selectEAmtVer(TimeUtil.getStartMon1());
        List<RunWorkOrder> runlists= new ArrayList<>();
        for (EAmtVerifyResult eAmtVerifyResult : eAmtVerifyResults) {
            if (runWorkOrderMapper.selectWorkByResultId(eAmtVerifyResult.getAppNo())==0) {//不存在则生成工单
                String market = runWorkOrderMapper.selectConsmarketSort(eAmtVerifyResult.getConsNo()).getMarketPropSort();
                if (eAmtVerifyResult.getVoltCode().equals("AC02202") && (market.equals("02") || market.equals("0201"))) {//为非市场化用户
                    System.out.println("非市场化用户并且电压等级为220V不生成工单");
                } else {
                    RunWorkOrder runwo = new RunWorkOrder();
                    runwo.setWorkOrderNo(eAmtVerifyResult.getAppNo());//工单编号
                    runwo.setConsNo(eAmtVerifyResult.getConsNo());//用户编号
                    runwo.setWorkOrderCtime(new DateTime());//工单创建时间
                    runwo.setWorkOrderCtime1(TimeUtil.getTodayTime());
                    List<GTg> gTgs = aRcvblFlowMapper.selectTgNoName(eAmtVerifyResult.getConsNo());
                    if(gTgs.size()!=0){
                        for (int i1 = 0; i1 < gTgs.size(); i1++) {
                            if(gTgs.get(i1)!=null) {
                                runwo.setTgNo(gTgs.get(i1).getTgNo());//台区编号
                                runwo.setTgName(gTgs.get(i1).getTgName());//台区名称
                                break;
                            }
                        }
                    }
                    runwo.setOrgName(collectWorkOrderMapper.selectOrgNo(eAmtVerifyResult.getOrgNo()));//供电单位名称
                    runwo.setVoltCode(eAmtVerifyResult.getVoltCode());//电压等级
                    runwo.setConsName(aRcvblFlowMapper.selectConsName(eAmtVerifyResult.getConsNo()).getConsName());//用户名称
                    String addr = aRcvblFlowMapper.selectConsName(eAmtVerifyResult.getConsNo()).getElecAddr();
                    runwo.setElecAddr(addr);//用户地址
                    runwo.setMobile(aRcvblFlowMapper.selectMobiAddr(eAmtVerifyResult.getConsNo()).get(0));//用户电话
                    runlists.add(runwo);
                }
            }
        }
        int i=0;
        for (RunWorkOrder runlist : runlists) {
            i+=runWorkOrderMapper.insertRunwork(runlist);
        }
        //将runlist新增到表中
        System.out.println("getEAmtVer生成数"+i);
    }


    //每月月初获取电费补抄源数据
    @RequestMapping("getPgec3")
    public String getPgec3(){
        List<EAmtVerifyResult> eAmtVerifyResults = runWorkOrderMapper.selectRunwo3(TimeUtil.getStartMon1());//TimeUtil.getStartMon1()
        for (EAmtVerifyResult eAmtVerifyResult : eAmtVerifyResults) {
            System.out.println(eAmtVerifyResult);
        }

        return "getPgec3";
    }

    @RequestMapping("getPge")
    public String getPge(){
        List<RunWorkOutside> runWorkOutsides = runWorkOrderMapper.selectRunwo();//TimeUtil.getStartMon1()
        System.out.println(runWorkOutsides);
        for (RunWorkOutside runWorkOutside : runWorkOutsides) {
            System.out.println(runWorkOutside);
        }
        return "getPge1";
    }

    @RequestMapping("getPgec")
    public String getPgec(){
        List<RunWorkOutside> runWorkOutsides = runWorkOrderMapper.selectRunwo();//TimeUtil.getStartMon1()
        System.out.println(runWorkOutsides);
        for (RunWorkOutside runWorkOutside : runWorkOutsides) {
            System.out.println(runWorkOutside);
        }
        return "getPgec";
    }



    @RequestMapping("testpg2")
    public void pgTest2(){
        List<Object> selectyyyy = runWorkOrderMapper.selectyyyy();
        for (Object o : selectyyyy) {
            System.out.println("pg库="+o);
        }
    }

    @RequestMapping("export")  //excel/export
    public void exportExcel2(HttpServletResponse response, @RequestParam String ids) throws IOException {
        List<RunWorkOrder> runWorkOrders = collectWorkOrderMapper.selectExcel6(ids);
        ExcelUtils.exportExcel(runWorkOrders, "电费补抄工单列表", "电费补抄", RunWorkOrder.class, "电费补抄工单文件", response);
    }


    @RequestMapping("exportAll")  //excel/export
    public void exportExcel2All(HttpServletResponse response, @RequestParam(required = false) String ids, RunWorkOrder r,
                                @RequestParam(required = false) String status, @RequestParam(required = false) String orgNo,
                                @RequestParam(required = false) String loName2) throws IOException {
        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<RunWorkOrder> runWorkOrders = runWorkOrderMapper.selectExcelList(r, orgName, status);
        ExcelUtils.exportExcel(runWorkOrders, "电费补抄工单列表", "电费补抄", RunWorkOrder.class, "电费补抄工单文件", response);
    }


    /**
     * 查询电费补超数据(web端)
     */
    @PostMapping(value = "/selectAll")
    public R selectAll(@RequestParam(name = "pageNo", defaultValue = "1") String pageNo,
                       @RequestParam(name = "pageSize", defaultValue = "10") String pageSize,
                       RunWorkOrder runWorkOrder,@RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String loName2){
        String role = "2";//feecontrolWorkOrderService.selectRole(sysUser.getLoginName());
        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        //Page<RunWorkOrder> page=new Page<>((Integer.parseInt(pageNo)-1)*Integer.parseInt(pageSize),Integer.parseInt(pageSize));
        Page<RunWorkOrder> page=new Page<>(Integer.parseInt(pageNo),Integer.parseInt(pageSize));

        R<IPage<RunWorkOrder>> success = success(runWorkOrderService.selectAll(page, runWorkOrder, role,status,orgName));
        if (success.getData().getRecords().size() > 0) {
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }

    /**
     * 查询电费补超数据(app端)
     */
    @PostMapping(value = "/queryAll")
    public R queryAll(@RequestParam(name = "pageNo", defaultValue = "0") String pageNo,
                          @RequestParam(name = "pageSize", defaultValue = "10") String pageSize,
                          String condition, @RequestParam String loName2,@RequestParam String workOrderStatus,
                      @RequestParam(required = false) String role,@RequestParam(required = false) String loginName){
        //String role = "2";//feecontrolWorkOrderService.selectRole(loName2);
        List<String> readNames = collectWorkOrderMapper.selectReadNames(loginName);
        Page<RunWorkOrder> page=new Page<>(Integer.parseInt(pageNo),Integer.parseInt(pageSize));
        R<IPage<RunWorkOrder>> success = success(runWorkOrderService.queryAll(readNames,page, condition, role,workOrderStatus,loName2));
        if (success.getData().getRecords().size() > 0) {
            success.setCode(ResultCode.SUCCESS.getCode());
            success.setMsg(ResultCode.SUCCESS.getMessage());
            return success;
        }
        success.setCode(ResultCode.ERROR.getCode());
        success.setMsg(ResultCode.ERROR.getMessage());
        return success;
    }

    /**
     * 手机端电费补抄工单展示
     * 4号凌晨研判方法调用之后调用,查询未抄表，
     * 通过台区经理编号查询工单中未抄表的数据
     * 查询未抄表的数据需要站长手动归档
     * @param
     * @return
     */
    @ApiOperation(value = "台区经理对应工单", notes = "电费-工单表判断生成")
    @PostMapping(value = "/query")
    public R queryS(Integer TqId) {
        return  R.ok(runWorkOrderService.queryRunWorker(TqId));
    }

    //==============工单处理===================//

    /**

     * 调用4号凌晨研判方法
     * 已抄表的数据进行自动归档
     * 未抄表的数据需要站长手动归档
     * @param
     * @return
     */
    @ApiOperation(value = "台区经理对应工单11")
    @PostMapping(value = "/queryTest")
    public R<?> query() throws ParseException {
        return runWorkOrderService.queryS();
    }


    /**
     * 4是待处理，3是处理中，2是待归档，1是已归档
     * 台区经理点击查看详情，修改状态为处理中（2）
     * 修改状态
     * @param workOrderStatus
     * @return
     */
    @ApiOperation(value = "台区经理对应工单状态修改", notes = "电费-修改工单状态")
    @PostMapping(value = "/update")
        public Object update(String userid, Integer workOrderStatus) {
        return runWorkOrderService.updateStatus(workOrderStatus, userid);
    }


    /**
     * 对于仍未抄表，数据异常的工单，需要站长手动归档
     * @return
     */
    @PostMapping(value = "/manual")
    public Integer manual(String gdNo){
        return runWorkOrderService.Gdfs(gdNo);
    }

    //==============现场处理工单===================//

    /**
     * 添加工单处理详情
     *
     * @param runGdDeal
     * @return
     */
    @ApiOperation(value = "添加工单处理",notes = "添加工单处理")
    @PostMapping(value = "/add",produces = "application/json")
    public int add(@RequestBody RunWorderDeal runGdDeal){
        return runWorderDealServiceImpl.insertRunGdDeal(runGdDeal);
    }

    /**
     * 通过工单编号查询对应历史记录中最近的一条
     * @param gdNo
     * @return
     */
    @PostMapping(value = "/queryOne")
    public R queryAll(String gdNo){
        return runWorderDealServiceImpl.queryAll(gdNo);
    }

    /**
     * 查询历史
     * @param gdNo
     * @return
     */
    @PostMapping(value = "/queryHistory")
    public  R queryRunDeals(String gdNo){
        return  runWorderDealServiceImpl.queryRunDeals(gdNo);
    }

    /**
     * 电费补抄导出
     *
     * @param ids
     * @return
     */
    @PostMapping("export")  //excel/export
    public void exportExcel1(HttpServletResponse response, @RequestParam List<String> ids) throws IOException {
        List<org.dfzt.entity.po.RunWorkOrderPo> list = new ArrayList<>();
        for (String id : ids) {
            RunWorkOrderPo runWorkOrder = runWorkOrderService.selectById(id);
            //多张图片导出
            //判断是否有图片，防止空指针
            if (StrUtil.isNotBlank(runWorkOrder.getPhoto())){
                String[] split = runWorkOrder.getPhoto().split(",");
                if (split.length>0){
                    runWorkOrder.setPhotoOne(split[0]);
                }
                if (split.length>1){
                    runWorkOrder.setPhotoTwo(split[1]);
                }
                if (split.length>2){
                    runWorkOrder.setPhotoThree(split[2]);
                }
            }
            list.add(runWorkOrder);
        }
        ExcelUtils.exportExcel(list, "电费补抄工单列表", "电费补抄", RunWorkOrderPo.class, "电费补抄工单文件", response);
    }


    @PostMapping(value = "test")
    public void test(){
        try {
            runSupplementaryCopyService.QueryAll1();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    //根据核算编号查询
    @RequestMapping("getRun1")
    @ResponseBody
    public List<Object> getRun1(@RequestParam String mrPlanNo){
        List<Object> objects = runWorkOrderMapper.selectRun1(mrPlanNo);
        return objects;
    }

    //根据电费年月
    @RequestMapping("getRun2")
    @ResponseBody
    public List<Object> getRun2(@RequestParam String ym){
        List<Object> objects = runWorkOrderMapper.selectRun2(ym);
        return objects;
    }

    //根据用户编号
    @RequestMapping("getRun3")
    @ResponseBody
    public List<Object> getRun3(@RequestParam String orgNo){
        List<Object> objects = runWorkOrderMapper.selectRun3(orgNo);
        return objects;
    }

    //根据用户编号
    @RequestMapping("getRun4")
    @ResponseBody
    public List<Object> getRun4(@RequestParam String appNo){
        List<Object> objects = runWorkOrderMapper.selectRun4(appNo);
        return objects;
    }

}

