package com.exam.modules.controller;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.modules.entity.SysRole;
import com.exam.modules.entity.SysUserRole;
import com.exam.modules.entity.dto.RoleMenuDTO;
import com.exam.modules.entity.vo.RoleMenuVo;
import com.exam.modules.entity.vo.RoleQueryVo;
import com.exam.modules.service.ISysMenuService;
import com.exam.modules.service.ISysRoleService;
import com.exam.modules.utils.Result;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * <p>
 * 角色表 前端控制器
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@RestController
@RequestMapping("/api/role")
public class SysRoleController {
    @Resource
    private ISysRoleService roleService;
    @Resource
    private ISysMenuService menuService;

    /**
     * 分页查询角色列表
     * @param roleQueryVo
     * @return
     */
    @PostMapping("/list")
    public Result list(@RequestBody RoleQueryVo roleQueryVo){
        //创建分页对象
        IPage<SysRole> page = new Page<SysRole>(roleQueryVo.getPageNo(),roleQueryVo.getPageSize());
        //调用分页查询方法
        roleService.findRoleListByUserId(page,roleQueryVo);
        //返回数据
        return Result.ok(page);
    }

    /**
     * 添加角色
     * @param role
     * @return
     */
    @PostMapping("/add")
    public Result add(@RequestBody SysRole role){
        if(roleService.save(role)){
            return Result.ok().message("角色添加成功");
        }
        return Result.error().message("角色添加失败");
    }

    /**
     * 修改角色
     * @param role
     * @return
     */
    @PostMapping("/update")
    public Result update(@RequestBody SysRole role){
        if(roleService.updateById(role)){
            return Result.ok().message("角色修改成功");
        }
        return Result.error().message("角色修改失败");
    }

    /**
     * 删除角色
     * @param id
     * @return
     */
    @GetMapping("/delete")
    public Result delete(Long id){
        //检查用户是否被使用
        if (roleService.hashRoleCount(id)){
            return Result.error().message("该角色分配给其他用户使用，无法删除");
        }
        if(roleService.deletRoleById(id)){
            return Result.ok().message("角色删除成功");
        }
        return Result.error().message("角色删除失败");
    }

    /**
     * 分配权限-查询权限树数据
     * @param userRole
     * @return
     */
    @PostMapping("/getAssignMenuTree")
    public Result getAssignMenuTree(@RequestBody SysUserRole userRole) {
        //调用查询权限树数据的方法
        RoleMenuVo menuTree = menuService.findMenuTree(userRole.getUserId(), userRole.getRoleId());
        //返回数据
        return Result.ok(menuTree);
    }


    /**
     * 分配权限-保存权限数据
     * @param roleMenuDTO
     * @return
     */
    @PostMapping("/saveRoleAssign")
    public Result saveRoleAssign(@RequestBody RoleMenuDTO roleMenuDTO) {
        if (roleService.saveRoleMenu(roleMenuDTO)){
            return Result.ok().message("权限分配成功");
        } else {
            return Result.error().message("权限分配失败");
        }
    }
}
