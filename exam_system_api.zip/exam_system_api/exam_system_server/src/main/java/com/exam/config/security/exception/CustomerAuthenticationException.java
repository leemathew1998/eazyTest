package com.exam.config.security.exception;
import org.springframework.security.core.AuthenticationException;
/**
 * @Author dyy
 * @Date 2022/10/31 16:30
 * @PackageName:com.exam.config.security.exception
 * @ClassName: CustomerAuthenticationException
 * @Description: TODO  自定义验证异常类
 * @Version 1.0
 */
public class CustomerAuthenticationException extends AuthenticationException {
    public CustomerAuthenticationException(String message){
        super(message);
    }
}
