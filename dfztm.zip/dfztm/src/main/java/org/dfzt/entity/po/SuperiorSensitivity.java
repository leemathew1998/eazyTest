package org.dfzt.entity.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/16
 * @Version: 1.00
 */
@Data
public class SuperiorSensitivity implements Serializable {
    //id
    private Integer id;
    //用户编号
    private String consNo;
    //用户名称
    private String consName;
    //用户电话
    private String mobile;
    //用电地址（用户地址）
    private String elecAddr;
    //台区编号
    private String tgNo;
    //台区名称
    private String tgName;
    //供电单位
    private String orgNo;

    //标记时间
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone="GMT+8")
    private Date labelTime;
    //标记原因
    private String labelCause;
    //标记人
    private String labelName;
    //1.是，0.否
    private String appType;
}
