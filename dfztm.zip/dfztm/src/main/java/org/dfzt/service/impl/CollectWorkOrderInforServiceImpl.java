package org.dfzt.service.impl;

import org.dfzt.entity.po.CollectWorkOrderInfor;
import org.dfzt.mapper.CollectWorkOrderInforMapper;
import org.dfzt.service.CollectWorkOrderInforService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/6/7
 * @Version: 1.00
 */
@Service
public class CollectWorkOrderInforServiceImpl implements CollectWorkOrderInforService {

    @Autowired
    private CollectWorkOrderInforMapper collectWorkOrderInforMapper;

    @Override
    public int insertSelective(CollectWorkOrderInfor cwol) {
        return collectWorkOrderInforMapper.insertSelective(cwol);
    }

    @Override
    public CollectWorkOrderInfor SelectVandP(String workOrderNo) {
        return collectWorkOrderInforMapper.SelectVandP(workOrderNo);
    }

    @Override
    public CollectWorkOrderInfor selectlineVandP(String workOrderNo) {
        return collectWorkOrderInforMapper.selectlineVandP(workOrderNo);
    }
}
