package com.exam.modules.service.impl;

import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.exam.modules.entity.ExamT;
import com.exam.modules.entity.dto.ExamPaperInfoDTO;
import com.exam.modules.entity.vo.ExamPaperInfoVo;
import com.exam.modules.mapper.ExamPaperInfoMapper;
import com.exam.modules.entity.ExamPaperInfo;
import com.exam.modules.service.ExamPaperInfoService;
import com.exam.modules.service.ExamTService;
import com.exam.modules.utils.ListUtils;
import org.springframework.stereotype.Service;
import springfox.documentation.spring.web.json.Json;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * (ExamPaperInfo)表服务实现类
 *
 * @author dyy
 * @since 2022-11-07 15:32:49
 */
@Service("examPaperInfoService")
public class ExamPaperInfoServiceImpl extends ServiceImpl<ExamPaperInfoMapper, ExamPaperInfo> implements ExamPaperInfoService {

    @Resource
    private ExamTService examTService;
    @Resource
    private ExamPaperInfoService examPaperInfoService;

    @Override
    public IPage<ExamPaperInfo> findPaperInfoList(IPage<ExamPaperInfo> page, ExamPaperInfoVo examPaperInfoVo) {
        //创建条件构造器
        QueryWrapper<ExamPaperInfo> queryWrapper = new QueryWrapper<>();
        //试卷名称
        queryWrapper.like(StrUtil.isNotBlank(examPaperInfoVo.getExamPaperName()),"EXAM_PAPER_NAME",examPaperInfoVo.getExamPaperName());
        //知识分类
        queryWrapper.like(StrUtil.isNotBlank(examPaperInfoVo.getKnowGory()),"KNOW_GORY",examPaperInfoVo.getKnowGory());

        return baseMapper.selectPage(page,queryWrapper);
    }

    @Override
    public boolean savePaper(ExamPaperInfoDTO examPaperInfo) {
        if (ObjectUtil.isNotEmpty(examPaperInfo)){
            //存储题目id
            String f = "";
            //五种题目类型
            String t1 = "";
            String t2 = "";
            String t3 = "";
            String t4 = "";
            String t5 = "";
            //判断题目类型不为空
            if (StrUtil.isNotBlank(examPaperInfo.getType1())){
                //如果题目类型=1，查询此知识分类，以及题目类型的所有题目
                //查询所有题库
                List<ExamT> list = examTService.list();
                //筛选符合条件的题目，存入list集合
                List<Long> tid = Optional.ofNullable(list).orElse(new ArrayList<>())
                        .stream()
                        .filter(Objects::nonNull)
                        .filter(s -> s.getTtype().equals("1"))
                        .filter(s -> s.getKnowGory().equals(examPaperInfo.getKnowGory()))
                        .map(ExamT::getTid)
                        .collect(Collectors.toList());
                //随机取出符合条数的tid
                List<Long> randomList = ListUtils.getRandomList(tid, examPaperInfo.getSingleTnum());
                for (Long s : randomList) {
                    String s1 = s.toString();
                    t1+=s1+',';
                }
            }
            if (StrUtil.isNotBlank(examPaperInfo.getType2())){
                //如果题目类型=1，查询此知识分类，以及题目类型的所有题目
                //查询所有题库
                List<ExamT> list = examTService.list();
                //筛选符合条件的题目，存入list集合
                List<Long> tid = Optional.ofNullable(list).orElse(new ArrayList<>())
                        .stream()
                        .filter(Objects::nonNull)
                        .filter(s -> s.getTtype().equals("2"))
                        .filter(s -> s.getKnowGory().equals(examPaperInfo.getKnowGory()))
                        .map(ExamT::getTid)
                        .collect(Collectors.toList());
                //随机取出符合条数的tid
                List<Long> randomList = ListUtils.getRandomList(tid, examPaperInfo.getSingleTnum());
                for (Long s : randomList) {
                    String s1 = s.toString();
                    t2+=s1+',';
                }
            }
            if (StrUtil.isNotBlank(examPaperInfo.getType3())){
                //如果题目类型=1，查询此知识分类，以及题目类型的所有题目
                //查询所有题库
                List<ExamT> list = examTService.list();
                //筛选符合条件的题目，存入list集合
                List<Long> tid = Optional.ofNullable(list).orElse(new ArrayList<>())
                        .stream()
                        .filter(Objects::nonNull)
                        .filter(s -> s.getTtype().equals("3"))
                        .filter(s -> s.getKnowGory().equals(examPaperInfo.getKnowGory()))
                        .map(ExamT::getTid)
                        .collect(Collectors.toList());
                //随机取出符合条数的tid
                List<Long> randomList = ListUtils.getRandomList(tid, examPaperInfo.getSingleTnum());
                for (Long s : randomList) {
                    String s1 = s.toString();
                    t3+=s1+',';
                }
            }
            if (StrUtil.isNotBlank(examPaperInfo.getType4())){
                //如果题目类型=1，查询此知识分类，以及题目类型的所有题目
                //查询所有题库
                List<ExamT> list = examTService.list();
                //筛选符合条件的题目，存入list集合
                List<Long> tid = Optional.ofNullable(list).orElse(new ArrayList<>())
                        .stream()
                        .filter(Objects::nonNull)
                        .filter(s -> s.getTtype().equals("4"))
                        .filter(s -> s.getKnowGory().equals(examPaperInfo.getKnowGory()))
                        .map(ExamT::getTid)
                        .collect(Collectors.toList());
                //随机取出符合条数的tid
                List<Long> randomList = ListUtils.getRandomList(tid, examPaperInfo.getSingleTnum());
                for (Long s : randomList) {
                    String s1 = s.toString();
                    t4+=s1+',';
                }
            }
            if (StrUtil.isNotBlank(examPaperInfo.getType5())){
                //如果题目类型=1，查询此知识分类，以及题目类型的所有题目
                //查询所有题库
                List<ExamT> list = examTService.list();
                //筛选符合条件的题目，存入list集合
                List<Long> tid = Optional.ofNullable(list).orElse(new ArrayList<>())
                        .stream()
                        .filter(Objects::nonNull)
                        .filter(s -> s.getTtype().equals("5"))
                        .filter(s -> s.getKnowGory().equals(examPaperInfo.getKnowGory()))
                        .map(ExamT::getTid)
                        .collect(Collectors.toList());
                //随机取出符合条数的tid
                List<Long> randomList = ListUtils.getRandomList(tid, examPaperInfo.getSingleTnum());
                for (Long s : randomList) {
                    String s1 = s.toString();
                    t5+=s1+',';
                }
            }
            //字符串拼接
            f=t1+t2+t3+t4+t5;
            System.out.println(f+"==="+t1+"===="+t2+"==="+t3+"==="+t4+"==="+t5+"===");
            //创建
            if (StrUtil.isNotBlank(f)){
                //构造器
                ExamPaperInfo paperInfo = new ExamPaperInfo(null,
                        examPaperInfo.getExamPaperName(),
                        examPaperInfo.getCreateBy(),
                        new Date(),
                        null,null,examPaperInfo.getKnowGory(),
                        examPaperInfo.getSingleTnum().toString(),
                        examPaperInfo.getMoreTnum().toString(),
                        examPaperInfo.getJudgeTnum().toString(),
                        examPaperInfo.getAnsTnum().toString(),
                        examPaperInfo.getProgramTnum().toString(),
                        f,examPaperInfo.getSum(),examPaperInfo.getDiff(),null
                );
                examPaperInfoService.save(paperInfo);
                return true;
            }else {
                return false;
            }
        }
        return false;
    }

    @Override
    public boolean updateUseNum(ExamPaperInfo examPaperInfo) {
        return baseMapper.updateuseNum(examPaperInfo.getExamPaperId());
    }
}
