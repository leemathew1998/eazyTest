package org.dfzt.entity.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

//采集失败
@Data
@NoArgsConstructor
public class CollectFailure implements Serializable {
    private Integer id;
    @Excel(name = "上级供电单位",orderNum = "0")
    private String upOrgName;
    @Excel(name = "供电单位",orderNum = "1")
    private String orgName;
    @Excel(name = "用户编码",orderNum = "2")
    private String consNo;
    @Excel(name = "用户名称",orderNum = "3")
    private String consName;
    @Excel(name = "用电地址",orderNum = "4")
    private String elecAddr;
    @Excel(name = "电能表资产号",orderNum = "5")
    private String meterAssetNo;
    @Excel(name = "电表接线方式")
    private String elecmeterContype;
    @Excel(name = "电表规约")
    private String elecmeterStatute;
    @Excel(name = "电能表厂家")
    private String elecmeterFactory;
    @Excel(name = "台区编号",orderNum = "6")
    private String tgId;
    @Excel(name = "台区名称",orderNum = "7")
    private String tgName;
    @Excel(name = "终端地址",orderNum = "8")
    private String terminalAddr;
    @Excel(name = "终端规约")
    private String terminalStatute;
    @Excel(name = "终端生产厂家",orderNum = "9")
    private String terminalFactory;
    @Excel(name = "终端运行状态",orderNum = "10")
    private String terminalState;
    @Excel(name = "测量点号",orderNum = "11")
    private Integer mpSn;

    private String mrDate;

    @Excel(name = "抄表日期",orderNum = "12")
    private String synchroTime;

    @Excel(name = "抄表员姓名",orderNum = "14")
    private String meterReader;

    private String synchro;

    private String synchroDep;


    private String synchroMode;
    @Excel(name = "台区经理",orderNum = "15")
    private String tgManager;
    @Excel(name = "用户电话",orderNum = "16")
    private String mobile;

    private String colSign;
    @Excel(name = "条形码号",orderNum = "17")
    private String elecmeterCode;
    @Excel(name = "用户类型",orderNum = "18")
    private String userType;

    public CollectFailure(String upOrgName, String orgName) {
        this.upOrgName = upOrgName;
        this.orgName = orgName;
    }
}
