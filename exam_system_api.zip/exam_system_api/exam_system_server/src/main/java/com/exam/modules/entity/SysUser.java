package com.exam.modules.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.annotation.TableId;

import java.sql.Timestamp;
import com.baomidou.mybatisplus.annotation.TableField;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * <p>
 * 用户表
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.SYS_USER")
public class SysUser implements Serializable , UserDetails {

    private static final long serialVersionUID = 1L;

    /**
     * 用户ID
     */
    @TableId(value = "USER_ID")
//    @JsonSerialize(using = ToStringSerializer.class)
    private Long userId;

    /**
     * 用户名
     */
    @TableField("USERNAME")
    private String username;

    /**
     * 密码（加密）
     */
    @TableField("PASSWORD")
    private String password;

    /**
     * 密码更新时间
     */
    @TableField("PASSWD_UPDATE_TIME")
    private Date passwdUpdateTime;

    /**
     * 最后一次登录时间
     */
    @TableField("LAST_LOGIN_TIME")
    private Date lastLoginTime;

    /**
     * 所属组别
     */
    @TableField("THE_GROUP")
    private String theGroup;

    /**
     * 电话
     */
    @TableField("PHONE")
    private String phone;

    @TableField("CREATE_BY")
    private String createBy;

    @TableField("CREATE_TIME")
    private Date createTime;

    @TableField("UPDATE_BY")
    private String updateBy;

    @TableField("UPDATE_TIME")
    private Date updateTime;

    /**
     * 角色ID
     */
    @TableField("ROLE_ID")
    private Long roleId;

    /**
     * 权限数组(待定字段)
     */
    @TableField("PERM_ARR")
    private String permArr;

    /**
     * 删除
     */
    @TableField("DEL_FLAG")
    private Integer delFlag;

    /**
     * 帐户是否过期(1 未过期，0已过期)
     */
    @TableField("IS_ACCOUNT_NON_EXPIRED")
    private boolean isAccountNonExpired = true;
    /**
     * 帐户是否被锁定(1 未过期，0已过期)
     */
    @TableField("IS_ACCOUNT_NON_LOCKED")
    private boolean isAccountNonLocked = true;
    /**
     * 密码是否过期(1 未过期，0已过期)
     */
    @TableField("IS_CREDENTIALS_NON_EXPIRED")
    private boolean isCredentialsNonExpired = true;
    /**
     * 帐户是否可用(1 可用，0 删除用户)
     */
    @TableField("IS_ENABLED")
    private boolean isEnabled = true;

    /**
     * 是否为管理员
     */
    @TableField("IS_ADMIN")
    private String isAdmin;
    /**
     * 权限列表
     */
    @TableField(exist = false)
    Collection<? extends GrantedAuthority> authorities;
    /**
     * 查询用户权限列表
     */
    @TableField(exist = false)
    private List<SysMenu> sysMenusList;

    //角色名称
    @TableField(exist = false)
    private String roleName;

    @TableField(exist = false)
    private Integer pageStart;
    @TableField(exist = false)
    private Integer pageEnd;
}
