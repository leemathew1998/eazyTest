package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/13
 * @Version: 1.00
 */
@Data
public class Performance1 {
    private Integer accountManagerTodayTotalIntegrate;

    private Integer qiCountyCompanyTodayRanking;

    private Integer powerStationTodayRanking;

    private List<Indicators> indicators;
}
