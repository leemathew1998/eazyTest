package org.dfzt.entity.vo;


import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

@ApiModel(value = "主动抢修返回",description = "")
@Data
//@TableName("ctiave_rush_repair")
public class RepairsWorkOrderVo {
    //主动抢修工单编号
    @ApiModelProperty(value = "主动抢修工单编号")
    private String workOrderNo;
    //台区经理姓名
    @ApiModelProperty(value = "台区经理姓名")
    private String tgManager;
    //台区编码
    @ApiModelProperty(value = "台区编码")
    private String tgNo;
    //台区名称
    @ApiModelProperty(value = "台区名称")
    private String tgName;
    //故障设备标识
    @ApiModelProperty(value = "故障设备标识")
    private String failureEquipment;
    //工单状态(1.待处理 2.处理中 3.待归档 4.已归档)
    @ApiModelProperty(value = "工单状态(1.待处理 2.处理中 3.待归档 4.已归档)")
    private String workOrderStatus;
    //电压
    @ApiModelProperty(value = "电压")
    private String voltCode;
    //电流
    @ApiModelProperty(value = "电流")
    private String ratedCurrent;
    //本体温度
    @ApiModelProperty(value = "本体温度")
    private String tgTemperature;
    //故障区域
    @ApiModelProperty(value = "故障区域")
    private String failureArea;
    //开关异常状态
    @ApiModelProperty(value = "开关异常状态(1.分 2.合)")
    private String errorStatus;

    @ApiModelProperty(value = "抢修类型")
    private String repairsType;
    @ApiModelProperty(value = "故障描述")
    private String faultDescribe;
    @ApiModelProperty(value = "开始处理工单的时间")
    private Date disposeTime;
    @ApiModelProperty(value = "处理结果")
    private String disposeResult;
    @ApiModelProperty(value = "消耗材料")
    private String consumeMaterials;
    @ApiModelProperty(value = "地点")
    private String location;
    @ApiModelProperty(value = "故障缺陷照片")
    private String faultPoint;


    //抢修单照片(顺序2)
    private String repairList;
    //监控班许可照片（顺序3）
    private String monShiftPer;
    //安全措施照片(顺序4)
    private String secuMeas;
    //到岗位置许可检查安全措施是否完备照片并同意开工照片（顺序5）
    private String iscompSecuMeas;
    //故障/危急缺陷处理后照片（顺序6）
    private String afterTrou;
    //安全措施拆除照片（顺序7）
    private String secuMeasRem;
    //工单创建时间
    @ApiModelProperty(value = "工单创建时间")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderCtime;

    @ApiModelProperty(value = "装换成处理中状态的时刻")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderdtime;

    @ApiModelProperty(value = "装换成待归档状态的时刻")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderwtime;

    @ApiModelProperty(value = "装换成已归档状态的时刻")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderatime;

    //是否有敏感工单用户
    private String appType;


}
