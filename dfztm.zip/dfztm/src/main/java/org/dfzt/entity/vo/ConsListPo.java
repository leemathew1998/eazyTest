package org.dfzt.entity.vo;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/8
 * @Version: 1.00 用户档案
 */
@Data
public class ConsListPo {
    private String consNo;//用户编号
    private String consName;//用户名称
    private String orgNo;//供电单位编号
    private String elecAddr;//用户地址
    private String statusCode;//用户状态
    private String consSortCode;//用户分类
    private String tradeCode;//行业分类
    private String voltCode;//供电电压
    private BigDecimal contractCap;//合同容量
    private String tmpFlag;//临时用电标志
    private String mrSectNo;//抄表段编号
    private String elecTypeCode;//用电类别
    private BigDecimal runCap;//运行容量
    private String spId;//受电点标识
    private String spName;//受电点名称
    private String psNumCode;//电源数目
    private String typeCode;//定价策略
    private String baCalcMode;//基本电费计算方式
    private BigDecimal dmdSpecValue;//需量核定值
    private String pfEvalMode;//功率因数考核方式
    private String realName;//抄表员

}
