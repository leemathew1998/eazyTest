package org.dfzt.mapper;



import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.vo.*;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-25
 */
@Mapper
@Transactional
public interface ActiveOperationMapper extends BaseMapper<ActiveOperation> {

    List<ActiveOperation> selectAll();//查看主动运维工单列表

    List<ActiveOperation> selectList1(ActiveOperation a);//主动运维工单条件模糊查询
    List<ActiveOperation> selectList3(ActiveOperation a);//主动运维工单条件模糊查询

    List<ActiveOperation> selectList2(String one);//主动运维工单单个条件查询
    List<ActiveOperation> selectList4(String one);//主动运维工单单个条件查询

    String selectRole(String username);//根据用户id差找所对应的权限


    /*ActiveOperation selectByConditions1(@Param("tgNo") String tgNo,
                                           @Param("tgManager") String tgManager,
                                           @Param("workOrderStatus") String workOrderStatus);*/

    DefectInfor selectload(String workOrderNo);//根据工单编号回显录入数据
    DefectRepair selectdload(String workOrderNo);//根据工单编号回显立行立改数据
    OverhaulInfor selectoload(String workOrderNo);//根据工单编号回显检修数据


    Integer upStatus2(String workOrderNo);//改变工单状态为处理中
    Integer upStatus3(String workOrderNo);//改变工单状态为待归档
    Integer upStatus4(String workOrderNo);//改变工单状态为已归档
    Integer upStatus5(String workOrderNo);//改变工单状态为误报工单
    Integer upStatus6(String workOrderNo);//改变工单状态为抢修工单
    /**
     * 用于导出
     * 根据id查询工单
     */
    org.dfzt.entity.po.ActiveOperation selectByActiveOperationNo(String workOrderNo);

    List<ActiveOperation> selectAllYWOapp();//查询主动运维中包含敏感用户的工单

    Long selectStatus1();//查询工单状态为待处理的个数1
    Long selectStatus2();//查询工单状态为处理中的个数2
    Long selectStatus3();//查询工单状态为待归档的个数3
    Long selectStatus4();//查询工单状态为已归档的个数4
    Long selectStatus5();//查询工单周期为一级的预警的个数5
    Long selectStatus6();//查询工单周期为二级的预警的个数6
    Long selectStatus7();//查询工单状态为误判工单的个数7
    Long selectStatus8();//查询工单状态为转抢修工单的个数8


    @DS("dora")
    List<Object> selectEMpVolCurve();
    @DS("dora")
    List<Object> selectEMpCurCurve();
    @DS("dora")
    List<Object> selectEMpPowCurve();

}



