package org.dfzt.eunm;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;


/**
 * @ClassName MeterReadingEnum
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/7/11 13:11
 */
@Getter
public enum MeterReadingEnum {
    METER_READING_ENUM_ONE("01","已抄表"),
    METER_READING_ENUM_ZERO("00","未抄表");


    @EnumValue
    private final String code;
    @JsonValue
    private final String message;

    MeterReadingEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }
}
