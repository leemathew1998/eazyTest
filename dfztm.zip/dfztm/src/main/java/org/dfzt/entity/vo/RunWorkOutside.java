package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2023-02-16
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "RunWorkOutside对象", description = "")
public class RunWorkOutside implements Serializable {


    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    @ApiModelProperty(value = "异常结果标识")
    @TableField("result_id")
    private String resultId;

    @ApiModelProperty(value = "电费计算标识")
    @TableField("calc_id")
    private String calcId;

    @ApiModelProperty(value = "本期电费年月")
    private String ym;

    @ApiModelProperty(value = "供电单位编号")
    @TableField("org_no")
    private String orgNo;

    @ApiModelProperty(value = "抄表段编号")
    @TableField("mr_sect_no")
    private String mrSectNo;

    @ApiModelProperty(value = "用户标识")
    @TableField("cons_id")
    private String consId;

    @ApiModelProperty(value = "用户编号")
    @TableField("cons_no")
    private String consNo;

    @ApiModelProperty(value = "计算类型:参见标准码amt_type")
    @TableField("calc_type")
    private String calcType;

    @ApiModelProperty(value = "计量点标识")
    @TableField("mp_id")
    private BigDecimal mpId;

    @ApiModelProperty(value = "电压等级:参见标准码volt_code")
    @TableField("volt_code")
    private String voltCode;

    @ApiModelProperty(value = "用电类别:参见标准码elec_type_code")
    @TableField("elec_type_code")
    private String elecTypeCode;

    @ApiModelProperty(value = "行业类别:参见标准码trade_type_code")
    @TableField("trade_type_code")
    private String tradeTypeCode;

    @ApiModelProperty(value = "审核规则代码")
    @TableField("rule_code")
    private String ruleCode;

    @ApiModelProperty(value = "审核结果描述:异常原因以及处理方法")
    @TableField("veri_remark")
    private String veriRemark;

    @ApiModelProperty(value = "审核粒度:用户。计量点等，有码值")
    @TableField("verify_scope")
    private String verifyScope;

    @ApiModelProperty(value = "总结算电量")
    @TableField("t_settle_pq")
    private String tSettlePq;

    @ApiModelProperty(value = "总结算电费")
    @TableField("t_amt")
    private String tAmt;

    @ApiModelProperty(value = "电价编码")
    @TableField("prc_code")
    private String prcCode;

    @ApiModelProperty(value = "异常工单状态:参见标准码rtsp excp order status")
    @TableField("excp_status")
    private String excpStatus;

    @ApiModelProperty(value = "工单处理原(为了效率，同SAPP表reason)")
    @TableField("order_reason")
    private String orderReason;

    @ApiModelProperty(value = "工单处理结果描述(为了效率，同S APP表attr3)")
    @TableField("order_result_remark")
    private String orderResultRemark;

    @ApiModelProperty(value = "工单产生时间(为了效率，同S_APP表handle_time)")
    @TableField("order_handle_time")
    private Date orderHandleTime;

    @ApiModelProperty(value = "工单完成时间(为了效率，同S_APP表complete_time)")
    @TableField("order_complete_time")
    private Date orderCompleteTime;

    @ApiModelProperty(value = "核算计划编号")
    @TableField("mr_plan_no")
    private String mrPlanNo;

    @ApiModelProperty(value = "异常类型:参见标准码rtsp_excp_type")
    @TableField("excp_type")
    private String excpType;

    @ApiModelProperty(value = "抄表例日")
    @TableField("mr_day")
    private String mrDay;

    @ApiModelProperty(value = "抄表数据来源")
    @TableField("mr_src")
    private String mrSrc;

    @ApiModelProperty(value = "用户分类:参见标准码cust_type_code")
    @TableField("cons_sort_code")
    private String consSortCode;

    @ApiModelProperty(value = "核算异常工单申请编号")
    @TableField("app_no")
    private String appNo;

    @ApiModelProperty(value = "异常环节:参见标准码rtsp excp_link")
    @TableField("excp_link")
    private String excpLink;

    @ApiModelProperty(value = "异常产生时间")
    @TableField("verify_date")
    private Date verifyDate;

    @ApiModelProperty(value = "工单处理结果(为了效率，同S APP表attr2)")
    @TableField("order_result")
    private String orderResult;

    @ApiModelProperty(value = "营销异常工单申请编号")
    @TableField("sgps_app_no")
    private Integer sgpsAppNo;

    @ApiModelProperty(value = "异常处理方式:参见标准码tsp_excphandlemodedoWS")
    @TableField("exception_handle_mode")
    private String exceptionHandleMode;

    @ApiModelProperty(value = "采集处理状态:参见标准码rtsp_collect_status")
    @TableField("collect_status")
    private String collectStatus;

    @ApiModelProperty(value = "中止发行状态:参见标准码rtsp_cancel_publish_status")
    @TableField("cancel_publish_status")
    private String cancelPublishStatus;

    @ApiModelProperty(value = "规则类型:参见标准码rule_type_stage")
    @TableField("rule_type")
    private String ruleType;

    @ApiModelProperty(value = "调整抄表日期状态:参见标准码rtsp_adjust_mrdate_status")
    @TableField("adjust_mrdate_status")
    private Date adjustMrdateStatus;

    @ApiModelProperty(value = "人工补录状态:参见标准码rtsp_handelmeterread_status")
    @TableField("handel_meterread_status")
    private String handelMeterreadStatus;

    @ApiModelProperty(value = "调整电量状态:参见标准码rtsp_adjust_pq_status")
    @TableField("adjust_pq_status")
    private String adjustPqStatus;

    @ApiModelProperty(value = "省级异常工单标志")
    @TableField("prov_order_flag")
    private String provOrderFlag;

    @ApiModelProperty(value = "自动重新提档处理标志")
    @TableField("get_data_again_flag")
    private String getDataAgainFlag;

    @ApiModelProperty(value = "发行自名单审核状态:参见标准码rtsp_publish_whitelist_status")
    @TableField("publish_whitelist_status")
    private String publishWhitelistStatus;

    @ApiModelProperty(value = "受电点标识")
    @TableField("sp_id")
    private Integer spId;

    @ApiModelProperty(value = "规则组合类型")
    @TableField("rule_kind")
    private String ruleKind;

    @ApiModelProperty(value = "客户群标识")
    @TableField("group_id")
    private String groupId;

    @ApiModelProperty(value = "组合规则标识")
    @TableField("combination_rule_id")
    private String combinationRuleId;

    @ApiModelProperty(value = "是否锁定1是、其余否")
    @TableField("lock_status")
    private String lockStatus;

    @ApiModelProperty(value = "锁定人")
    @TableField("lock_person")
    private String lockPerson;

    @ApiModelProperty(value = "异常处理原因")
    @TableField("confirm_normal_type")
    private String confirmNormalType;

    @ApiModelProperty(value = "原因描述")
    @TableField("confirm_normal_reason")
    private String confirmNormalReason;

    @ApiModelProperty(value = "处理原国类型rtsp_confirm_normaltype")
    @TableField("deal_reason_type")
    private String dealReasonType;

    @ApiModelProperty(value = "处理原因描述")
    @TableField("deal_reason_describe")
    private String dealReasonDescribe;

    @ApiModelProperty(value = "锁定原因")
    @TableField("lock_reason")
    private String lockReason;


}
