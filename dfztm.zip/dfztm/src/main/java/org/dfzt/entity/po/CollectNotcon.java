package org.dfzt.entity.po;

import cn.afterturn.easypoi.excel.annotation.Excel;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

//采集未接入
@Data
public class CollectNotcon implements Serializable {
    private Integer id;
    @Excel(name = "供电单位",orderNum = "2")
    private String powsupComp;

    private String upOrgName;
    @Excel(name = "供电所",orderNum = "3")
    private String orgName;
    @Excel(name = "用户编号",orderNum = "4")
    private String consNo;
    @Excel(name = "用户名称",orderNum = "5")
    private String consName;
    @Excel(name = "抄表段编号",orderNum = "6")
    private String meterreadNum;
    @Excel(name = "用电地址",orderNum = "7")
    private String elecAddr;
    @Excel(name = "计量点编号")
    private String mpNo;
    @Excel(name = "线路编号")
    private String lineId;
    @Excel(name = "线路名称")
    private String lineName;
    @Excel(name = "台区编号",orderNum = "9")
    private String tgId;
    @Excel(name = "台区名称",orderNum = "10")
    private String tgName;
    @Excel(name = "电能表资产号",orderNum = "8")
    private String meterAssetNo;

    private String expoUserName;

    private Integer expoUserDeptno;

    private Date expoUserTime;

    private String synchro;

    private String synchroDep;

    private Date synchroTime;

    private String synchroMode;
    @Excel(name = "台区经理",orderNum = "12")
    private String tgManager;
    @Excel(name = "用户电话",orderNum = "13")
    private String mobile;

    private String colSign;
    @Excel(name = "条形码号",orderNum = "14")
    private String elecmeterCode;
    @Excel(name = "终端地址",orderNum = "15")
    private String terminalAddr;

}