package com.exam.modules.entity;


import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * (ExamT)表实体类
 *
 * @author dyy
 * @since 2022-11-08 09:58:11
 */
@EqualsAndHashCode(callSuper = false)
@TableName("EXAM.EXAM_T")
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ExamT implements Serializable {
    //题目id
    @TableId("TID")
    private Long tid;
    //知识分类（1.前端 2.后端 3.设计 4.测试）

    @TableField("KNOW_GORY")
    private String knowGory;
    //题目类型（1.单选题 2.多选题 3.判断题 4.简答题 5.编程题）
    @TableField("TTYPE")
    private String ttype;
    //题目难度（1.简单、2.一般、3.复杂）
    @TableField("TDIFF")
    private String tdiff;
    //试题问题
    @TableField("TPROBLEM")
    private String tproblem;
    //答案A
    @TableField("TA")
    private String ta;
    //答案B
    @TableField("TB")
    private String tb;
    //答案C
    @TableField("TC")
    private String tc;
    //答案D
    @TableField("TD")
    private String td;
    //答案E
    @TableField("TE")
    private String te;
    //答案F
    @TableField("TF")
    private String tf;

    //测试用例输入
    @TableField("TEST_INPUT")
    private String testInput;

    //测试用例输出
    @TableField("TEST_OUTPUT")
    private String testOutput;
    //默认分数
    @TableField("SCORE")
    private String score;
    //正确答案
    @TableField("ANSWER")
    private String answer;
    //答案解析
    @TableField("ANSWER_INFO")
    private String answerInfo;
    //使用数量
    @TableField("USE_NUM")
    private String useNum;
    //创建人
    @TableField("CREATE_BY")
    private String createBy;
    //创建时间
    @TableField("CREATE_TIME")
    private Date createTime;
}
