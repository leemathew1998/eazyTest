package com.exam.modules.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * list 工具类
 */
public class ListUtils {

    /**
    * @Description list 随机取数据
    * @params     list    list集合
    *           num     随机取多少条
    **/
    public static List<Long> getRandomList(List list, Long num) {
        List<Long> olist = new ArrayList<>();
        if (list.size() <= num) {
            return list;
        } else {
            Random random = new Random();
            for (int i = 0 ;i<num;i++){
                int intRandom = random.nextInt(list.size() - 1);
                olist.add((Long) list.get(intRandom));
                list.remove(list.get(intRandom));
            }
            return olist;
        }
    }
}
