package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.DMeter;
import org.dfzt.entity.po.DMeter2;

import java.math.BigDecimal;
import java.util.List;

/**
 * (DMeter2)表数据库访问层
 *
 * @author makejava
 * @since 2022-08-01 10:10:42
 */
public interface DMeter2Mapper extends BaseMapper<DMeter2> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<DMeter2> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<DMeter2> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<DMeter2> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<DMeter2> entities);

    @DS("mpg")
    List<DMeter> selectDeter(String belngDept);

    Integer insertDMeter(DMeter dMeter);

    Integer selectBymeterId(Long meterId);
}

