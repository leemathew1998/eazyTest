package org.dfzt.filter;

import com.alibaba.fastjson.JSON;
import com.auth0.jwt.interfaces.DecodedJWT;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.util.jwt.JwtUtil;
import org.springframework.core.annotation.Order;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

import static org.dfzt.util.jwt.respUtil.responseAppJSON;

/**
 * @Author dyy
 * @Date 2022/7/22 11:25
 * @PackageName:org.dfzt.modules.dfzt.filter
 * @ClassName: AuthFilter
 * @Description: TODO
 * @Version 1.0
 */
//@Slf4j
//@Order(value = 1)
//@WebFilter(filterName = "authFilter",urlPatterns = "/*")
public class AuthFilter implements Filter {

    private static final Set<String> ALLOWED_PATHS = Collections.unmodifiableSet(new HashSet<>(
        Arrays.asList("/SysUser/login")));

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("初始化filter");
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
//        HttpServletRequest req = (HttpServletRequest) request;
//        HttpServletResponse resp = (HttpServletResponse) response;
//
//        String requestURI = req.getRequestURI();
//        System.out.println(requestURI);
//
//        String path = req.getRequestURI().substring(req.getContextPath().length()).replaceAll("[/]+$", "");
//        System.out.println(path);
//        boolean allowedPath = ALLOWED_PATHS.contains(path);
//
//        if (allowedPath) {
//            System.out.println("这里是不需要处理的url进入的方法");
//            chain.doFilter(request,response);
//        }
//
//        String token = req.getHeader("Authorization");
//        if (token == null) {
//            Map<String, Object> map = new HashMap<>();
//            map.put("msg", "未获取到token！");
//            map.put("code","40040");
//            responseAppJSON(resp, map);
//            return;
//        }
//
//        DecodedJWT verify = JwtUtil.verify(token);
//        if (verify == null){
//            Map<String, Object> map = new HashMap<>();
//            map.put("msg", "校验失败！");
//            map.put("code","30000");
//            responseAppJSON(resp, map);
//            return;
//        }
//
//        SysUser parse = JwtUtil.parse(verify);
//        if (parse == null){
//            Map<String, Object> map = new HashMap<>();
//            map.put("msg", "解析信息失败！");
//            map.put("code","50000");
//            responseAppJSON(resp, map);
//            return;
//        }
//
//        log.info("拦截器filter获取到User对象："+ JSON.toJSONString(parse));
//        chain.doFilter(request,response);
//        String loginNames = parse.getLoginName();
    }

    @Override
    public void destroy() {
        System.out.println("destroy----------filter");
    }


}
