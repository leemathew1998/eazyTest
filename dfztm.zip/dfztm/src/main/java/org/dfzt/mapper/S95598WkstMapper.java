package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.S95598Wkst;
import org.dfzt.entity.po.SSrvReq;
import org.dfzt.entity.po.SuperiorWorkOrder;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/20
 * @Version: 1.00
 */
@Mapper
@Transactional
public interface S95598WkstMapper extends BaseMapper<S95598Wkst> {
    @DS("sele")
    Object selectNowday();//查询昨日的95598工单

    @DS("sele")
    List<S95598Wkst> select95598WKST(String today);
    Integer selectAppNo(String appNo);//查询当日工单表中是否有同一个优质服务的存在
    Integer insertS95598Wkst(S95598Wkst s95598Wkst);

    Integer insert95598WorkOrder(SuperiorWorkOrder superiorWorkOrder);

    @DS("sele")
    SSrvReq selectSSrvReq(Long reqId);

    List<String> selectS95598codeList();//从工单表中查询未归档的工单申请编号

    @DS("sele")
    String selectHandleCode(String appNo);//去营销系统中通过申请编号查询该工单的归档状态。
    Integer update95598Status(String appNo);//若营销系统中工单状态为08归档，对应修改状态为4

    Integer update95598Cycle(@Param("cycle") String cycle, @Param("workOrderNo") String workOrderNo);//若营销系统中工单状态为08归档，对应修改状态为4


    List<String> select95598EarlyWarning(@Param("dateTime") String dateTime, @Param("grade") String grade);
}