package org.dfzt.mapper;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import io.swagger.models.auth.In;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.FeecontrolVo;
import org.dfzt.entity.po.FeecontrolWorkOrder;
import org.dfzt.entity.vo.RecycleWorkOrder;

/**
 * (FeecontrolWorkOrder)表数据库访问层
 *
 * @author makejava
 * @since 2022-07-12 14:58:25
 */
@Mapper
public interface FeecontrolWorkOrderMapper extends BaseMapper<FeecontrolWorkOrder> {

    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<FeecontrolWorkOrder> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<FeecontrolWorkOrder> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<FeecontrolWorkOrder> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<FeecontrolWorkOrder> entities);

    /**
     * 状态扭转
     * @param map
     * @return
     */
    int updateFeecontrolWorkOrder(Map map);

    /**
     * 根据id查询工单
     * @param workOrderNo
     * @return
     */
    FeecontrolWorkOrder selectFeecontrolWordOrderNo(String workOrderNo);

    /**
     * 查询历史数据(含图片)
     * @param workOrderNo
     * @return
     */
    FeecontrolWorkOrder selectWorkOrderScene(String workOrderNo);

    /**
     * 查询源表数据(费控复电)
     */
    List<FeecontrolWorkOrder> getWorkOrderData();

    /**
     * 费控复电手机端提交功能
     * @param workOrderInfor
     * @return
     */
    int updateWorkOrderStatus(WorkOrderInfor workOrderInfor);

    /**
     * 查询登录人员
     * @param loginName
     * @return
     */
    String selectRole(String loginName);//根据用户id差找所对应的权限

    /**
     * 用于导出
     * 根据id查询工单
     */
    FeecontrolWorkOrder selectByFeecontrolWordOrderNo(String workOrderNo);

    /**
     * app停电复电失败数
     * @return
     */
    List<Map> selectBusiness1();
    List<Map> selectBusiness2();

    /**
     * 敏感用户工单查询
     * @return
     */
    List<SuperiorWorkOrder> selectWorkOrderList(FeecontrolWorkOrder feecontrolWorkOrder);

    @DS("sele")
    List<FeecontrolVo> feecontrolVo();

    @DS("sele")
    List<ARcaCtrlDet> selectARCACTRL(String today);

    Integer selectCtrlId(BigDecimal ctrlId);//查询费控复电的工单是否包含之前的工单

    @DS("sele")
    List<BigDecimal> selectFee5();//费控5分钟更新归档
    List<BigDecimal> selectFeeWorko5();

    List<ConAssetNo> selectFeeWorkwebservice();

    void updateFeeWorkOrder(String consNo);

    @DS("mpg")
    List<ConAssetNo> selectconsAssetNo(List<ConAssetNo> consNos);




    @DS("sele")
    String selectFeeByCtrlId(BigDecimal ctrlId);//查询营销系统中的该工单的状态

    Integer updateFeeStatus(String consNo);//更改系统工单中的工单状态

    /**
     * 修改预警
     * @param cycle
     * @param
     * @return
     */
    Integer updateFeeCycle(@Param("cycle") String cycle, @Param("workOrderNoList") List<String> workOrderNoList);//更改系统工单中的工单状态


    Integer insertFeeWork(org.dfzt.entity.po.FeecontrolWorkOrder feeWorkOrder);

    Integer insertFeeARca(ARcaCtrlDet aRcaCtrlDet);

    List<org.dfzt.entity.po.FeecontrolWorkOrder> selectFeeList(@Param("f") org.dfzt.entity.po.FeecontrolWorkOrder f,@Param("pageNo") Integer pageNo,@Param("pageSize") Integer pageSize,@Param("status") String status,@Param("orgName") String orgName);

    List<FeecontrolWorkOrder> selectCycleOneList();
    List<FeecontrolWorkOrder> selectCycleTwoList();

    List<BigDecimal> selectFeeWorkOrder();//查询费控工单中没归档的费控编号
}

