package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import nonapi.io.github.classgraph.json.Id;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@ApiModel(value="o_staff")
@Data
@TableName(value = "o_staff")
public class OStaff {

    private Integer id;
    /**
     * 人员编号
     */
    @TableId(value = "emp_no", type = IdType.INPUT)
    @ApiModelProperty(value="人员编号")
    private String empNo;

    /**
     * 部门编号
     */
    @TableField(value = "dept_no")
    @ApiModelProperty(value="部门编号")
    private String deptNo;

    /**
     * 工号
     */
    @TableField(value = "staff_no")
    @ApiModelProperty(value="工号")
    private String staffNo;

    /**
     * 姓名
     */
    @TableField(value = "`name`")
    @ApiModelProperty(value="姓名")
    private String name;

    /**
     * 性别，01男，02女
     */
    @TableField(value = "gender")
    @ApiModelProperty(value="性别，01男，02女")
    private String gender;

    /**
     * 相片
     */
    @TableField(value = "photo")
    @ApiModelProperty(value="相片")
    private byte[] photo;

    /**
     * 职位
     */
    @TableField(value = "pos_name")
    @ApiModelProperty(value="职位")
    private String posName;

    /**
     * 岗位
     */
    @TableField(value = "`position`")
    @ApiModelProperty(value="岗位")
    private String position;

    /**
     * 工种，01检定人员、02修校人员、03装表接电
     */
    @TableField(value = "work_type_code")
    @ApiModelProperty(value="工种，01检定人员、02修校人员、03装表接电")
    private String workTypeCode;

    /**
     * 技术等级代码
     */
    @TableField(value = "tech_level_code")
    @ApiModelProperty(value="技术等级代码")
    private String techLevelCode;

    /**
     * 出生年月
     */
    @TableField(value = "ymd")
    @ApiModelProperty(value="出生年月")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,timezone="GMT+8")
    private Date ymd;

    /**
     * 文化程度，01专科、02本科、03研究生、04博士、05博士后
     */
    @TableField(value = "degree_code")
    @ApiModelProperty(value="文化程度，01专科、02本科、03研究生、04博士、05博士后")
    private String degreeCode;

    /**
     * 手机号码
     */
    @TableField(value = "mobile")
    @ApiModelProperty(value="手机号码")
    private String mobile;

    /**
     * 办公电话
     */
    @TableField(value = "office_tel_no")
    @ApiModelProperty(value="办公电话")
    private String officeTelNo;

    /**
     * 服务等级，01一级、02二级、03三级、04四级、05五级
     */
    @TableField(value = "srv_level_code")
    @ApiModelProperty(value="服务等级，01一级、02二级、03三级、04四级、05五级")
    private String srvLevelCode;

    /**
     * 持证标志，是否持有专业学习证明
     */
    @TableField(value = "cert_flag")
    @ApiModelProperty(value="持证标志，是否持有专业学习证明")
    private String certFlag;

    /**
     * 定编标志
     */
    @TableField(value = "fixed_flag")
    @ApiModelProperty(value="定编标志")
    private String fixedFlag;

    /**
     * 在岗标志
     */
    @TableField(value = "on_pos_flag")
    @ApiModelProperty(value="在岗标志")
    private String onPosFlag;

    /**
     * 专业
     */
    @TableField(value = "profession_code")
    @ApiModelProperty(value="专业")
    private String professionCode;

    /**
     * 本人在该业务专业工作的开始日期
     */
    @TableField(value = "profession_bgn_date")
    @ApiModelProperty(value="本人在该业务专业工作的开始日期")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,timezone="GMT+8")
    private Date professionBgnDate;

    /**
     * 工作日期
     */
    @TableField(value = "join_date")
    @ApiModelProperty(value="工作日期")
    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,timezone="GMT+8")
    private Date joinDate;

    /**
     * 职称
     */
    @TableField(value = "titel")
    @ApiModelProperty(value="职称")
    private String titel;

    /**
     * 政治面貌，01普通，02团员，03党员
     */
    @TableField(value = "political_status_code")
    @ApiModelProperty(value="政治面貌，01普通，02团员，03党员")
    private String politicalStatusCode;

    /**
     * 职称级别
     */
    @TableField(value = "title_level_code")
    @ApiModelProperty(value="职称级别")
    private String titleLevelCode;

    /**
     * 调退亡
     */
    @TableField(value = "status_code")
    @ApiModelProperty(value="调退亡")
    private String statusCode;

    /**
     * 备注
     */
    @TableField(value = "remark")
    @ApiModelProperty(value="备注")
    private String remark;

    /**
     * 用电类别
     */
    @TableField(value = "categories")
    @ApiModelProperty(value="用电类别")
    private String categories;
}