package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import java.util.Date;
import lombok.Data;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/20
 * @Version: 1.00
 */
@ApiModel(value="s_95598_wkst")
@Data
@TableName(value = "s_95598_wkst")
public class S95598Wkst {
    /**
     * 该实体的唯一标识
     */
    @TableId(value = "id", type = IdType.INPUT)
    @ApiModelProperty(value="该实体的唯一标识")
    private Long id;

    /**
     * 申请编号
     */
    @TableField(value = "app_no")
    @ApiModelProperty(value="申请编号")
    private String appNo;

    /**
     * 服务请求标识
     */
    @TableField(value = "req_id")
    @ApiModelProperty(value="服务请求标识")
    private Long reqId;

    /**
     * 分组编号
     */
    @TableField(value = "group_no")
    @ApiModelProperty(value="分组编号")
    private String groupNo;

    /**
     * 受理业务类型
     */
    @TableField(value = "busi_type_code")
    @ApiModelProperty(value="受理业务类型")
    private String busiTypeCode;

    /**
     * 业务子类型
     */
    @TableField(value = "busi_sub_type")
    @ApiModelProperty(value="业务子类型")
    private String busiSubType;

    /**
     * 所属区县
     */
    @TableField(value = "county_code")
    @ApiModelProperty(value="所属区县")
    private String countyCode;

    /**
     * 城乡类别
     */
    @TableField(value = "urban_rural_flag")
    @ApiModelProperty(value="城乡类别")
    private String urbanRuralFlag;

    /**
     * 供电单位编码
     */
    @TableField(value = "org_no")
    @ApiModelProperty(value="供电单位编码")
    private String orgNo;

    /**
     * 受理人员工号
     */
    @TableField(value = "emp_no")
    @ApiModelProperty(value="受理人员工号")
    private String empNo;

    /**
     * 受理时间
     */
    @TableField(value = "handle_time")
    @ApiModelProperty(value="受理时间")
    private Date handleTime;

    /**
     * 受理方式
     */
    @TableField(value = "accept_mode")
    @ApiModelProperty(value="受理方式")
    private String acceptMode;

    /**
     * 受理内容
     */
    @TableField(value = "accept_content")
    @ApiModelProperty(value="受理内容")
    private String acceptContent;

    /**
     * 受理意见
     */
    @TableField(value = "handle_opinion")
    @ApiModelProperty(value="受理意见")
    private String handleOpinion;

    /**
     * 回复标志
     */
    @TableField(value = "reply_flag")
    @ApiModelProperty(value="回复标志")
    private String replyFlag;

    /**
     * 回复标志
     */
    @TableField(value = "reply_date")
    @ApiModelProperty(value="回复标志")
    private Date replyDate;

    /**
     * 回复方式
     */
    @TableField(value = "reply_mode")
    @ApiModelProperty(value="回复方式")
    private String replyMode;

    /**
     * 客户意见
     */
    @TableField(value = "cons_opinion")
    @ApiModelProperty(value="客户意见")
    private String consOpinion;

    /**
     * 回复电话
     */
    @TableField(value = "reply_tel")
    @ApiModelProperty(value="回复电话")
    private String replyTel;

    /**
     * 工单下发时间
     */
    @TableField(value = "send_date")
    @ApiModelProperty(value="工单下发时间")
    private Date sendDate;

    /**
     * 工作单有关附件
     */
    @TableField(value = "attach")
    @ApiModelProperty(value="工作单有关附件")
    private String attach;

    /**
     * 身份验证方式
     */
    @TableField(value = "iden_mode")
    @ApiModelProperty(value="身份验证方式")
    private String idenMode;

    /**
     * 证件类型
     */
    @TableField(value = "cert_type_code")
    @ApiModelProperty(value="证件类型")
    private String certTypeCode;

    /**
     * 证件号码
     */
    @TableField(value = "cert_no")
    @ApiModelProperty(value="证件号码")
    private String certNo;

    /**
     * 归档方式
     */
    @TableField(value = "arc_mode")
    @ApiModelProperty(value="归档方式")
    private String arcMode;

    /**
     * 完整性标志
     */
    @TableField(value = "integrity_flag")
    @ApiModelProperty(value="完整性标志")
    private String integrityFlag;

    /**
     * 准确性标志
     */
    @TableField(value = "accuracy_flag")
    @ApiModelProperty(value="准确性标志")
    private String accuracyFlag;

    /**
     * 归档意见
     */
    @TableField(value = "arc_opinion")
    @ApiModelProperty(value="归档意见")
    private String arcOpinion;

    /**
     * 归档意见
     */
    @TableField(value = "time_len")
    @ApiModelProperty(value="归档意见")
    private Long timeLen;

    /**
     * 归档人员
     */
    @TableField(value = "arc_emp_name")
    @ApiModelProperty(value="归档人员")
    private String arcEmpName;

    /**
     * 归档时间
     */
    @TableField(value = "arc_date")
    @ApiModelProperty(value="归档时间")
    private Date arcDate;

    /**
     * 处理状态步骤代码，如
：00接单分理
01服务处理
02工单受理
03接单派工
04故障处理
05答复用电客户
06故障调度
07工单审核
08归档
     */
    @TableField(value = "handle_status_code")
    @ApiModelProperty(value="处理状态步骤代码，如,：00接单分理,01服务处理,02工单受理,03接单派工,04故障处理,05答复用电客户,06故障调度,07工单审核,08归档")
    private String handleStatusCode;

    /**
     * 回复成功标志
     */
    @TableField(value = "reply_succ_flag")
    @ApiModelProperty(value="回复成功标志")
    private String replySuccFlag;

    /**
     * 回访未成功原因
     */
    @TableField(value = "retvisit_fail_reason")
    @ApiModelProperty(value="回访未成功原因")
    private String retvisitFailReason;

    /**
     * 回复失败次数
     */
    @TableField(value = "reply_fail_times")
    @ApiModelProperty(value="回复失败次数")
    private Integer replyFailTimes;

    /**
     * 受理派单时长
     */
    @TableField(value = "dispatch_len")
    @ApiModelProperty(value="受理派单时长")
    private Long dispatchLen;

    /**
     * 接单派工时长
     */
    @TableField(value = "transfer_len")
    @ApiModelProperty(value="接单派工时长")
    private Long transferLen;

    @TableField(value = "sg_app_no")
    @ApiModelProperty(value="")
    private String sgAppNo;
}