package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.CMpItRela;
import org.dfzt.mapper.CMpItRelaMapper;
import org.springframework.stereotype.Service;

/**
 * (CMpItRela)表服务实现类
 *
 * @author makejava
 * @since 2022-07-29 16:07:32
 */
@Service("cMpItRelaService")
public class CMpItRelaServiceImpl extends ServiceImpl<CMpItRelaMapper, CMpItRela> implements CMpItRelaService {

}

