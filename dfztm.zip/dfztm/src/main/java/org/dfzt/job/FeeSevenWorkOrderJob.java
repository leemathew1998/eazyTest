package org.dfzt.job;

import org.dfzt.service.FeecontrolWorkOrderService;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;

import javax.annotation.Resource;

/**
 * @Date:2023/2/27-15:37
 * @User:chengchuanlin
 * @Name:FeeWorkOrderJob
 * @Message:
 */
public class FeeSevenWorkOrderJob extends QuartzJobBean {

    @Resource
    private FeecontrolWorkOrderService feeService;

    @Override
    protected void executeInternal(JobExecutionContext context) throws JobExecutionException {

        feeService.feecontrolVo();

    }
}
