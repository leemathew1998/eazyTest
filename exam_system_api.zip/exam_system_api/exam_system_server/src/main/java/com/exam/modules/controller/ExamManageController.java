package com.exam.modules.controller;


import cn.hutool.core.util.ObjectUtil;
import cn.hutool.core.util.StrUtil;
import com.alibaba.fastjson.JSON;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.modules.entity.ExamInfo;
import com.exam.modules.entity.ExamManage;
import com.exam.modules.entity.ExamPaperInfo;
import com.exam.modules.entity.ExamT;
import com.exam.modules.entity.vo.ExamManageVo;
import com.exam.modules.mapper.ExamInfoMapper;
import com.exam.modules.service.ExamInfoService;
import com.exam.modules.service.ExamManageService;
import com.exam.modules.service.ExamPaperInfoService;
import com.exam.modules.service.ExamTService;
import com.exam.modules.utils.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.*;
import java.util.stream.Collectors;

/**
 * 考试管理(ExamManage)表控制层
 *
 * @author dyy
 * @since 2022-11-08 17:16:07
 */
@RestController
@RequestMapping("api/examManage")
@Slf4j
public class ExamManageController {
    /**
     * 服务对象
     */
    @Resource
    private ExamManageService examManageService;

    @Resource
    private ExamPaperInfoService examPaperInfoService;
    @Resource
    private ExamInfoService examInfoService;
    @Resource
    private ExamTService examTService;
    @Resource
    private ExamInfoMapper examInfoMapper;


    /**
     * 分页查询所有数据
     * @param examManageVo 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll") //api/examManage/selectAll
    public Result selectAll(@RequestBody ExamManageVo examManageVo) {
        //创建分页对象
        IPage<ExamManage> page = new Page<>(examManageVo.getPageNo(),examManageVo.getPageSize());
        //调用分页查询
        examManageService.findExamManageList(page,examManageVo);
        return Result.ok(page);
    }

    /**
     * 新建考试
     * @param
     * @return
     */
    @PostMapping("add") //api/examManage/add
    public Result add(@RequestBody ExamManageVo examManageVo) {
        //新增考试管理
        ExamManage examManage = new ExamManage(null,
                examManageVo.getExamName(),examManageVo.getExamPaperId(),
                examManageVo.getUserIds(),examManageVo.getExamType(),examManageVo.getExamStatus(),
                examManageVo.getExamBeginTime(),examManageVo.getExamEndTime(),examManageVo.getExamLongTime(),
                examManageVo.getPassScore(),0,0
        );
        examManageService.save(examManage);
        Long examId = examManage.getExamId();
        examInfoService.add(examManageVo,examId);
        return Result.ok().message("操作成功！");
    }

    /**
     * 修改考试
     * @param
     * @return
     */
    @PostMapping("update") //api/examManage/update
    public Result update(@RequestBody ExamManageVo examManageVo) {
        //新增或修改考试管理
        if(examManageService.updateById(examManageVo)){
            examInfoService.updateInfo(examManageVo);
            return Result.ok().message("操作成功！");
        }
        return Result.error().message("操作失败！");
    }


    /**
     * 删除考试
     * @param
     * @return
     */
    @PostMapping("del") //api/examManage/del
    public Result add(@RequestParam Long examId) {
        //根据id查询考试状态
        ExamManage examManage = examManageService.getById(examId);
        if(examManage.getExamStatus().equals("2")){
            return Result.error().message("考试进行中无法删除！");
        }
        if (examManage.getExamStatus().equals("3")){
            //根据考试id查询考试信息
            List<String> collect = examInfoService.list().stream()
                    .filter(s -> s.getExamId().equals(examId))
                    .map(ExamInfo::getMarkStatus)
                    .collect(Collectors.toList());

            for (String s : collect) {
                if (s.equals("2") || s.equals("3")){
                    return Result.error().message("本场考试未阅卷完成，删除失败！");
                }
            }
        }
        //考试未开始，可以删除
        QueryWrapper<ExamInfo> exam_id = new QueryWrapper<ExamInfo>().eq("EXAM_ID", examId);
        examInfoService.remove(exam_id);
        return Result.ok(examManageService.removeById(examId)).message("删除成功!");
    }

    /**
     * 根据题目ids,查询试卷中所有题(无答案)
     * @param
     * @return
     */
    @PostMapping("selPaper") //api/examManage/selPaper
    public Result selPaper(@RequestBody ExamPaperInfo examPaperInfo){
        List<String> list = Arrays.asList(examPaperInfo.getTids().split(","));
        List<ExamT> examTS = examTService.listByIds(list);
        //根据题目类型排序
        List<ExamT> collect = examTS.stream()
                .sorted(Comparator.comparing(ExamT::getTtype, Comparator.reverseOrder()))
                .peek(item -> {
                    item.setAnswer(null);
                    item.setAnswerInfo(null);
                })
                .collect(Collectors.toList());
        return Result.ok(collect);
    }

    /**
     * 根据题目ids,查询试卷中所有题(有答案)
     * @param
     * @return
     */
    @PostMapping("selectPaper") //api/examManage/selectPaper
    public Result selectPaper(@RequestBody ExamPaperInfo examPaperInfo){
        List<String> list = Arrays.asList(examPaperInfo.getTids().split(","));
        List<ExamT> examTS = examTService.listByIds(list);
        //根据题目类型排序
        List<ExamT> collect = examTS.stream()
                .sorted(Comparator.comparing(ExamT::getTtype, Comparator.reverseOrder()))
                .collect(Collectors.toList());
        return Result.ok(collect);
    }

    /**
     * 阅卷页面列表
     * @param
     * @return
     */
    @PostMapping("select") //api/examManage/select
    public Result select(@RequestBody ExamManageVo manageVo) {
        //分页
        IPage<ExamManage> page = new Page<>(manageVo.getPageNo(), manageVo.getPageSize());
        //获取考试id
        List<Long> collect = examManageService.list()
                .stream()
                .filter(Objects::nonNull)
                .map(ExamManage::getExamId)
                .collect(Collectors.toList());
        //创建list集合，存储考试人数
        List<ExamManage> list = new ArrayList<>();
        for (Long aLong : collect) {
            ExamManage examManage = new ExamManage();
            //应考人数
            Long count = examInfoMapper.count(aLong);
            //实考人数
            Long count1 = examInfoMapper.count1(aLong);

            examManage.setSunNum(count);
            examManage.setPerNum(count1);
            examManage.setExamId(aLong);
            list.add(examManage);
        }
        //分页查询
        IPage<ExamManage> examManageList = examManageService.findExamManageList(page, manageVo);
        //存储每场考试，应考人数，实考人数
        for (ExamManage record : examManageList.getRecords()) {
            for (ExamManage manage : list) {
                if (manage.getExamId().equals(record.getExamId())){
                    record.setSunNum(manage.getSunNum());
                    record.setPerNum(manage.getPerNum());
                }
            }
        }
        //返回数据
        return Result.ok(examManageList);
    }


    /**
     * 考试倒计时（每秒执行一次）
     */
//    @Scheduled(fixedDelay = 1000)
    public void ExamStop(){
        List<Date> beginTime = examManageService.list().stream()
                .filter(Objects::nonNull)
                .map(ExamManage::getExamBeginTime)
                .collect(Collectors.toList());

        List<Date> endTime = examManageService.list().stream()
                .filter(Objects::nonNull)
                .map(ExamManage::getExamEndTime)
                .collect(Collectors.toList());

        for (Date date : beginTime) {
            if (date.compareTo(new Date())==0){
                List<ExamManage> collect = Optional.ofNullable(examManageService.list()).orElse(new ArrayList<>())
                        .stream()
                        .filter(Objects::nonNull)
                        .peek(s -> s.setExamStatus("2"))
                        .collect(Collectors.toList());
                examManageService.updateBatchById(collect);
            }
            System.out.println("fixedDelay 每隔1秒" + new Date());
        }

        for (Date date : endTime) {
            if (date.compareTo(new Date())==0){
                List<ExamManage> collect = Optional.ofNullable(examManageService.list()).orElse(new ArrayList<>())
                        .stream()
                        .filter(Objects::nonNull)
                        .peek(s -> s.setExamStatus("3"))
                        .collect(Collectors.toList());
                examManageService.updateBatchById(collect);
            }
        }
    }
}
