package org.dfzt.entity.vo;

import lombok.Data;

@Data
public class ConsTgVo {
    private String consNo;
    private String tgNo;
    private String tgName;
}
