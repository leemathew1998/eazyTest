package org.dfzt.webservice;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/21
 * @Version: 1.00
 */
@WebService(name = "WebServiceGetValue",targetNamespace="webservice.dfzt.org")
public interface WebServiceGetValue {
    @WebMethod
    String getKPIValue(@WebParam(name="param") String param);
}
