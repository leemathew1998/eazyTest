package org.dfzt.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.dfzt.eunm.ContactModeEnum;

import java.math.BigDecimal;

/**
 * @ClassName ContList
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/8/5 10:25
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ContList {
    @ApiModelProperty(value = "联系类型")
    @TableField("contact_mode")
    private ContactModeEnum contactMode;

    @ApiModelProperty(value = "联系人")
    @TableField("contact_name")
    private String contactName;

    @ApiModelProperty(value = "性别")
    private String gender;

    @ApiModelProperty(value = "职务/职称")
    private String title;

    @ApiModelProperty(value = "办公电话")
    @TableField("office_tel")
    private String officeTel;

    @ApiModelProperty(value = "移动电话")
    private String mobile;

    @ApiModelProperty(value = "用户编号")
    private String consNo;

    @ApiModelProperty(value = "受电点名称")
    @TableField("ele_name")
    private String eleName;

    @ApiModelProperty(value = "电源数目")
    @TableField("num_of_power_supplies")
    private String numOfPowerSupplies;

    @ApiModelProperty(value = "受电点编号")
    private String  powerPointNo;

    @ApiModelProperty(value = "用户名称")
    @TableField("cons_name")
    private String consName;

    @ApiModelProperty(value = "用户地址")
    @TableField("cons_addr")
    private String consAddr;

    @ApiModelProperty(value = "用户分类")
    @TableField("cons_sort_code")
    private String consSortCode;

    @ApiModelProperty(value = "行业分类")
    @TableField("trade_code")
    private String tradeCode;

    @ApiModelProperty(value = "供电电压")
    @TableField("volt_code")
    private byte[] voltCode;

    @ApiModelProperty(value = "合同容量")
    @TableField("contract_cap")
    private BigDecimal contractCap;

    @ApiModelProperty(value = "用电标志")
    @TableField("elec_code")
    private String elecCode;

    @ApiModelProperty(value = "供电单位")
    @TableField("org_name")
    private String orgName;

    @ApiModelProperty(value = "抄表段编号")
    @TableField("mr_sect_no")
    private String mrSectNo;

    @ApiModelProperty(value = "用电类别")
    @TableField("elec_type_code")
    private String elecTypeCode;

    @ApiModelProperty(value = "运行容量")
    @TableField("run_cap")
    private BigDecimal runCap;

    @ApiModelProperty(value = "抄表员姓名")
    @TableField("reader_name")
    private String readerName;

    @ApiModelProperty(value = "催费员姓名")
    @TableField("remind_name")
    private String remindName;

    @ApiModelProperty(value = "用户状态")
    @TableField("cons_state")
    private String consState;

    @ApiModelProperty(value = "定价策略")
    @TableField("price_strategy")
    private String priceStrategy;

    @ApiModelProperty(value = "基本电费计算方式")
    @TableField("basic_cal_method")
    private String basicCalMethod;

    @ApiModelProperty(value = "需量核定值")
    @TableField("de_value")
    private String deValue;

    @ApiModelProperty(value = "功率因数考核方式")
    @TableField("ass_method")
    private String assMethod;

}
