package org.dfzt.eunm;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * @ClassName MyExceptionEnum
 * @Description TODO
 * @Author xingjunhao
 * @Date 2022/6/16 8:29
 */

@ApiModel(value="自定义异常对象")
public enum MyExceptionEnum {
    USER_CUNZAI(100, "时间段不符合电费发行未抄表数据抽取规则"),
    USER_BUCUNZAI(101, ""),
    USER_WEIZHUCE(102, "时间段符合电费发行未抄表数据抽取规则，但工单生成失败"),
    USER_YIZHUCE(202, "工单生成成功"),
    USER_CC(300, "工单已存在"),
    USER_AA(200, "对应台区经理工单查询成功"),
    USER_BB(201, "台区经理手动归档")
    ;
    @ApiModelProperty(value = "状态码")
    private Integer code;
    @ApiModelProperty(value = "异常信息")
    private String message;

    MyExceptionEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return this.code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return this.message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
