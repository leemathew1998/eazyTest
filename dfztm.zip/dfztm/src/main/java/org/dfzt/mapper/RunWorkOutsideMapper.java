package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.vo.RunWorkOutside;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2023-02-16
 */
public interface RunWorkOutsideMapper extends BaseMapper<RunWorkOutside> {

}
