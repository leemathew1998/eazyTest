package org.dfzt.job;

import lombok.RequiredArgsConstructor;
import org.dfzt.service.RunSupplementaryCopyService;
import org.jetbrains.annotations.NotNull;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import java.text.ParseException;

/**
 * @ClassName RunWorkOrder
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2023/2/27 16:55
 */
@Component
@RequiredArgsConstructor
public class RunWorkOrderJob extends QuartzJobBean {
    private final RunSupplementaryCopyService runSupplementaryCopyService;

    @Override
    protected void executeInternal(@NotNull JobExecutionContext context){
        try {
            runSupplementaryCopyService.Scheduled();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
