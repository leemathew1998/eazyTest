package org.dfzt.mapper;

import org.dfzt.entity.po.CollectWorkOrderInfor;
import org.springframework.stereotype.Repository;

@Repository
public interface CollectWorkOrderInforMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(CollectWorkOrderInfor record);

    int insertSelective(CollectWorkOrderInfor record);

    CollectWorkOrderInfor selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(CollectWorkOrderInfor record);

    int updateByPrimaryKeyWithBLOBs(CollectWorkOrderInfor record);

    int updateByPrimaryKey(CollectWorkOrderInfor record);

    CollectWorkOrderInfor SelectVandP(String workOrderNo);//采集运维表中回显图片视频数据

    CollectWorkOrderInfor selectlineVandP(String workOrderNo);//线损表中回显图片视频数据
    //计量表也使用此回显
}
