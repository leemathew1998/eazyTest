package org.dfzt.entity.po;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/5/31
 * @Version: 1.00
 */
@Data
public class AcAll {
    private Integer id;//id
    private String acName;//层级名称
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date dataDate;//数据时间
    private String ymd;//数据时间
    private String orgNo;//供电单位编号
    private String readName;//抄表员账号
    private Integer failNums;//台区经理（台区经理旗县营业站）采集失败的用户数 1 2
    private Integer allNums;//该台区经理（台区经理旗县营业站）管辖的用户数 1 5
    private Integer nohandleNums;//当天未处理采集失败工单数（台区经理旗县营业站） 2
    private String feestartSucnums;//费控复电成功数 3
    private String feestartAllnums;//费控复电总数 3
    private String feestopSucnums;//费控停电成功数 4
    private String feestopAllnums;//费控停电总数 4
    private String handNums;//中止（手动归档的客户数） 5
    private String allNums5;//（台区经理旗县营业站）所有的营业户数
    private String lossPqall;//（台区经理旗县营业站）管辖台区的损耗电量 6
    private String ppqAll;//（台区经理旗县营业站）管辖台区的供电电量 6
    private Integer tgNums;//（台区经理旗县营业站）管辖的所有台区个数 7 8 9
    private String lossrateHigh;//（台区经理旗县营业站）高损台区（线损为>=6的） 7
    private String lossrateLow;//（台区经理旗县营业站）负损台区（线损为<=-1的） 8
    private String lossrateNormal;//（台区经理旗县营业站）线损在0-4的台区个数 9
    private String linelossThreehandle;//（台区经理旗县营业站）三天以上未处理高负损工单数 10
    private String linelossAlls;//（台区经理旗县营业站）所有高负损工单数 10
    private String rcvblPenalty;//（台区经理旗县营业站）欠费金额（包含偏差考核和价差收益） 11
    private String rcvblAmt;//（台区经理旗县营业站）发行金额 11
    private String tgexceNums;//异常台区次数 12
    private String reply45Nums;//（台区经理旗县营业站）复电时间小于45分钟工单数 13
    private String replyAllnums;//（台区经理旗县营业站）所有现场复电工单数 13
    private String complaintNums;//（台区经理旗县营业站）投诉工单数 14
    private String opinionNums;//（台区经理旗县营业站）意见工单数 14
    private String sceneNums;//（台区经理旗县营业站主动运维主动抢修）45分钟到达现场工单数 15
    private String sceneAllnums;//（台区经理旗县营业站主动运维主动抢修）所有工单数 15
    private String meterThreenums;//（台区经理旗县营业站）三天以上未处理计量异常工单数 16
    private String meterAllnums;//（台区经理旗县营业站）所有计量异常工单数 16
    private String acId;//层级标识
}
