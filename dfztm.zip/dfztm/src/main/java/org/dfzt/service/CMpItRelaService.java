package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.CMpItRela;

/**
 * (CMpItRela)表服务接口
 *
 * @author makejava
 * @since 2022-07-29 16:07:32
 */
public interface CMpItRelaService extends IService<CMpItRela> {

}

