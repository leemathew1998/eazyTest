package com.exam.modules.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.exam.modules.entity.dto.AnsRecordDTO;
import com.exam.modules.entity.vo.AnsRecordVo;
import com.exam.modules.mapper.AnsRecordMapper;
import com.exam.modules.entity.AnsRecord;
import com.exam.modules.service.AnsRecordService;
import org.springframework.stereotype.Service;

/**
 * 作答记录(AnsRecord)表服务实现类
 *
 * @author makejava
 * @since 2022-11-09 15:33:34
 */
@Service("ansRecordService")
public class AnsRecordServiceImpl extends ServiceImpl<AnsRecordMapper, AnsRecord> implements AnsRecordService {


}
