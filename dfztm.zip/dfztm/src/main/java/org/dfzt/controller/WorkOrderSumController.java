package org.dfzt.controller;

import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.api.ApiController;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.dto.WorkOSumDto;
import org.dfzt.entity.po.WorkOrderSum;
import org.dfzt.mapper.WorkOrderSumMapper;
import org.dfzt.util.TimeUtil;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/7
 * @Version: 1.00 pc端工单概述
 */
@Slf4j
@RestController
@RequestMapping("/wosum")
@CrossOrigin
public class WorkOrderSumController extends ApiController{

    @Resource
    WorkOrderSumMapper workOrderSumMapper;


    //定时更新工单概述中的数据
//    @Scheduled()
    public void getWorkSumData(){
        List<WorkOSumDto> workOSumDtos1 = workOrderSumMapper.selectAllStatus1();
        for (WorkOSumDto workOSumDto1 : workOSumDtos1) {
            WorkOrderSum wos = workOrderSumMapper.selectTgNameexist(workOSumDto1.getTgName(), TimeUtil.getNowMonY());
            if (wos.equals("") || wos==null){
                WorkOrderSum workOrderSum = new WorkOrderSum();
                workOrderSum.setTgName(workOSumDto1.getTgName());
                workOrderSum.setDataMonth(TimeUtil.getNowMonY());
                workOrderSum.setStatusOnenums(1);
                workOrderSumMapper.insertSelective(workOrderSum);
            }else {
                workOrderSumMapper.updateStaonenum1(wos.getStatusOnenums()+1,wos.getTgName());
            }

        }

        List<WorkOSumDto> workOSumDtos2 = workOrderSumMapper.selectAllStatus2();
        for (WorkOSumDto workOSumDto2 : workOSumDtos2) {
            WorkOrderSum wos = workOrderSumMapper.selectTgNameexist(workOSumDto2.getTgName(), TimeUtil.getNowMonY());
            if (wos.equals("") || wos==null){
                WorkOrderSum workOrderSum = new WorkOrderSum();
                workOrderSum.setTgName(workOSumDto2.getTgName());
                workOrderSum.setDataMonth(TimeUtil.getNowMonY());
                workOrderSum.setStatusOnenums(1);
                workOrderSumMapper.insertSelective(workOrderSum);
            }else {
                workOrderSumMapper.updateStaonenum2(wos.getStatusOnenums()+1,wos.getTgName());
            }

        }

        List<WorkOSumDto> workOSumDtos3 = workOrderSumMapper.selectAllStatus3();
        for (WorkOSumDto workOSumDto3 : workOSumDtos3) {
            WorkOrderSum wos = workOrderSumMapper.selectTgNameexist(workOSumDto3.getTgName(), TimeUtil.getNowMonY());
            if (wos.equals("") || wos==null){
                WorkOrderSum workOrderSum = new WorkOrderSum();
                workOrderSum.setTgName(workOSumDto3.getTgName());
                workOrderSum.setDataMonth(TimeUtil.getNowMonY());
                workOrderSum.setStatusOnenums(1);
                workOrderSumMapper.insertSelective(workOrderSum);
            }else {
                workOrderSumMapper.updateStaonenum3(wos.getStatusOnenums()+1,wos.getTgName());
            }

        }
    }



    /**
     * TODO 获取工单概述并展示 PC
     * @return
     */
    @PostMapping("getWorkoSum1")
    public R getWorkoSum1(){
        Map<String, List<WorkOrderSum>> sunmap = new HashMap<>();
        List<WorkOrderSum> workOrderSums = workOrderSumMapper.selectWorkSumBymon1(TimeUtil.getNowMonY());
        sunmap.put("当月待处理工单",workOrderSums);
        return success(sunmap);
    }

    @PostMapping("getWorkoSum2")
    public R getWorkoSum2(){
        Map<String, List<WorkOrderSum>> sunmap = new HashMap<>();
        List<WorkOrderSum> workOrderSums = workOrderSumMapper.selectWorkSumBymon2(TimeUtil.getNowMonY());
        sunmap.put("当月处理中工单",workOrderSums);
        return success(sunmap);
    }

    @PostMapping("getWorkoSum3")
    public R getWorkoSum3(){
        Map<String, List<WorkOrderSum>> sunmap = new HashMap<>();
        List<WorkOrderSum> workOrderSums = workOrderSumMapper.selectWorkSumBymon3(TimeUtil.getNowMonY());
        sunmap.put("当月已处理工单",workOrderSums);
        return success(sunmap);
    }

}
