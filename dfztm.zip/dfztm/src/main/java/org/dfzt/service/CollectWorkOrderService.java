package org.dfzt.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.CollectYwWorkOrderv;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/11
 * @Version: 1.00
 */
public interface CollectWorkOrderService extends IService<CollectWorkOrder> {

    IPage<CollectWorkOrder> selectAllYWO1(Map<String,Object> map);

    List<CollectWorkOrder> selectAllYWO();
    int insertSelective(CollectWorkOrder cywo);

    int updateStatus2(int id);//添加台区经理，修改为待处理

    int updateStatus3(String workOrderNo);//状态修改为3，待归档

    int updateStatus1(int id);//状态修改为1，待处理

    int updateStatus4(int id);//状态修改为4，已归档
    //根据id查询工单
    CollectWorkOrder selectByPrimaryKey(Integer id);

    //查询创建时间，以便后期判断工单周期
    Date SelectWoTime(int id);

    List<CollectWorkOrder> selectByeleNum(String eleNum);//根据用户编码查找相同用户编码的信息

    int updateWorkCycle(String workOrderCycle,Integer id);//修改工单周期

    List<CollectWorkOrder> selectList1(CollectWorkOrder c,String username,String s,String pageNo,String pageSize,List<String> orgNames,String status);//采集运维条件查询
    List<CollectWorkOrder> selectList2(List<String> readNames,String one,String username,Integer pageNo,Integer pageSize,String workOrderStatus,List<String> orgName,String role);//采集运维单个条件查询

    List<CollectWorkOrder> selectAllYWOapp();//查询敏感用户的采集运维工单

    CollectNotcon selectByPrimaryKeyn(Integer id);//原始数据关联采集未接入
    CollectInforma selectByPrimaryKeyi(Integer id);//原始数据关联采集异常
    CollectFailure selectByPrimaryKeyf(Integer id);//原始数据关联采集失败

    List<Map<String,Object>> nineCollWd(String username);//工单的状态和预警个数

    void insertCollFail(List<CollectFailure> collFails);//采集失败工单生成并入库
    void insertCollNotc(CollectNotcon collNotc);//采集未接入工单生成并入库
    void insertCollInfo(CollectInforma collInfo);//采集异常工单生成并入库

}
