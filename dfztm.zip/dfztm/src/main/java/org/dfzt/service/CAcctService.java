package org.dfzt.service;

import org.dfzt.entity.po.CAcct;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/14
 * @Version: 1.00
 */
public interface CAcctService extends IService<CAcct>{


}
