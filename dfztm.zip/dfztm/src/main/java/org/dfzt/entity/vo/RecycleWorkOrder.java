package org.dfzt.entity.vo;


import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.extension.activerecord.Model;

import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.dfzt.eunm.WorkOrderStatusEnum;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

/**
 * (RecycleWorkOrder)表实体类
 *
 * @author makejava
 * @since 2022-07-11 15:38:15
 */
@SuppressWarnings("serial")
@TableName("recycle_work_order")
@Data
public class RecycleWorkOrder extends Model<RecycleWorkOrder> {

    private Integer id;
    private BigDecimal rcvblAmtId;//应收电费标识
    //工单编号
    @Excel(name = "工单编号",orderNum = "1")
    private String workOrderNo;
    //台区经理
    @Excel(name = "台区经理",orderNum = "2")
    private String tgManager;
    //台区编号
    @Excel(name = "台区经理",orderNum = "3")
    private String tgId;
    //台区名称
    @Excel(name = "台区名称",orderNum = "4")
    private String tgName;
    //供电单位
    @Excel(name = "供电单位",orderNum = "5")
    private String orgNo;
    //用户名称
    @Excel(name = "用户名称",orderNum = "6",width = 20)
    private String consName;
    //用户编号
    private String consNo;
    //用户地址
    @Excel(name = "用户地址",orderNum = "7",width = 25)
    private String elecAddr;
    //用户电话
    @Excel(name = "用户电话",orderNum = "8")
    private String mobile;
    //用电类别
    @Excel(name = "用电类别",orderNum = "9",width = 20)
    private String elecTypeCode;
    //电度电费
    @Excel(name = "电度电费",orderNum = "11",width = 15)
    private BigDecimal oweAmt;
    //违约金
    private BigDecimal rcvblPenalty;
    //差价收益
    private BigDecimal differenceEarnings;
    //偏差考核
    private BigDecimal deviationAssess;
    //工单状态，1.待处理，2.处理中，3.待归档，4.已归档
    @ApiModelProperty("状态")
    @Excel(name = "处理状态",orderNum = "10")
    private WorkOrderStatusEnum workOrderStatus;
    //工单处理时间
    private Date workOrderStime;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderTime;
    //是连续几天的工单
    private Integer workOrderCycle;
    //工单描述
    private String workOrderDes;

//    public void setWorkOrderStatus(String workOrderStatus) {
//        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
//    }
}
