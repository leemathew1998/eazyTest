package org.dfzt.service;

import org.dfzt.entity.po.EMpVolCurve;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author 李木
* @description 针对表【e_mp_vol_curve】的数据库操作Service
* @createDate 2023-02-25 14:24:13
*/
public interface EMpVolCurveService extends IService<EMpVolCurve> {

}
