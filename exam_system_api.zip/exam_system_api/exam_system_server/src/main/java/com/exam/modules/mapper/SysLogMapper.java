package com.exam.modules.mapper;

import com.exam.modules.entity.SysLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.exam.modules.entity.vo.LogVo;

import java.util.Date;
import java.util.List;

/**
 * <p>
 * 登录日志 Mapper 接口
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
public interface SysLogMapper extends BaseMapper<SysLog> {
    //登录失败日志信息
    List<LogVo> loglFailure();
}
