package org.dfzt.config;

import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.dfzt.webservice.WebServiceGetValue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.Resource;
import javax.xml.ws.Endpoint;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/21
 * @Version: 1.00
 */
@Configuration
public class WebSerConfig {
    @Resource
    WebServiceGetValue serviceGetValue;

    @Bean(name = Bus.DEFAULT_BUS_ID)
    public SpringBus springBus() {
        return new SpringBus();
    }

//   //把实现类交给spring管理
//    @Bean
//    public WSAPI webService() {
//        return new WSAPIImpl();
//    }

    @Bean
    public Endpoint endpoint() {
        EndpointImpl endpoint=new EndpointImpl(springBus(), serviceGetValue);
        endpoint.publish("/getvalue");//访问地址
        return endpoint;
    }

}
