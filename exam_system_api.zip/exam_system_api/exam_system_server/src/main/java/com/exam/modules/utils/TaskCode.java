package com.exam.modules.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**
 * @Author dyy
 * @Date 2022/11/0114:36
 * @PackageName:com.dfzt.modules.operation.utils
 * @ClassName: taskCode
 * @Description: TODO
 * @Version 1.0
 */
public class TaskCode {
    public static String taskCode(){
        String s = new SimpleDateFormat("yyMMddss").format(new Date());
        Random random=new Random();
        int min=1000;
        int max=9999;
        int sum  = random.nextInt(max)%(max-min+1) + min;
        String key = "";
        for (int i = 0;i<1;i++){
            key = key+ (char)(Math.random()*26+'A');
        }
        String str =key+ s+sum;
        return str;
    }
}
