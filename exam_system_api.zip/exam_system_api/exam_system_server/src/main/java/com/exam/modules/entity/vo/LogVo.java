package com.exam.modules.entity.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @Author dyy
 * @Date 2022/11/2 17:11
 * @PackageName:com.exam.modules.entity.vo
 * @ClassName: LogVo
 * @Description: TODO 登录日志
 * @Version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class LogVo {
    private String username;
    private String theGroup;
    private Date loginTime;
    private String remark;
}
