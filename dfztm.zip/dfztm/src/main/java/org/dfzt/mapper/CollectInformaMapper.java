package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.CollectInforma;

/**
* @author 李木
* @description 针对表【collect_informa】的数据库操作Mapper
* @createDate 2023-02-25 11:07:08
* @Entity org/afzt.entity/po.CollectInforma
*/
public interface CollectInformaMapper extends BaseMapper<CollectInforma> {

}




