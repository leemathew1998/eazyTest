package org.dfzt.entity.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/28
 * @Version: 1.00
 * TODO 绩效相关的采集成功数和失败数
 */
@Data
public class CollectNum implements Serializable {
    private int collsucc;//采集成功数
    private int collfail;//采集失败数
    private int collall;//采集总数
}
