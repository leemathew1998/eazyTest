package org.dfzt.entity.vo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/7
 * @Version: 1.00
 */
@Data
public class WorkOrderSumVo {
    //台区名称
    private String tgName;
    //台区编号
    private String tgNo;
}
