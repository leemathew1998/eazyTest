package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.dfzt.entity.vo.SysUser;

/**
 * (SysUser)表数据库访问层
 *
 * @author makejava
 * @since 2022-07-21 11:58:53
 */
public interface SysUserMapper extends BaseMapper<SysUser> {

    @Select("SELECT * FROM sys_user WHERE login_name = #{loginName} AND pass_word = #{passWord}")
    public SysUser findByLoginNameAndPassWord(@Param("loginName") String loginName,@Param("passWord") String passWord);

    int deleteByKey(Integer id);

    int insertSelective(SysUser sysUser);

    SysUser selectByKey(Integer id);

    int updateByKeySelective(SysUser sysUser);

}


