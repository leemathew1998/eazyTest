package org.dfzt.entity.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/8/18
 * @Version: 1.00
 * TODO 分时显示
 */
@Data
public class SplitTime implements Serializable {
    private String timeSlot;//分时时间段
    private String phaseSlot;//分相段
    private String ppq;//供电量
    private String tgSpq;//售电量
    private String lossPq;//损耗电量
    private String linelossRate;//线损率
}
