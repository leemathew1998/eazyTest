package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.dfzt.entity.po.PreventStealing;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/5
 * @Version: 1.00
 */
@Mapper
public interface PreventStealingMapper extends BaseMapper<PreventStealing> {

    List<PreventStealing> select();

    List<PreventStealing> selectNo();

    List<PreventStealing> selectAllStatus(PreventStealing p);
}
