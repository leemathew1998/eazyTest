package org.dfzt.entity.tdo;

import lombok.Data;

import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 获取人 所 站统计
 */
@Data
public class PlaceStation {
    //所名称、站名称、人名称
    private String name;
    //服务范围
    private String scopeOfServices;
    //统计列表
    private List<StatisticsList> statisticsList;
}
