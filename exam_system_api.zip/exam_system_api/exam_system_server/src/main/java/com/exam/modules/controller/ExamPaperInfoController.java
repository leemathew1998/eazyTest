package com.exam.modules.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.modules.entity.ExamPaperInfo;
import com.exam.modules.entity.dto.ExamPaperInfoDTO;
import com.exam.modules.entity.vo.ExamPaperInfoVo;
import com.exam.modules.service.ExamPaperInfoService;
import com.exam.modules.service.ExamTService;
import com.exam.modules.utils.Result;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;

/**
 * (ExamPaperInfo)表控制层
 * 试卷信息
 * @author dyy
 * @since 2022-11-07 15:32:49
 */
@RestController
@RequestMapping("api/examPaperInfo")
public class ExamPaperInfoController{

    /**
     * 服务对象
     */
    @Resource
    private ExamPaperInfoService examPaperInfoService;
    @Resource
    private ExamTService examTService;

    /**
     * 分页查询所有数据
     * @param examPaperInfoVo 查询实体
     * @return 所有数据
     */
    @PostMapping("selectAll") //api/examPaperInfo/selectAll
    public Result selectAll(@RequestBody ExamPaperInfoVo examPaperInfoVo) {
        //创建分页对象
        IPage<ExamPaperInfo> page = new Page<>(examPaperInfoVo.getPageNo(),examPaperInfoVo.getPageSize());
        //调用分页查询
        examPaperInfoService.findPaperInfoList(page,examPaperInfoVo);
        return Result.ok(page);
    }

    /**
     * 添加或修改试卷
     * @param examPaperInfo
     * @return
     */
    @PostMapping("/addOrUpdate") //api/examPaperInfo/addOrUpdate
    public Result add(@RequestBody ExamPaperInfo examPaperInfo){
        if(examPaperInfoService.saveOrUpdate(examPaperInfo)){
            return Result.ok().message("添加成功");
        }
        return Result.error().message("添加失败");
    }

    /**
     * 自动添加试卷
     * @param examPaperInfo
     * @return
     */
    @PostMapping("/save")
    public Result save(@RequestBody ExamPaperInfoDTO examPaperInfo){
        if(examPaperInfoService.savePaper(examPaperInfo)){
            return Result.ok().message("添加成功");
        }
        return Result.error().message("添加失败");
    }

    /**
     * 删除角色
     * @param id
     * @return
     */
    @GetMapping("/delete")  // api/examPaperInfo/delete
    public Result delete(Long id){
        if(examPaperInfoService.removeById(id)){
            return Result.ok().message("删除成功");
        }
        return Result.error().message("删除失败");
    }

    /**
     * 修改试卷使用次数
     * @param examPaperInfo
     * @return
     */
    @PostMapping("/useNum")//api/examPaperInfo/useNum
    public Result useNum(@RequestBody ExamPaperInfo examPaperInfo){

        if(examPaperInfoService.updateUseNum(examPaperInfo)){
            return Result.ok().message("成功");
        }
        return Result.error().message("失败");
    }
}
