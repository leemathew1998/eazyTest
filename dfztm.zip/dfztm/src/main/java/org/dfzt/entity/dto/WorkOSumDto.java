package org.dfzt.entity.dto;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/7
 * @Version: 1.00
 */
@Data
public class WorkOSumDto implements Serializable {
    private String tgName;
    private String workOrderCtime;
}
