package org.dfzt.service.impl;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.date.DateUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import org.dfzt.entity.po.RunWorkOrderPo;
import org.dfzt.entity.vo.RecycleWorkOrder;
import org.dfzt.entity.vo.RunWorkOrder;
import org.dfzt.eunm.MeterReadingEnum;
import org.dfzt.eunm.MyExceptionEnum;
import org.dfzt.eunm.WorkOrderEnum;
import org.dfzt.mapper.RunWorkOrderMapper;
import org.dfzt.service.FeecontrolWorkOrderService;
import org.dfzt.service.RunSupplementaryCopyService;
import org.dfzt.service.RunWorkOrderService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Service
public class RunWorkOrderServiceImpl extends ServiceImpl<RunWorkOrderMapper, RunWorkOrder> implements RunWorkOrderService {

    @Resource
    RunWorkOrderMapper runWorkOrderMapper;

    @Resource
    private FeecontrolWorkOrderService feecontrolWorkOrderService;

    @Resource
    private RunSupplementaryCopyService runSupplementaryCopyService;

    @Override
    public IPage<RunWorkOrder> selectAll(Page page, RunWorkOrder runWorkOrder, String role,String status,String orgName) {
        //1.台区经理 2.所站长
        if ("1".equals(role)) {
            LambdaQueryWrapper<RunWorkOrder> wrapper = new LambdaQueryWrapper<RunWorkOrder>()
                    .like(runWorkOrder.getConsNo() != null, RunWorkOrder::getConsNo, runWorkOrder.getConsNo())
                    .like(runWorkOrder.getConsName() != null, RunWorkOrder::getConsName, runWorkOrder.getConsName())
                    .eq(runWorkOrder.getWorkOrderStatus() != null, RunWorkOrder::getWorkOrderStatus, runWorkOrder.getWorkOrderStatus())
                    .eq(orgName != null, RunWorkOrder::getOrgName, orgName)
                    .inSql(status!=null,RunWorkOrder::getWorkOrderStatus1,status);
            IPage<RunWorkOrder> iPage = runWorkOrderMapper.selectPage(page, wrapper);
            return iPage;
        } else {
            LambdaQueryWrapper<RunWorkOrder> wrapper = new LambdaQueryWrapper<RunWorkOrder>()
                    .like(runWorkOrder.getConsNo() != null, RunWorkOrder::getConsNo, runWorkOrder.getConsNo())
                    .like(runWorkOrder.getConsName() != null, RunWorkOrder::getConsName, runWorkOrder.getConsName())
                    .eq(runWorkOrder.getWorkOrderStatus() != null, RunWorkOrder::getWorkOrderStatus, runWorkOrder.getWorkOrderStatus())
                    .eq(orgName != null, RunWorkOrder::getOrgName, orgName)
                    .inSql(status!=null,RunWorkOrder::getWorkOrderStatus1,status);
            IPage<RunWorkOrder> iPage = runWorkOrderMapper.selectPage(page, wrapper);
            return iPage;
        }
    }

    @Override
    public IPage<RunWorkOrder> queryAll(List<String> readNames,Page page, String condition, String role,String workOrderStatus,String loName2) {

//        //当前时间
//        Long currentTime = Long.valueOf(splitSpring(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-ddHH:mm:ss"))));
//        //当月1号0点0分
//        Long startTime = Long.valueOf(splitSpring(DateStartTime()).replaceAll(" ", ""));
//        //当前月2号0点0分
//        Long endTime = Long.valueOf(splitSpring(DateStartEarlyTime().replaceAll(" ", "")));
            if ("2".equals(role)) {
                LambdaQueryWrapper<RunWorkOrder> wrapper = new LambdaQueryWrapper<RunWorkOrder>()
                        .inSql(workOrderStatus != null, RunWorkOrder::getWorkOrderStatus1,workOrderStatus)
                        .in(readNames!=null,RunWorkOrder::getArcEmpName,readNames)
//                        .eq(loName2!=null,RunWorkOrder::getArcEmpName,loName2)
                        //少一个预警的
                        .like(condition != null, RunWorkOrder::getConsNo, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getWorkOrderNo, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getConsName, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getOrgName, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMrStatusCode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getAmtYm, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getVoltCode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getWorkOrderStatus, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMobile, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getTgName, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getTgNo, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMarketType, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getExcpTypeCode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getElecTypeCode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterAssetNo, condition)
                        .or()
//                    .like(condition != null, RunWorkOrderPo::getGpsLatitud, condition)
//                    .or()
                        .like(condition != null, RunWorkOrder::getArcMode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterGenerationTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getArcDate, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterPendingTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getArcDate, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterPendingTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterProcessingTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterToBeTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getElecAddr, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterCycle, condition);

                IPage<RunWorkOrder> iPage = runWorkOrderMapper.selectPage(page, wrapper);
                return iPage;
                }else {
                //                //判断当前是否为2号，是二号做预警操作
//                if (currentTime >= startTime && currentTime <= endTime){
                LambdaQueryWrapper<RunWorkOrder> wrapper = new LambdaQueryWrapper<RunWorkOrder>()
                        .inSql(workOrderStatus != null, RunWorkOrder::getWorkOrderStatus1,workOrderStatus).or()
                        .eq(loName2!=null,RunWorkOrder::getArcEmpName,loName2)
                        //少一个判断台区编码的判断
                        .like(condition != null, RunWorkOrder::getConsNo, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getWorkOrderNo, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getConsName, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getOrgName, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMrStatusCode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getAmtYm, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getVoltCode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getWorkOrderStatus, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMobile, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getTgName, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getTgNo, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMarketType, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getExcpTypeCode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getElecTypeCode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterAssetNo, condition)
                        .or()
//                    .like(condition != null, RunWorkOrderPo::getGpsLatitud, condition)
//                    .or()
                        .like(condition != null, RunWorkOrder::getArcMode, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterGenerationTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getArcDate, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterPendingTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getArcDate, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterPendingTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterProcessingTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterToBeTime, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getElecAddr, condition)
                        .or()
                        .like(condition != null, RunWorkOrder::getMeterCycle, condition);

                IPage<RunWorkOrder> iPage = runWorkOrderMapper.selectPage(page, wrapper);
                return iPage;
                }
//            } else {
//                LambdaQueryWrapper<RunWorkOrder> wrapper = new LambdaQueryWrapper<RunWorkOrder>()
//                        .eq(RunWorkOrder::getWorkOrderStatus,0)//未抄表
//
//                        .like(condition != null, RunWorkOrder::getConsNo, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getConsName, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getOrgName, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMrStatusCode, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getAmtYm, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getVoltCode, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getWorkOrderStatus, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMobile, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getTgName, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getTgNo, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMarketType, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getExcpTypeCode, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getElecTypeCode, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMeterAssetNo, condition)
//                        .or()
////                    .like(condition != null, RunWorkOrderPo::getGpsLatitud, condition)
////                    .or()
//                        .like(condition != null, RunWorkOrder::getArcMode, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMeterGenerationTime, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getArcDate, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMeterPendingTime, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getArcDate, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMeterPendingTime, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMeterProcessingTime, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMeterToBeTime, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getElecAddr, condition)
//                        .or()
//                        .like(condition != null, RunWorkOrder::getMeterCycle, condition);
//                IPage<RunWorkOrder> iPage = runWorkOrderMapper.selectPage(page, wrapper);
//                return iPage;
            //}
    }

    /**
     * 查看工单详细
     *
     * @return
     */
    @Override
    public List<RunWorkOrder> queryAdd() {
        return runWorkOrderMapper.queryAdd();
    }


    /**
     * @param id
     * @return
     */
    @Override
    public int queryid(Integer id) {
        return runWorkOrderMapper.queryid(id);
    }

    /**
     * 通过台区经理id查询对应台区经理待处理工单
     *
     * @param tqid
     * @return
     */
    @Override
    public R querylist(Integer tqid) {
        R apiResult = new R();
        apiResult.setCode(MyExceptionEnum.USER_YIZHUCE.getCode());//获取工单成功状态码
        apiResult.setData(this.getBaseMapper().selectList(new LambdaQueryWrapper<RunWorkOrder>()
                .eq(RunWorkOrder::getTgNo, tqid)));
        apiResult.setMsg(MyExceptionEnum.USER_YIZHUCE.getMessage());//获取工单成功信息
        return R.ok(apiResult);

    }


    /**
     * 4号凌晨规则研判
     *
     * @return
     */
    @Override
    public R<?> queryS() throws ParseException {
        //获取年月日时分秒
        LocalDateTime datetime = LocalDateTime.now();
        //定义R类
        R<String> apiResult = new R<>();
        //获取当前月工单数据信息
        List<RunWorkOrder> list =
                runWorkOrderMapper.selectList(new LambdaQueryWrapper<RunWorkOrder>()
                        .ge(RunWorkOrder::getMeterGenerationTime, this.DateStartTime()));
        list.forEach(System.err::println);
        if (datetime.isEqual(LocalDateTime.now().withDayOfMonth(4).withHour(0).withMinute(0).withSecond(0))) {
            if (list.size() > 0) {
                for (RunWorkOrder runWorkOrder : list) {
                    if ("00".equals(runWorkOrder.getMrStatusCode().getCode()) || runWorkOrder.getExcpTypeCode() == 1) {//0：未抄表，1：数据存在异常
                        runWorkOrder.setMeterGenerationTime(this.datetimemill());//修改抄表日期时间
                        runWorkOrder.setAmtYm(this.amt_ym());//获取电费年月
                        runWorkOrder.setWorkOrderStatus(WorkOrderEnum.WORK_ORDER_ENUM_ONE);//再次生成的工单修改工单状态为1：待处理
                        this.getBaseMapper().insert(runWorkOrder);
                        apiResult.setData("修改成功");
                        apiResult.setCode(MyExceptionEnum.USER_BB.getCode());
                        apiResult.setMsg(MyExceptionEnum.USER_BB.getMessage());
                        //1,代表已抄表和数据异常为否,两者必须同时满足
                    } else if ("01".equals(runWorkOrder.getMrStatusCode().getCode()) && runWorkOrder.getExcpTypeCode() == 0) {
                        //通过工单编号修改状态为自动归档
                        runWorkOrderMapper.updateid(0, runWorkOrder.getAppNo());
                        apiResult.setCode(MyExceptionEnum.USER_BB.getCode());
                        apiResult.setData("符合时间条件修改成功");
                        apiResult.setMsg(MyExceptionEnum.USER_BB.getMessage());
                    }
                }
            }
        }
        return apiResult;
    }

    /**
     * 判断工单周期
     *
     * @param dfbcGdUserid
     * @return
     */
    @Override
    public String selectPeriod(String dfbcGdUserid) {
        Integer period = 0;
        for (int i = 1; i > 0; i++) {
            int selectPeriod = runWorkOrderMapper.selectPeriod(dfbcGdUserid, i);
            if (selectPeriod == 0) {
                return String.valueOf(period);//退出循环
            }
            period += 1;
        }

        return "0";
    }

    @Override
    public int updateStatus(Integer workOrderStatus, String id) {
        return runWorkOrderMapper.updateStatus(workOrderStatus, id);
    }


    /**
     * 查询每月4号凌晨仍未抄表的数据
     * 需要站长手动归档
     * 调用Gdfs(GdNo)
     *
     * @param TqId
     * @return
     */
    @Override
    public List<RunWorkOrder> queryRunWorker(Integer TqId) {
        //查询出对应台区经理当前月份的未抄表的数据
        return this.getBaseMapper().selectList(new LambdaQueryWrapper<RunWorkOrder>()
                        .eq(RunWorkOrder::getTgNo, TqId)
//                .eq(RunWorkOrderPo::getMrStatusCode,MeterReadingEnum.METER_READING_ENUM_ZERO)
//                .between(RunWorkOrderPo::getMeterGenerationTime, this.DateStartTime(), this.DateEndTime())
        );
    }

    /**
     * 当前月第一天
     *
     * @return
     */
    public String DateStartTime() {
        //获取当前月份第一天的年月日时分秒
        LocalDateTime localDateTime = LocalDateTime
                .of(LocalDate
                        .now().getYear(), LocalDate.now().getMonth(), 1, 0, 0, 0);
        return localDateTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }

    /**
     * 当前月最后一天
     *
     * @return
     */
    public String DateEndTime() {
        //获取当前月份最后一天的年月日时分秒
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date());
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String s2 = simpleDateFormat.format(DateUtil.endOfDay(cal.getTime()));
        return s2;
    }

    /**
     * 台区经理手动归档方法
     *
     * @param GdNo
     * @return
     */
    @Override
    public int Gdfs(String GdNo) {
        return runWorkOrderMapper.updateid(1, GdNo);
    }

    /**
     * 九大工单右上角图标计数功能
     * 台区经理
     *
     * @return
     */
    @Override
    public List<Map<String, Object>> nineMajorWorkOrders(String loginName) {
        String role = feecontrolWorkOrderService.selectRole(loginName);
        List<Map<String, Object>> list1 = Lists.newArrayList();
        if ("1".equals(role)) {
            Map<String, Object> map = returnToGeneral();
            list1.add(map);
        } else if ("2".equals(role)) {
            Map<String, Object> map = returnToGeneral();
            List<RunWorkOrder> list = list(new LambdaQueryWrapper<RunWorkOrder>().between(RunWorkOrder::getMeterGenerationTime, DateStartTime(), DateEndTime()));
            //待处理个数
            long pendingNum = list.stream().map(RunWorkOrder::getWorkOrderStatus).filter(Objects::nonNull).filter(s -> s.equals(WorkOrderEnum.WORK_ORDER_ENUM_ONE)).count();
            //处理中个数
            long processingNUm = list.stream().map(RunWorkOrder::getWorkOrderStatus).filter(Objects::nonNull).filter(s -> s.equals(WorkOrderEnum.WORK_ORDER_ENUM_TWO)).count();
            //待归档个数
            long noArchivedNum = list.stream().map(RunWorkOrder::getWorkOrderStatus).filter(Objects::nonNull).filter(s -> s.equals(WorkOrderEnum.WORK_ORDER_ENUM_THREE)).count();
            //已归档个数
            long archivedNum = list.stream().map(RunWorkOrder::getWorkOrderStatus).filter(Objects::nonNull).filter(s -> s.equals(WorkOrderEnum.WORK_ORDER_ENUM_FOUR)).count();

            map.put("pendingNum", pendingNum);
            map.put("processingNUm", processingNUm);
            map.put("noArchivedNum", noArchivedNum);
            map.put("archivedNum", archivedNum);
            list1.add(map);
        }

//        //计量运维
//        List<Map<String,Object>> list2=meterWorkOrderService.workOrderMeasurement(loginName);
//        //采集运维
//        List<Map<String,Object>> list3=collectYwWorkOrderService.nineCollWd(loginName);
//        //优质服务
//        List<Map<String,Object>> list4=superiorWorkorderServiceImpl.highQuality(loginName);
//        //电费回收
//        List<Map<String,Object>> list5= recycleWorkorderService.nineMajorWorkOrders(loginName);
//        //主动运维
//        List<Map<String,Object>> list6=activeOperationService.nineAcOperWd(loginName);
//        //线损治理
//        List<Map<String,Object>> list7=linelossWorkOrderService.nineLinelossWd(loginName);
//        //费控复电
//        List<Map<String,Object>> list8= feecontrolWorkOrderService.nineMajorWorkOrders(loginName);
//        //主动抢修
//        List<Map<String,Object>> list9= repairsWorkOrderService.rushToRepair(loginName);

//        //敏感用户个数
//        List<Map<String,Object>> list=new ArrayList<>();
//        Map<String,Object> map=new HashMap<>();
//        map.put("sensitiveUsers",countAll());
//        list.add(map);
//        //反窃查违
//        list.add(preventStealingService.statusNumber().get(0));
//        //聚合
//        List<Map<String,Object>> resultList= Stream.of(list,list1,list2,list3,list4,list5,list6,list7,list8,list9)
//                .flatMap(Collection::stream).collect(Collectors.toList());
//        return resultList;
        return null;
    }

    @Override
    public RunWorkOrderPo selectById(String appNo) {
        return runWorkOrderMapper.selectById(appNo);
    }

    /**
     * 电费发行-返回通用
     *
     * @return
     */
    public Map<String, Object> returnToGeneral() {
        Long integer =
                Long.valueOf
                        (splitSpring(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-ddHH:mm:ss"))));

        Long s1 = Long.valueOf(splitSpring(DateStartEarlyTime().replaceAll(" ", "")));//当前每个月2号最小时间
        Long s2 = Long.valueOf(splitSpring(DateStartTime()).replaceAll(" ", ""));//当前月一号最小时间
        long count;
        if (integer <= s1 && integer >= s2) {
            count = 0;
        } else {
            count = list(new LambdaQueryWrapper<RunWorkOrder>()
                    .between(RunWorkOrder::getMeterGenerationTime, DateStartTime(), DateEndTime())
                    .eq(RunWorkOrder::getWorkOrderStatus, 1)).stream().filter(Objects::nonNull).count();
        }
        Map<String, Object> map = new HashMap<>();
        map.put("makeUpCopyEarlyWarning", count);
        return map;
    }

    /**
     * 封装返回字符串数组拼接的spilt的String方法
     *
     * @param str
     * @return
     */
    public String splitSpring(String str) {
        String s3 = "";
        for (String s : str.split("-|:")) {
            s3 += s;
        }
        return s3;
    }

    /**
     * 当前月份第二天的最小时间
     *
     * @return
     */
    public String DateStartEarlyTime() {
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        c.set(Calendar.DAY_OF_MONTH, 2);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String s2 = simpleDateFormat.format(DateUtil.beginOfDay(c.getTime()));
        return s2;
    }


    /**
     * 获取下个月的日期
     *
     * @return
     */
    public String datetimemill() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 1);
        DateFormat s = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        DateTime dateTime = DateUtil.beginOfMonth(calendar.getTime());
        return s.format(dateTime);
    }

    /**
     * 电费年月
     *
     * @return
     */
    public String amt_ym() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.MONTH, 1);//下个月的时间戳
        DateFormat s = new SimpleDateFormat("yyyy-MM");
        DateTime dateTime = DateUtil.beginOfMonth(calendar.getTime());
        String ss = s.format(dateTime);
        String[] s2 = ss.split("-");//"-"分隔符
        String s3 = "";
        for (String s4 : s2) {
            s3 += s4;
        }//例如：202206，202207
        return s3;
    }

}
