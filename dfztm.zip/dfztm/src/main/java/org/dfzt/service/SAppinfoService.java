package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.SAppinfo;

/**
 * @author 李木
 * @description 针对表【s_appinfo】的数据库操作Service
 * @createDate 2023-05-29 11:32:55
 */
public interface SAppinfoService extends IService<SAppinfo> {

}
