package org.dfzt.entity.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/6
 * @Version: 1.00
 */
@Data
public class AcStationSp implements Serializable {
    private String stationName;
    private String toPoint;
    private String dataDate;
}
