package org.dfzt.util;

import org.dfzt.entity.po.LinelossPower;
import org.dfzt.entity.po.MeterCurrent;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/27
 * @Version: 1.00
 */
public class TwenfourPointUtil {
    public static int getMaxPoint(MeterCurrent mcvA, MeterCurrent mcvB, MeterCurrent mcvC) {
        BigDecimal a=new BigDecimal("0.1");//10%转换为Decimal

        if(
                getMaxMin(mcvA.getI1(),mcvB.getI1(),mcvC.getI1()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI2(),mcvB.getI2(),mcvC.getI2()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI3(),mcvB.getI3(),mcvC.getI3()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI4(),mcvB.getI4(),mcvC.getI4()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI5(),mcvB.getI5(),mcvC.getI5()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI6(),mcvB.getI6(),mcvC.getI6()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI7(),mcvB.getI7(),mcvC.getI7()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI8(),mcvB.getI8(),mcvC.getI8()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI9(),mcvB.getI9(),mcvC.getI9()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI10(),mcvB.getI10(),mcvC.getI10()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI11(),mcvB.getI11(),mcvC.getI11()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI12(),mcvB.getI12(),mcvC.getI12()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI13(),mcvB.getI13(),mcvC.getI13()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI14(),mcvB.getI14(),mcvC.getI14()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI15(),mcvB.getI15(),mcvC.getI15()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI16(),mcvB.getI16(),mcvC.getI16()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI17(),mcvB.getI17(),mcvC.getI17()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI18(),mcvB.getI18(),mcvC.getI18()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI19(),mcvB.getI19(),mcvC.getI19()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI20(),mcvB.getI20(),mcvC.getI20()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI21(),mcvB.getI21(),mcvC.getI21()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI22(),mcvB.getI22(),mcvC.getI22()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI23(),mcvB.getI23(),mcvC.getI23()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI24(),mcvB.getI24(),mcvC.getI24()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI25(),mcvB.getI25(),mcvC.getI25()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI26(),mcvB.getI26(),mcvC.getI26()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI27(),mcvB.getI27(),mcvC.getI27()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI28(),mcvB.getI28(),mcvC.getI28()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI29(),mcvB.getI29(),mcvC.getI29()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI30(),mcvB.getI30(),mcvC.getI30()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI31(),mcvB.getI31(),mcvC.getI31()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI32(),mcvB.getI32(),mcvC.getI32()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI33(),mcvB.getI33(),mcvC.getI33()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI34(),mcvB.getI34(),mcvC.getI34()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI35(),mcvB.getI35(),mcvC.getI35()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI36(),mcvB.getI36(),mcvC.getI36()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI37(),mcvB.getI37(),mcvC.getI37()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI38(),mcvB.getI38(),mcvC.getI38()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI39(),mcvB.getI39(),mcvC.getI39()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI40(),mcvB.getI40(),mcvC.getI40()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI41(),mcvB.getI41(),mcvC.getI41()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI42(),mcvB.getI42(),mcvC.getI42()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI43(),mcvB.getI43(),mcvC.getI43()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI44(),mcvB.getI44(),mcvC.getI44()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI45(),mcvB.getI45(),mcvC.getI45()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI46(),mcvB.getI46(),mcvC.getI46()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI47(),mcvB.getI47(),mcvC.getI47()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI48(),mcvB.getI48(),mcvC.getI48()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI49(),mcvB.getI49(),mcvC.getI49()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI50(),mcvB.getI50(),mcvC.getI50()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI51(),mcvB.getI51(),mcvC.getI51()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI52(),mcvB.getI52(),mcvC.getI52()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI53(),mcvB.getI53(),mcvC.getI53()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI54(),mcvB.getI54(),mcvC.getI54()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI55(),mcvB.getI55(),mcvC.getI55()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI56(),mcvB.getI56(),mcvC.getI56()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI57(),mcvB.getI57(),mcvC.getI57()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI58(),mcvB.getI58(),mcvC.getI58()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI59(),mcvB.getI59(),mcvC.getI59()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI60(),mcvB.getI60(),mcvC.getI60()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI61(),mcvB.getI61(),mcvC.getI61()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI62(),mcvB.getI62(),mcvC.getI62()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI63(),mcvB.getI63(),mcvC.getI63()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI64(),mcvB.getI64(),mcvC.getI64()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI65(),mcvB.getI65(),mcvC.getI65()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI66(),mcvB.getI66(),mcvC.getI66()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI67(),mcvB.getI67(),mcvC.getI67()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI68(),mcvB.getI68(),mcvC.getI68()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI69(),mcvB.getI69(),mcvC.getI69()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI70(),mcvB.getI70(),mcvC.getI70()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI71(),mcvB.getI71(),mcvC.getI71()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI72(),mcvB.getI72(),mcvC.getI72()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI73(),mcvB.getI73(),mcvC.getI73()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI74(),mcvB.getI74(),mcvC.getI74()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI75(),mcvB.getI75(),mcvC.getI75()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI76(),mcvB.getI76(),mcvC.getI76()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI77(),mcvB.getI77(),mcvC.getI77()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI78(),mcvB.getI78(),mcvC.getI78()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI79(),mcvB.getI79(),mcvC.getI79()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI80(),mcvB.getI80(),mcvC.getI80()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI81(),mcvB.getI81(),mcvC.getI81()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI82(),mcvB.getI82(),mcvC.getI82()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI83(),mcvB.getI83(),mcvC.getI83()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI84(),mcvB.getI84(),mcvC.getI84()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI85(),mcvB.getI85(),mcvC.getI85()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI86(),mcvB.getI86(),mcvC.getI86()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI87(),mcvB.getI87(),mcvC.getI87()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI88(),mcvB.getI88(),mcvC.getI88()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI89(),mcvB.getI89(),mcvC.getI89()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI90(),mcvB.getI90(),mcvC.getI90()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI91(),mcvB.getI91(),mcvC.getI91()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI92(),mcvB.getI92(),mcvC.getI92()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI93(),mcvB.getI93(),mcvC.getI93()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI94(),mcvB.getI94(),mcvC.getI94()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI95(),mcvB.getI95(),mcvC.getI95()).compareTo(a)==1 ||
                        getMaxMin(mcvA.getI96(),mcvB.getI96(),mcvC.getI96()).compareTo(a)==1){
            return 1;
        }

        return 0;

    }

    //TODO 获取三个数的差值
    public static BigDecimal getMaxMin(BigDecimal A,BigDecimal B,BigDecimal C){
        if(A.compareTo(B)==1){//A>B
            if(B.compareTo(C)==1){//B>C
                return A.subtract(C);
            }else{//C>B
                if(A.compareTo(C)==1){//A>C
                    return A.subtract(B);
                }else {//C>A
                    return C.subtract(B);
                }
            }
        }else {//B>A
            if(B.compareTo(C)==1){//B>C
                if(A.compareTo(C)==1){//A>C
                    return B.subtract(C);
                }else {//A<C
                    return B.subtract(A);
                }
            }else {//B<C
                return C.subtract(A);
            }
        }
    }

    public static BigDecimal getMaxPower(LinelossPower linePower) {
        List<BigDecimal> list = new ArrayList();
        list.add(linePower.getP1());
        list.add(linePower.getP2());
        list.add(linePower.getP3());
        list.add(linePower.getP4());
        list.add(linePower.getP5());
        list.add(linePower.getP6());
        list.add(linePower.getP7());
        list.add(linePower.getP8());
        list.add(linePower.getP9());
        list.add(linePower.getP10());
        list.add(linePower.getP11());
        list.add(linePower.getP12());
        list.add(linePower.getP13());
        list.add(linePower.getP14());
        list.add(linePower.getP15());
        list.add(linePower.getP16());
        list.add(linePower.getP17());
        list.add(linePower.getP18());
        list.add(linePower.getP19());
        list.add(linePower.getP20());
        list.add(linePower.getP21());
        list.add(linePower.getP22());
        list.add(linePower.getP23());
        list.add(linePower.getP24());
        list.add(linePower.getP25());
        list.add(linePower.getP26());
        list.add(linePower.getP27());
        list.add(linePower.getP28());
        list.add(linePower.getP29());
        list.add(linePower.getP30());
        list.add(linePower.getP31());
        list.add(linePower.getP32());
        list.add(linePower.getP33());
        list.add(linePower.getP34());
        list.add(linePower.getP35());
        list.add(linePower.getP36());
        list.add(linePower.getP37());
        list.add(linePower.getP38());
        list.add(linePower.getP39());
        list.add(linePower.getP40());
        list.add(linePower.getP41());
        list.add(linePower.getP42());
        list.add(linePower.getP43());
        list.add(linePower.getP44());
        list.add(linePower.getP45());
        list.add(linePower.getP46());
        list.add(linePower.getP47());
        list.add(linePower.getP48());
        list.add(linePower.getP49());
        list.add(linePower.getP50());
        list.add(linePower.getP51());
        list.add(linePower.getP52());
        list.add(linePower.getP53());
        list.add(linePower.getP54());
        list.add(linePower.getP55());
        list.add(linePower.getP56());
        list.add(linePower.getP57());
        list.add(linePower.getP58());
        list.add(linePower.getP59());
        list.add(linePower.getP60());
        list.add(linePower.getP61());
        list.add(linePower.getP62());
        list.add(linePower.getP63());
        list.add(linePower.getP64());
        list.add(linePower.getP65());
        list.add(linePower.getP66());
        list.add(linePower.getP67());
        list.add(linePower.getP68());
        list.add(linePower.getP69());
        list.add(linePower.getP70());
        list.add(linePower.getP71());
        list.add(linePower.getP72());
        list.add(linePower.getP73());
        list.add(linePower.getP74());
        list.add(linePower.getP75());
        list.add(linePower.getP76());
        list.add(linePower.getP77());
        list.add(linePower.getP78());
        list.add(linePower.getP79());
        list.add(linePower.getP80());
        list.add(linePower.getP81());
        list.add(linePower.getP82());
        list.add(linePower.getP83());
        list.add(linePower.getP84());
        list.add(linePower.getP85());
        list.add(linePower.getP86());
        list.add(linePower.getP87());
        list.add(linePower.getP88());
        list.add(linePower.getP89());
        list.add(linePower.getP90());
        list.add(linePower.getP91());
        list.add(linePower.getP92());
        list.add(linePower.getP93());
        list.add(linePower.getP94());
        list.add(linePower.getP95());
        list.add(linePower.getP96());
        BigDecimal max = Collections.max(list);
        return max;
    }


    //获取累计电量之和
    public static BigDecimal getAddPower(LinelossPower l) {
        return l.getP1().add(l.getP2()).add(l.getP3()).add(l.getP4()).
                add(l.getP5()).add(l.getP6()).add(l.getP7()).add(l.getP8()).
                add(l.getP9()).add(l.getP10()).add(l.getP11()).add(l.getP12()).
                add(l.getP13()).add(l.getP14()).add(l.getP15()).add(l.getP16()).
                add(l.getP17()).add(l.getP18()).add(l.getP19()).add(l.getP20()).
                add(l.getP21()).add(l.getP22()).add(l.getP23()).add(l.getP24()).
                add(l.getP25()).add(l.getP26()).add(l.getP27()).add(l.getP28()).
                add(l.getP29()).add(l.getP30()).add(l.getP31()).add(l.getP32()).
                add(l.getP33()).add(l.getP34()).add(l.getP35()).add(l.getP36()).
                add(l.getP37()).add(l.getP38()).add(l.getP39()).add(l.getP40()).
                add(l.getP41()).add(l.getP42()).add(l.getP43()).add(l.getP44()).
                add(l.getP45()).add(l.getP46()).add(l.getP47()).add(l.getP48()).
                add(l.getP49()).add(l.getP50()).add(l.getP51()).add(l.getP52()).
                add(l.getP53()).add(l.getP54()).add(l.getP55()).add(l.getP56()).
                add(l.getP57()).add(l.getP58()).add(l.getP59()).add(l.getP60()).
                add(l.getP61()).add(l.getP62()).add(l.getP63()).add(l.getP64()).
                add(l.getP65()).add(l.getP66()).add(l.getP67()).add(l.getP68()).
                add(l.getP69()).add(l.getP70()).add(l.getP71()).add(l.getP72()).
                add(l.getP73()).add(l.getP74()).add(l.getP75()).add(l.getP76()).
                add(l.getP77()).add(l.getP78()).add(l.getP79()).add(l.getP80()).
                add(l.getP81()).add(l.getP82()).add(l.getP83()).add(l.getP84()).
                add(l.getP85()).add(l.getP86()).add(l.getP87()).add(l.getP88()).
                add(l.getP89()).add(l.getP90()).add(l.getP91()).add(l.getP92()).
                add(l.getP93()).add(l.getP94()).add(l.getP95()).add(l.getP96());

    }
}
