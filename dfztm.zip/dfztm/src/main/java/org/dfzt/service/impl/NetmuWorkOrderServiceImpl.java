package org.dfzt.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.NetmuWorkOrder;
import org.dfzt.service.NetmuWorkOrderService;
import org.dfzt.mapper.NetmuWorkOrderMapper;
import org.springframework.stereotype.Service;

/**
* @author 李木
* @description 针对表【netmu_work_order】的数据库操作Service实现
* @createDate 2023-05-29 14:22:28
*/
@Service
public class NetmuWorkOrderServiceImpl extends ServiceImpl<NetmuWorkOrderMapper, NetmuWorkOrder>
    implements NetmuWorkOrderService{



    @Override
    public int updateNetmuWorkOrder(NetmuWorkOrder netmuWorkOrder) {

        return baseMapper.updateNetmuWorkOrder(netmuWorkOrder);
    }
}




