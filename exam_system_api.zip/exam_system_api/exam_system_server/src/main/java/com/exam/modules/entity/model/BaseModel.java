package com.exam.modules.entity.model;

import lombok.Data;


@Data
public class BaseModel {
	//知识分类
	private String knowGory;
	//开始分数
	private Integer beginScore;
	//结束得分
	private Integer endScore;

}
