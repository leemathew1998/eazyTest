package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/5/22
 * @Version: 1.00
 */
@Data
public class TdTgManager implements Serializable {
    private String userName;
    private String readName;
}
