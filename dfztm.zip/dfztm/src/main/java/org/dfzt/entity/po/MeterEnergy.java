package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/20
 * @Version: 1.00 日冻结电能示值
 */
@Data
public class MeterEnergy {
    private Integer id;
    //上级供电单位
    private String upOrgName;
    //供电单位
    private String orgName;
    //用户编码
    private String consNo;
    //用户名称
    private String consName;
    //异常数据
    private String exceptData;
    //电能表资产号
    private String meterAssetNo;
    //电能表厂家
    private String metManufacturer;
    //终端厂家
    private String factoryCode;
    //接线方式
    private String wiringMode;
    //台区编号
    private String tgNo;
    //台区名称
    private String tgName;
    //综合倍率
    private Integer tFactor;
    //正向有功总
    private BigDecimal papE;
    //尖
    private BigDecimal rateOne;
    //峰
    private BigDecimal rateTwo;
    //平
    private BigDecimal rateThree;
    //谷
    private BigDecimal rateFour;
    //反向无功总
    private BigDecimal rrpE;
    //正向无功总
    private BigDecimal prpE;
    //反向有功总
    private BigDecimal rapE;
    //一象限无功
    private BigDecimal rp1R;
    //二象限无功
    private BigDecimal rp2R;
    //三象限无功
    private BigDecimal rp3R;
    //四象限无功
    private BigDecimal rp4R;
    //用电地址
    private String elecAddr;
    //终端地址
    private String terminalAddr;
    //上送时间
    private Date recTime;
    //终端抄表时间
    private Date statDate;
    //测量点号
    private Integer mpSn;
    //抄表段编号
    private Integer mrSectNo;
    //终端资产号
    private String tmnlAssetNo;
    //抄表员信息
    private String readerName;

    private String synchro;

    private String synchroDep;

    private Date synchroTime;

    private String synchroMode;
    //用户类型
    private String userType;
    //创建时间
    private Date createTime;
    //台区经理
    private String tgManager;
    //手机号
    private String mobile;
    //采集标识1采集失败2采集异常3采集未接入
    private String colSign;
    //条形码号
    private String elecmeterCode;
}
