package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.CElecAddr;

import java.math.BigDecimal;
import java.util.List;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface CElecAddrMapper extends BaseMapper<CElecAddr> {

    @DS("mpg")
    List<CElecAddr> selectCElecAddr(String orgNo);

    Integer insertCElecAddr(CElecAddr cElecAddr);

    Integer selectByconsId(BigDecimal consId);
}