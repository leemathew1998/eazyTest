package org.dfzt.entity.vo;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/6
 * @Version: 1.00 曲线图展示VO
 */
@Data
public class AcManagerSp implements Serializable {
    private String tgManager;
    private String dataDate;
    private String totalScore;
}
