package org.dfzt.controller;

import com.baomidou.mybatisplus.extension.api.R;
import io.swagger.annotations.ApiOperation;
import org.dfzt.entity.po.*;
import org.dfzt.mapper.CConsMapper;
import org.dfzt.service.OStaffService;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author: liuxihu
 * @Date: 2022/11/2 13:59
 */

@RestController
@RequestMapping("oStaff")
//@Transactional
public class OStaffController {
    @Resource
    private CConsMapper cConsMapper;
    @Resource
    private OStaffService oStaffService;

    @PostMapping("selectMess")
    public List<CCons> selectMess1(String one){
//        Page<CCons> page = new Page<>(pageNo,pageSize);
        //Page<CCons> cConsPage = cConsMapper.selectUserAll(page,one);
        List<CCons> cConsPage = cConsMapper.selectUserAll(one);
        return cConsPage;
    }

    @PostMapping("selectCcon")
    public List<OStaff> selectCcon1(String empOn){
        List<OStaff> oStaff = cConsMapper.selectCcon(empOn);
        return oStaff;
    }

    @PostMapping("selectElec")
    public List<ElectricityPrice> selectElec1(String consNo){
        List<ElectricityPrice> elecs = cConsMapper.selectElec(consNo);
        return elecs;
    }

    @PostMapping("selectInfor")
    public List<CInformation> selectInfor(String consNo){
        List<CInformation> cInfors = cConsMapper.selectInfor(consNo);
        return cInfors;
    }

    @PostMapping(value = "/selectMessage")
    @ApiOperation(value = "APP端的用户档案模糊查询",notes = "查询信息-全量查询--分页")
    public R selectMessage(@RequestParam(required = false) String  message,
                           @RequestParam(defaultValue = "1")  Long pageNo,
                           @RequestParam(defaultValue = "10")  Long pageSize){
        return oStaffService.selectMessage(message, pageNo, pageSize);


    }
}
