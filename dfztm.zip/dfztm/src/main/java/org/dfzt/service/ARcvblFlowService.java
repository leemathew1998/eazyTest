package org.dfzt.service;

import org.dfzt.entity.po.ARcvblFlow;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface ARcvblFlowService extends IService<ARcvblFlow>{


}
