package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import nonapi.io.github.classgraph.json.Id;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@ApiModel(value="o_org")
@Data
@TableName(value = "o_org")
public class OOrg {

    private Integer id;

    /**
     * 唯一标识，创建供电单位的唯一编码
     */
    @TableId(value = "org_no", type = IdType.INPUT)
    @ApiModelProperty(value="唯一标识，创建供电单位的唯一编码")
    private String orgNo;

    /**
     * 供电单位详细的名称
     */
    @TableField(value = "org_name")
    @ApiModelProperty(value="供电单位详细的名称")
    private String orgName;

    /**
     * 直接上级供电单位编号
     */
    @TableField(value = "p_org_no")
    @ApiModelProperty(value="直接上级供电单位编号")
    private String pOrgNo;

    /**
     * 单位类别：01 国网公司、02 省公司、03 地市公司 、04 区县公司、05 分公司、06 供电所
     */
    @TableField(value = "org_type")
    @ApiModelProperty(value="单位类别：01 国网公司、02 省公司、03 地市公司 、04 区县公司、05 分公司、06 供电所")
    private String orgType;

    /**
     * 在同级中的排列顺序的序号，用自然数标识，如，1、2、3。
     */
    @TableField(value = "sort_no")
    @ApiModelProperty(value="在同级中的排列顺序的序号，用自然数标识，如，1、2、3。")
    private Integer sortNo;

    /**
     * 类型
     */
    @TableField(value = "org_shorthand")
    @ApiModelProperty(value="类型")
    private String orgShorthand;
}