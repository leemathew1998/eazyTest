package org.dfzt.entity.po;

import com.google.common.collect.Lists;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.apache.cxf.service.model.BindingInfo;
import org.apache.cxf.service.model.BindingOperationInfo;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.dfzt.entity.xmlDemoReal.*;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.util.TimeUtil;
import org.dfzt.util.XStreamUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.Document;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @ClassName WebService
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/8 13:28
 */

public class WebServiceDemo {

    @Resource
    CollectWorkOrderMapper collectWorkOrderMapper;

//    @Value("${param.url}")
//    private
    String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";


    /*@GetMapping(value = "/service",produces = "application/json;charset=utf-8")*/
    public List<General> testSend1(String sendXml)  {
        /*创建动态客户端*/
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        /*创建本地客户端连接*/
        Client client = dcf.createClient(wsdlUrl);
        /*初始化反参集合*/
        List<General> list = Lists.newArrayList();
        try {
             /*调用服务端接口方法*/
             Object[]  objects = client.invoke("getInfoBad", sendXml);
             /*接收服务端返参*/
             String  receiveXml = (String) objects[0];
             /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
             Demo1 demo1 = XStreamUtils.xmlToObject(receiveXml, Demo1.class, new DemoConverter());
             /*获取解析之后的General对象*/
             List<General> demo2 = demo1.getDemo2().getGeneral();
//             List<General> demo3 = demo1.getDemo3().getGeneral();
//             /*通过Java8新特性-stream流转换解析之后General的返回格式*/
//             list = Stream.of(demo2,demo3)
//                     .flatMap(Collection::stream)
//                     .collect(Collectors.toList());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
//
//    @Scheduled(cron = "0 * 08 * * ? *")
//    public void onTimeDoc(){
//
//     //   业务逻辑 形成一个入参xml
//        String xml ="";
//        testSend1(xml);
//    }


    /**
     * 抄表失败明细清单 （1）抽取规则：每天8：00（每月1号不生成采集工单）
     * @throws Exception
     */
    public List<General> testSendCollFail(String sendXml,String funName,Client client){
        List<General> list = Lists.newArrayList();
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), funName);
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if (funName.equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            /*调用服务端接口方法*/
            //Object[]  objects = client.invoke(funName, sendXml);
            Object[] objects = client.invoke(opName, sendXml);
//            String s = objects[0].toString();
//            System.out.println("返回的数据"+s);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
//            Document doc = (Document) objects[0];
//            String resultxml = doc.getFirstChild().getFirstChild().getNodeValue();
            System.out.println("获取返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
               // if (!demo1.equals(null)) {
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
//                    List<General> demo3 = demo1.getDemo3().getGeneral();
//                    /*通过Java8新特性-stream流转换解析之后General的返回格式*/
//                    list = Stream.of(demo2, demo3)
//                            .flatMap(Collection::stream)
//                            .collect(Collectors.toList());
                //}
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }



    public List<List<General>> testSendCollFails(String sendXml,String funName){
        System.out.println("webservice执行");
        /*创建动态客户端*/
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        /*创建本地客户端连接*/
        System.out.println("获取客户端连接前");
        Client client = dcf.createClient(wsdlUrl);
        System.out.println("获取客户端连接后");
        //List<General> list = Lists.newArrayList();
        List<List<General>> lists = Lists.newArrayList();
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), funName);
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if (funName.equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            /*调用服务端接口方法*/
            //Object[]  objects = client.invoke(funName, sendXml);
            Object[] objects = client.invoke(opName, sendXml);
//            String s = objects[0].toString();
//            System.out.println("返回的数据"+s);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
//            Document doc = (Document) objects[0];
//            String resultxml = doc.getFirstChild().getFirstChild().getNodeValue();
            System.out.println("获取返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1s demo1s = XStreamUtils.xmlToObject(resultxml, Demo1s.class, new DemoConverter());
                // if (!demo1.equals(null)) {
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1s.getDemo2().getGeneral();
                List<List<General>> demo4s = demo1s.getDemo4().getGeneral();
                for (List<General> demo40 : demo4s) {
                    lists.add(Stream.of(demo2, demo40)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList()));
                }
//                List<General> demo41 = demo1s.getDemo4().getGeneral1();
//                List<General> demo42 = demo1s.getDemo4().getGeneral2();
                /*通过Java8新特性-stream流转换解析之后General的返回格式*/
//                list = Stream.of(demo2, demo41)
//                        .flatMap(Collection::stream)
//                        .collect(Collectors.toList());
                //}


//                lists.add(Stream.of(demo2, demo41)
//                        .flatMap(Collection::stream)
//                        .collect(Collectors.toList()));
//                lists.add(Stream.of(demo2, demo42)
//                        .flatMap(Collection::stream)
//                        .collect(Collectors.toList()));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return lists;
    }


//    /**
//     * 采集未接入明细清单
//     * @throws Exception
//     */
//    public void testSendCollncon(String sendXml,String funName) throws Exception {
//        /*创建动态客户端*/
//        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
//        /*创建本地客户端连接*/
//        Client client = dcf.createClient("http://localhost:8083/webservice/test?wsdl");
//        /*初始化反参集合*/
//        List<General> list = Lists.newArrayList();
//        try {
//            /*调用服务端接口方法*/
//            Object[]  objects = client.invoke(funName, sendXml);
//            /*接收服务端返参*/
//            String  receiveXml = (String) objects[0];
//            /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
//            Demo1 demo1 = XStreamUtils.xmlToObject(receiveXml, Demo1.class, new DemoConverter());
//            /*获取解析之后的General对象*/
//            List<General> demo2 = demo1.getDemo2().getGeneral();
//            List<General> demo3 = demo1.getDemo3().getGeneral();
//            /*通过Java8新特性-stream流转换解析之后General的返回格式*/
//            list = Stream.of(demo2,demo3)
//                    .flatMap(Collection::stream)
//                    .collect(Collectors.toList());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return list;
//    }


    /**
     * 抄表明细（含异常数据）
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendCollInfo(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String tgId="";
            String consType="";
            String mrExce="";
            objects = client.invoke("getCollInfo",TimeUtil.getTodayTime(),tgId,consType,mrExce);
            writer.println(Arrays.toString(objects));
            System.err.println("抄表明细（含异常数据）:" + objects[0]);
            collectWorkOrderMapper.insertCollinfo(null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 日冻结电能示值
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendDayEnergy(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String tgId="";
            String consType="";
            String mrExce="";
            objects = client.invoke("getDayEnergy",TimeUtil.getTodayTime(),tgId,consType,mrExce);
            writer.println(Arrays.toString(objects));
            System.err.println("日冻结电能示值:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 日冻结电压曲线
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendDayVol(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String massetNo = "";
            objects = client.invoke("getDayVol",TimeUtil.getTodayTime(),massetNo);
            writer.println(Arrays.toString(objects));
            System.err.println("日冻结电压曲线:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 日冻结电压曲线
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendDayCurr(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String massetNo = "";
            objects = client.invoke("getDayCurr",TimeUtil.getTodayTime(),massetNo);
            writer.println(Arrays.toString(objects));
            System.err.println("日冻结电流曲线:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 日冻结电压曲线
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendDayPower(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String massetNo = "";
            objects = client.invoke("getDayPower",TimeUtil.getTodayTime(),massetNo);
            writer.println(Arrays.toString(objects));
            System.err.println("日冻结功率曲线:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 示值曲线
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendDayIndi(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String massetNo = "";
            objects = client.invoke("getDayIndi",TimeUtil.getTodayTime(),massetNo);
            writer.println(Arrays.toString(objects));
            System.err.println("示值曲线:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 运行情况监测
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendRunsur(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String teraddr = "";
            objects = client.invoke("getDayIndi",TimeUtil.getTodayTime(),teraddr);
            writer.println(Arrays.toString(objects));
            System.err.println("运行情况监测:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 台区考核单元明细
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendTgexam(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String tgno = "";
            objects = client.invoke("getDayIndi",TimeUtil.getTodayTime(),tgno);
            writer.println(Arrays.toString(objects));
            System.err.println("台区考核单元明细:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 供电量明细表
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendTgppq(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String tgno = "";
            objects = client.invoke("getTgppq",tgno,TimeUtil.getTodayTime());
            writer.println(Arrays.toString(objects));
            System.err.println("供电量明细表:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 售电量明细表
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendTgspq(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String tgno = "";
            objects = client.invoke("getTgspq",tgno,TimeUtil.getTodayTime());
            writer.println(Arrays.toString(objects));
            System.err.println("售电量明细表:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 低压远程费控执行
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendFee(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String appNo="";
            String tgno = "";
            String teraddr ="";
            String conType="";
            objects = client.invoke("getFee",appNo,TimeUtil.getTodayTime(),TimeUtil.getTomDay(),tgno,teraddr,conType);
            writer.println(Arrays.toString(objects));
            System.err.println("低压远程费控执行:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 电能表相位信息
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendPhaseFlag(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);

            String tgno = "";
            objects = client.invoke("getPhaseFlag",tgno,TimeUtil.getTodayTime());
            writer.println(Arrays.toString(objects));
            System.err.println("电能表相位信息:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 电能表正向有功总，单次透抄，可通过查询终端实时数据实现
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendPap(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);

            String teraddr = "";
            String massetNo="";
            objects = client.invoke("getPap",TimeUtil.getTodayTime(),teraddr,massetNo);
            writer.println(Arrays.toString(objects));
            System.err.println("电能表正向有功总，单次透抄:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 费控开关状态，单次透抄
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendFeeswitch(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);

            String massetNo="";
            objects = client.invoke("getFeeswitch",massetNo);
            writer.println(Arrays.toString(objects));
            System.err.println("费控开关状态，单次透抄:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 电能表相位角，单次透抄
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendPhaseflag(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);

            String commaddr="";
            objects = client.invoke("getPhaseflag",commaddr);
            writer.println(Arrays.toString(objects));
            System.err.println("电能表相位角，单次透抄:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 配网感知工单
     * @param mobileCode
     * @param userID
     * @param response
     * @throws Exception
     */
    public void testSendDisper(String mobileCode, String userID,HttpServletResponse response) throws Exception {
        // 创建动态客户端
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        Client client =
                dcf.createClient(wsdlUrl);
        Object[] objects;
        PrintWriter writer = response.getWriter();
        try {
            // invoke("方法名",参数1,参数2,参数3....);
            String orgName="";
            String status="";
            String stopTime="";
            String LineId="";
            String LineName="";
            String appNo="";

            objects = client.invoke("getPhaseflag",orgName,status,stopTime,LineId,LineName,appNo);
            writer.println(Arrays.toString(objects));
            System.err.println("配网感知工单:" + objects[0]);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
