package com.exam.modules.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import com.exam.modules.entity.ExamT;

/**
 * (ExamT)表数据库访问层
 *
 * @author makejava
 * @since 2022-11-08 09:58:14
 */
public interface ExamTMapper extends BaseMapper<ExamT> {



}


