package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/24
 * @Version: 1.00
 */
@Data
public class OrgNameNums implements Serializable {
    private String id;
    private String orgNo;//工单单位编号
    private String orgName;//供电所名称
    private Integer collFailNum;//采集失败数
    private Integer collSuccNum;//采集成功数
    private Integer collAllNum;//采集总数
    private String ymd;
    private String pOrgNo;//上级供电单位编号
}
