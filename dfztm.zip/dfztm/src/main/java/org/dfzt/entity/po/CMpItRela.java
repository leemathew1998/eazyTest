package org.dfzt.entity.po;


import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;

/**
 * (CMpItRela)表实体类
 *
 * @author makejava
 * @since 2022-07-29 16:07:31
 */
@SuppressWarnings("serial")
@TableName("c_mp_it_rela")
@Data
public class CMpItRela extends Model<CMpItRela> {

    private Integer id;
    //关系分类
    private String relationType;
    //计量点
    private String mpName;
    //计量点编号
    private String mpNo;
    //用电客户
    private String consName;
    //关系比例值
    private Double relationTsg;
    //用户编号
    private String consNo;
    //相关计量点计量方向
    private String mpDirectionCode;
}
