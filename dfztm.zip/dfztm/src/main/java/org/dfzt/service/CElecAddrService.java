package org.dfzt.service;

import org.dfzt.entity.po.CElecAddr;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface CElecAddrService extends IService<CElecAddr>{


}
