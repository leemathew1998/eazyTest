package org.dfzt.eunm;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;
import lombok.Getter;


/**
 * @ClassName MarketTypeEnum
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/7/11 13:59
 */
@Getter
public enum MarketTypeEnum {
    //0101市场化直购用户、0102市场化零售客户、0103部分市场化零售客户、0201非市场化客户、0202放弃选择权的客户，空值认为是非市场化用户。
    MARKET_TYPE_ENUM_FIRST("65","市场化直购用户"),
    MARKET_TYPE_ENUM_SECOND("66","市场化零售客户"),
    MARKET_TYPE_ENUM_THIRD("67","部分市场化零售客户"),
    MARKET_TYPE_ENUM_FOURTH("129","非市场化客户"),
    MARKET_TYPE_ENUM_FIFTH("",null),
    MARKET_TYPE_ENUM_SEX("02","非市场化用户")
    ;

    @EnumValue
    private String code;
    @JsonValue
    private String message;

    MarketTypeEnum(String code, String message) {
        this.code = code;
        this.message = message;
    }
}
