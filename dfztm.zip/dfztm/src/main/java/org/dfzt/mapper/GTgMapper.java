package org.dfzt.mapper;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.po.GTg;
import org.dfzt.entity.vo.ConsTgVo;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Mapper
@Transactional
public interface GTgMapper extends BaseMapper<GTg> {

    @DS("mpg")
    List<GTg> selectTg();//查询台区信息

    Integer insertGTg(GTg gTg);//向华为云中的数据库插入台区信息

    Integer selectBytgid(BigDecimal tgId);//查询台区信息中是否存在重复的信息

    @DS("mpg")
    List<ConsTgVo> selectCourts(@Param("list") List<String> consNos);
}
