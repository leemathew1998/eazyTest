package org.dfzt.config;

import org.apache.commons.lang3.StringUtils;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.annotation.CurrentUser;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.util.ServiceException;
import org.dfzt.util.ServiceExceptionEnum;
import org.dfzt.util.jwt.JwtUtil;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;


/**
 * @ClassName CurrentUserMethodArgumentResolver
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/8/10 18:05
 */
//@Component
public class CurrentUserMethodArgumentResolver implements HandlerMethodArgumentResolver {

    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        //判断是否支持使用@CurrentUser注解的参数;如果该参数注解有@CurrentUser且参数类型是Usor.
        return parameter.getParameterType().isAssignableFrom(SysUser.class) && parameter.hasParameterAnnotation(CurrentUser.class);
    }
    @Override
    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
                                  NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {

        String token = webRequest.getHeader("Authorization");
        if (StringUtils.isBlank(token)) {
            throw new ServiceException(ServiceExceptionEnum.LOGIN_INVALID);

        } else {
            SysUser sysUser = JwtUtil.parse(JwtUtil.verify(token));
            if (sysUser==null) {
                throw new ServiceException(ServiceExceptionEnum.LOGIN_DIFFERENT);
            } else {
                return sysUser;
            }
        }
    }
}
