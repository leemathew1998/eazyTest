package org.dfzt.mapper;

import org.dfzt.entity.po.EMpReadCurve;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author dfzt
 * @since 2022-07-11
 */
public interface EMpReadCurveMapper extends BaseMapper<EMpReadCurve> {

}
