package org.dfzt.entity.po;

import java.math.BigDecimal;
import java.util.Date;
import java.io.Serializable;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author dfzt
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value="EMpCurCurve对象", description="")
public class EMpCurCurve implements Serializable {

    private static final long serialVersionUID = 1L;

    @ApiModelProperty(value = "标识")
    private Long id;

    @ApiModelProperty(value = "供电单位编号")
    private String orgNo;

    @ApiModelProperty(value = "数据日期")
    private Date dataDate;

    @ApiModelProperty(value = "CT")
    private Integer ct;

    @ApiModelProperty(value = "标记")
    private Integer mark;

    @ApiModelProperty(value = "相序标志0：功率总/电流零序/ 功率因数总 1：A相 2：B相 3：C相")
    private Integer phaseFlag;

    @ApiModelProperty(value = "数据完整性标志（用96个1或0来表示96点数据的完整性标志（左第一位表示第一点））")
    private String dataWholeFlag;

    @ApiModelProperty(value = "数据点标志  1.96点，2.48点，3.24点")
    private Integer dataPointFlag;

    @ApiModelProperty(value = "电流")
    private BigDecimal l1;

    @ApiModelProperty(value = "电流")
    private BigDecimal l2;

    @ApiModelProperty(value = "电流")
    private BigDecimal l3;

    @ApiModelProperty(value = "电流")
    private BigDecimal l4;

    @ApiModelProperty(value = "电流")
    private BigDecimal l5;

    @ApiModelProperty(value = "电流")
    private BigDecimal l6;

    @ApiModelProperty(value = "电流")
    private BigDecimal l7;

    @ApiModelProperty(value = "电流")
    private BigDecimal l8;

    @ApiModelProperty(value = "电流")
    private BigDecimal l9;

    @ApiModelProperty(value = "电流")
    private BigDecimal l10;

    @ApiModelProperty(value = "电流")
    private BigDecimal l11;

    @ApiModelProperty(value = "电流")
    private BigDecimal l12;

    @ApiModelProperty(value = "电流")
    private BigDecimal l13;

    @ApiModelProperty(value = "电流")
    private BigDecimal l14;

    @ApiModelProperty(value = "电流")
    private BigDecimal l15;

    @ApiModelProperty(value = "电流")
    private BigDecimal l16;

    @ApiModelProperty(value = "电流")
    private BigDecimal l17;

    @ApiModelProperty(value = "电流")
    private BigDecimal l18;

    @ApiModelProperty(value = "电流")
    private BigDecimal l19;

    @ApiModelProperty(value = "电流")
    private BigDecimal l20;

    @ApiModelProperty(value = "电流")
    private BigDecimal l21;

    @ApiModelProperty(value = "电流")
    private BigDecimal l22;

    @ApiModelProperty(value = "电流")
    private BigDecimal l23;

    @ApiModelProperty(value = "电流")
    private BigDecimal l24;

    @ApiModelProperty(value = "电流")
    private BigDecimal l25;

    @ApiModelProperty(value = "电流")
    private BigDecimal l26;

    @ApiModelProperty(value = "电流")
    private BigDecimal l27;

    @ApiModelProperty(value = "电流")
    private BigDecimal l28;

    @ApiModelProperty(value = "电流")
    private BigDecimal l29;

    @ApiModelProperty(value = "电流")
    private BigDecimal l30;

    @ApiModelProperty(value = "电流")
    private BigDecimal l31;

    @ApiModelProperty(value = "电流")
    private BigDecimal l32;

    @ApiModelProperty(value = "电流")
    private BigDecimal l33;

    @ApiModelProperty(value = "电流")
    private BigDecimal l34;

    @ApiModelProperty(value = "电流")
    private BigDecimal l35;

    @ApiModelProperty(value = "电流")
    private BigDecimal l36;

    @ApiModelProperty(value = "电流")
    private BigDecimal l37;

    @ApiModelProperty(value = "电流")
    private BigDecimal l38;

    @ApiModelProperty(value = "电流")
    private BigDecimal l39;

    @ApiModelProperty(value = "电流")
    private BigDecimal l40;

    @ApiModelProperty(value = "电流")
    private BigDecimal l41;

    @ApiModelProperty(value = "电流")
    private BigDecimal l42;

    @ApiModelProperty(value = "电流")
    private BigDecimal l43;

    @ApiModelProperty(value = "电流")
    private BigDecimal l44;

    @ApiModelProperty(value = "电流")
    private BigDecimal l45;

    @ApiModelProperty(value = "电流")
    private BigDecimal l46;

    @ApiModelProperty(value = "电流")
    private BigDecimal l47;

    @ApiModelProperty(value = "电流")
    private BigDecimal l48;

    @ApiModelProperty(value = "电流")
    private BigDecimal l49;

    @ApiModelProperty(value = "电流")
    private BigDecimal l50;

    @ApiModelProperty(value = "电流")
    private BigDecimal l51;

    @ApiModelProperty(value = "电流")
    private BigDecimal l52;

    @ApiModelProperty(value = "电流")
    private BigDecimal l53;

    @ApiModelProperty(value = "电流")
    private BigDecimal l54;

    @ApiModelProperty(value = "电流")
    private BigDecimal l55;

    @ApiModelProperty(value = "电流")
    private BigDecimal l56;

    @ApiModelProperty(value = "电流")
    private BigDecimal l57;

    @ApiModelProperty(value = "电流")
    private BigDecimal l58;

    @ApiModelProperty(value = "电流")
    private BigDecimal l59;

    @ApiModelProperty(value = "电流")
    private BigDecimal l60;

    @ApiModelProperty(value = "电流")
    private BigDecimal l61;

    @ApiModelProperty(value = "电流")
    private BigDecimal l62;

    @ApiModelProperty(value = "电流")
    private BigDecimal l63;

    @ApiModelProperty(value = "电流")
    private BigDecimal l64;

    @ApiModelProperty(value = "电流")
    private BigDecimal l65;

    @ApiModelProperty(value = "电流")
    private BigDecimal l66;

    @ApiModelProperty(value = "电流")
    private BigDecimal l67;

    @ApiModelProperty(value = "电流")
    private BigDecimal l68;

    @ApiModelProperty(value = "电流")
    private BigDecimal l69;

    @ApiModelProperty(value = "电流")
    private BigDecimal l70;

    @ApiModelProperty(value = "电流")
    private BigDecimal l71;

    @ApiModelProperty(value = "电流")
    private BigDecimal l72;

    @ApiModelProperty(value = "电流")
    private BigDecimal l73;

    @ApiModelProperty(value = "电流")
    private BigDecimal l74;

    @ApiModelProperty(value = "电流")
    private BigDecimal l75;

    @ApiModelProperty(value = "电流")
    private BigDecimal l76;

    @ApiModelProperty(value = "电流")
    private BigDecimal l77;

    @ApiModelProperty(value = "电流")
    private BigDecimal l78;

    @ApiModelProperty(value = "电流")
    private BigDecimal l79;

    @ApiModelProperty(value = "电流")
    private BigDecimal l80;

    @ApiModelProperty(value = "电流")
    private BigDecimal l81;

    @ApiModelProperty(value = "电流")
    private BigDecimal l82;

    @ApiModelProperty(value = "电流")
    private BigDecimal l83;

    @ApiModelProperty(value = "电流")
    private BigDecimal l84;

    @ApiModelProperty(value = "电流")
    private BigDecimal l85;

    @ApiModelProperty(value = "电流")
    private BigDecimal l86;

    @ApiModelProperty(value = "电流")
    private BigDecimal l87;

    @ApiModelProperty(value = "电流")
    private BigDecimal l88;

    @ApiModelProperty(value = "电流")
    private BigDecimal l89;

    @ApiModelProperty(value = "电流")
    private BigDecimal l90;

    @ApiModelProperty(value = "电流")
    private BigDecimal l91;

    @ApiModelProperty(value = "电流")
    private BigDecimal l92;

    @ApiModelProperty(value = "电流")
    private BigDecimal l93;

    @ApiModelProperty(value = "电流")
    private BigDecimal l94;

    @ApiModelProperty(value = "电流")
    private BigDecimal l95;

    @ApiModelProperty(value = "电流")
    private BigDecimal l96;

    @ApiModelProperty(value = "记录时间")
    private Date recTime;

    @ApiModelProperty(value = "电表标识")
    private String meterId;

    @ApiModelProperty(value = "数据来源")
    private String dataSrc;

    @ApiModelProperty(value = "是否有效")
    private Integer isValid;


}
