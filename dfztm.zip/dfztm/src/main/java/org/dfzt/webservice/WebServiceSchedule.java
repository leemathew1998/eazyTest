package org.dfzt.webservice;

import cn.hutool.core.util.ObjectUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import io.swagger.models.auth.In;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.apache.cxf.service.model.BindingInfo;
import org.apache.cxf.service.model.BindingOperationInfo;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.dfzt.entity.dto.*;
import org.dfzt.entity.po.*;
import org.dfzt.entity.xmlDemoReal.*;
import org.dfzt.mapper.*;
import org.dfzt.service.CollectInformaService;
import org.dfzt.service.CollectWorkOrderService;
import org.dfzt.service.LinelossWorkOrderService;
import org.dfzt.service.MeterWorkOrderService;
import org.dfzt.util.GetPointUtil;
import org.dfzt.util.TimeUtil;
import org.dfzt.util.XStreamUtils;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import javax.xml.namespace.QName;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/14
 * @Version: 1.00 定时器webservice定时获取数据，并参与入库研判操作
 */
@RestController
@RequestMapping("/webservice")
@Slf4j
@Component
@CrossOrigin
public class WebServiceSchedule {
    @Resource
    AsyncTaskExecutor asyncTaskExecutor;
    @Resource
    private Client wsdlClient;
    @Resource
    CollectWorkOrderMapper collwoMapper;
    @Resource
    CollectWorkOrderService collwoService;
    @Resource
    CollectInformaService collinfoService;
    @Resource
    LinelossWorkOrderMapper linelossWorkOrderMapper;
    @Resource
    LinelossWorkOrderService linelossWorkOrderService;
    @Autowired
    private SqlSessionTemplate sqlSessionTemplate;
    @Resource
    private RepairsWorkOrderMapper repairsWorkOrderMapper;
    @Resource
    ExecuteLogMapper    executeLogMapper;
    @Resource
    ExecuteLogDetailMapper    executeLogDetailMapper;
    @Autowired
    private MeterWorkOrderService meterWorkOrderService;
    @Resource
    private FeecontrolWorkOrderMapper feecontrolWorkOrderMapper;
    /**
     * 级别
     */
    private final static String ONE_GRADE = "1";
    private final static String TWO_GRADE = "2";
    /**
     * 工单状态
     */
    private final static String ONE_STATUS = "1";
    private final static String TWO_STATUS = "2";
    private final static String THREE_STATUS = "3";
    private final static String FOUR_STATUS = "4";



    public static Client getClient(){
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        System.out.println("webservice执行");
        /*创建动态客户端*/
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        /*创建本地客户端连接*/
        System.out.println("获取客户端连接前");
        Client client = dcf.createClient(wsdlUrl);
        System.out.println("获取客户端连接后");
        return client;
    }


    /**
     * 定时获取采集失败相关数据
     */
    @Scheduled(cron = "0 0 6 2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31 * ? ")
    @Async
    @RequestMapping("collfail")
    public void getCollFail() {
        // 开始时间
        long stime = System.currentTimeMillis();
        List<General> generals = Lists.newArrayList();
        //入参mr_date字符串 （2022-12-15）
        String startTime = TimeUtil.getTodayTime();
        //String startTime1 = org.dfzt.util.DateUtil.getBeforeDay();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        /*创建动态客户端*/
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        /*创建本地客户端连接*/
        System.out.println("获取采集失败客户端连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalFailData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisticalFailData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> lists = collwoMapper.selectOrgList();
//            List<String> lists = new ArrayList<>();
//            lists.add("1542121");
//            lists.add("1542122");
//            lists.add("1542110");
            for (String orgNo :lists) {
                ExecuteLog executeLog = new ExecuteLog();
                executeLog.setThread(orgNo);
                executeLogMapper.insert(executeLog);
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"ORG_NO\">" + orgNo + "</C>\n" +
                        "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";
                Object[] objects = client.invoke(opName, sendXml);
                if (objects == null || objects.length == 0) {
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String resultxml = (String) objects[0];
                ExecuteLogDetail executeLogDetail = new ExecuteLogDetail();
                executeLogDetail.setAddress(orgNo);
                executeLogDetail.setXmlVol(resultxml);
                executeLogDetailMapper.insert(executeLogDetail);

                System.out.println("字符串长度:" + resultxml.length()+"获取返回的采集失败xml数据" + resultxml);
                if (resultxml.length() > 155) {
                    List<CollectFailure>  collFails = new ArrayList<>();
                    /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                    for (List<General> demo3 : demo3s) {
                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());
                        System.out.println("generals长度" + generals.size());
                        if (generals.size() != 0) {
                            CollectFailure collFail = new CollectFailure();
                            collFail.setUpOrgName(generals.get(2).getValue());
                            System.out.println("UpOrgName======" + generals.get(2).getValue());
                            collFail.setOrgName(generals.get(3).getValue());
                            collFail.setConsNo(generals.get(4).getValue());
                            collFail.setConsName(generals.get(5).getValue());
                            collFail.setElecAddr(generals.get(6).getValue());
                            collFail.setUserType(generals.get(7).getValue());
                            collFail.setMeterAssetNo(generals.get(8).getValue());
                            collFail.setTgId(generals.get(9).getValue());
                            collFail.setTgName(generals.get(10).getValue());
                            collFail.setTerminalAddr(generals.get(11).getValue());
                            collFail.setTerminalFactory(generals.get(12).getValue());
                            collFail.setTerminalState(generals.get(13).getValue());
                            collFail.setMpSn(Integer.parseInt(generals.get(14).getValue()));
                            collFail.setMrDate(generals.get(15).getValue());
                            collFail.setMeterReader(generals.get(16).getValue());
                            System.out.println("MeterReader======" + generals.get(16).getValue());
                            collFails.add(collFail);
                        }
                    }
                    //SqlSession sqlSession = sqlSessionTemplate.getSqlSessionFactory().openSession(ExecutorType.BATCH, false);//跟上述sql区别
                    //CollectWorkOrderMapper collectwoMapper = sqlSession.getMapper(CollectWorkOrderMapper.class);
                    for (CollectFailure collFail : collFails) {//collwoMapper 69113ms
                        int i = collwoMapper.insertCollfail(collFail);
                        System.out.println("=="+JSONObject.toJSONString(collFail));
                        System.out.println("自增id"+collFail.getId()+"=="+i);
                    }
                    collwoService.insertCollFail(collFails);//生成工单入库
                    //sqlSession.commit();
                }
            }
            } catch (Exception e) {
            e.printStackTrace();
        }
        // 结束时间
        long etime = System.currentTimeMillis();
        System.out.printf("执行时长：%d 毫秒.", (etime - stime));
        System.out.println("采集失败生成完成！");
    }



    /**
     * 定时获取采集失败相关数据
     */
    //@Scheduled(cron = "0 0 5 2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31 * ? ")
    //@Async
    //@RequestMapping("collfail1")
    public void getCollFail1() {
        // 开始时间
        long stime = System.currentTimeMillis();
        List<General> generals = Lists.newArrayList();
        //入参mr_date字符串 （2022-12-15）
        String startTime = TimeUtil.getTodayTime();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        /*创建动态客户端*/
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        /*创建本地客户端连接*/
        System.out.println("获取采集失败客户端连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalFailData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisticalFailData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> lists = collwoMapper.selectOrgList();
//            List<String> lists = new ArrayList<>();
//            lists.add("1542110");
//            lists.add("1542112");
//            lists.add("1542104");
//            lists.add("1542109");
//            lists.add("1542111");
            for (String orgNo :lists) {
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"ORG_NO\">" + orgNo + "</C>\n" +
                        "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";
                Object[] objects = client.invoke(opName, sendXml);
                if (objects == null || objects.length == 0) {
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String resultxml = (String) objects[0];
                System.out.println("字符串长度:" + resultxml.length()+"获取返回的采集失败xml数据" + resultxml);
                if (resultxml.length() > 155) {
                    List<CollectFailure>  collFails = new ArrayList<>();
                    /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                    for (List<General> demo3 : demo3s) {
                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());
                        System.out.println("generals长度" + generals.size());
                        if (generals.size() != 0) {
                            CollectFailure collFail = new CollectFailure();
                            collFail.setUpOrgName(generals.get(2).getValue());
                            System.out.println("UpOrgName======" + generals.get(2).getValue());
                            collFail.setOrgName(generals.get(3).getValue());
                            collFail.setConsNo(generals.get(4).getValue());
                            collFail.setConsName(generals.get(5).getValue());
                            collFail.setElecAddr(generals.get(6).getValue());
                            collFail.setUserType(generals.get(7).getValue());
                            collFail.setMeterAssetNo(generals.get(8).getValue());
                            collFail.setTgId(generals.get(9).getValue());
                            collFail.setTgName(generals.get(10).getValue());
                            collFail.setTerminalAddr(generals.get(11).getValue());
                            collFail.setTerminalFactory(generals.get(12).getValue());
                            collFail.setTerminalState(generals.get(13).getValue());
                            collFail.setMpSn(Integer.parseInt(generals.get(14).getValue()));
                            collFail.setMrDate(generals.get(15).getValue());
                            collFail.setMeterReader(generals.get(16).getValue());
                            System.out.println("MeterReader======" + generals.get(16).getValue());
                            collFails.add(collFail);
                        }
                    }
                    //SqlSession sqlSession = sqlSessionTemplate.getSqlSessionFactory().openSession(ExecutorType.BATCH, false);//跟上述sql区别
                    //CollectWorkOrderMapper collectwoMapper = sqlSession.getMapper(CollectWorkOrderMapper.class);
                    for (CollectFailure collFail : collFails) {//collwoMapper 69113ms
                        int i = collwoMapper.insertCollfail(collFail);
                        System.out.println("=="+JSONObject.toJSONString(collFail));
                        System.out.println("自增id"+collFail.getId()+"=="+i);
                    }
                    collwoService.insertCollFail(collFails);//生成工单入库
                    //sqlSession.commit();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 结束时间
        long etime = System.currentTimeMillis();
        System.out.printf("执行时长：%d 毫秒.", (etime - stime));
        System.out.println("采集失败生成完成！");
    }


    /**
     * 定时获取采集失败相关数据
     */
    //@Scheduled(cron = "0 30 5 2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31 * ? ")
    //@Async
    //@RequestMapping("collfail2")
    public void getCollFail2() {
        // 开始时间
        long stime = System.currentTimeMillis();
        List<General> generals = Lists.newArrayList();
        //入参mr_date字符串 （2022-12-15）
        String startTime = TimeUtil.getTodayTime();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        /*创建动态客户端*/
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        /*创建本地客户端连接*/
        System.out.println("获取采集失败客户端连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalFailData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisticalFailData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> lists = collwoMapper.selectOrgList();
//            List<String> lists = new ArrayList<>();
//            lists.add("1542106");
//            lists.add("1542113");
//            lists.add("1542105");
//            lists.add("1542109");
//            lists.add("1542111");
            for (String orgNo :lists) {
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"ORG_NO\">" + orgNo + "</C>\n" +
                        "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";
                Object[] objects = client.invoke(opName, sendXml);
                if (objects == null || objects.length == 0) {
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String resultxml = (String) objects[0];
                System.out.println("字符串长度:" + resultxml.length()+"获取返回的采集失败xml数据" + resultxml);
                if (resultxml.length() > 155) {
                    List<CollectFailure>  collFails = new ArrayList<>();
                    /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                    for (List<General> demo3 : demo3s) {
                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());
                        System.out.println("generals长度" + generals.size());
                        if (generals.size() != 0) {
                            CollectFailure collFail = new CollectFailure();
                            collFail.setUpOrgName(generals.get(2).getValue());
                            System.out.println("UpOrgName======" + generals.get(2).getValue());
                            collFail.setOrgName(generals.get(3).getValue());
                            collFail.setConsNo(generals.get(4).getValue());
                            collFail.setConsName(generals.get(5).getValue());
                            collFail.setElecAddr(generals.get(6).getValue());
                            collFail.setUserType(generals.get(7).getValue());
                            collFail.setMeterAssetNo(generals.get(8).getValue());
                            collFail.setTgId(generals.get(9).getValue());
                            collFail.setTgName(generals.get(10).getValue());
                            collFail.setTerminalAddr(generals.get(11).getValue());
                            collFail.setTerminalFactory(generals.get(12).getValue());
                            collFail.setTerminalState(generals.get(13).getValue());
                            collFail.setMpSn(Integer.parseInt(generals.get(14).getValue()));
                            collFail.setMrDate(generals.get(15).getValue());
                            collFail.setMeterReader(generals.get(16).getValue());
                            System.out.println("MeterReader======" + generals.get(16).getValue());
                            collFails.add(collFail);
                        }
                    }
                    //SqlSession sqlSession = sqlSessionTemplate.getSqlSessionFactory().openSession(ExecutorType.BATCH, false);//跟上述sql区别
                    //CollectWorkOrderMapper collectwoMapper = sqlSession.getMapper(CollectWorkOrderMapper.class);
                    for (CollectFailure collFail : collFails) {//collwoMapper 69113ms
                        int i = collwoMapper.insertCollfail(collFail);
                        System.out.println("=="+JSONObject.toJSONString(collFail));
                        System.out.println("自增id"+collFail.getId()+"=="+i);
                    }
                    collwoService.insertCollFail(collFails);//生成工单入库
                    //sqlSession.commit();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 结束时间
        long etime = System.currentTimeMillis();
        System.out.printf("执行时长：%d 毫秒.", (etime - stime));
        System.out.println("采集失败生成完成！");
    }


    /**
     * 采集未接入
     */
    @RequestMapping("test2")
    @Scheduled(cron = "0 30 5 2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31 * ? ")
    @Async
    public void getCollncon(){
        String startTime = TimeUtil.getTodayTime();
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取采集未接入连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "unCoverageData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("unCoverageData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
           List<String> lists = collwoMapper.selectOrgList();
           for (String orgNo : lists) {
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"ORG_NO\">" + orgNo + "</C>\n" +
                        "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";
            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());

            if(resultxml.length()>155) {
                List<CollectNotcon> collnots = new ArrayList<>();
                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    if (generals.size() != 0) {
                        CollectNotcon collnotc = new CollectNotcon();
                        collnotc.setUpOrgName(generals.get(3).getValue());
                        collnotc.setOrgName(generals.get(4).getValue());
                        collnotc.setConsNo(generals.get(5).getValue());
                        collnotc.setConsName(generals.get(6).getValue());
                        collnotc.setMeterreadNum(generals.get(7).getValue());
                        collnotc.setElecAddr(generals.get(8).getValue());
                        collnotc.setMeterAssetNo(generals.get(9).getValue());
                        collnotc.setTgId(generals.get(11).getValue());
                        collnotc.setTgName(generals.get(12).getValue());
                        collnotc.setTgManager(generals.get(13).getValue());
                        System.out.println(collnotc);
                        collnots.add(collnotc);
                    }
                }
                //SqlSession sqlSession = sqlSessionTemplate.getSqlSessionFactory().openSession(ExecutorType.BATCH, false);//跟上述sql区别
                //CollectWorkOrderMapper collectwoMapper = sqlSession.getMapper(CollectWorkOrderMapper.class);
                for (CollectNotcon collnot : collnots) {
                    int i = collwoMapper.insertCollnot(collnot);
                    System.out.println(collnot.getId()+"=="+i);
                    collwoService.insertCollNotc(collnot);//生成工单入库
                }
                //sqlSession.commit();
            }
                }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println("采集未接入生成完成！");
    }

    @RequestMapping("threadjl")
    @Async
    @Scheduled(cron = "0 30 4 * * ? ")
    public void GetCollInfoThread(){
//        ExecutorService executor = Executors.newFixedThreadPool(8);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) wsdlClient.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(800000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(800000);// 响应超时(毫秒)
            Endpoint endpoint = wsdlClient.getEndpoint();
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalIndicatingDetail");
            QName opNameVol = new QName(endpoint.getService().getName().getNamespaceURI(), "voltageCurveDetail");
            QName opNameCurr = new QName(endpoint.getService().getName().getNamespaceURI(), "currentCurveDetail");
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisticalIndicatingDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }

            if (bindingInfo.getOperation(opNameVol) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("voltageCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opNameVol = operationInfo.getName();
                        break;
                    }
                }
            }

            if (bindingInfo.getOperation(opNameCurr) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("currentCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opNameCurr = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> lists = collwoMapper.selectOrgList();
            List<String> list = collwoMapper.selectTerminalAddr();
            ExecuteLog executeLog = new ExecuteLog();
            executeLog.setThread(String.valueOf(list.size()));
            executeLogMapper.insert(executeLog);
            for (String terminaladdr : list) {
                QName finalOpName = opName;
                QName finalOpNameVol = opNameVol;
                QName finalOpNameCurr = opNameCurr;
//                QName finalOpNameVol = null;
//                QName finalOpNameCurr = null;
                Runnable task = new Runnable() {
                    public void run() {
                        try {
                            GetCollInfoTask(wsdlClient, finalOpName,terminaladdr,finalOpNameVol,finalOpNameCurr);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                };
                asyncTaskExecutor.submit(task);
//                executor.submit(task);
            }
//            executor.shutdown();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 此方法用于测试单个终端地址
     */
    @RequestMapping("threadjl1")
    public void GetCollInfoThread1(@RequestParam String ymd){
        ExecutorService executor = Executors.newFixedThreadPool(1);
        List<General> generals = Lists.newArrayList();
        System.out.println("获取采集异常（日冻结）客户端连接前");
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) wsdlClient.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(800000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(800000);// 响应超时(毫秒)
            Endpoint endpoint = wsdlClient.getEndpoint();
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalIndicatingDetail");
            QName opNameVol = new QName(endpoint.getService().getName().getNamespaceURI(), "voltageCurveDetail");
            QName opNameCurr = new QName(endpoint.getService().getName().getNamespaceURI(), "currentCurveDetail");
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisticalIndicatingDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }

            if (bindingInfo.getOperation(opNameVol) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("voltageCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opNameVol = operationInfo.getName();
                        break;
                    }
                }
            }

            if (bindingInfo.getOperation(opNameCurr) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("currentCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opNameCurr = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> list = new ArrayList<>();
            list.add(ymd);
            for (String terminaladdr : list) {
                QName finalOpName = opName;
                QName finalOpNameVol = opNameVol;
                QName finalOpNameCurr = opNameCurr;
                Runnable task = new Runnable() {
                    public void run() {
                        try {
                            GetCollInfoTask(wsdlClient, finalOpName,terminaladdr,finalOpNameVol,finalOpNameCurr);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                };
                executor.submit(task);
            }
            executor.shutdown();
        }catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void GetCollInfoTask(Client wsdlClient,QName opName,String terminaladdr,QName opNameVol,QName opNameCurr) throws Exception {
        String startTime = org.dfzt.util.DateUtil.getBeforeDay();
        List<General> generals = Lists.newArrayList();
        String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<DBSET>\n" +
                "<R>\n" +
                "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                "<C N=\"TERMINAL_ADDR\">" + terminaladdr + "</C>\n" +
                "</R>\n" +
                "</DBSET>\n";
        System.out.println("3opName"+opName);

        //执行servicebegin
        ExecuteLogDetail executeLogDetail = new ExecuteLogDetail();
        executeLogDetail.setAddress(terminaladdr);
        executeLogDetailMapper.insert(executeLogDetail);

        //***********************开始调用*********************************
        Object[] objects = wsdlClient.invoke(opName, sendXml);

        Object[] objectsVol=null;
        objectsVol = wsdlClient.invoke(opNameVol, sendXml);

        Object[] objectsCurr=null;
        objectsCurr = wsdlClient.invoke(opNameCurr, sendXml);

        if(objects == null || objects.length==0){
            System.out.println("接口返回参数为空");
        }

        //****************************接收结果**********************************
        String  resultxml = (String) objects[0];
        System.out.println("获取返回采集异常（日冻结）的xml数据"+resultxml);
        System.out.println("字符串长度:"+resultxml.length());
        if(resultxml.length()>155) {
            List<CollectInforma> collinfors = new ArrayList<>();

            //接收用户结果
            Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
            List<General> demo2 = demo1.getDemo2().getGeneral();
            List<List<General>> demo3s = demo1.getDemo3().getGeneral();

            //接收电压结果
            List<MeterVoltage> meterVs = new ArrayList<>();
            List<General> generalsVol = Lists.newArrayList();
            String  resultxmlVol = (String) objectsVol[0];
            System.out.println("获取返回电压曲线的xml数据1"+resultxmlVol);
            System.out.println("获取返回电压曲线的xml数据2:"+resultxmlVol.length());
            if(resultxmlVol.length()>155) {
                Demo1 demo1Vol = XStreamUtils.xmlToObject(resultxmlVol, Demo1.class, new DemoConverter());
                List<General> demo2Vol = demo1Vol.getDemo2().getGeneral();
                List<List<General>> demo3sVol = demo1Vol.getDemo3().getGeneral();
                System.out.println("获取返回电压曲线的xml数据3"+demo3sVol);
                for (List<General> demo3Vol : demo3sVol) {
                    System.out.println("获取返回电压曲线的xml数据4"+demo3Vol);
                    MeterVoltage meterVoltageVol = new MeterVoltage();
                    generalsVol = Stream.of(demo2Vol, demo3Vol)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    System.out.println("获取返回电压曲线的xml数据5"+generalsVol);
                    MeterVoltage dayVol = GetPointUtil.getDayVol(meterVoltageVol, generalsVol);
                    System.out.println("获取返回电压曲线的xml数据6"+dayVol);
                    meterVs.add(dayVol);
                }
                System.out.println("获取返回电压曲线的xml数据7"+meterVs);
            }

            //接收电流结果
            List<MeterCurr> meterCurrs = new ArrayList<>();
            List<General> generalsCurr = Lists.newArrayList();
            String  resultxmlCurr = (String) objectsCurr[0];
            System.out.println("获取返回电流曲线的xml数据1"+resultxmlCurr);
            System.out.println("获取返回电流曲线的xml数据2:"+resultxmlCurr.length());
            if(resultxmlCurr.length()>155) {
                Demo1 demo1Curr = XStreamUtils.xmlToObject(resultxmlCurr, Demo1.class, new DemoConverter());
                List<General> demo2Curr = demo1Curr.getDemo2().getGeneral();
                List<List<General>> demo3sCurr = demo1Curr.getDemo3().getGeneral();
                System.out.println("获取返回电流曲线的xml数据3"+demo3sCurr);
                for (List<General> demo3Curr : demo3sCurr) {
                    System.out.println("获取返回电流曲线的xml数据4"+demo3Curr);
                    generalsCurr = Stream.of(demo2Curr, demo3Curr)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    MeterCurr meterCurr = new MeterCurr();
                    System.out.println("获取返回电流曲线的xml数据5"+generalsCurr);
                    MeterCurr dayCurr = GetPointUtil.getDayCurr(meterCurr, generalsCurr);
                    System.out.println("获取返回电流曲线的xml数据6"+dayCurr);
                    meterCurrs.add(dayCurr);
                }
                System.out.println("获取返回电流曲线的xml数据7"+meterCurrs);
            }

            //************************开始按用户循环********************************
            List<MeterWorkOrder> collectInformaList = new ArrayList<>();
            for (List<General> demo3 : demo3s) {
                generals = Stream.of(demo2, demo3)
                        .flatMap(Collection::stream)
                        .collect(Collectors.toList());

                if (generals!=null && generals.size()!=0) {
                    CollectInforma collinfo = new CollectInforma();
                    collinfo.setUpOrgName(generals.get(2).getValue());
                    collinfo.setOrgName(generals.get(3).getValue());
                    collinfo.setConsNo(generals.get(4).getValue());
                    collinfo.setConsName(generals.get(5).getValue());
                    collinfo.setAbnormalData(generals.get(6).getValue());
                    collinfo.setMeterAssetNo(generals.get(7).getValue());
                    collinfo.setElecmeterFactory(generals.get(8).getValue());
                    collinfo.setTerminalFactory(generals.get(9).getValue());
                    collinfo.setElecmeterContype(generals.get(10).getValue());
                    collinfo.setTgId(generals.get(11).getValue());
                    collinfo.setTgName(generals.get(12).getValue());
                    collinfo.setTFactor(generals.get(13).getValue());
                    collinfo.setPapE((generals.get(14).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(14).getValue()));
                    collinfo.setRateOne((generals.get(15).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(15).getValue()));
                    collinfo.setRateTwo((generals.get(16).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(16).getValue()));
                    collinfo.setRateThree((generals.get(17).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(17).getValue()));
                    collinfo.setRateFour((generals.get(18).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(18).getValue()));
                    collinfo.setRrpE((generals.get(19).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(19).getValue()));
                    collinfo.setRapE((generals.get(20).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(20).getValue()));
                    collinfo.setRp1R((generals.get(21).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(21).getValue()));
                    collinfo.setRp2R((generals.get(22).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(22).getValue()));
                    collinfo.setRp3R((generals.get(23).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(23).getValue()));
                    collinfo.setRp4R((generals.get(24).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(24).getValue()));
                    collinfo.setElecAddr(generals.get(25).getValue());
                    collinfo.setTerminalAddr(generals.get(26).getValue());
                    if (!"".equals(generals.get(27).getValue())){
                        collinfo.setRecTime(new SimpleDateFormat("yyyyMMddHHmmss").parse(generals.get(27).getValue()));
                    }
                    if(!"".equals(generals.get(28).getValue())){
                        collinfo.setStatDate(new SimpleDateFormat("yyyy-MM-dd").parse(generals.get(28).getValue()));
                    }
                    collinfo.setMpSn(generals.get(29).getValue());
                    collinfo.setMrSectNo(generals.get(30).getValue());
                    collinfo.setTmnlAssetNo(generals.get(31).getValue());
                    collinfo.setTgManager(generals.get(32).getValue());
                    collinfo.setConsType(generals.get(33).getValue());
                    collinfors.add(collinfo);

                    if(generals.get(6).getValue().contains("异常数据")){//日冻结中包含了异常数据
                        collwoService.insertCollInfo(collinfo);//采集异常工单生成
                    }

                    //计算单个用户计量工单
                    List<MeterVoltage> collectVol=null;
                    collectVol = meterVs.stream().filter(i -> i.getMeterAssetNo().equals(collinfo.getMeterAssetNo())).collect(Collectors.toList());

                    List<MeterCurr> collectCurr = null;
                    collectCurr = meterCurrs.stream().filter(i -> i.getMeterAssetNo().equals(collinfo.getMeterAssetNo())).collect(Collectors.toList());

                    MeterWorkOrder meterWorkOrder = collinfoService.meterWorkOrderUser(collinfo, collectVol, collectCurr);
                    collectInformaList.add(meterWorkOrder);
                }
            }

            //保存计量工单
            meterWorkOrderService.saveBatch(collectInformaList);

//            collinfoService.meterWorkOrder(collinfors);

            collinfoService.saveBatch(collinfors);

            //保存当天数据
//            for (CollectInforma collinfo : collinfors) {
//                i += collwoMapper.insertCollinfo(collinfo);
//                if(generals.get(6).getValue().contains("异常数据")){//日冻结中包含了异常数据
//                    collwoService.insertCollInfo(collinfo);//采集异常工单生成
//                }
//            }
//            System.out.println("新增条数为"+i);
        }
    }

    /**
     * 采集异常 计量
     * @throws ParseException
     */
    @RequestMapping("test3")
    @Async
//    @Scheduled(cron = "0 30 4 * * ? ")
    public void getCollInfo() throws ParseException {
        String startTime = TimeUtil.getTodayTime();
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取采集异常（日冻结）客户端连接前");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(800000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(800000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalIndicatingDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisticalIndicatingDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            //List<String> lists = collwoMapper.selectOrgList();
            List<String> list = collwoMapper.selectTerminalAddr();

            //**********************************开始循环终端地址**********************************
            for (String terminaladdr : list) {

                //获取终端地址包含的用户数量、用户电压、用户电流的调用地址
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                        "<C N=\"TERMINAL_ADDR\">" + terminaladdr + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";

                Object[] objects = client.invoke(opName, sendXml);
                if(objects == null || objects.length==0){
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String  resultxml = (String) objects[0];
                System.out.println("获取返回采集异常（日冻结）的xml数据"+resultxml);
                System.out.println("字符串长度:"+resultxml.length());
                if(resultxml.length()>155) {
                    int i=0;
                    int j=0;
                    List<CollectInforma> collinfors = new ArrayList<>();
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();

                    //*************************开始循环每个用户*************************
                    for (List<General> demo3 : demo3s) {

                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());

                        if (generals!=null && generals.size()!=0) {
                            CollectInforma collinfo = new CollectInforma();
                            collinfo.setUpOrgName(generals.get(2).getValue());
                            collinfo.setOrgName(generals.get(3).getValue());
                            collinfo.setConsNo(generals.get(4).getValue());
                            collinfo.setConsName(generals.get(5).getValue());
                            collinfo.setAbnormalData(generals.get(6).getValue());
                            collinfo.setMeterAssetNo(generals.get(7).getValue());
                            collinfo.setElecmeterFactory(generals.get(8).getValue());
                            collinfo.setTerminalFactory(generals.get(9).getValue());
                            collinfo.setElecmeterContype(generals.get(10).getValue());
                            collinfo.setTgId(generals.get(11).getValue());
                            collinfo.setTgName(generals.get(12).getValue());
                            collinfo.setTFactor(generals.get(13).getValue());
                            collinfo.setPapE((generals.get(14).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(14).getValue()));
                            collinfo.setRateOne((generals.get(15).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(15).getValue()));
                            collinfo.setRateTwo((generals.get(16).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(16).getValue()));
                            collinfo.setRateThree((generals.get(17).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(17).getValue()));
                            collinfo.setRateFour((generals.get(18).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(18).getValue()));
                            collinfo.setRrpE((generals.get(19).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(19).getValue()));
                            collinfo.setRapE((generals.get(20).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(20).getValue()));
                            collinfo.setRp1R((generals.get(21).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(21).getValue()));
                            collinfo.setRp2R((generals.get(22).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(22).getValue()));
                            collinfo.setRp3R((generals.get(23).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(23).getValue()));
                            collinfo.setRp4R((generals.get(24).getValue().equals("")) ? new BigDecimal(0) : new BigDecimal(generals.get(24).getValue()));
                            collinfo.setElecAddr(generals.get(25).getValue());
                            collinfo.setTerminalAddr(generals.get(26).getValue());
                            if (!"".equals(generals.get(27).getValue())){
                                collinfo.setRecTime(new SimpleDateFormat("yyyyMMddHHmmss").parse(generals.get(27).getValue()));
                            }
                            if(!"".equals(generals.get(28).getValue())){
                                collinfo.setStatDate(new SimpleDateFormat("yyyy-MM-dd").parse(generals.get(28).getValue()));
                            }
                            collinfo.setMpSn(generals.get(29).getValue());
                            collinfo.setMrSectNo(generals.get(30).getValue());
                            collinfo.setTmnlAssetNo(generals.get(31).getValue());
                            collinfo.setTgManager(generals.get(32).getValue());
                            collinfo.setConsType(generals.get(33).getValue());

                            if(generals.get(6).getValue().contains("异常数据")){//日冻结中包含了异常数据
                                collwoService.insertCollInfo(collinfo);//采集异常工单生成
                            }

                            collinfors.add(collinfo);
                            //collwoService.insertCollInfo(collinfo);//生成工单入库
                        }
                    }

                    collinfoService.meterWorkOrder(collinfors);
                    collinfoService.saveBatch(collinfors);


//                    for (CollectInforma collinfo : collinfors) {
//                        i += collwoMapper.insertCollinfo(collinfo);
//                        if(generals.get(6).getValue().contains("异常数据")){//日冻结中包含了异常数据
//                            collwoService.insertCollInfo(collinfo);//采集异常工单生成
//                        }
//                    }
//                    System.out.println("新增条数为"+i);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 日冻结电能示值 No operation was found with the name {http://impl.webservice.nari.com/}statisticalindIcatingDetail
     */
    @RequestMapping("test4")
    public void getDayEnergy() throws ParseException {
        String startTime = TimeUtil.getTodayTime();
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取日冻结电能示值连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(800000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(800000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalIndicatingDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisticalIndicatingDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> orgNos = new ArrayList<>();
            orgNos.add("154212203");
            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"ORG_NO\">" + "154212203" + "</C>\n" +
                    "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";
            System.out.println("4opName"+opName);
            Object[] objects = client.invoke(opName, sendXml);

            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                List<CollectInforma> collinfors = new ArrayList<>();
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    if (generals.size()!=0) {
                        CollectInforma collinfo = new CollectInforma();
                        collinfo.setUpOrgName(generals.get(2).getValue());
                        collinfo.setOrgName(generals.get(3).getValue());
                        collinfo.setConsNo(generals.get(4).getValue());
                        collinfo.setConsName(generals.get(5).getValue());
                        collinfors.add(collinfo);
                    }
                }
                for (CollectInforma collinfo : collinfors) {
                    System.out.println(collinfo);
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 日冻结电压曲线
     */
    @RequestMapping("test5")//MeterVoltage
    public List<MeterVoltage> getDayVol(String meterAssetNo) throws ParseException{

        List<MeterVoltage> meterVs = new ArrayList<>();
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
//        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();

        System.out.println("获取日冻结电压曲线连接");
//        Client client = dcf.createClient(wsdlUrl);

        try {
            /*初始化反参集合*/
//            HTTPConduit http = (HTTPConduit) client.getConduit();
            HTTPConduit http = (HTTPConduit) wsdlClient.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(800000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(800000);// 响应超时(毫秒)
//            Endpoint endpoint = client.getEndpoint();
            Endpoint endpoint = wsdlClient.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "voltageCurveDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("voltageCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
        String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"METER_ASSET_NO\">" + meterAssetNo + "</C>\n" +
                    "<C N=\"MR_DATE\">" + TimeUtil.getStartTime() + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";

//            Object[] objects = client.invoke(opName, sendXml);

            //************************开始调用***********************************
            Object[] objects = wsdlClient.invoke(opName, sendXml);

            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取返回电压曲线的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    MeterVoltage meterVoltage = new MeterVoltage();
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    MeterVoltage dayVol = GetPointUtil.getDayVol(meterVoltage, generals);
                    meterVs.add(dayVol);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return meterVs;
    }

    /**
     * 日冻结电流曲线
     */
    @RequestMapping("test6")//MeterCurr
    public List<MeterCurr> getDayCurr(String meterAssetNo) throws ParseException {
        List<MeterCurr> meterCurrs = new ArrayList<>();
        List<General> generals = Lists.newArrayList();
//        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
//        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();

        System.out.println("获取日冻结电流曲线连接");
//        Client client = dcf.createClient(wsdlUrl);

        try {
            /*初始化反参集合*/
//            HTTPConduit http = (HTTPConduit) client.getConduit();
            HTTPConduit http = (HTTPConduit) wsdlClient.getConduit();

            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();

            httpClientPolicy.setConnectionTimeout(800000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(800000);// 响应超时(毫秒)
//            Endpoint endpoint = client.getEndpoint();
            Endpoint endpoint = wsdlClient.getEndpoint();

            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "currentCurveDetail");

            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("currentCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }

            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"METER_ASSET_NO\">" + meterAssetNo + "</C>\n" +
                    "<C N=\"MR_DATE\">" + TimeUtil.getStartTime() + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";

//            Object[] objects = client.invoke(opName, sendXml);
            Object[] objects = wsdlClient.invoke(opName, sendXml);

            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取返回电流曲线的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    MeterCurr meterCurr = new MeterCurr();
                    MeterCurr dayCurr = GetPointUtil.getDayCurr(meterCurr, generals);
                    meterCurrs.add(dayCurr);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return meterCurrs;
    }

    /**
     * 日冻结功率曲线 LinelossPower
     */
    @RequestMapping("test7")
    public static LinelossPower getDayPower(String meterAssetNo,String mrdate){
        List<LinelossPower> linelossPowers = new ArrayList<>();
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取功率曲线连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "powerCurveDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("powerCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<DBSET>\n" +
                "<R>\n" +
                "<C N=\"METER_ASSET_NO\">" + meterAssetNo  + "</C>\n" +
                "<C N=\"MR_DATE\">" + mrdate + "</C>\n" +
                "</R>\n" +
                "</DBSET>\n";

            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取功率曲线返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3).flatMap(Collection::stream).collect(Collectors.toList());
                    if(generals.size()!=0) {
                        LinelossPower linelossPower = new LinelossPower();
                        LinelossPower dayPower = GetPointUtil.getDayPower(linelossPower, generals);
                        linelossPowers.add(dayPower);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(linelossPowers.size()==0){
            return null;
        }
        return linelossPowers.get(0);
    }


    /**
     * 日冻结功率曲线 LinelossPower 集合
     */
    @RequestMapping("test7s")
    public static List<LinelossPower> getDayPowers(String meterAssetNo,String mrdate){
        List<LinelossPower> linelossPowers = new ArrayList<>();
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取功率曲线连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "powerCurveDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("powerCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"METER_ASSET_NO\">" + meterAssetNo  + "</C>\n" +
                    "<C N=\"MR_DATE\">" + mrdate + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";

            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取功率曲线返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3).flatMap(Collection::stream).collect(Collectors.toList());
                    if(generals.size()!=0) {
                        LinelossPower linelossPower = new LinelossPower();
                        LinelossPower dayPower = GetPointUtil.getDayPower(linelossPower, generals);
                        linelossPowers.add(dayPower);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(linelossPowers.size()==0){
            return null;
        }
        return linelossPowers;
    }

    /**
     * 示值曲线
     */
    @RequestMapping("test8")
    public static List<IndicationValue> getDayIndi(String meterAssetNo){
//入参mr_date字符串 （2022-12-15）
        String startTime = TimeUtil.getStartTwoTime();
        List<IndicationValue> indis = new ArrayList<>();
        List<General> generals;
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取示值曲线连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "indicatingCurveDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("indicatingCurveDetail".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }

            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"METER_ASSET_NO\">" + meterAssetNo + "</C>\n" +
                    "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";

            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取示值曲线的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {

                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    IndicationValue indValue = new IndicationValue();
                    if (generals.size() != 0) {
                        IndicationValue indi = GetPointUtil.getIndi(indValue, generals);
                        indis.add(indi);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return indis;
    }


    /**
     * 运行情况监测（采集研判） "000070061468" 返回状态为1 可能没有对应的数据
     */
    //@RequestMapping("test9")
    public static String getRunsur(String terminalAddr){
        //入参mr_date字符串 （2022-12-15）
        String startTime = TimeUtil.getTodayTime();
        //入参tg_no字符串
            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"mr_date\">" + startTime + "</C>\n" +
                    "<C N=\"terminal_addr\">" + terminalAddr + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";
            WebServiceDemo webServiceDemo = new WebServiceDemo();
            List<General> generals = webServiceDemo.testSendCollFail(sendXml, "runStatusEntityData",getClient());
            //value是通信状态
        String value ="中断";
        if (generals.size()!=0) {
            value = generals.get(11).getValue();
        }
        return value;
    }


    /** 有数据
     * 台区考核单元明细
     */
    @Async
    @RequestMapping("test10")
    @Scheduled(cron = "0 40 3 * * ? ")
    public void getTgexam() throws ParseException {
        //String startTime = TimeUtil.getStartTime();//1
        String startTime = TimeUtil.getStartTwoTime(); //要改
        List<General> generals;
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取台区考核单元连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisLineLossData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> orgNos = collwoMapper.selectOrgList();
            List<String> linethrlist = linelossWorkOrderMapper.selectLinelossStatus(TimeUtil.getStart5Time());//要改获取昨天的工单台区编号列表
            List<LinelossSynana> linelossys = new ArrayList<>();
            for (String orgNo : orgNos) {
            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                    "<C N=\"ORG_NO\">" + orgNo + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";

            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取台区考核单元明细返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {

                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    //<C N="LOSS_PQ"></C> 损失电量 get(12)
                    //<C N="L_LLR_REAL"></C> 线损率get(13)
                    if (generals.size() != 0) {
                        System.out.println("generals"+generals.get(13).getValue());
                        int i = new BigDecimal("".equals(generals.get(13).getValue())?"0":generals.get(13).getValue()).compareTo(new BigDecimal("6"));//判断线损率大于6 424
                        int j = new BigDecimal("".equals(generals.get(13).getValue())?"0":generals.get(13).getValue()).compareTo(new BigDecimal("-1"));//判断线损率小于-1
                        int k = new BigDecimal("".equals(generals.get(12).getValue())?"0":generals.get(12).getValue()).compareTo(new BigDecimal("15"));//判断损耗电量值大于15
                        int l = new BigDecimal("".equals(generals.get(12).getValue())?"0":generals.get(12).getValue()).compareTo(new BigDecimal("-3"));//判断损耗电量值小于-3
                        System.out.println("i j k l"+i+j+k+l);
                        if (((i == 1 && k == 1) || (j == -1 && l==-1))) {
                            LinelossSynana linelossSynana = new LinelossSynana();
                            linelossSynana.setUpOrgName(generals.get(3).getValue());
                            linelossSynana.setOrgName(generals.get(2).getValue());
                            linelossSynana.setTgName(generals.get(5).getValue());
                            linelossSynana.setTgNo(generals.get(4).getValue());
                            linelossSynana.setTgCap(Integer.parseInt(generals.get(6).getValue()));
                            linelossSynana.setChkunitName(generals.get(7).getValue());
                            linelossSynana.setDataDate(new SimpleDateFormat("yyyy-MM-dd").parse(generals.get(8).getValue()));
                            linelossSynana.setPpq(generals.get(9).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(9).getValue()));
                            linelossSynana.setTgSpq(generals.get(10).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(10).getValue()));
                            linelossSynana.setSpq(generals.get(11).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(11).getValue()));
                            linelossSynana.setLossPq(generals.get(12).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(12).getValue()));
                            linelossSynana.setLinelossRate(generals.get(13).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(13).getValue()));
                            linelossSynana.setLlIdxUp(generals.get(14).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(14).getValue()));
                            linelossSynana.setLlIdxLow(generals.get(15).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(15).getValue()));
                            linelossSynana.setDifferValue(generals.get(16).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(16).getValue()));
                            linelossSynana.setStarTg(generals.get(17).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(17).getValue()));
                            linelossSynana.setReadSuccCnt(generals.get(18).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(18).getValue()));
                            linelossSynana.setReadSuccRate(generals.get(19).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(19).getValue()));
                            linelossSynana.setInstRate(generals.get(20).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(20).getValue()));
                            linelossSynana.setPfFlag(generals.get(21).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(21).getValue()));
                            linelossSynana.setLinelossTheory(generals.get(16).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(16).getValue()));
                            linelossSynana.setURate(generals.get(22).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(22).getValue()));
                            linelossSynana.setIRate(generals.get(23).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(23).getValue()));
                            linelossSynana.setLoadRate(generals.get(24).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(24).getValue()));
                            linelossSynana.setChargePerson(generals.get(25).getValue());
                            linelossSynana.setComposeSign(generals.get(26).getValue());
                            linelossSynana.setPpqRepair(generals.get(27).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(27).getValue()));
                            linelossSynana.setSpqRepair(generals.get(28).getValue()==null?BigDecimal.ZERO:new BigDecimal(generals.get(28).getValue()));
                            linelossSynana.setTgLabel(generals.get(29).getValue());
                            linelossWorkOrderService.insertLineloss(linelossSynana);
                            linelossys.add(linelossSynana);
                            System.out.println(linelossSynana);
                        }
                    }
                }
            }
            }
            //List<String> otherTgNo = new ArrayList<>();//拿到昨天剩余的工单
            for (LinelossSynana linelossSynana : linelossys) {
                //linelossWorkOrderMapper.insertlilossSynana(linelossSynana);//添加到数据表
                //linelossWorkOrderService.insertLineloss(linelossSynana);//生成新工单
                if(linethrlist.contains(linelossSynana.getTgNo())) {//判断该台区编号在不在昨天的工单里
                    String s = linelossWorkOrderMapper.selectWorkCycle(linelossSynana.getTgNo(), TimeUtil.getTodayTime1());//要改1getStart5Time
                    if(s==null)s="0";
                    Integer i = Integer.parseInt(s) + 1;
                    linelossWorkOrderMapper.updateworkCycle(linelossSynana.getTgNo(),TimeUtil.getTodayTime(),i.toString());//要改1getTomDay()
                }
                //System.out.println(linelossSynana.getId()+"=="+i);
            }
//            int i = 0;
//            for (String s : linethrlist) {//判断昨天的工单今天是不是存在，如果不存在则将状态改为4已归档
//                if(!linelossys.contains(s)){
//                    i += linelossWorkOrderMapper.updateWoStatus4(s);
//                }
//            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Async
    @RequestMapping("test10a")
//    @Scheduled(cron = "0 10 2 * * ? ")
    public void getTgexama() throws ParseException {
        String startTime = TimeUtil.getStartTwoTime();
        List<General> generals;
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取台区考核单元连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisLineLossData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> orgNos = collwoMapper.selectOrgList();
            for (String orgNo : orgNos) {
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"MR_DATE\">" + startTime + "</C>\n" +
                        "<C N=\"ORG_NO\">" + orgNo + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";

                Object[] objects = client.invoke(opName, sendXml);
                if(objects == null || objects.length==0){
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String  resultxml = (String) objects[0];
                System.out.println("获取台区考核单元明细返回的xml数据"+resultxml);
                System.out.println("字符串长度:"+resultxml.length());
                if(resultxml.length()>155) {
                    List<LinelossSynana> linelossys = new ArrayList<>();
                    /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                    for (List<General> demo3 : demo3s) {
                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());
                        //<C N="LOSS_PQ"></C> 损失电量 get(12)
                        //<C N="L_LLR_REAL"></C> 线损率get(13)
                        if (generals.size() != 0) {
                            LinelossSynana linelossSynana = new LinelossSynana();
                            linelossSynana.setUpOrgName(generals.get(3).getValue());
                            linelossSynana.setOrgName(generals.get(2).getValue());
                            linelossSynana.setTgName(generals.get(5).getValue());
                            linelossSynana.setTgNo(generals.get(4).getValue());
                            linelossSynana.setTgCap(Integer.parseInt(generals.get(6).getValue()));
                            linelossSynana.setChkunitName(generals.get(7).getValue());
                            linelossSynana.setDataDate(new SimpleDateFormat("yyyy-MM-dd").parse(generals.get(8).getValue()));
                            linelossSynana.setPpq(new BigDecimal(generals.get(9).getValue()));
                            linelossSynana.setTgSpq(new BigDecimal(generals.get(10).getValue()));
                            linelossSynana.setSpq(new BigDecimal(generals.get(11).getValue()));
                            linelossSynana.setLossPq(new BigDecimal(generals.get(12).getValue()));
                            linelossSynana.setLinelossRate(new BigDecimal(generals.get(13).getValue()));
                            linelossSynana.setLlIdxUp(new BigDecimal(generals.get(14).getValue()));
                            linelossSynana.setLlIdxLow(new BigDecimal(generals.get(15).getValue()));
                            linelossSynana.setDifferValue(new BigDecimal(generals.get(16).getValue()));
                            linelossSynana.setStarTg(new BigDecimal(generals.get(17).getValue()));
                            linelossSynana.setReadSuccCnt(new BigDecimal(generals.get(18).getValue()));
                            linelossSynana.setReadSuccRate(new BigDecimal(generals.get(19).getValue()));
                            linelossSynana.setInstRate(new BigDecimal(generals.get(20).getValue()));
                            linelossSynana.setPfFlag(new BigDecimal(generals.get(21).getValue()));
                            linelossSynana.setLinelossTheory(new BigDecimal(generals.get(16).getValue()));
                            linelossSynana.setURate(new BigDecimal(generals.get(22).getValue()));
                            linelossSynana.setIRate(new BigDecimal(generals.get(23).getValue()));
                            linelossSynana.setLoadRate(new BigDecimal(generals.get(24).getValue()));
                            linelossSynana.setChargePerson(generals.get(25).getValue());
                            linelossSynana.setComposeSign(generals.get(26).getValue());
                            linelossSynana.setPpqRepair(new BigDecimal(generals.get(27).getValue()));
                            linelossSynana.setSpqRepair(new BigDecimal(generals.get(28).getValue()));
                            linelossSynana.setTgLabel(generals.get(29).getValue());
                            linelossys.add(linelossSynana);
                        }
                    }
                    int i = 0;
                    for (LinelossSynana linelossSynana : linelossys) {
                         i+= linelossWorkOrderMapper.insertlilossSynana(linelossSynana);
                    }
                    System.out.println("线损工单归档的数据为"+i+"条");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * 供电量明细 LinelossPpq
     * @param //tgNo 台区编号
     * @return
     */
    //@RequestMapping("test11") //String tgNo
    public static List<LinelossPpq> getTgppq(String tgNo,String startTime) throws ParseException {
        List<General> generals = Lists.newArrayList();
        List<LinelossPpq> linelossPpqs = new ArrayList<>();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取供电量明细连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisLineLossPpqData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisLineLossPpqData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"DATA_TIME\">" + startTime + "</C>\n" +
                    "<C N=\"TG_NO\">" + tgNo + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";
            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("供电量明细获取返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    LinelossPpq linelossPpq = new LinelossPpq();
                    linelossPpq.setConsNo(generals.get(2).getValue());
                    linelossPpq.setConsName(generals.get(3).getValue());
                    linelossPpq.setConsType(generals.get(4).getValue());
                    linelossPpq.setTerminalAddr(generals.get(6).getValue());
                    linelossPpq.setTotalPointsIdent(generals.get(7).getValue());
                    linelossPpq.setDataDate(new SimpleDateFormat("yyyy-MM-dd").parse(generals.get(8).getValue()));
                    linelossPpq.setStartpapE(new BigDecimal("".equals(generals.get(9).getValue())?"0":generals.get(9).getValue()));
                    linelossPpq.setEndpapE(new BigDecimal("".equals(generals.get(10).getValue())?"0":generals.get(10).getValue()));
                    linelossPpq.setPapE(new BigDecimal("".equals(generals.get(11).getValue())?"0":generals.get(11).getValue()));
                    linelossPpq.setStartrapE(new BigDecimal("".equals(generals.get(12).getValue())?"0":generals.get(12).getValue()));
                    linelossPpq.setEndrapE(new BigDecimal("".equals(generals.get(13).getValue())?"0":generals.get(13).getValue()));
                    linelossPpq.setRapE(new BigDecimal("".equals(generals.get(14).getValue())?"0":generals.get(14).getValue()));
                    linelossPpq.setTgPpq(new BigDecimal("".equals(generals.get(16).getValue())?"0":generals.get(16).getValue()));
                    linelossPpq.setUsageTypeCode(generals.get(17).getValue());
                    linelossPpq.setTFactor(new BigDecimal("".equals(generals.get(18).getValue())?"0":generals.get(18).getValue()));
                    linelossPpq.setCt(generals.get(19).getValue());
                    linelossPpq.setPt(generals.get(20).getValue());
                    linelossPpq.setMeterAssetNo(generals.get(21).getValue());
                    linelossPpq.setFmrAssetNo(generals.get(22).getValue());
                    linelossPpq.setMpSn(generals.get(23).getValue());
                    System.out.println(linelossPpq);
                    linelossPpqs.add(linelossPpq);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return linelossPpqs;
    }



    //@RequestMapping("test11") //通过供电量获取电能表资产号
    public static String getTgppq1(String tgNo,String startTime) throws ParseException {
        List<General> generals = Lists.newArrayList();
        String meterAssetNo = null;
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("通过供电量获取电能表资产号连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisLineLossPpqData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisLineLossPpqData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"DATA_TIME\">" + startTime + "</C>\n" +
                    "<C N=\"TG_NO\">" + tgNo + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";
            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("供电量获取电能表资产号返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                  if(generals.get(17).getValue().contains("台区供电考核")) {
                      meterAssetNo = generals.get(21).getValue();
                  }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return meterAssetNo;
    }

    public static BigDecimal getTgppq30(String tgNo,String startTime) throws ParseException {
        List<General> generals = Lists.newArrayList();
        List<LinelossPpq> linelossPpqs = new ArrayList<>();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取30天供电量连接");
        Client client = dcf.createClient(wsdlUrl);
        BigDecimal ppqAll = new BigDecimal("0");
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisLineLossPpqData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisLineLossPpqData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"DATA_TIME\">" + startTime + "</C>\n" +
                    "<C N=\"TG_NO\">" + tgNo + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";

            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("30天供电量获取返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    ppqAll = ppqAll.add(new BigDecimal("".equals(generals.get(16).getValue())?"0":generals.get(16).getValue()));
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ppqAll;
    }

    /**
     * 售电量明细 LinelossSpq
     * @param //tgNo 台区编号 String tgNo
     * @return
     */
    @RequestMapping("test12")
    public static List<LinelossSpq> getTgspq(String tgNo,String startTime) throws ParseException {
        List<LinelossSpq> spqList = new ArrayList<>();
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取售电量明细连接");
        Client client = dcf.createClient(wsdlUrl);

        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisLineLossSpqData");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisLineLossSpqData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
        String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<DBSET>\n" +
                "<R>\n" +
                "<C N=\"DATA_TIME\">" + startTime + "</C>\n" +
                "<C N=\"TG_NO\">" + tgNo + "</C>\n" +
                "</R>\n" +
                "</DBSET>\n";
        Object[] objects = client.invoke(opName, sendXml);
        if(objects == null || objects.length==0){
            System.out.println("接口返回参数为空");
        }
        /*接收服务端返参*/
        String  resultxml = (String) objects[0];
        System.out.println("获取售电量明细返回的xml数据"+resultxml);
        System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    LinelossSpq linelossSpq = new LinelossSpq();
                    linelossSpq.setConsNo(generals.get(2).getValue());
                    linelossSpq.setConsName(generals.get(3).getValue());
                    linelossSpq.setConsType(generals.get(4).getValue());
                    linelossSpq.setElecAddr(generals.get(5).getValue());
                    linelossSpq.setTerminalAddr(generals.get(6).getValue());
                    linelossSpq.setTotalPointsIdent(generals.get(7).getValue());
                    linelossSpq.setDataDate(new SimpleDateFormat("yyyy-MM-dd").parse(generals.get(8).getValue()));
                    linelossSpq.setStartpapE(new BigDecimal("".equals(generals.get(9).getValue())?"0":generals.get(9).getValue()));//
                    linelossSpq.setEndpapE(new BigDecimal("".equals(generals.get(10).getValue())?"0":generals.get(10).getValue()));
                    linelossSpq.setPapE(new BigDecimal("".equals(generals.get(11).getValue())?"0":generals.get(11).getValue()));
                    linelossSpq.setStartrapE(new BigDecimal("".equals(generals.get(12).getValue())?"0":generals.get(12).getValue()));
                    linelossSpq.setEndrapE(new BigDecimal("".equals(generals.get(13).getValue())?"0":generals.get(13).getValue()));
                    linelossSpq.setRapE(new BigDecimal("".equals(generals.get(14).getValue())?"0":generals.get(14).getValue()));
                    linelossSpq.setTgSpq(new BigDecimal("".equals(generals.get(15).getValue())?"0":generals.get(15).getValue()));
                    linelossSpq.setUsageTypeCode(generals.get(17).getValue());
                    linelossSpq.setTFactor(new BigDecimal("".equals(generals.get(18).getValue())?"0":generals.get(18).getValue()));
                    linelossSpq.setCt(generals.get(19).getValue());
                    linelossSpq.setPt(generals.get(20).getValue());
                    linelossSpq.setMeterAssetNo(generals.get(21).getValue());
                    linelossSpq.setFmrAssetNo(generals.get(22).getValue());
                    linelossSpq.setMpSn(generals.get(23).getValue());
                    spqList.add(linelossSpq);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return spqList;
    }


    /**
     * 低压远程费控执行
     * @param //appNo 工单编号 String appNo
     * @return
     */
    @RequestMapping("test13")
    public FeeData Fee(){
        String startTime = TimeUtil.getStartTwoTime();
        List<General> generals;
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("获取低压远程费控执行连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "statisticalDetail");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("statisLineLossData".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
        String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<DBSET>\n" +
                "<R>\n" +
                "<C N=\"app_no\">" + "" + "</C>\n" +
                "<C N=\"bgn_time\">" + "" + "</C>\n" +
                "<C N=\"end_time\">" + "" + "</C>\n" +
                "<C N=\"tg_no\">" + "" + "</C>\n" +
                "<C N=\"terminal_addr\">" + "" + "</C>\n" +
                "<C N=\"control_type\">" + "" + "</C>\n" +
                "</R>\n" +
                "</DBSET>\n";
            Object[] objects = client.invoke(opName, sendXml);
            if(objects == null || objects.length==0){
                System.out.println("接口返回参数为空");
            }
            /*接收服务端返参*/
            String  resultxml = (String) objects[0];
            System.out.println("获取1返回的xml数据"+resultxml);
            System.out.println("字符串长度:"+resultxml.length());
            if(resultxml.length()>155) {
                List<LinelossSynana> linelossys = new ArrayList<>();
                /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                /*获取解析之后的General对象*/
                List<General> demo2 = demo1.getDemo2().getGeneral();
                List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                for (List<General> demo3 : demo3s) {
                    generals = Stream.of(demo2, demo3)
                            .flatMap(Collection::stream)
                            .collect(Collectors.toList());
                    //<C N="LOSS_PQ"></C> 损失电量 get(12)
                    //<C N="L_LLR_REAL"></C> 线损率get(13)
                    if (generals.size() != 0) {
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 高级应用-HPLC管理-相位拓扑识别 电能表相位信息
     * @param //tgno 台区编号 String tgno
     */
    @RequestMapping("test14")
    public List<PhaseFlag> PhaseFlag(){
        //入参mr_date字符串 （2022-12-15）
        String startTime = TimeUtil.getStartTime();
        String mr_date = "2022-10-01";
        String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<DBSET>\n" +
                "<R>\n" +
                "<C N=\"tg_no\">" + "1800000186" + "</C>\n" +
                "<C N=\"mr_date\">" + mr_date + "</C>\n" +
                "</R>\n" +
                "</DBSET>\n";
        WebServiceDemo webServiceDemo = new WebServiceDemo();
        List<General> generals = webServiceDemo.testSendCollFail(sendXml, "statisHplcPhasePositionData",this.getClient());
        List<PhaseFlag> phaseFlags = new ArrayList<>();
        PhaseFlag phaseFlag = new PhaseFlag();
        phaseFlag.setOrgName(generals.get(2).getValue());
        phaseFlag.setTgNo(generals.get(3).getValue());
        phaseFlag.setTgName(generals.get(4).getValue());
        phaseFlag.setTerminalAddr(generals.get(5).getValue());
        phaseFlag.setDmetTypeCode(generals.get(6).getValue());
        phaseFlag.setFhloadFlag(generals.get(7).getValue());
        phaseFlag.setPhaseCode(generals.get(8).getValue());
        phaseFlag.setConsNo(generals.get(9).getValue());
        phaseFlag.setConsName(generals.get(10).getValue());
        phaseFlag.setCommAddr(generals.get(11).getValue());
        phaseFlag.setElecAddr(generals.get(12).getValue());
        phaseFlag.setProtocolCode(generals.get(13).getValue());
        phaseFlag.setPhaseFlag(generals.get(14).getValue());
        phaseFlag.setSpq(new BigDecimal(generals.get(15).getValue()));
        phaseFlag.setUsageTypeCode(generals.get(16).getValue());
        System.out.println(phaseFlag);
        phaseFlags.add(phaseFlag);
        return phaseFlags;
    }





    /**
     * 电能表正向有功总，单次透抄，可通过查询终端实时数据实现
     * @param //terminalAddr 终端地址 String terminalAddr, "000070061468"
     * @param //meterAssetNo  电能表资产号  String meterAssetNo  "1540001011500318563394"
     */
    @RequestMapping("test15")
    public RealTimeData getSendPap(@RequestParam String terminalAddr,@RequestParam String meterAssetNo) {
        //入参tg_no字符串
        String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                    "<DBSET>\n" +
                    "<R>\n" +
                    "<C N=\"terminal_addr\">" + terminalAddr + "</C>\n" +
                    "<C N=\"meter_asset_no\">" + meterAssetNo + "</C>\n" +
                    "</R>\n" +
                    "</DBSET>\n";
        WebServiceDemo webServiceDemo = new WebServiceDemo();
        List<General> generals = webServiceDemo.testSendCollFail(sendXml, "getMeterPapR",this.getClient());
        RealTimeData realTimeData = new RealTimeData();
        realTimeData.setTerminalAddr(generals.get(2).getValue());
        realTimeData.setMeterAssetNo(generals.get(3).getValue());
        realTimeData.setPapE(new BigDecimal(generals.get(4).getValue()));
        System.out.println(realTimeData);
        return realTimeData;

    }


    /**
     * 费控开关状态，单次透抄
     *   电能表资产号 1540001011500318563394
     * @return
     */
    @RequestMapping("test16")
    @Async
    @Scheduled(cron = "0 0 00 * * ?")
    public void getFeeswitch() {
        List<General> generals = Lists.newArrayList();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        List<ConAssetNo> consNos = feecontrolWorkOrderMapper.selectFeeWorkwebservice();
        List<ConAssetNo> conAssetNos = feecontrolWorkOrderMapper.selectconsAssetNo(consNos);
        System.out.println("费控归档请求连接");
        /*创建动态客户端*/
        System.out.println("费控归档1");
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        System.out.println("费控归档2");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            System.out.println("费控归档3");
            HTTPConduit http = (HTTPConduit) client.getConduit();
            System.out.println("费控归档4");
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "getStatusCharacterThree");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("getStatusCharacterThree".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }

            for (ConAssetNo conAssetNo : conAssetNos) {
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"meter_asset_no\">" + conAssetNo.getAssetNo() + "</C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";
                Object[] objects = client.invoke(opName, sendXml);
                if (objects == null || objects.length == 0) {
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String resultxml = (String) objects[0];
                System.out.println("字符串长度:" + resultxml.length()+"获取返回的xml数据" + resultxml);
                if (resultxml.length() > 150) {
                    /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                    for (List<General> demo3 : demo3s) {
                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());
                        if (generals.size() != 0) {
                            String status = generals.get(3).getValue();//获取电能表资产号开关状态
                            if("通".equals(status)){
                                Integer i = feecontrolWorkOrderMapper.updateFeeStatus(conAssetNo.getConsNo());
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /** 有数据
     * 电能表相位 单次透抄
     * @param commAddr 电能表地址 000001053176
     * @return
     */
    @RequestMapping("test17")
    public RealTimeData getPhaseflag(@RequestParam String commAddr) {
        //入参tg_no字符串
        String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                "<DBSET>\n" +
                "<R>\n" +
                "<C N=\"comm_addr\">" + commAddr + "</C>\n" +
                "</R>\n" +
                "</DBSET>\n";
        WebServiceDemo webServiceDemo = new WebServiceDemo();
        List<General> generals = webServiceDemo.testSendCollFail(sendXml, "getPhaseFlag",this.getClient());
        RealTimeData realTimeData = new RealTimeData();
        realTimeData.setCommAddr(generals.get(2).getValue());
        realTimeData.setPhaseFlag(generals.get(3).getValue());
        return realTimeData;
    }


    /**
     * 配网感知 givePowerOffOnRepairOrder  抢修
     */
    @RequestMapping("test18")
    @Async
    @Scheduled(cron = "0 0/30 7-17 * * ?")
    public String getRepairOrder() {
        int i = 0;
        List<RepairsWorkOrder> repairwos = new ArrayList<>();
        List<General> generals = Lists.newArrayList();
        //入参mr_date字符串 （2022-12-15）
        String startTime = TimeUtil.getTodayTime();
        String wsdlUrl = "http://10.173.14.201:20013/service/CJ_INTERFACE?wsdl";
        /*创建动态客户端*/
        JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
        /*创建本地客户端连接*/
        System.out.println("获取客户端连接");
        Client client = dcf.createClient(wsdlUrl);
        try {
            /*初始化反参集合*/
            HTTPConduit http = (HTTPConduit) client.getConduit();
            http.getClient().setReceiveTimeout(0);
            HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
            httpClientPolicy.setConnectionTimeout(80000);// 连接超时(毫秒)
            httpClientPolicy.setAllowChunking(false);// 取消块编码
            httpClientPolicy.setReceiveTimeout(80000);// 响应超时(毫秒)
            Endpoint endpoint = client.getEndpoint();
            QName opName = new QName(endpoint.getService().getName().getNamespaceURI(), "givePowerOffOnRepairOrder");
            BindingInfo bindingInfo = endpoint.getEndpointInfo().getBinding();
            if (bindingInfo.getOperation(opName) == null) {
                for (BindingOperationInfo operationInfo : bindingInfo.getOperations()) {
                    if ("givePowerOffOnRepairOrder".equals(operationInfo.getName().getLocalPart())) {
                        opName = operationInfo.getName();
                        break;
                    }
                }
            }
            List<String> lists = collwoMapper.selectOrgList();
            for (String orgNo :lists) {
                //入参tg_no字符串
                String sendXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
                        "<DBSET>\n" +
                        "<R>\n" +
                        "<C N=\"orgNo\">" + orgNo + "</C>\n" +
                        "<C N=\"workType\"></C>\n" +
                        "<C N=\"faultType\"></C>\n" +
                        "<C N=\"workStatus\"></C>\n" +
                        "<C N=\"workType\"></C>\n" +
                        "<C N=\"faultTime\">" + TimeUtil.getTodayTime() + "</C>\n" +
                        "<C N=\"lineRoadName\"></C>\n" +
                        "<C N=\"lineRoadNo\"></C>\n" +
                        "<C N=\"workNo\"></C>\n" +
                        "</R>\n" +
                        "</DBSET>\n";

                Object[] objects = client.invoke(opName, sendXml);
                if (objects == null || objects.length == 0) {
                    System.out.println("接口返回参数为空");
                }
                /*接收服务端返参*/
                String resultxml = (String) objects[0];
                System.out.println("字符串长度:" + resultxml.length() + "获取返回的xml数据" + resultxml);
                if (resultxml.length() > 155) {
                    List<CollectFailure> collFails = new ArrayList<>();
                    /*通过转化器内部实现，将接收到的反参数据解析为Java对象*/
                    Demo1 demo1 = XStreamUtils.xmlToObject(resultxml, Demo1.class, new DemoConverter());
                    /*获取解析之后的General对象*/
                    List<General> demo2 = demo1.getDemo2().getGeneral();
                    List<List<General>> demo3s = demo1.getDemo3().getGeneral();
                    for (List<General> demo3 : demo3s) {
                        generals = Stream.of(demo2, demo3)
                                .flatMap(Collection::stream)
                                .collect(Collectors.toList());
                        System.out.println("generals长度" + generals.size());
                        if (generals.size() != 0) {
                            RepairsWorkOrder repairwo = new RepairsWorkOrder();
                            repairwo.setWorkNo(generals.get(2).getValue());
                            repairwo.setCityOrgNo(generals.get(3).getValue());
                            repairwo.setCityOrgName(generals.get(4).getValue());
                            repairwo.setOrgNo(generals.get(5).getValue());
                            repairwo.setOrgName(generals.get(6).getValue());
                            repairwo.setWorkType(generals.get(7).getValue());
                            repairwo.setFaultType(generals.get(8).getValue());
                            repairwo.setWorkStatus(generals.get(9).getValue());
                            repairwo.setLineRoadName(generals.get(10).getValue());
                            repairwo.setLineRoadNo(generals.get(11).getValue());
                            repairwo.setFaultName(generals.get(12).getValue());
                            repairwo.setOrderId(generals.get(13).getValue());
                            repairwo.setFaultTime(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").parse((generals.get(14).getValue().equals("")) ? "0000-00-00 00:00:00" : generals.get(14).getValue()));
                            repairwos.add(repairwo);
                        }
                    }
                }
                for (RepairsWorkOrder repairwo : repairwos) {
                    if(repairsWorkOrderMapper.selectRepairs(repairwo.getWorkNo())==0) {
                        i += repairsWorkOrderMapper.insertRepairs(repairwo);
                    }
                }

                //查询需要预警的主动抢修工单
                List<RepairsWorkOrder> repairsWorkOrders = repairsWorkOrderMapper.selectCycleOneList();
                if (repairsWorkOrders.size() > 0){
                    for (RepairsWorkOrder repairsWorkOrder : repairsWorkOrders) {
                        repairsWorkOrderMapper.updateCycle(repairsWorkOrder.getWorkNo(), ONE_GRADE);
                    }
                }

            }
            } catch (Exception e) {
            e.printStackTrace();
        }
            return "配网感知"+i;
    }

    /**
     * 通过定时任务查询出生成工单35分钟后的全部未处理 主动抢修工单
     * @return
     */
    @RequestMapping("getCycleTwoList")
    @ResponseBody
    @Async
    @Scheduled(cron = "0 5,35 * * * ?")
    public String getCycleTwoList(){
        List<RepairsWorkOrder> repairsWorkOrders = repairsWorkOrderMapper.selectCycleTwoList();
        if (repairsWorkOrders.size() > 0){
            for (RepairsWorkOrder repairsWorkOrder : repairsWorkOrders) {
                repairsWorkOrderMapper.updateCycle(repairsWorkOrder.getWorkNo(), ONE_GRADE);
            }
        }
        return "主动抢修预警数据";
    }

    /**
     * 主动运维预警工单生成
     * @return
     */
//    @RequestMapping("getOperationAndMaintenance")
//    @ResponseBody
//    @Async
//    @Scheduled(cron = "0 30/30 8-17 * * ?")
//    public String getOperationAndMaintenance(){
//        Integer voltage = 0;
//        MmdHEMpVolCurve curve = new MmdHEMpVolCurve();
//        if (ObjectUtil.isNotEmpty(curve)){
//            if (((new BigDecimal("220").subtract(curve.getU1())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//                voltage += 1;
//            }
//            if (((new BigDecimal("220").subtract(curve.getU2())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU3())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU4())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU5())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU6())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU7())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU8())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU9())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU10())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU11())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU12())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU13())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU14())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU15())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU16())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU17())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU18())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU19())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU20())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU21())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU22())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU23())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU24())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU25())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU26())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU27())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU28())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU29())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU30())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU31())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU32())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU33())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU34())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU35())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU36())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU37())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU38())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU39())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU40())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU41())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU42())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU43())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU44())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU45())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU46())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU47())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU48())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU49())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU50())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU51())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU52())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU53())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU54())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU55())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU56())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU57())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU58())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU59())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU60())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU61())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU62())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU63())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU64())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU65())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU66())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU67())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU68())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU69())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU70())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU71())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU72())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU73())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU74())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU75())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU76())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU77())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU78())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU79())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU80())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU81())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU82())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU83())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU84())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU85())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU86())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU87())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU88())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU89())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU90())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU91())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU92())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU93())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU94())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU95())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//            if (((new BigDecimal("220").subtract(curve.getU96())).divide(new BigDecimal("220"), 2, RoundingMode.HALF_UP)).compareTo(new BigDecimal("0.10")) > 0){
//
//            }
//        }
//        return "主动运维数据";
//    }

}
