package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.DMeter;

/**
* @author 李木
* @description 针对表【d_meter(电能表信息)】的数据库操作Service
* @createDate 2023-02-25 18:01:28
*/
public interface DMeterService extends IService<DMeter> {

}
