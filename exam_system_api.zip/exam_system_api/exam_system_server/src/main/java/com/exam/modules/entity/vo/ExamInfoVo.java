package com.exam.modules.entity.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.exam.modules.entity.ExamInfo;
import lombok.Data;

/**
 * @Author dyy
 * @Date 2022/11/22 11:35
 * @PackageName:com.exam.modules.entity.vo
 * @ClassName: ExamInfoVo
 * @Description: TODO
 * @Version 1.0
 */
@Data
public class ExamInfoVo extends ExamInfo {
    private Long pageNo = 1L;//当前页码
    private Long pageSize = 10L;//每页显示数量
}
