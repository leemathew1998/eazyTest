package org.dfzt.util;

import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.po.MeterCurrentVoltage;

import java.math.BigDecimal;

@Slf4j
public class VPointUtil {

    public static int  VPoint(MeterCurrentVoltage meterCurrentVoltage , BigDecimal d){
        //（额定电压的90%）
        BigDecimal multiply = meterCurrentVoltage.getVoltage().multiply(d);
        //判断96点是否大于（额定电压的90%）
        if (meterCurrentVoltage.getV1().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV2().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV3().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV4().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV5().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV6().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV7().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV8().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV9().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV10().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV11().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV12().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV13().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV14().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV15().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV16().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV17().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV18().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV19().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV20().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV21().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV22().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV23().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV24().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV25().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV26().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV27().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV28().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV29().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV30().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV31().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV32().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV33().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV34().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV35().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV36().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV37().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV38().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV39().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV40().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV41().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV42().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV43().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV44().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV45().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV46().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV47().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV48().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV49().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV50().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV51().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV52().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV53().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV54().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV55().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV56().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV57().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV58().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV59().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV60().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV61().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV62().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV63().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV64().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV65().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV66().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV67().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV68().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV69().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV70().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV71().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV72().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV73().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV74().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV75().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV76().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV77().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV78().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV79().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV80().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV81().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV82().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV83().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV84().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV85().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV86().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV87().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV88().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV89().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV90().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV91().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV92().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV93().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV94().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV95().compareTo(multiply) == -1){
            return 1;
        }else if (meterCurrentVoltage.getV96().compareTo(multiply) == -1){
            return 1;
        }
        return 0;
    }

}
