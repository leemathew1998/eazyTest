package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.DMeter2;

/**
 * (DMeter2)表服务接口
 *
 * @author makejava
 * @since 2022-08-01 10:10:42
 */
public interface DMeter2Service extends IService<DMeter2> {

}

