package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.dfzt.entity.po.OOrg;

import java.util.List;
import java.util.Map;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
@Mapper
public interface OOrgMapper extends BaseMapper<OOrg> {
    @DS("mpg")
    List<OOrg> selectOrg();

    Integer insertOrg(OOrg oOrg);

    Integer selectByorgno(String orgNo);

    @DS("mpgt")
    List<OOrg> selectPowerInfo(List<String> consNos);
}