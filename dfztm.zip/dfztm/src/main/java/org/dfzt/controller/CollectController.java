package org.dfzt.controller;

import cn.hutool.core.date.DateTime;
import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.google.common.collect.Lists;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.endpoint.Endpoint;
import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;
import org.apache.cxf.service.model.BindingInfo;
import org.apache.cxf.service.model.BindingOperationInfo;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.dfzt.annotation.CurrentUser;
import org.dfzt.entity.po.FeecontrolWorkOrder;
import org.dfzt.entity.po.WorkOrderInfor;
import org.dfzt.entity.po.SuperiorWorkOrder;
import org.dfzt.entity.vo.*;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.entity.xmlDemoReal.Demo1;
import org.dfzt.entity.xmlDemoReal.DemoConverter;
import org.dfzt.entity.xmlDemoReal.General;
import org.dfzt.mapper.*;
import org.dfzt.service.*;
import org.dfzt.util.*;
import org.dfzt.webservice.WebServiceSchedule;
import org.json.JSONException;
import org.json.JSONObject;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.dfzt.entity.po.*;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import java.io.*;
import java.math.BigDecimal;
import java.net.*;
import java.nio.charset.Charset;
import java.sql.Time;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/11
 * @Version: 1.00
 * TODO 采集运维
 */
@RestController
@Slf4j
@CrossOrigin
@RequestMapping("/coll")
@Api(value = "采集运维")
public class CollectController extends ApiController {

    @Autowired
    private WorkOrderInforService workOrderInforService;

    @Autowired
    private CollectWorkOrderService collectWorkOrderService;

    @Autowired
    private CollectWorkOrderMapper collectWorkOrderMapper;

    @Resource
    private OOrgMapper oOrgMapper;

    @Resource
    private GTgMapper gTgMapper;
    @Resource
    private CContactMapper cContactMapper;
    @Resource
    private CElecAddrMapper cElecAddrMapper;
    @Resource
    private CInformationMapper cInformationMapper;
    @Resource
    private ElectricityPriceMapper electricityPriceMapper;
    @Resource
    private OStaffMapper oStaffMapper;
    @Resource
    private S95598WkstMapper s95598WkstMapper;
    @Resource
    private SuperiorWorkOrderService superiorWorkOrderService;
    @Resource
    private CConsService cConsService;
    @Resource
    private S95598WkstService s95598WkstService;
    @Resource
    private FeecontrolWorkOrderService feecontrolWorkOrderService;

    @Resource
    private FeecontrolWorkOrderMapper feecontrolWorkOrderMapper;
    @Resource
    private ARcvblFlowMapper aRcvblFlowMapper;

    @Resource
    private SqlSessionTemplate sqlSessionTemplate;

    /**
     * 级别
     */
    private final static String ONE_GRADE = "1";
    private final static String TWO_GRADE = "2";
    /**
     * 工单状态
     */
    private final static String ONE_STATUS = "1";
    private final static String TWO_STATUS = "2";
    private final static String THREE_STATUS = "3";
    private final static String FOUR_STATUS = "4";

    @ResponseBody
    @GetMapping("gettest")
    public void getTTest(){
        System.out.println("探针请求测试");
    }


    @RequestMapping("testmpg")
    @ResponseBody
    public void getTestMpg(){
        Object o = collectWorkOrderMapper.selectMdpg();
        Object c = collectWorkOrderMapper.selectMCons();
        System.out.println("中台数据库查询tg表:"+o);
        System.out.println("中台数据库查询用户表:"+c);
    }

    @RequestMapping("getNum")
    @ResponseBody
    public String getNum(@RequestParam String num){
        System.out.println("测试时间接口:"+TimeUtil.getTodayTime());
        System.out.println("前端传回的参数num为:"+num);
        return TimeUtil.getTodayTime()+"num为"+num;
    }

    @RequestMapping(value = "getOrg" , produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getOrg(){
        int i=0;
        List<OOrg> oOrgs = oOrgMapper.selectOrg();
        for (OOrg oOrg : oOrgs) {
            if(oOrgMapper.selectByorgno(oOrg.getOrgNo())==0){
                Integer j = oOrgMapper.insertOrg(oOrg);
                System.out.println(j);
                i=i+j;
            }
        }
        return "新增成功条数:"+i;
    }


    @RequestMapping(value = "getGTg" , produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getGTg(){
        int i = 0;
        try {
            List<GTg> gTgs = gTgMapper.selectTg();
            for (GTg gTg : gTgs) {
                if(gTgMapper.selectBytgid(gTg.getTgId())==0) {
                    i += gTgMapper.insertGTg(gTg);
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            System.out.println(e);
        }
        return "新增成功条数:"+i;
    }

    @RequestMapping(value = "getCCons" , produces = "application/json;charset=utf-8")
    @ResponseBody
//    @Scheduled(cron = "0 0 1 26 * ? ")
    public String getCCons(){
        int i = 0;
        List<CCons> cCons = cContactMapper.selectCCons("154212206");
        for (CCons cCon : cCons) {
            if(cContactMapper.selectByconsId(cCon.getConsId())==0){
                i += cContactMapper.insertCCons(cCon);
            }
        }
        return "新增条数:"+i;
    }


    @RequestMapping(value = "getCElecAddr" , produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getCElecAddr(){
        int i = 0;
        List<CElecAddr> cElecAddrs = cElecAddrMapper.selectCElecAddr("154212206");
        for (CElecAddr cElecAddr : cElecAddrs) {
            if (cElecAddrMapper.selectByconsId(cElecAddr.getConsId())==0){
                i += cElecAddrMapper.insertCElecAddr(cElecAddr);
            }
        }
        return "新增条数:"+i;
    }

    @RequestMapping(value = "getCContact" , produces = "application/json;charset=utf-8")//获取用户联系方式表
    @ResponseBody
    public String getCContact(){

        int i = 0;
        for (BigDecimal bigDecimal : cContactMapper.selectCustIdList()) {
            for (CContact cContact : cContactMapper.selectCConTact(bigDecimal)) {
                i += cContactMapper.insertCContact(cContact);
            }
        }
        return "新增条数:"+i;
    }

    @RequestMapping(value = "getOStaff" , produces = "application/json;charset=utf-8")//获取用户联系方式表
    @ResponseBody
    public String getOStaff(){
        int i = 0;
        List<OStaff> oStaffs = oStaffMapper.selectOsList();
        for (OStaff oStaff : oStaffs) {
            i += oStaffMapper.insertOStaff(oStaff);
        }
        return "新增条数:"+i;
    }

    @RequestMapping(value = "getCSp" , produces = "application/json;charset=utf-8")//获取受电点信息
    @ResponseBody
    public String getCSp(){
        int i = 0;
        int j = 0;
        CInformation cInformation = new CInformation();
        for (BigDecimal bigDecimal : cInformationMapper.selectConsIdList()) {
            for (CSp cSp : cInformationMapper.selectScp(bigDecimal)) {
                if (StringUtils.isEmpty(cSp)) {
                    j += j;
                } else {
                    cInformation.setKeyId(String.valueOf(cSp.getSpId()));
                    cInformation.setPowerPointNo(String.valueOf(cSp.getSpId()));
                    cInformation.setEleName(cSp.getSpName());
                    cInformation.setNumOfPowerSupplies(cSp.getPsNumCode());
                    cInformation.setConsNo(String.valueOf(cSp.getConsId()));
                    i += cInformationMapper.insertSCP(cInformation);
                }
            }
        }
        return "新增条数:"+i+"j:"+j;
    }

    @RequestMapping(value = "getSPrcTactic" , produces = "application/json;charset=utf-8")//获取定价策略信息
    @ResponseBody
    public String getSPrcTactic(){
        int i = 0;
        int j = 0;
        ElectricityPrice elecPrice = new ElectricityPrice();
        for (BigDecimal bigDecimal : electricityPriceMapper.selectKeyIdList()) {
            for (SPrcTacticScheme sPrcScheme : electricityPriceMapper.selectSPrc(bigDecimal)) {
                if (StringUtils.isEmpty(sPrcScheme)) {
                    j += j;
                } else {
                    elecPrice.setKeyId(String.valueOf(sPrcScheme.getSpId()));
                    elecPrice.setPriceStrategy(sPrcScheme.getTypeCode());
                    elecPrice.setBasicCalMethod(sPrcScheme.getBaCalcMode());
                    elecPrice.setDeValue(String.valueOf(sPrcScheme.getDmdSpecValue()));
                    elecPrice.setAssMethod(sPrcScheme.getPfEvalMode());
                    elecPrice.setConsNo(String.valueOf(sPrcScheme.getConsId()));
                    i += electricityPriceMapper.insertSPrc(elecPrice);
                }
            }
        }
        return "新增条数:"+i+"j:"+j;
    }


    /**
     * TODO 添加分页的采集运维列表
     * @param map
     * @return
     */
    @ResponseBody
    @PostMapping("listp")
    public R<IPage<CollectWorkOrder>> pageList(@RequestBody Map<String,Object> map){
        IPage<CollectWorkOrder> iPage = collectWorkOrderService.selectAllYWO1(map);
        return success(iPage);
    }


//
//    /**
//     * TODO 导入excel数据
//     * @param file
//     * @return
//     */
//    @ResponseBody
//    @RequestMapping("/import")
//    public String uploadExcel(@RequestParam("file") MultipartFile file) {
//        try {
//            long startTime = System.currentTimeMillis();
//
//            String name = file.getOriginalFilename();
//            if(name.contains("采集失败")){
//                List<CollectFailure> list = ExcelUtils.importExcel(file, CollectFailure.class);
//                System.out.println("------>采集失败------>");
//                for (int i = 0; i < list.size(); i++) {
//                    System.out.println(list.get(i));
//                    collectFailureService.insertSelective(list.get(i));
//                }
//                collectFailureService.selectAllFail(TimeUtil.getStartTime(), TimeUtil.getEndTime());
//            }else if(name.contains("采集异常")){
//                List<CollectInforma> list = ExcelUtils.importExcel(file, CollectInforma.class);
//                System.out.println("------>采集异常------>");
//                for (int i = 0; i < list.size(); i++) {
//                    System.out.println(list.get(i));
//                    collectInformaService.insertSelective(list.get(i));
//                }
//                collectInformaService.selectAllInfor(TimeUtil.getStartTime(), TimeUtil.getEndTime());
//            }else if(name.contains("采集未接入")){
//                List<CollectNotcon> list = ExcelUtils.importExcel(file, CollectNotcon.class);
//                System.out.println("------>采集未接入------>");
//                for (int i = 0; i < list.size(); i++) {
//                    System.out.println(list.get(i));
//                    collectNotconService.insertSelective(list.get(i));
//                }
//                collectNotconService.selectAllNotCon(TimeUtil.getStartTime(),TimeUtil.getEndTime());
//            }
//            List<CollectYwWorkOrderv> AllcollecList = collectYwWorkOrderService.selectAllYWO();
//            for (CollectYwWorkOrderv collectywov : AllcollecList) {
//                achievementsManagerService.selectdayPoint(collectywov.getAreaManagerDesk());
//            }
//
//
//            long endTime = System.currentTimeMillis();
//            System.out.println("用时：" + (endTime - startTime));
//
//        } catch (Exception e) {
//            e.printStackTrace();
//            return "系统异常";
//        }
//        return "数据导入完成";
//    }


    /**
     * TODO 采集运维工单列表
     * @return
     */
    @ResponseBody
    @PostMapping("/list")
    @ApiOperation(value = "查询所有工单信息")
    public R CollectWorkOrderList() {
        List<CollectWorkOrder> collects= collectWorkOrderService.selectAllYWO();
        if (collects.size() < 1){
            return success("采集列表为空").setMsg("查询失败").setCode(500);
        }
        return success(collects).setMsg("查询成功").setCode(200);
    }

    //获取预警个数
    @PostMapping("/getWarnNum")
    public Map<String,Integer> getWarnNum(@RequestParam String wkId){//工单标识
        Map map = new HashMap();
        //查询
        if(wkId.equals("1")){
            //Map<String, Integer> map1 = collectWorkOrderMapper.selectcollStaNum1(TimeUtil.getTodayTime());
            //Map<String, Integer> map1 = collectWorkOrderMapper.selectcollStaNum1(TimeUtil.getTodayTime());
            //Map<String, Integer> warnNumUtil1 = TimeUtil.getWarnNumUtil(map1);
//            map.put("sAll",warnNumUtil1.get("1")+warnNumUtil1.get("2")+warnNumUtil1.get("3"));
//            map.put("s1",warnNumUtil1.get("1"));
//            map.put("s2",warnNumUtil1.get("2"));
//            map.put("s3",warnNumUtil1.get("3"));
            Integer i1 = collectWorkOrderMapper.selectWorkWarns1(TimeUtil.getStart5Time());
            if(i1==null)i1=0;
            map.put("sAll",i1);
            map.put("s1",0);
            map.put("s2",0);
            map.put("s3",0);
        }else if(wkId.equals("2")){
            Integer i2 = collectWorkOrderMapper.selectWorkWarns2(TimeUtil.getStart5Time());
            if(i2==null)i2=0;
            map.put("sAll",i2);
            map.put("s1",0);
            map.put("s2",0);
            map.put("s3",0);
        }else if(wkId.equals("3")){
            Integer i3 = collectWorkOrderMapper.selectWorkWarns3(TimeUtil.getStart5Time());
            if(i3==null)i3=0;
            map.put("sAll",i3);
            map.put("s1",0);
            map.put("s2",0);
            map.put("s3",0);
        }else if(wkId.equals("4")){
            Integer i4 = collectWorkOrderMapper.selectWorkWarns4(TimeUtil.getStart5Time());
            if(i4==null)i4=0;
            map.put("sAll",i4);
            map.put("s1",0);
            map.put("s2",0);
            map.put("s3",0);
        }else if(wkId.equals("5")){
            Integer i5 = collectWorkOrderMapper.selectWorkWarns5(TimeUtil.getNowMonY());
            if(i5==null)i5=0;
            map.put("sAll",i5);
            map.put("s1",0);
            map.put("s2",0);
            map.put("s3",0);
        }else if(wkId.equals("6")){
            Integer i6 = collectWorkOrderMapper.selectWorkWarns6(TimeUtil.getNowMonY());
            if(i6==null)i6=0;
            map.put("sAll",i6);
            map.put("s1",0);
            map.put("s2",0);
            map.put("s3",0);
        }else if(wkId.equals("7")){
            Integer i7 = collectWorkOrderMapper.selectWorkWarns7(TimeUtil.getStart5Time());
            if(i7==null)i7=0;
            map.put("sAll",i7);
            map.put("s1",0);
            map.put("s2",0);
            map.put("s3",0);
        }else{
            map.put("sAll",0);
            map.put("s1",0);
            map.put("s2",0);
            map.put("s3",0);
        }
        return map;
    }

    /**
     * TODO 采集运维工单条件搜索-Web端口
     * @return
     */
    //@ResponseBody
    @PostMapping("/list1")
    public R CollectWorkOrderList1(CollectWorkOrder c,
                                   HttpServletRequest request,
                                   @RequestParam(name = "pageNo",defaultValue = "1") String pageNo,
                                   @RequestParam(name = "pageSize",defaultValue = "10") String pageSize,
                                   @RequestParam(required = false) String status,
                                   @RequestParam(required = false) String orgNo,
                                   @RequestParam(required = false) String loName2,
                                   @RequestParam(required = false) String role,
                                   @RequestParam(required = false) String loginName) {

//        String orgName = null;
        List<String> orgNames=null;
        if("1".equals(role)){
            orgNames.add(collectWorkOrderMapper.selectOrgNo(collectWorkOrderMapper.selectOrgNoByrole(loName2)));
        }else if("3".equals(role)){
            orgNames = collectWorkOrderMapper.selectOrgNos(collectWorkOrderMapper.selectOrgNoByrole(loName2));
        }
//        if (orgNo !=null || "".equals(orgNo)) {
//            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
//        }
//        List<String> roles = collectWorkOrderMapper.selectRoles(loName2);
//        String role = roles.get(0);
        String pageNo1 = String.valueOf((Integer.parseInt(pageNo)-1)*Integer.parseInt(pageSize));
        List<CollectWorkOrder> AllcollecList = collectWorkOrderService.selectList1(c,loName2,role,pageNo1,pageSize,orgNames,status);
        int size = collectWorkOrderService.selectList1(c, loName2, role, "0", "999999999",orgNames,status).size();
        Map<Integer,List<CollectWorkOrder>> map = new HashMap<>();
        map.put(size,AllcollecList);
        return success(map);
    }

    @RequestMapping("export")  //excel/export
    public void exportExcel2(HttpServletResponse response, @RequestParam String ids) throws IOException {
        List<CollectWorkOrder> collectWorkOrders = collectWorkOrderMapper.selectExcel1(ids);
        ExcelUtils.exportExcel(collectWorkOrders, "采集运维工单列表", "采集运维", CollectWorkOrder.class, "采集运维工单文件", response);
    }

    @RequestMapping("exportAll")  //excel/export
    public void exportExcel2All(HttpServletResponse response, @RequestParam(required = false) String ids,CollectWorkOrder c,
                                @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,
                                @RequestParam(required = false) String loName2,@RequestParam(required = false) String role,
                                @RequestParam(required = false) String loginName) throws IOException {
        String orgName=null;
        List<String> orgNames=null;
        if("1".equals(role)){
            orgNames.add(collectWorkOrderMapper.selectOrgNo(collectWorkOrderMapper.selectOrgNoByrole(loName2)));
        }else if("3".equals(role)){
            orgNames = collectWorkOrderMapper.selectOrgNos(collectWorkOrderMapper.selectOrgNoByrole(loName2));
        }
        List<CollectWorkOrder> AllcollecList = collectWorkOrderService.selectList1(c,loName2,role,"0","999999999",orgNames,status);
        ExcelUtils.exportExcel(AllcollecList, "采集运维工单列表", "采集运维", CollectWorkOrder.class, "采集运维工单文件", response);
    }


    /**
     * TODO 采集运维工单个条件搜索-APP端
     * @return.
     */
    @ResponseBody
    @PostMapping("/list2")
    public List<CollectWorkOrder> selectlist2(String one,@RequestParam(name = "pageNo",defaultValue = "0") String pageNo,
                                              @RequestParam(name = "pageSize",defaultValue = "10") String pageSize,@RequestParam String workOrderStatus,
                                              @RequestParam(required = false) String loName2,@RequestParam(required = false) String orgNo,
                                              @RequestParam(required = false) String role,@RequestParam(required = false) String loginName) {
        //List<CollectWorkOrder> collectWorkOrders = collectWorkOrderMapper.selectCollByLoName1(loName2);//判断当前登录是不是台区经理
        List<String> orgName = new ArrayList<>();
        List<String> readNames = collectWorkOrderMapper.selectReadNames(loginName);
        if ("2".equals(role)) {
            List<CollectWorkOrder> collectList = collectWorkOrderService.selectList2(readNames,one, loName2, Integer.parseInt(pageNo), Integer.parseInt(pageSize), workOrderStatus, orgName,role);
            return collectList;
        }
        return collectWorkOrderService.selectList2(readNames,one, loName2, Integer.parseInt(pageNo), Integer.parseInt(pageSize), workOrderStatus, orgName,role);
    }



    @ResponseBody
    @PostMapping("/list3")
    public List<CollectWorkOrder> selectlist3(@RequestParam String pageNo,@RequestParam String pageSize) {
        List<CollectWorkOrder> collectList = collectWorkOrderMapper.selectTest(Integer.parseInt(pageNo),Integer.parseInt(pageSize));
        return collectList;
    }


    /**
     * TODO 采集运维工单个条件搜索-APP端
     * @return
     */
    @ResponseBody
    @PostMapping("/list2c")
    public List<CollectWorkOrder> selectlist2c(@RequestParam String one,@RequestParam String pageNo,@RequestParam String pageSize) {
        String workOrderStatus = "1";
        //List<CollectWorkOrder> collectList = collectWorkOrderService.selectList2(one,"刘月焱",Integer.parseInt(pageNo),Integer.parseInt(pageSize),workOrderStatus);
        //return collectList;
        return null;
    }


    /**
     * TODO 敏感用户采集运维工单列表
     * @return
     */
    @ResponseBody
    @PostMapping("/listapp")
    public List<CollectWorkOrder> CollectWorkOrderListapp() {
        List<CollectWorkOrder> AllcollecList = collectWorkOrderService.selectAllYWOapp();
        return AllcollecList;
    }


    /**
     * TODO 点击查询单个工单具体详情 工单状态改为2.处理中
     * @return
     */
    @ResponseBody
    @PostMapping("/selectOne")
    @ApiOperation(value = "点击查看，状态变为处理中")
    public CollectWorkOrder selectOneLwo(int id){
        int i = collectWorkOrderService.updateStatus2(id);
        CollectWorkOrder cv = collectWorkOrderService.selectByPrimaryKey(id);
        return cv;
    }


    /**
     * TODO 提交图片和视频 并且修改状态为3待归档
     * @param infor
     * @return
     */
    @ResponseBody
    @PostMapping("/commit")
    @ApiOperation(value = "提交图片视频，状态变为待归档")
    public int CollectInfor(WorkOrderInfor infor){
        int i = workOrderInforService.insertSelective(infor);//提交，将视频和图片存放到库中
        collectWorkOrderService.updateStatus3(infor.getWorkOrderNo());//提交完之后修改状态
        return i;
    }

    //提交图片和视频等信息（测试）
    @ResponseBody
    @RequestMapping("/test")
    public Object Collectinfor1(WorkOrderInfor infor, MultipartFile file){
        int i = 0;
        try {
            InputStream ins = file.getInputStream();
            byte[] buffer=new byte[1024];
            int len=0;
            ByteArrayOutputStream bos=new ByteArrayOutputStream();
            while((len=ins.read(buffer))!=-1){
                bos.write(buffer,0,len);
            }
            bos.flush();
            byte data[] = bos.toByteArray();
            //infor.setLivePhotos(data);
            i = workOrderInforService.insertSelective(infor);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return i;
    }

    /**
     * TODO 回显工单处理表的图片和视频
     * @param workOrderNo
     * @return
     */
    @ResponseBody
    @GetMapping("/load1")
    @ApiOperation(value = "回显图片和视频")
    public WorkOrderInfor loadInfovp1(@RequestParam String workOrderNo){
        return workOrderInforService.SelectVandP(workOrderNo);
    }


    /**
     * TODO 回显工单处理表的图片和视频
     * @param workOrderNo
     * @return
     */
    @ResponseBody
    @PostMapping("/load")
    @ApiOperation(value = "回显图片和视频")
    public WorkOrderInfor loadInfovp(@RequestParam String workOrderNo){
        return workOrderInforService.SelectVandP(workOrderNo);
    }


    /**
     * TODO 原始数据的关联
     * @param id
     * @return
     */
    @ResponseBody
    @PostMapping("/rawdata")
    public Object CollFail(@RequestParam String id){
        CollectWorkOrder cyo = collectWorkOrderMapper.selectByPrimaryKey(Integer.parseInt(id));
        if(cyo.getFailDetailsId()!=null){
            CollectFailure cFailDetail = collectWorkOrderService.selectByPrimaryKeyf(cyo.getFailDetailsId());
            return cFailDetail;
        }else if(cyo.getColInforId()!=null){
            CollectInforma ctInfor = collectWorkOrderService.selectByPrimaryKeyi(cyo.getColInforId());
            return ctInfor;
        }else if(cyo.getNotConnectId()!=null){
            CollectNotcon cNotCon = collectWorkOrderService.selectByPrimaryKeyn(cyo.getNotConnectId());
            return cNotCon;
        }
        return "系统繁忙!";
    }

    /**
     * TODO 记录工单状态以及预警数
     * @param user
     * @return
     */
    @PostMapping(value = "/count")
    public R countAll(@CurrentUser SysUser user){
        return R.ok(collectWorkOrderService.nineCollWd(user.getLoginName()));
    }


    /**
     * TODO 模拟数据召测 待归档变为已归档
     */
    @ResponseBody
    @PostMapping("/test")
    public int BigTest(@RequestParam int id){
        int i = collectWorkOrderService.updateStatus4(id);
        return i;
    }

    @RequestMapping("getcollManager")
    @ResponseBody
    public void getcollManager(){
        String today = TimeUtil.getTodayTime();
        List<String> consNos = collectWorkOrderMapper.selectCollManager(today);
        for (String consNo : consNos) {
            String manager = collectWorkOrderMapper.selectTgManage1(consNo);
            if(manager!=null){
                collectWorkOrderMapper.UpdateCollManager(consNo,manager,today);
            }
        }
    }


    /**
     * 优质服务工单生成及工单预警
     * @return
     */
    @Scheduled(cron = "0 0/30 7-17 * * ?")
    @ResponseBody
    @Async
    @RequestMapping("getsel95598")
    public String select95598(){
        int i = 0;
        int j = 0;
        int k = 0;
        //List<String> lists = collectWorkOrderMapper.selectOrgList();
        List<S95598Wkst> s95598Wksts = s95598WkstMapper.select95598WKST(TimeUtil.getTodayTime());//TimeUtil.getTodayTime()
        for (S95598Wkst s95598Wkst : s95598Wksts) {
            if(s95598WkstMapper.selectAppNo(s95598Wkst.getAppNo())==0) {
                i += s95598WkstMapper.insertS95598Wkst(s95598Wkst);
                SuperiorWorkOrder swo = new SuperiorWorkOrder();
                j += s95598WkstService.insert95598WorkOrder(swo,s95598Wkst);
            }
        }
        log.info("新增数据为:"+i+"工单生成条数为:"+j);
        List<String> l95598list = s95598WkstMapper.selectS95598codeList();//查询表中未归档数据
        for (String appNo : l95598list) {
            if (s95598WkstMapper.selectHandleCode(appNo).equals("08")){
                k +=s95598WkstMapper.update95598Status(appNo);
            }
        }

//        //获取24至48小时之内的未归档工单
//        List<String> superiorList = s95598WkstMapper.select95598EarlyWarning(DateUtil.getStringDate(), ONE_GRADE);
//        if (superiorList.size() > 0) {
//            for (String superior : superiorList) {
//                j +=s95598WkstMapper.update95598Cycle(ONE_GRADE, superior);
//            }
//        }2211
//
//        //获取48小时以上的未归档工单
//        superiorList = s95598WkstMapper.select95598EarlyWarning(DateUtil.getStringDate(), TWO_GRADE);
//        if (superiorList.size() > 0) {
//            for (String superior : superiorList) {
//                j +=s95598WkstMapper.update95598Cycle(TWO_GRADE, superior);
//            }
//        }
        return "优质服务新增数据为:"+i+"工单生成条数为:"+j+"更改归档数量为:"+k;
    }


    @RequestMapping("getFee1")
    @ResponseBody
    public String getFee1(){
        feecontrolWorkOrderService.feecontrolVo();
        System.out.println("执行费控");
        return "费控执行完成";
    }

    /**
     * 费控复电工单生成及工单预警
     * @return
     */
    @RequestMapping("getFee")
    @ResponseBody
    @Async
    @Scheduled(cron = "0 0/30 7-17 * * ?")
    public String getFee(){
        DateTime time = new DateTime();
        int i = 0;
        int j = 0;
        List<ARcaCtrlDet> aRcaCtrlDets = feecontrolWorkOrderMapper.selectARCACTRL(TimeUtil.getTodayTime());
        for (ARcaCtrlDet aRcaCtrlDet : aRcaCtrlDets) {
            if(feecontrolWorkOrderMapper.selectCtrlId(aRcaCtrlDet.getCtrlId())==0){//判断工单表中是否存在一样的数据
                i += feecontrolWorkOrderMapper.insertFeeARca(aRcaCtrlDet);
                FeecontrolWorkOrder feeWorkOrder = new FeecontrolWorkOrder();
                feeWorkOrder.setWorkOrderNo(TimeUtil.getTime(time) + "04" + OrderWarnUtil.OrderNum());
                feeWorkOrder.setCtrlId(aRcaCtrlDet.getCtrlId());
                feeWorkOrder.setFailTime(aRcaCtrlDet.getRemoteDate());
                feeWorkOrder.setConsNo(aRcaCtrlDet.getConsNo());
                feeWorkOrder.setWorkOrderCycle(1);
                List<GTg> gTgs = aRcvblFlowMapper.selectTgNoName(aRcaCtrlDet.getConsNo());
                if(gTgs.size()!=0){
                    for (int i1 = 0; i1 < gTgs.size(); i1++) {
                        if(gTgs.get(i1)!=null) {
                            feeWorkOrder.setTgId(gTgs.get(i1).getTgNo());
                            feeWorkOrder.setTgName(gTgs.get(i1).getTgName());
                            break;
                        }
                    }
                }


                feeWorkOrder.setTgManager(collectWorkOrderMapper.selectTgManage1(aRcaCtrlDet.getConsNo()));//获取台区经理名称
                List<String> mobiles = aRcvblFlowMapper.selectMobiAddr(aRcaCtrlDet.getConsNo());
                if(mobiles.size()!=0){
                    feeWorkOrder.setMobile(mobiles.get(0));
                }
                CCons cCons = aRcvblFlowMapper.selectConsName(aRcaCtrlDet.getConsNo());
                if (!StringUtils.isEmpty(cCons)){
                    feeWorkOrder.setElecAddr(cCons.getElecAddr());
                    feeWorkOrder.setConsName(cCons.getConsName());
                }
                feeWorkOrder.setOrgNo(collectWorkOrderMapper.selectOrgNo(aRcaCtrlDet.getOrgNo()));
                feeWorkOrder.setCtrlType(aRcaCtrlDet.getCtrlType());
                feeWorkOrder.setCpNo(aRcaCtrlDet.getCpNo());
                feeWorkOrder.setMeterId(aRcaCtrlDet.getMeterId());
                feeWorkOrder.setRemark(aRcaCtrlDet.getRemark());
                feeWorkOrder.setRemoteDate(aRcaCtrlDet.getRemoteDate());
                feeWorkOrder.setRemoteRtDate(aRcaCtrlDet.getRemoteRtDate());
                feeWorkOrder.setRemoteRslt(aRcaCtrlDet.getRemoteRslt());
                feeWorkOrder.setWorkOrderStatus("1");
                feeWorkOrder.setWorkOrderCtime(new DateTime());
                feeWorkOrder.setWorkOrderCtime1(TimeUtil.getTodayTime());
                Integer integer = feecontrolWorkOrderMapper.insertFeeWork(feeWorkOrder);
                System.out.println("工单生成"+integer);
            }
        }
//        List<BigDecimal> bigDecimals = feecontrolWorkOrderMapper.selectFeeWorkOrder();
//        for (BigDecimal bigDecimal : bigDecimals) {
//
//        }
        System.out.println("费控获取数据");
        return "费控获取数据";
    }

    @RequestMapping("getFeeOneCycle")
    @ResponseBody
    @Async
    //@Scheduled(cron = "0 10/40 * * * ?")定时任务注释
    public String getFeeOneCycle(){

        List<String> workOrderNoList = new ArrayList<>();
        List<FeecontrolWorkOrder> feecontrolWorkOrders = feecontrolWorkOrderMapper.selectCycleOneList();

        for (FeecontrolWorkOrder workOrder : feecontrolWorkOrders) {
            if (StrUtil.isNotBlank(workOrder.getWorkOrderNo())){
                workOrderNoList.add(workOrder.getWorkOrderNo());
            }
        }
        feecontrolWorkOrderMapper.updateFeeCycle(ONE_GRADE, workOrderNoList);
        return "费控预警数据";
    }

    @RequestMapping("getFeeTwoCycle")
    @ResponseBody
    @Async
    //@Scheduled(cron = "0 15/45 * * * ?")定时任务注释
    public String getFeeTwoCycle(){

        List<String> workOrderNoList = new ArrayList<>();
        List<FeecontrolWorkOrder> feecontrolWorkOrders = feecontrolWorkOrderMapper.selectCycleTwoList();

        for (FeecontrolWorkOrder workOrder : feecontrolWorkOrders) {
            if (StrUtil.isNotBlank(workOrder.getWorkOrderNo())){
                workOrderNoList.add(workOrder.getWorkOrderNo());
            }
        }
        feecontrolWorkOrderMapper.updateFeeCycle(TWO_GRADE, workOrderNoList);
        return "费控预警数据";
    }


//    @RequestMapping("getFee5")
//    @ResponseBody
//    @Scheduled(cron = "0 1/30 * * * ?")
//    @Async
//    public String getFee15(){
//        int i = 0;
//        //List<BigDecimal> f5sta = new ArrayList<>();//营销系统完成的工单
//        List<BigDecimal> fo5s = feecontrolWorkOrderMapper.selectFeeWorko5();
//        for (BigDecimal fo5 : fo5s) {
//            String s = feecontrolWorkOrderMapper.selectFeeByCtrlId(fo5);
//            if (s.equals("03")){//已经执行成功的工单
//                //f5sta.add(fo5);
//                i += feecontrolWorkOrderMapper.updateFeeStatus(fo5);
//            }
//        }
//        return "归档完成工单"+i;
//    }

    @RequestMapping("getPg1")
    public String getPg1(){
        String s = collectWorkOrderMapper.selectTgManager("30145112");
        System.out.println("1=="+s);
        return "1=="+s;
    }

    @RequestMapping("getPg3")
    public String getPg3(){
        String s = collectWorkOrderMapper.selectCustId("3001476198");
        System.out.println("3=="+s);
        return "3=="+s;
    }


    @RequestMapping("getTgmans")
    public String getTgmans(@RequestParam String orgNo){
        List<TgManList> tgManLists = collectWorkOrderMapper.selectAlltest(orgNo);
        Map<String,Integer> map = new HashMap<>();
        for (TgManList tgManList : tgManLists) {
            String opNo = collectWorkOrderMapper.selectOperator(tgManList.getMrSectNo());
            String tgManager = collectWorkOrderMapper.selectTgManager(opNo);
            if(map.containsKey(tgManager)){
                map.put(tgManager,map.get(tgManager)+tgManList.getConsNum());
            }else {
                map.put(tgManager, tgManList.getConsNum());
            }
        }
        System.out.println(map);
        return "执行完成";
    }


//    //组织架构导数
//    @RequestMapping("getconsTg")
//    public String getconsTg(@RequestParam String orgNo){
//        //List<String> lists = collectWorkOrderMapper.selectOrgList();
//        //for (String orgNo : lists) {
//        List<consTg> consTgs = collectWorkOrderMapper.selectCCons(orgNo);
//        //线程数，按线程数拆分，默认3个线程
//        int threadCount = 3;
//        //按线程数平均分配后，每个线程处理的数据量
//        int perThreadData = consTgs.size() / threadCount;
//        //按线程数平均分配后，多余的数据量
//        int remainderCount = consTgs.size() % threadCount;
//        //有多余的数据，再开个线程处理
//        boolean havingRemainder = remainderCount > 0;
//        if (havingRemainder) {
//            threadCount += 1;
//        }
//
//        for (int i = 0; i < threadCount; i++) {
//            //处理平均分配的数据量，多余的数据放在最后一个线程中处理
//            List<consTg> splitList = consTgs.stream()
//                    .skip((long) i * perThreadData)
//                    .limit((i == threadCount - 1) ? (havingRemainder ? remainderCount : perThreadData) : perThreadData)
//                    .collect(Collectors.toList());
//            System.out.println("splitList = " + splitList);
//
//            //此时可以开启多线程处理数据，提高并发处理效率
//        }
//        Integer integer = collectWorkOrderMapper.insertconsTgList(consTgs);
//        System.out.println("组织架构导入完成"+integer);
//        return "组织架构导入完成"+integer;
//    }




    //组织架构导数
    @RequestMapping("getconsTg")
    public String getconsTg(@RequestParam String orgNo){
        //List<String> lists = collectWorkOrderMapper.selectOrgList();
        //for (String orgNo : lists) {
        List<consTg> consTgs = collectWorkOrderMapper.selectCCons(orgNo);

        Integer integer = collectWorkOrderMapper.insertconsTgList(consTgs);
        System.out.println("组织架构导入完成"+integer);
        return "组织架构导入完成"+integer;
    }

    //组织架构导数
    @RequestMapping("getconsTg1")
    public String getconsTg1(@RequestParam String orgNo){
        int i =0;
        //List<String> lists = collectWorkOrderMapper.selectOrgList();
        //for (String orgNo : lists) {
        List<consTg> consTgs = collectWorkOrderMapper.selectCCons(orgNo);
        for (consTg consTg : consTgs) {
                //consTg.setPOrgName(TimeUtil.getPorgName(consTg.getPOrgNo()));
                i += collectWorkOrderMapper.insertconsTg(consTg);
            }
        //}
        System.out.println("组织架构导入完成"+i);
        return "组织架构导入完成"+i;
    }

    //组织架构导数
    @RequestMapping("getconsTg2")
    public String getconsTg2(@RequestParam String orgNo){
        int i =0;
        SqlSession sqlSession = sqlSessionTemplate.getSqlSessionFactory().openSession(ExecutorType.BATCH, false);//跟上述sql区别
        CollectWorkOrderMapper collectwoMapper = sqlSession.getMapper(CollectWorkOrderMapper.class);

        List<consTg> consTgs = collectwoMapper.selectCCons(orgNo);
        for (consTg consTg : consTgs) {
                i += collectwoMapper.insertconsTg(consTg);
        }
        sqlSession.commit();
        System.out.println("组织架构导入完成"+i);
        return "组织架构导入完成"+i;
    }


    @PostMapping("getConsList")
    public ConsListVo getConsList(@RequestParam String consNo){
        ConsListVo consListVo = new ConsListVo();
        ConsListPo consListPo = collectWorkOrderMapper.selectConsList(consNo).get(0);
        consListVo.setConsNo(consListPo.getConsNo());
        consListVo.setConsName(consListPo.getConsName());
        //consListVo.setOrgNo(OrgNameUtil.getOrgName(consListPo.getOrgNo()));
        //consListVo.setOrgName(OrgNameUtil.getOrgName(consListPo.getOrgNo()));
        consListVo.setElecAddr(consListPo.getElecAddr());
        consListVo.setStatusCode(collectWorkOrderMapper.selectElecName("cons_status_code", consListPo.getStatusCode()));
        consListVo.setConsSortCode(collectWorkOrderMapper.selectElecName("cons_volt_code", consListPo.getConsSortCode()));
        consListVo.setTradeCode(collectWorkOrderMapper.selectElecName("trade_type_code", consListPo.getTradeCode()));
        consListVo.setVoltCode(collectWorkOrderMapper.selectElecName("volt_code", consListPo.getVoltCode()));
        consListVo.setContractCap(BigDecimalUtil.notNull(consListPo.getContractCap()));
        consListVo.setTmpFlag(collectWorkOrderMapper.selectElecName("tmp_flag",consListPo.getTmpFlag()));
        consListVo.setMrSectNo(consListPo.getMrSectNo());
        consListVo.setElecTypeCode(collectWorkOrderMapper.selectElecName("elec_type_code",consListPo.getElecTypeCode()));
        consListVo.setRunCap(BigDecimalUtil.notNull(consListPo.getRunCap()));
        consListVo.setSpId(consListPo.getSpId());
        consListVo.setSpName(consListPo.getSpName());
        consListVo.setSpName(consListPo.getSpName());
        consListVo.setPsNumCode(collectWorkOrderMapper.selectElecName("ps_num_code",consListPo.getPsNumCode()));
        consListVo.setTypeCode(collectWorkOrderMapper.selectElecName("prc_type_code",consListPo.getTypeCode()));
        consListVo.setBaCalcMode(collectWorkOrderMapper.selectElecName("ba_calc_mode",consListPo.getBaCalcMode()));
        consListVo.setDmdSpecValue(BigDecimalUtil.notNull(consListPo.getDmdSpecValue()));
        consListVo.setPfEvalMode(collectWorkOrderMapper.selectElecName("pf_eval_mode",consListPo.getPfEvalMode()));
        consListVo.setRealName(consListPo.getRealName());
        return consListVo;
    }


    @RequestMapping("getConsListweb")
    public List<ConsListPo> getConsListweb(@RequestParam(required=false) String consNo,@RequestParam(required=false) String consName,
                                     @RequestParam(required=false) String orgName,@RequestParam(required=false) String elecTypeCode){
        List<ConsListPo> consListPos = new ArrayList<>();

        List<ConsListPo> consListPoslist = collectWorkOrderMapper.selectConsListweb(consNo,consName,orgName,elecTypeCode);
        for (ConsListPo consListPo : consListPoslist) {
            if ("".equals(consListPo)|| consListPo!=null ) {
                consListPo.setConsNo(consListPo.getConsNo());
                consListPo.setConsName(consListPo.getConsName());
                //consListVo.setOrgNo(OrgNameUtil.getOrgName(consListPo.getOrgNo()));
                //consListVo.setOrgName(OrgNameUtil.getOrgName(consListPo.getOrgNo()));
                consListPo.setElecAddr(consListPo.getElecAddr());
                consListPo.setStatusCode(collectWorkOrderMapper.selectElecName("cons_status_code", consListPo.getStatusCode()));
                consListPo.setConsSortCode(collectWorkOrderMapper.selectElecName("cons_volt_code", consListPo.getConsSortCode()));
                consListPo.setTradeCode(collectWorkOrderMapper.selectElecName("trade_type_code", consListPo.getTradeCode()));
                consListPo.setVoltCode(collectWorkOrderMapper.selectElecName("volt_code", consListPo.getVoltCode()));
                consListPo.setContractCap(BigDecimalUtil.notNull(consListPo.getContractCap()));
                consListPo.setTmpFlag(collectWorkOrderMapper.selectElecName("tmp_flag", consListPo.getTmpFlag()));
                consListPo.setMrSectNo(consListPo.getMrSectNo());
                consListPo.setElecTypeCode(collectWorkOrderMapper.selectElecName("elec_type_code", consListPo.getElecTypeCode()));
                consListPo.setRunCap(BigDecimalUtil.notNull(consListPo.getRunCap()));
                consListPo.setSpId(consListPo.getSpId());
                consListPo.setSpName(consListPo.getSpName());
                consListPo.setSpName(consListPo.getSpName());
                consListPo.setPsNumCode(collectWorkOrderMapper.selectElecName("ps_num_code", consListPo.getPsNumCode()));
                consListPo.setTypeCode(collectWorkOrderMapper.selectElecName("prc_type_code", consListPo.getTypeCode()));
                consListPo.setBaCalcMode(collectWorkOrderMapper.selectElecName("ba_calc_mode", consListPo.getBaCalcMode()));
                consListPo.setDmdSpecValue(BigDecimalUtil.notNull(consListPo.getDmdSpecValue()));
                consListPo.setPfEvalMode(collectWorkOrderMapper.selectElecName("pf_eval_mode", consListPo.getPfEvalMode()));
                consListPo.setRealName(consListPo.getRealName());
            }
            consListPos.add(consListPo);
        }
        return consListPos;
    }


    @PostMapping("getConsListMobile")
    public List<ConsConMobile> getConsListMobile(@RequestParam String consNo){
        List<ConsConMobile> consConMobiles = collectWorkOrderMapper.selectConsListMobile(consNo);
        List<ConsConMobile> conMobiles = new ArrayList<>();
        for (ConsConMobile consConMobile : consConMobiles) {
            String contactMode = consConMobile.getContactMode();
            String s = collectWorkOrderMapper.selectElecName("contact_type", contactMode);
            consConMobile.setContactMode(s);
            conMobiles.add(consConMobile);
        }
        return conMobiles;
    }


    @RequestMapping("getConsListMobileweb")
    public List<ConsConMobile> getConsListMobileweb(@RequestParam String consNo){
        List<ConsConMobile> consConMobiles = collectWorkOrderMapper.selectConsListMobileweb(consNo);
        List<ConsConMobile> conMobiles = new ArrayList<>();
        for (ConsConMobile consConMobile : consConMobiles) {
            String contactMode = consConMobile.getContactMode();
            String s = collectWorkOrderMapper.selectElecName("contact_type", contactMode);
            consConMobile.setContactMode(s);
            conMobiles.add(consConMobile);
        }
        return conMobiles;
    }






    @PostMapping("getCons1")
    public String getCons1(@RequestParam String consNo){
        System.out.println(consNo);
        return consNo;
    }

    @RequestMapping("getMeter1")
    public List<MpListPo> selectMpList(@RequestParam(required = false) String mpId,@RequestParam(required = false) String assetNo){
        List<MpListPo> mpListPos = collectWorkOrderMapper.selectMpList(mpId,assetNo);
        List<MpListPo> mpListPoss = new ArrayList<>();
        for (MpListPo mpListPo : mpListPos) {
            mpListPo.setVoltCode(collectWorkOrderMapper.selectElecName("volt_code", mpListPo.getVoltCode()));
            mpListPo.setCalcMode(collectWorkOrderMapper.selectElecName("pq_calc_mode", mpListPo.getCalcMode()));
            mpListPo.setFrDeductFlag("1".equals(mpListPo.getFrDeductFlag()) ? "是" : "否");
            mpListPo.setMeasMode(collectWorkOrderMapper.selectElecName("meas_mode", mpListPo.getMeasMode()));
            mpListPo.setTlShareFlag("1".equals(mpListPo.getTlShareFlag()) ? "是" : "否");
            mpListPo.setLlBillFlag("1".equals(mpListPo.getLlBillFlag()) ? "是" : "否");
            mpListPo.setLlShareFlag("1".equals(mpListPo.getLlShareFlag()) ? "是" : "否");
            mpListPo.setFqrValue(BigDecimalUtil.notNull(mpListPo.getFqrValue()));
            mpListPo.setTlBillFlag("1".equals(mpListPo.getTlBillFlag()) ? "是" : "否");
            mpListPo.setLlCalcMode("1".equals(mpListPo.getLlCalcMode()) ? "是" : "否");
            mpListPo.setStatusCode(collectWorkOrderMapper.selectElecName("status_code", mpListPo.getStatusCode()));
            mpListPo.setWiringMode(collectWorkOrderMapper.selectElecName("wiring_mode", mpListPo.getWiringMode()));
            mpListPo.setMarketType(collectWorkOrderMapper.selectElecName("market_type", mpListPo.getMarketType()));
            mpListPoss.add(mpListPo);
        }
        return mpListPoss;
    }

    @RequestMapping("getMeter2")
    public List<RealMpPo> selectMpListReal(@RequestParam(required = false) String mpId,@RequestParam(required = false) String assetNo){
        List<RealMpPo> realMpPos = collectWorkOrderMapper.selectMpListReal(mpId,assetNo);
        List<RealMpPo> realMpPos1 = new ArrayList<>();
        for (RealMpPo realMpPo : realMpPos) {
            realMpPo.setRelaSortCode(collectWorkOrderMapper.selectElecName("rela_sort_code", realMpPo.getRelaSortCode()));
            realMpPo.setMpDirectionCode(collectWorkOrderMapper.selectElecName("mp_direction_code", realMpPo.getMpDirectionCode()));
            realMpPos1.add(realMpPo);
        }
        return realMpPos1;
    }

    @RequestMapping("getMeter3")
    public List<DMeterPo> selectDMeter(@RequestParam(required = false) String mpId,@RequestParam(required = false) String assetNo){
        List<DMeterPo> dMeterPos = collectWorkOrderMapper.selectDMeter(mpId,assetNo);
        List<DMeterPo> dMeterPos2 = new ArrayList<>();
        for (DMeterPo dMeterPo : dMeterPos) {
            String refMeterFlag = dMeterPo.getRefMeterFlag();
            if (refMeterFlag.equals("0")){
                dMeterPo.setRefMeterFlag("否");
            }else {
                dMeterPo.setRefMeterFlag("是");
            }
            String voltCode = dMeterPo.getVoltCode();
            if (voltCode.equals("01")){
                dMeterPo.setVoltCode("220V");
            }else if(voltCode.equals("02")){
                dMeterPo.setVoltCode("3x380");
            }else if(voltCode.equals("03")){
                dMeterPo.setVoltCode("3x380/220V");
            }else if(voltCode.equals("04")){
                dMeterPo.setVoltCode("3x100V");
            }else if(voltCode.equals("05")){
                dMeterPo.setVoltCode("3x57.7/100V");
            }else {
                dMeterPo.setVoltCode("");
            }
            dMeterPo.setRatedCurrent(collectWorkOrderMapper.selectElecName("rated_current", dMeterPo.getRatedCurrent()));
            dMeterPo.setApPreLevelCode(collectWorkOrderMapper.selectElecName("ap_pre_level_code", dMeterPo.getApPreLevelCode()));
            dMeterPo.setRpPreLevelCode(collectWorkOrderMapper.selectElecName("ap_pre_level_code", dMeterPo.getRpPreLevelCode()));
            dMeterPo.setWiringMode(collectWorkOrderMapper.selectElecName("wiring_mode", dMeterPo.getWiringMode()));
            dMeterPo.setConMode("01".equals(dMeterPo.getConMode())?"直接接入":"经互感器接入");
            dMeterPo.setCommProtCode(collectWorkOrderMapper.selectElecName("communication_protocol", dMeterPo.getCommProtCode()));
            dMeterPos2.add(dMeterPo);
        }
        return dMeterPos2;
    }

    @RequestMapping("getMeter4")
    public List<DItPo> selectDItList(@RequestParam(required = false) String mpId,@RequestParam(required = false) String assetNo){
        List<DItPo> dItPos = collectWorkOrderMapper.selectDItList(mpId,assetNo);
        List<DItPo> dItPos1 = new ArrayList<>();
        for (DItPo dItPo : dItPos) {
            if (dItPo.getSortCode().equals("01")){
                dItPo.setSortCode("电流互感器");
            }else if(dItPo.getSortCode().equals("02")){
                dItPo.setSortCode("电压互感器");
            }else{
                dItPo.setSortCode("组合互感器");
            }
            dItPo.setRcRatioCode(collectWorkOrderMapper.selectElecName("rc_ratio_code", dItPo.getRcRatioCode()));
            dItPo.setCurrentRatioCode(collectWorkOrderMapper.selectElecName("rc_ratio_code", dItPo.getCurrentRatioCode()));
            dItPo.setTvPreCode(collectWorkOrderMapper.selectElecName("it_accuracy_code", dItPo.getTvPreCode()));
            dItPos1.add(dItPo);
        }

        return dItPos1;
    }


    @GetMapping("getJson")
    @ResponseBody
    public Map<String,String> getJson(@RequestParam(required = false) String abc){
        System.out.println(abc);
        Map<String,String> map = new HashMap<>();
        map.put("name","刘月焱");
        if("".equals(abc)||abc==null||abc.length()==0) {
            map.put("userid", "250120");
        }else {
            map.put("userid", abc);
        }
        return map;
    }


    @RequestMapping("getCorg")//所级
    @ResponseBody
    public List<OrgNoName> getCorg(){
        List<OrgNoName> orgNoNames = collectWorkOrderMapper.selectCounty();
        return  orgNoNames;
    }


    @RequestMapping("getSorg")//站级
    @ResponseBody
    public List<OrgNoName> getSorg(@RequestParam String orgNo){
        List<OrgNoName> orgNoNames = collectWorkOrderMapper.selectStation1(orgNo);
        return  orgNoNames;
    }

    @RequestMapping("getDora")//
    @ResponseBody
    public Integer getDora(){
        Integer integer = collectWorkOrderMapper.selectDora();
        return  integer;
    }

    @RequestMapping("getUserRoleOrgNo")//
    @ResponseBody
    public void getUserRoleOrgNo(){
        List<String> strings = collectWorkOrderMapper.selectUserNameOrgNo();
        for (String username : strings) {
            String orgNo = collectWorkOrderMapper.selectOrgNoByusername(username);
            collectWorkOrderMapper.updateOrgNo(orgNo,username);
        }
    }
}
