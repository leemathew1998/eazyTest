package org.dfzt.mapper;

import org.dfzt.entity.po.PicmaWorkOrder;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author 李木
* @description 针对表【picma_work_order】的数据库操作Mapper
* @createDate 2023-05-30 09:41:22
* @Entity org.dfzt.entity.po.PicmaWorkOrder
*/
public interface PicmaWorkOrderMapper extends BaseMapper<PicmaWorkOrder> {

}




