package com.exam;

import com.exam.modules.entity.SysUser;
import com.exam.modules.mapper.SysUserMapper;
import com.exam.modules.utils.MyLong;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import javax.annotation.Resource;
import java.util.List;

@SpringBootTest
class ExamSystemServerApplicationTests {
    @Resource
    private SysUserMapper mapper;
    @Resource
    private BCryptPasswordEncoder passwordEncoder;
    @Test
    void contextLoads() {

            for(int i=0;i<10;i++){
                System.out.println("第"+i+"个："+ MyLong.getRand());
            }
    }
    //测试密码加密
    @Test
    void contexts() {
        System.out.println(passwordEncoder.encode("456789"));
    }
}
