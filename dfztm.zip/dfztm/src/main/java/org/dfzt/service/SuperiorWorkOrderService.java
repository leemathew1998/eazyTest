package org.dfzt.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.FeecontrolWorkOrder;
import org.dfzt.entity.vo.SuperiorSensitivity;
import org.dfzt.entity.vo.SuperiorWorkOrder;


import java.util.List;
import java.util.Map;

/**
 * (SuperiorWorkOrder)表服务接口
 *
 * @author makejava
 * @since 2022-07-11 14:51:01
 */
public interface SuperiorWorkOrderService extends IService<SuperiorWorkOrder> {

    /**
     * 根据角色权限查看不同的数据
     * @param superiorWorkOrder
     * @param role
     * @return
     */
    LambdaQueryWrapper<SuperiorWorkOrder> queryWrapper(SuperiorWorkOrder superiorWorkOrder, String role);
    LambdaQueryWrapper<SuperiorWorkOrder> wrapper(List<String> readNames,String str, String role,String workOrderStatus,String loName2,List<String> orgName);


    /**
     * 状态扭转
     * @param map
     * @return
     */
    int updateSuperiorWordOrder(org.dfzt.entity.po.SuperiorWorkOrder map);

    /**
     * 历史提交数据
     * @param workOrderNo
     * @return
     */
    SuperiorWorkOrder selectSuperiorWordOrderNo(String workOrderNo);

    //修改敏感用户状态
    Boolean updateSen(String workorderNo);

    List<SuperiorWorkOrder> selectCountAll();


    /**
     * 查询登录人员
     * @param loginName
     * @return
     */
    String selectRole(String loginName);//根据用户id差找所对应的权限

    Integer insertSen(SuperiorSensitivity sSensitivity);//没有则新增字段并添加描述

}

