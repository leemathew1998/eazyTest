package org.dfzt.entity.tdo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 预警列表
 */
@Data
public class WarningList {
    //类型(失流 过流)
    private String type;
    //预警位置
    private String location;
    //设备id
    private String deviceId;
    //发生时间
    private String happenTime;

}
