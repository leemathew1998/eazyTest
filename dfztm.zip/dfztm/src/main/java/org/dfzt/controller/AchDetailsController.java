package org.dfzt.controller;

import com.baomidou.mybatisplus.extension.api.ApiController;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.entity.po.CollectWorkOrder;
import org.dfzt.mapper.AchievementsManagerMapper;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.service.AchievementsManagerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

/**
 * @Author: 14259 zhangsheng 绩效详情页
 * @Date: 2023/6/1
 * @Version: 1.00
 */
@Slf4j
@RestController
@RequestMapping("/achdetails")
@CrossOrigin
@Component
public class AchDetailsController extends ApiController {

    @Resource
    private AchievementsManagerMapper achsManMapper;
    @Resource
    private CollectWorkOrderMapper collMapper;


    //台区经理查询采集工单详情
    @RequestMapping("getAcManDetails1")
    @ResponseBody
    public List<CollectWorkOrder> getAcManDetails1(@RequestParam String ymd,@RequestParam String tgManager){
        List<CollectWorkOrder> acManDetails1 = achsManMapper.getAcManDetails1(tgManager, ymd);
        return acManDetails1;
    }
    //营业站层级查询采集工单详情
    @RequestMapping("getAcStaDetails1")
    @ResponseBody
    public List<CollectWorkOrder> getAcStaDetails1(@RequestParam String ymd,@RequestParam String orgName){
        List<CollectWorkOrder> acStaDetails1 = achsManMapper.getAcStaDetails1(orgName, ymd);
        return acStaDetails1;
    }
    //旗县层级采集工单详情
    @RequestMapping("getAcCouDetails1")
    @ResponseBody
    public List<CollectWorkOrder> getAcCouDetails1(@RequestParam String ymd,@RequestParam String pOrgName){
        List<CollectWorkOrder> acCouDetails1 = achsManMapper.getAcCouDetails1(pOrgName, ymd);
        return acCouDetails1;
    }

    //市层级采集工单详情
    @RequestMapping("getAcCityDetails1")
    @ResponseBody
    public List<CollectWorkOrder> getAcCityDetails1(@RequestParam String ymd,@RequestParam String orgNo){
        List<CollectWorkOrder> acCityDetails1 = achsManMapper.getAcCityDetails1(orgNo, ymd);
        return acCityDetails1;
    }
}
