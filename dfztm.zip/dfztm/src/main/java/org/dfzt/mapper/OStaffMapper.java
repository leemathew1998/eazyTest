package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.OStaff;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * @Author: xiayepeng
 * @Date: 2022/10/13
 * @Version: 1.00
 */
public interface OStaffMapper extends BaseMapper<OStaff> {
    @DS("mpg")
    List<OStaff> selectOsList();
    Integer insertOStaff(OStaff oStaff);

}