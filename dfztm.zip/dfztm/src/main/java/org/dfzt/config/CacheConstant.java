package org.dfzt.config;

/**
 * @author: huangxutao
 * @date: 2019-06-14
 * @description: 缓存常量
 */
public interface CacheConstant {

	/**
	 * 蒙东单位
	 */
    String SYS_ORG_CACHE = "sys:cache:org";


	String SYS_ORG_CACHE_REDIS = "sys:cache:org:redis";

	//电流、电压码值
	String SYS_PROP_CACHE = "sys:cache:prop";

	//码值
	String SYS_CONS_CACHE = "sys:cache:cons";

}
