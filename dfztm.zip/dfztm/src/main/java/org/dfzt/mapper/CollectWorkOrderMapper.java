package org.dfzt.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.dfzt.entity.dto.LoadRateDto;
import org.dfzt.entity.po.*;
import org.dfzt.entity.po.FeecontrolWorkOrder;
import org.dfzt.entity.po.MeterWorkOrder;
import org.dfzt.entity.po.RecycleWorkOrder;
import org.dfzt.entity.po.SuperiorSensitivity;
import org.dfzt.entity.vo.*;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
public interface CollectWorkOrderMapper extends BaseMapper<CollectWorkOrder> {
    int deleteByPrimaryKey(Integer id);

//    int insert(CollectWorkOrder record);

    int insertSelective(CollectWorkOrder record);

    CollectWorkOrder selectByPrimaryKey(int id);

//    int updateByPrimaryKeySelective(CollectWorkOrder record);
//
//    int updateByPrimaryKey(CollectWorkOrder record);

    int updateStatus1(int id);//状态改为待处理

    int updateStatus2(int id);//状态改为处理中

    int updateStatus3(String workOrderNo);//状态改为待归档

    int updateStatus4(int id);//状态改为已归档



    IPage<CollectWorkOrder> selectAllYWO1(Page<CollectWorkOrder> page);//采集列表分页查询



    List<CollectWorkOrder> selectAllYWO();

    //查询终端地址相同的个数
    int SelectCountterAdds(String terminalAddr,String today);


    //查询创建时间，以便后期判断工单周期
    @Select("select work_order_ctime from collect_yw_work_order where id=#{id}")
    Date SelectWoTime(int id);

    List<CollectWorkOrder> selectByeleNum(String eleNum);//根据用户编码查找相同用户编码的信息

    int updateWorkCycle(String workOrderCycle, Integer id);//修改工单周期

    String selectRole(String username);//根据用户id差找所对应的权限

    String selectOrgNoByrole(String username);//根据用户id差找所对应的营业站


    List<CollectWorkOrder> selectList1(@Param("c")CollectWorkOrder c,@Param("username")String username,@Param("pageNo") Integer pageNo,@Param("pageSize") Integer pageSize,@Param("status") String status);//采集运维条件查询
    List<CollectWorkOrder> selectList3(@Param("c")CollectWorkOrder c,@Param("pageNo") Integer pageNo,@Param("pageSize") Integer pageSize,@Param("orgNames") List<String> orgNames,@Param("status") String status);//所站长采集运维条件查询工单预警为二级的

    List<CollectWorkOrder> selectExcel1(@Param("ids") String ids);//批量导出
    List<MeterWorkOrder> selectExcel2(@Param("ids") String ids);
    List<LinelossWorkOrder> selectExcel3(@Param("ids") String ids);
    List<FeecontrolWorkOrder> selectExcel4(@Param("ids") String ids);
    List<RecycleWorkOrder> selectExcel5(@Param("ids") String ids);
    List<RunWorkOrder> selectExcel6(@Param("ids") String ids);


    List<CollectWorkOrder> selectList2(List<String> readNames,String one, Integer pageNo, Integer pageSize, String workOrderStatus, String username);//采集运维单个条件查询
    List<CollectWorkOrder> selectList4(String one,Integer pageNo,Integer pageSize,String workOrderStatus,String username,List<String> orgName);//采集运维单个条件查询

    List<CollectWorkOrder> selectTest(Integer pageNo,Integer pageSize);

    List<CollectWorkOrder> selectAllYWOapp();//查询敏感用户的采集运维工单

    CollectNotcon selectByPrimaryKeyn(Integer id);
    CollectInforma selectByPrimaryKeyi(Integer id);
    CollectFailure selectByPrimaryKeyf(Integer id);

    Long selectStatus1();//查询工单状态为待处理的个数1
    Long selectStatus2();//查询工单状态为处理中的个数2
    Long selectStatus3();//查询工单状态为待归档的个数3
    Long selectStatus4();//查询工单状态为已归档的个数4
    Long selectStatus5();//查询工单周期为一级的预警的个数5
    Long selectStatus6();//查询工单周期为二级的预警的个数6

    int insertCollfail(CollectFailure collectFailure);
    int insertCollinfo(CollectInforma collectInforma);
    int insertCollnot(CollectNotcon collectNotcon);

    @DS("mpg")
    List<String> selectTgNoList();//查询台区编号集合作为入参条件

    @DS("mpg")
    Object selectMdpg();

    @DS("mpg")
    Object selectMCons();


    @DS("mpg")
    CElecAddr selectCEAddrByconsId(Integer consId);//根据用户标识consid查询用户地址信息（数据中台）



    @DS("mpg")
    String selectOperatorMpg(String mrSectNo);//获取台区经理编号



    @DS("mpgt")
    String selectTgManagerByLoginName(String userName);//从sa_user查询台区经理名称 OPERATOR_NO

    List<String> selectOrgNoByuName(String userName);

    @DS("mpg")
    String selectMrSectNo(String consNo);//通过用户编号查询抄表端编号
    @DS("mpgt")
    String selectTgManager(String userId);//从sa_user查询台区经理名称 OPERATOR_NO
    @DS("sele")
    String selectOperator(String mrSectNo);//获取台区经理编号

    @DS("mpgt")
    String selectTgManage1(String orgNo);//查询台区经理

    @DS("mpg")
    String selectLinelossMan(String tgNo);

    @DS("mpgt")
    List<OrgNoName> selectOrgNameByc(String consNo);//通过用户编号查询供电单位编号

    @DS("mpg")
    List<GTg> selectTgByConsno(String consNo);//通过用户编号查询该用户所属台区名称和编号

    @DS("mpg")
    String selectOrgNo(String orgNo);//查询供电单位名称

    @DS("mpg")
    List<String> selectOrgNos(String orgNo);//查询供电单位名称

    @DS("mpgt")
    List<String> selectOrgNos1();//查询供电单位名称

    @DS("mpg")
    List<String> selectOrgnos(String orgNo);//查询供电单位编号列表

    List<String> selectfailfin(String todaytime);//查询当天采集失败的电能表资产号列表

    List<String> selectnotcfin();//查询当天采集未接入电能表资产号列表

    Integer UpdatefinStatus(String massetNo,String todaytime);//更改已归档状态

    @DS("mpg")
    List<String> selectTerminalAddr();

    @DS("mpg")
    List<String> selectElecCode(String consNo);//通过用户编号查询用电类别编号

    @DS("mpgt")
    String selectElecName(String codeType,String codeValue);//根据用电类别查询用电类别名称
                                                 //根据业务类型编码查询业务类型中文名称

    @DS("mpgt")
    List<PropListVo> selectPropList(String codeType);//根据用电类别查询码值集合

    @DS("mpg")
    String selectCustId(String custId);//根据custId查询用户编号
    //根据电能表资产号查询额定电流/电压



    @DS("mpg")
    List<TgManList> selectAlltest(String orgNo);//查询对应的抄表端对应的用户数

    @DS("pg")
    String selectTguserId(String mrSectNo);

    List<CollectInforma> selectTwoRape(String meterAssetNo, String agoday, String ago2day);

    @DS("mpg")
    DMeter selectvandc(String meterAssetNo); //根据电能表资产号查询额定电压和额定电流

    @DS("mpg")
    List<consTg> selectCCons(String orgNo);

    Integer insertconsTg(consTg constg);

    Integer insertconsTgList(List<consTg> constgs);

    List<CollectInforma> selectCollInfo(String today);

    @MapKey("work_order_status")
    Map<String,Integer> selectcollStaNum1(String today);
    @MapKey("work_order_status")
    Map<String,Integer> selectcollStaNum2(String today);

    @DS("mpg")
    List<ConsListPo> selectConsList(String consNo);//用户档案
    @DS("mpg")
    List<ConsConMobile> selectConsListMobile(String consNo);//用户档案

    @DS("mpg")
    List<ConsListPo> selectConsListweb(String consNo,String consName,String orgName,String elecTypeCode);//用户档案
    @DS("mpg")
    List<ConsConMobile> selectConsListMobileweb(String consNo);//用户档案


    @DS("mpg")
    List<MpListPo> selectMpList(String mpId,String assetNo);//计量点档案

    @DS("mpg")
    List<RealMpPo> selectMpListReal(String mpId,String assetNo);//主分计费关系

    @DS("mpg")
    List<DMeterPo> selectDMeter(String mpId,String assetNo);//电能表

    @DS("mpg")
    List<DItPo> selectDItList(String mpId,String assetNo);//互感器


    @DS("mpgt")
    List<String> selectOrgList();//查询呼伦贝尔所有供电单位编号

    @DS("mpgt")
    List<String> selectOrgList1();//查询呼伦贝尔所有供电单位编号

    List<CollectWorkOrder> selectLists1(List<String> lists);

    Integer insertSerSuser(SuperiorSensitivity superiorSensitivity);


    @DS("mpgt")
    List<OrgNoName> selectCounty();//查询所级营业站列表

    @DS("mpgt")
    List<OrgNoName> selectStation1(String orgNo);//根据所级营业站查询该所下所有营业站

    List<TdTgManager> selectAcManager(String orgNo);//根据营业站查询该所下台区经理

    List<CollectWorkOrder> selectCollByLoName1(String loName2);
    List<MeterWorkOrder> selectCollByLoName2(String loName2);

    @DS("mpg")
    Integer selectPub1(List<String> orgNos);//公变
    @DS("mpg")
    Integer selectPub2(List<String> orgNos);//专变
    @DS("mpg")
    Integer selectCons1(List<String> orgNos);//高压
    @DS("mpg")
    Integer selectCons2(List<String> orgNos);//低压
    @DS("mpg")
    BigDecimal selectLine1(List<String> orgNos);//10kv 03
    @DS("mpg")
    BigDecimal selectLine2(List<String> orgNos);//0.4kv 08
    @DS("mpg")
    Integer selectCMeter1(List<String> orgNos);//在运电能表数量
    @DS("mpg")
    Integer selectCMeter2(List<String> orgNos);//在运电能表数量

    Integer selecctOrgNameNum(String orgName,String ymd);

    Integer selectOrgAllNum(String orgName);
//    Integer selectOrgnoNum(String orgNo);


    @DS("mpg")
    Integer selectStaconNums(String orgNo);//营业站总用户数
    @DS("mpg")
    Integer selectAcconNums(String orgNo);//旗县总用户数

    @DS("mpg")
    Integer selectStatgNums(String orgNo);//营业站总台区数
    @DS("mpg")
    Integer selectActgNums(String orgNo);//旗县总台区数




    @DS("sele")
    Integer selectFee3(List<String> orgNos,String ymd,String remote);//获取费控两个指标 复电
    @DS("sele")
    Integer selectFee4(List<String> orgNos,String ymd,String remote);//获取费控两个指标 停电

    Integer selectFeeManage3(String ymd,String tgManager);//台区经理获取费控复电成功数
    Integer selectFeeManage3all(String ymd,String tgManager);//台区经理获取费控复电成功总数数


    Integer selectSiperNum(String orgNo,String ymd);//查询投诉意见工单数量

    Integer selectNum6(String orgNo);//终止发行占比详情

    Integer selectLine8(String orgNo,String ymd);//查询该营业站线损大于6的工单数
    Integer selectLine9(String orgNo,String ymd);//查询该营业站线损小于-1的工单数
    Integer selectLine10(String orgNo,String ymd);//查询该营业站线损0-4之间的工单数
    //Integer selectNum8(String orgNo);//查询该旗县管辖的台区数量

    Integer selectAcCouzb1(List<String> orgNames,String ymd);//旗县 指标1
    Integer selectAcCouzb2(List<String> orgNames,String ymd);//旗县 指标2

    BigDecimal selectLoss6(String orgName,String ymd);//旗县低压线损率 指标6
    BigDecimal selectLoss61(String orgName,String ymd);//旗县低压线损率 指标6

    Integer selectAcCou10();//旗县 高负损台区处理及时率 指标10

    BigDecimal selectAcCou11a(List<String> orgs,String ym);//旗县 电费结零率 指标11 电费发行金额
    BigDecimal selectAcCou11b(List<String> orgs,String ym);//旗县 电费结零率 指标11  欠费金额


    BigDecimal selectAcMan11a(String tgManager,String ym);//台区经理 电费结零率 指标11 电费发行金额
    BigDecimal selectAcMan11b(String tgManager,String ym);//台区经理 电费结零率 指标11  欠费金额




    Integer selectAc13(List<String> orgs,String ymd);//旗县 查询复电时长小于45的工单数
    Integer selectAc13a(List<String> orgs,String ymd);//旗县 查询复电所有的工单数

    Integer selectAcMan13(String tgManager,String ymd);//台区经理 查询复电时长小于45的工单数
    Integer selectAcMan13aa(String tgManager,String ymd);//台区经理 查询复电时长小于45的工单数
    Integer selectAcMan13a(String tgManager,String ymd);//台区经理 查询复电所有的工单数

    Integer selectAc14tou(List<String> orgs,String ymd);//旗县 投诉数量 指标14
    Integer selectAc14yi(List<String> orgs,String ymd);//旗县 意见数量 指标14


    Integer selectAc16a(List<String> orgs,String ymd);//旗县 指标16 所有计量工单数
    Integer selectAc16(List<String> orgs,String ymd);//旗县 指标16 所有三天未处理计量工单数

    Integer selectAcMan16a(String tgManager,String ymd);//台区经理 指标16 所有计量工单数
    Integer selectAcMan16(String tgManager,String ymd);//台区经理 指标16 所有三天未处理计量工单数

    @DS("dora")
    Integer selectDora();

    UserRole selectUserRole(String userName);

    List<UserRole> selectUserList(String orgNo);

    List<UserRole> selectReadName(String userName);


    Integer insertUserRole(UserRole userRole);
    Integer updateUserRole(UserRole userRole);
    Integer deleteById(Integer id);

    List<String> selectReadNames(String loginName);
    List<String> selectRoles(String loginName);

    List<DocumentInfoVo> selectTgLoad(@Param("districtNumber") String districtNumber);

    List<DocumentInfoVo> selectDocumentInfo(@Param("documentField") String documentField);

    LoadRateVo selectLoadRate(@Param("tgNo") String tgNo, @Param("beforeTwoDay") String beforeTwoDay);

    List<String> selectUserNameOrgNo();

    @DS("mpgt")
    String selectOrgNoByusername(String userName);

    void updateOrgNo(String orgNo,String userName);

    @DS("mpgt")
    Integer selectUserNameConsNum(String userName);//查询抄表员所管辖的用户数
    @DS("mpgt")
    Integer selectUserNameTgNum(String userName);//查询抄表员所管辖的台区数

    String selectUserRoleName(String readName);

    Integer selectWorkWarns1(String ymd);//获取采集工单预警个数
    Integer selectWorkWarns2(String ymd);//获取计量工单预警个数
    Integer selectWorkWarns3(String ymd);//获取线损工单预警个数
    Integer selectWorkWarns4(String ymd);//获取费控工单预警个数
    Integer selectWorkWarns5(String ym);//获取电费回收预警个数
    Integer selectWorkWarns6(String ym);//获取电费补抄预警个数
    Integer selectWorkWarns7(String ymd);//获取优质服务预警个数


    //根据上级id查询下级id和姓名
    List<LoadRateVo> getNameForId(@Param("id") String id);

    //根据台区编号查询用户信息
    List<LoadRateVo> getUserNameForId(@Param("id") String id);

    //查询当日用户台区经理
    List<String> selectCollManager(String today);

    void UpdateCollManager(String consNo,String tgManager,String today);

}
