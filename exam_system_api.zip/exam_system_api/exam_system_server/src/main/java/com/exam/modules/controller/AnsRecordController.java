package com.exam.modules.controller;



import com.exam.modules.entity.AnsRecord;
import com.exam.modules.entity.dto.AnsRecordDTO;
import com.exam.modules.entity.vo.AnsRecordVo;
import com.exam.modules.service.AnsRecordService;
import com.exam.modules.utils.Result;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.Collection;


/**
 * 作答记录(AnsRecord)表控制层
 *
 * @author dyy
 * @since 2022-11-09 15:33:35
 */
@RestController
@RequestMapping("api/ansRecord")
public class AnsRecordController{
    /**
     * 服务对象
     */
    @Resource
    private AnsRecordService ansRecordService;


    /**
     * 提交答案
     * @return
     */
    @PostMapping("save")//api/ansRecord/save
    public Result save(@RequestBody Collection<AnsRecord> ansRecord){
        if (ansRecordService.saveBatch(ansRecord)){
            return Result.ok();
        }
        return Result.error();
    }
}
