package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.annotations.XStreamImplicit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @ClassName Demo2
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/15 18:39
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Demo2 {
      /**/
      @XStreamImplicit
      private List<General> general;
}
