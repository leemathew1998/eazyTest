package org.dfzt.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.AcManager;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AcManagerMapper extends BaseMapper<AcManager> {
    int deleteByPrimaryKey(Integer id);

    int insert(AcManager record);

    int insertSelective(AcManager record);

    AcManager selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(AcManager record);

    int updateByPrimaryKey(AcManager record);

    List<AcManager> listAcCounty(List<Integer> ids);

    AcManager selectTdManager(String tgManager,String datedm);
}
