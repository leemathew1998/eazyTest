package org.dfzt.entity.po;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/19
 * @Version: 1.00
 * 电能表相位信息
 */
@Data
public class PhaseFlag {
    //    供电单位
    private String orgName;
    //    台区编号
    private String tgNo;
    //    台区名称
    private String tgName;
    //    终端地址
    private String terminalAddr;
    //    表类型
    private String dmetTypeCode;
    //    全半载标识
    private String fhloadFlag;
    //    相位
    private String phaseCode;
    //    用户编号
    private String consNo;
    //    用户名称
    private String consName;
    //    表地址
    private String commAddr;
    //    用户地址
    private String elecAddr;
    //    终端通讯规约
    private String protocolCode;
    //    电能表相位信息
    private String phaseFlag;
    //    电量值
    private BigDecimal spq;
    //    主用途类型
    private String usageTypeCode;

}
