package org.dfzt.eunm;

import java.util.HashMap;
import java.util.Map;

/**
 * @Date:2022/7/12-15:16
 * @User:chengchuanlin
 * @Name:FeeconterWayEnum
 * @Message:
 */
public enum FeecontrWayEnum {

    WAY_ONE("0","远程复电"),
    WAY_TWO("1","现场复电");

    // 成员变量
    private final String strWay;
    private final String way;

    FeecontrWayEnum(String strWay, String way) {
        this.strWay = strWay;
        this.way = way;
    }

    // 将数据缓存到map中
    private static final Map<String, String> map = new HashMap<>();

    static {
        for (FeecontrWayEnum color : FeecontrWayEnum.values()) {
            map.put(color.getStrWay(), color.getWay());
        }
    }

    // 根据name查询value值
    public static String getValueByName(String name) {
        return map.get(name);
    }

    public String getStrWay() {
        return strWay;
    }

    public String getWay() {
        return way;
    }
}
