package org.dfzt.eunm;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * @ClassName WorkOrderEnum
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/6/28 13:39
 */
@Getter
public enum WorkOrderEnum {

    WORK_ORDER_ENUM_ONE(1,"待处理"),
    WORK_ORDER_ENUM_TWO(2,"处理中"),
    WORK_ORDER_ENUM_THREE(3,"待归档"),
    WORK_ORDER_ENUM_FOUR(4,"已归档")
    ;

    @EnumValue
    private int code;
    @JsonValue
    private String message;

    WorkOrderEnum(int code, String message) {
        this.code = code;
        this.message = message;
    }
    private static final Map<Integer,String> map = new HashMap<>();

    static {
        for (WorkOrderEnum color : WorkOrderEnum.values()) {
            map.put(color.getCode(), color.getMessage());
        }
    }

    public static String getMessage(String code){
        return map.get(code);
    }

    public int getCode(){
        return code;
    }
    public String getMessage(){
        return message;
    }
}
