package org.dfzt.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.dfzt.entity.po.*;
import org.dfzt.mapper.CMpMapper;
import org.dfzt.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * (CMp)表服务实现类
 *
 * @author makejava
 * @since 2022-07-29 14:51:17
 */
@Service("cMpService")
public class CMpServiceImpl extends ServiceImpl<CMpMapper, CMp> implements CMpService {

    @Autowired
    private CMpItRelaService cMpItRelaService;
    @Autowired
    private DMeter2Service dMeter2Service;
    @Autowired
    private RCpService rCpService;
    @Autowired
    private SItSchemeService sItSchemeService;
    @Autowired
    private CMpMapper cMpMapper;

    public LambdaQueryWrapper queryWrapper(CMp cMp) {
        return new LambdaQueryWrapper<CMp>()
                .like(cMp.getMpNo() != null, CMp::getMpNo, cMp.getMpNo()).or()
                .like(cMp.getMpCap() != null, CMp::getMpCap, cMp.getMpCap()).or()
                .like(cMp.getVoltCode() != null, CMp::getVoltCode, cMp.getVoltCode()).or()
                .like(cMp.getKwhPrc() != null, CMp::getKwhPrc, cMp.getKwhPrc()).or()
                .like(cMp.getCatPrcName() != null, CMp::getCatPrcName, cMp.getCatPrcName()).or()
                .like(cMp.getCalcMode() != null, CMp::getCalcMode, cMp.getCalcMode()).or()
                .like(cMp.getFqrValue() != null, CMp::getFqrValue, cMp.getFqrValue()).or()
                .like(cMp.getFrDeductFlag() != null, CMp::getFrDeductFlag, cMp.getFrDeductFlag()).or()
                .like(cMp.getMeasMode() != null, CMp::getMeasMode, cMp.getMeasMode()).or()
                .like(cMp.getTlBillFlag() != null, CMp::getTlBillFlag, cMp.getTlBillFlag()).or()
                .like(cMp.getTlShareFlag() != null, CMp::getTlShareFlag, cMp.getTlShareFlag()).or()
                .like(cMp.getLlCalcMode() != null, CMp::getLlCalcMode, cMp.getLlCalcMode()).or()
                .like(cMp.getLlShareFlag() != null, CMp::getLlShareFlag, cMp.getLlShareFlag()).or()
                .like(cMp.getStatusCode() != null, CMp::getStatusCode, cMp.getStatusCode()).or()
                .like(cMp.getTgId() != null, CMp::getTgId, cMp.getTgId()).or()
                .like(cMp.getTgName() != null, CMp::getTgName, cMp.getTgName()).or()
                .like(cMp.getLineId() != null, CMp::getLineId, cMp.getLineId()).or()
                .like(cMp.getLineName() != null, CMp::getLineName, cMp.getLineName()).or()
                .like(cMp.getWiringMode() != null, CMp::getWiringMode, cMp.getWiringMode()).or()
                .like(cMp.getMarketType() != null, CMp::getMarketType, cMp.getMarketType());
    }

    @Override
    public LambdaQueryWrapper wrapper(String str) {
        return new LambdaQueryWrapper<CMp>()
                .nested(wrapper -> {
                    wrapper.apply("1=1")
                            .like(str != null, CMp::getMpNo, str).or()
                            .like(str != null, CMp::getMpCap, str).or()
                            .like(str != null, CMp::getVoltCode, str).or()
                            .like(str != null, CMp::getKwhPrc, str).or()
                            .like(str != null, CMp::getCatPrcName, str).or()
                            .like(str != null, CMp::getCalcMode, str).or()
                            .like(str != null, CMp::getFqrValue, str).or()
                            .like(str != null, CMp::getFrDeductFlag, str).or()
                            .like(str != null, CMp::getMeasMode, str).or()
                            .like(str != null, CMp::getTlBillFlag, str).or()
                            .like(str != null, CMp::getTlShareFlag, str).or()
                            .like(str != null, CMp::getLlCalcMode, str).or()
                            .like(str != null, CMp::getLlShareFlag, str).or()
                            .like(str != null, CMp::getStatusCode, str).or()
                            .like(str != null, CMp::getTgId, str).or()
                            .like(str != null, CMp::getTgName, str).or()
                            .like(str != null, CMp::getLineId, str).or()
                            .like(str != null, CMp::getLineName, str).or()
                            .like(str != null, CMp::getWiringMode, str).or()
                            .like(str != null, CMp::getMarketType, str);
                });
    }

    /**
     * 模糊查询4表
     *
     * @param str
     * @return
     */
    @Override
    public List<CMp> selectListByMany(String str) {
        ArrayList<CMp> objects = new ArrayList<>();
        ArrayList<String> coll = new ArrayList<>();
//1.表1的模糊查询--CMpItRela
        LambdaQueryWrapper<CMpItRela> wrapper1 = new LambdaQueryWrapper<>();
        wrapper1.like(str != null, CMpItRela::getRelationType, str).or()
                .like(str != null, CMpItRela::getMpName, str).or()
                .like(str != null, CMpItRela::getMpNo, str).or()
                .like(str != null, CMpItRela::getConsName, str).or()
                .like(str != null, CMpItRela::getRelationTsg, str).or()
                .like(str != null, CMpItRela::getConsNo, str).or()
                .like(str != null, CMpItRela::getMpDirectionCode, str);

        List<CMpItRela> list1 = cMpItRelaService.list(wrapper1);
        //获取计量点编号
        for (CMpItRela C : list1) {
            String mpNo = C.getMpNo();//获取计量点编号
            coll.add(mpNo);
        }


//2.表2的模糊查询--RCP
        LambdaQueryWrapper<RCp> wrapper2 = new LambdaQueryWrapper<>();
        wrapper2.like(str != null, RCp::getTerminalAddr, str).or()
                .like(str != null, RCp::getTerminalTypeCode, str).or()
                .like(str != null, RCp::getProtocolCode, str).or()
                .like(str != null, RCp::getFactoryCode, str).or()
                .like(str != null, RCp::getMpNo, str).or();
        List<RCp> list2 = rCpService.list(wrapper2);
        for (RCp r : list2) {
            String mpNo = r.getMpNo();
            coll.add(mpNo);
        }


//表3的模糊查询--DMeter2
        LambdaQueryWrapper<DMeter2> wrapper3 = new LambdaQueryWrapper<>();
        wrapper3.like(str != null, DMeter2::getMeterAssetNo, str).or()
                .like(str != null, DMeter2::getTFactor, str).or()
                .like(str != null, DMeter2::getRefMeterFlag, str).or()
                .like(str != null, DMeter2::getVoltCode, str).or()
                .like(str != null, DMeter2::getRatedCurrent, str).or()
                .like(str != null, DMeter2::getApPreLevelCode, str).or()
                .like(str != null, DMeter2::getRpPreLevelCode, str).or()
                .like(str != null, DMeter2::getWiringMode, str).or()
                .like(str != null, DMeter2::getConMode, str).or()
                .like(str != null, DMeter2::getManufacturer, str).or()
                .like(str != null, DMeter2::getProtocolCode, str).or()
                .like(str != null, DMeter2::getMpNo, str);

        List<DMeter2> list3 = dMeter2Service.list(wrapper3);

        for (DMeter2 d : list3) {
            String mpNo = d.getMpNo();
            coll.add(mpNo);
        }
//表4的模糊--SItScheme
        LambdaQueryWrapper<SItScheme> wrapper4 = new LambdaQueryWrapper<>();
        wrapper4.like(str != null, SItScheme::getId, str).or()
                .like(str != null, SItScheme::getSortCode, str).or()
                .like(str != null, SItScheme::getCtRatio, str).or()
                .like(str != null, SItScheme::getCurrentRatioCode, str).or()
                .like(str != null, SItScheme::getChangeRatio, str).or()
                .like(str != null, SItScheme::getTaAccuracyCode, str).or()
                .like(str != null, SItScheme::getManufacturer, str).or()
                .like(str != null, SItScheme::getMpNo, str);


        List<SItScheme> list4 = sItSchemeService.list(wrapper4);
        for (SItScheme s : list4) {
            String mpNo = s.getMpNo();
            coll.add(mpNo);
        }

        List<String> list = coll.stream().distinct().collect(Collectors.toList());//去重复
        if(list==null){
            return null;
        }

        for (String S:list) {
            LambdaQueryWrapper<CMp> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(CMp::getMpNo,S);
            CMp cMp = cMpMapper.selectOne(wrapper);
//            for (CMp cMp : cMps) {
                objects.add(cMp);
//            }
        }



        return objects;
    }

    /**
     * 用户档案--》计量点
     * @param cMp
     * @return
     */
    @Override

        public LambdaQueryWrapper selectCmpByUser(CMp cMp) {
            return new LambdaQueryWrapper<CMp>().eq(cMp!=null,CMp::getPowerPointNo,cMp.getPowerPointNo());

        }







}

