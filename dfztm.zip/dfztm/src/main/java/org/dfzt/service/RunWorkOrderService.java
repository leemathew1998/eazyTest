package org.dfzt.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.R;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.RunWorkOrderPo;
import org.dfzt.entity.vo.RunWorkOrder;
import org.dfzt.entity.vo.SysUser;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
public interface RunWorkOrderService extends IService<RunWorkOrder> {

    /**
     * 查询电费补抄数据(web端)
     */
    IPage<RunWorkOrder> selectAll(Page page, RunWorkOrder runWorkOrder, String role,String status,String orgName);

    /**
     * 查询电费补抄数据(app端)
     */
    IPage<RunWorkOrder> queryAll(List<String> readNames,Page page, String condition, String role,String workOrderStatus,String loName2);

    /**
     *
     * @return
     */
    List<RunWorkOrder> queryAdd();

    /**
     *
     * @param id
     * @return
     */
    int queryid(Integer id);

    /**
     * 通过台区经理id查询对应台区经理待处理工单
     * @param gdbh
     * @return
     */
    R querylist(Integer gdbh);

    /**
     * 每月4号凌晨研判
     * @return
     * @throws ParseException
     */
    R queryS() throws ParseException;

    /**
     * 根据工单用户编号查询工单周期
     * @param dfbcGdUserid
     * @return
     */
    String selectPeriod(String dfbcGdUserid);

    //app端更新状态功能
    int updateStatus(Integer workOrderStatus, String id);

    /**
     * 4号凌晨研判之后，查询需要手动归档的数据
     *
     * @return
     */
    List<RunWorkOrder> queryRunWorker(Integer TqId);

    /**
     * 开始
     * @return
     */
    String  DateStartTime();

    /**
     * 结束
     * @return
     */
    String DateEndTime();

    /**
     *
     * @return
     */
    int Gdfs(String DfbcGdNo);

    /**
     * 九大工单右上角图标计数功能
     * 台区经理
     * @return
     */
    List<Map<String,Object>> nineMajorWorkOrders(String loginName);

    //根据工单编号查询电费补抄工单
    RunWorkOrderPo selectById(String appNo);



}
