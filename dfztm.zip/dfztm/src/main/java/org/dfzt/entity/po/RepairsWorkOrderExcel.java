package org.dfzt.entity.po;


import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.dfzt.eunm.WorkOrderStatusEnum;

import java.util.Date;

@ApiModel(value = "主动抢修返回",description = "")
@Data
@SuppressWarnings("serial")
@TableName("ctiave_rush_repair")
public class RepairsWorkOrderExcel {
    //主动抢修工单编号
    @Excel(name = "主动抢修工单编号",orderNum = "0",width = 20)
    @ApiModelProperty(value = "主动抢修工单编号")
    private String workOrderNo;
    //台区经理姓名
    @Excel(name = "台区经理",orderNum = "1")
    @ApiModelProperty(value = "台区经理姓名")
    private String tgManager;
    //台区编码
    @Excel(name = "台区编号",orderNum = "2",width = 12)
    @ApiModelProperty(value = "台区编码")
    private String tgNo;
    //台区名称
    @Excel(name = "台区名称",orderNum = "3",width = 12)
    @ApiModelProperty(value = "台区名称")
    private String tgName;
    //故障设备标识
    @Excel(name = "故障设备标识",orderNum = "4",width = 12)
    @ApiModelProperty(value = "故障设备标识")
    private String failureEquipment;
    //工单状态(1.待处理 2.处理中 3.待归档 4.已归档)
    @Excel(name = "工单状态",orderNum = "5",width = 12)
    @ApiModelProperty(value = "工单状态(1.待处理 2.处理中 3.待归档 4.已归档)")
    private String workOrderStatus;
    //电压
    @Excel(name = "电压(V)",orderNum = "6",width = 12)
    @ApiModelProperty(value = "电压(V)")
    private String voltCode;
    //电流
    @Excel(name = "电流(A)",orderNum = "7",width = 12)
    @ApiModelProperty(value = "电流(A)")
    private String ratedCurrent;
    //本体温度
    @Excel(name = "本体温度(℃)",orderNum = "8",width = 12)
    @ApiModelProperty(value = "本体温度(℃)")
    private String tgTemperature;
    //故障区域
    @Excel(name = "故障区域",orderNum = "9",width = 12)
    @ApiModelProperty(value = "故障区域")
    private String failureArea;
    //开关异常状态
    @Excel(name = "开关异常状态(1.分 2.合)",orderNum = "10",width = 12)
    @ApiModelProperty(value = "开关异常状态(1.分 2.合)")
    private String errorStatus;


    @Excel(name = "抢修类型",orderNum = "11",width = 12)
    @ApiModelProperty(value = "抢修类型")
    private String repairsType;

    @ApiModelProperty(value = "故障描述")
    private String faultDescribe;
    @ApiModelProperty(value = "开始处理工单的时间")
    private Date disposeTime;
    @ApiModelProperty(value = "处理结果")
    private String disposeResult;
    @ApiModelProperty(value = "消耗材料")
    private String consumeMaterials;
    @ApiModelProperty(value = "地点")
    private String location;

    @TableField(exist = false)
    private String photo;

    @ApiModelProperty(value = "故障缺陷照片")
    @Excel(name = "故障缺陷照片",orderNum = "12",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String faultPoint;
    //抢修单照片(顺序2)
    @Excel(name = "抢修单照片",orderNum = "13",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String repairList;
    //监控班许可照片（顺序3）
    @Excel(name = "监控班许可照片",orderNum = "14",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String monShiftPer;
    //安全措施照片(顺序4)
    @Excel(name = "安全措施照片",orderNum = "15",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String secuMeas;
    //到岗位置许可检查安全措施是否完备照片并同意开工照片（顺序5）
    @Excel(name = "到岗位置许可检查安全措施是否完备照片并同意开工照片",orderNum = "16",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String iscompSecuMeas;
    //故障/危急缺陷处理后照片（顺序6）
    @Excel(name = "危急缺陷处理后照片",orderNum = "17",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String afterTrou;
    //安全措施拆除照片（顺序7）
    @Excel(name = "安全措施拆除照片",orderNum = "18",type = 2,width = 30.0 ,height = 30.0 ,imageType = 1,groupName = "图片")
    private String secuMeasRem;


    //工单创建时间
    @ApiModelProperty(value = "工单创建时间")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderCtime;

    @ApiModelProperty(value = "转换成处理中状态的时刻")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderdtime;

    @ApiModelProperty(value = "转换成待归档状态的时刻")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderwtime;

    @ApiModelProperty(value = "转换成已归档状态的时刻")
    @JsonFormat(pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date workOrderatime;

    //是否有敏感工单用户
    private String appType;

    public void setWorkOrderStatus(String workOrderStatus) {
        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
    }
}
