package org.dfzt.service.impl;

import cn.hutool.core.date.DateTime;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.common.collect.Lists;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.CollectYwWorkOrderv;
import org.dfzt.eunm.CollectReasonEnum;
import org.dfzt.eunm.CollectTypeEnum;
import org.dfzt.eunm.WorkOrderStatusEnum;
import org.dfzt.mapper.ARcvblFlowMapper;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.service.CollectWorkOrderService;
import org.dfzt.util.FailTypeUtil;
import org.dfzt.util.OrderWarnUtil;
import org.dfzt.util.TimeUtil;
import org.dfzt.webservice.WebServiceSchedule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.text.DecimalFormat;
import java.util.*;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/11
 * @Version: 1.00
 */
@Service
//@Transactional
public class CollectWorkOrderServiceImpl extends ServiceImpl<CollectWorkOrderMapper, CollectWorkOrder> implements CollectWorkOrderService {

    //工单后6位序号
    DecimalFormat df = new DecimalFormat("000000");
    int num=1;//每天进行重新赋值为1

    @Autowired
    private CollectWorkOrderMapper collectWorkOrderMapper;
    @Resource
    private ARcvblFlowMapper aRcvblFlowMapper;

    @Override
    public IPage<CollectWorkOrder> selectAllYWO1(Map<String, Object> map) {
        Integer pageNum = (Integer) map.get("pageNum");
        Integer pageSize = (Integer) map.get("pageSize");
        Page<CollectWorkOrder> page = new Page<>(pageNum,pageSize);
        IPage<CollectWorkOrder> iPage = collectWorkOrderMapper.selectAllYWO1(page);
        return iPage;
    }

    @Override
    public List<CollectWorkOrder> selectAllYWO() {
        List<CollectWorkOrder> cvs = new ArrayList<>();
        for (CollectWorkOrder cy : collectWorkOrderMapper.selectAllYWO()) {
            CollectYwWorkOrderv cv = new CollectYwWorkOrderv();
//            cv.setConsNo(cy.getUserCode());
//            cv.setConsName(cy.getUserName());
//            cv.setTgId(cy.getPlatformId());
//            cv.setTgName(cy.getPlatformName());
//            cv.setWorkOrderNo(cy.getWorkOrderNo());
//            cv.setAreaManagerDesk(cy.getAreaManagerDesk());
//            cv.setOrgName(cy.getPowerSupplyUnit());
//            cv.setElecAddr(cy.getUserAdd());
//            cv.setGpsLatitude(cy.getUserGpsLatitude().toString());
//            cv.setGpsLongitude(cy.getUserGpsLongitude().toString());
//            cv.setMobile(cy.getUserPhone());
//            cv.setMeterAssetNo(cy.getElecmeterAssetNum());
//            cv.setMeterBarCode(cy.getElecmeterCode());
//            cv.setMetManufacturer(cy.getElecmeterFactory());
//            cv.setEventReason(CollectReasonEnum.getValueByName(cy.getEventReason()));
//            cv.setWorkOrderStatus(cy.getWorkOrderStatus());
//            cv.setEventType(CollectTypeEnum.getValueByName(cy.getEventType()));
//            cvs.add(cv);
        }
        return cvs;
    }


    /**
     * TODO 存放入工单表
     * @param cywo
     * @return
     */
    @Override
    public int insertSelective(CollectWorkOrder cywo) {
        return collectWorkOrderMapper.insertSelective(cywo);
    }


    /**
     * TODO 给工单分配台区经理
     * @param id
     * @return
     */
    @Override
    public int updateStatus2(int id) {
        return collectWorkOrderMapper.updateStatus2(id);
    }

    @Override
    public int updateStatus3(String workOrderNo) {
        return collectWorkOrderMapper.updateStatus3(workOrderNo);
    }

    @Override
    public int updateStatus1(int id) {
        return collectWorkOrderMapper.updateStatus1(id);
    }

    @Override
    public int updateStatus4(int id) {
        return collectWorkOrderMapper.updateStatus4(id);
    }

    @Override
    public CollectWorkOrder selectByPrimaryKey(Integer id) {
        CollectWorkOrder cv = new CollectWorkOrder();
        CollectWorkOrder cy = collectWorkOrderMapper.selectByPrimaryKey(id);
//        cv.setConsNo(cy.getUserCode());
//        cv.setConsName(cy.getUserName());
//        cv.setTgId(cy.getPlatformId());
//        cv.setTgName(cy.getPlatformName());
//        cv.setWorkOrderNo(cy.getWorkOrderNo());
//        cv.setAreaManagerDesk(cy.getAreaManagerDesk());
//        cv.setOrgName(cy.getPowerSupplyUnit());
//        cv.setElecAddr(cy.getUserAdd());
//        cv.setGpsLatitude(cy.getUserGpsLatitude().toString());
//        cv.setGpsLongitude(cy.getUserGpsLongitude().toString());
//        cv.setMobile(cy.getUserPhone());
//        cv.setMeterAssetNo(cy.getElecmeterAssetNum());
//        cv.setMeterBarCode(cy.getElecmeterCode());
//        cv.setMetManufacturer(cy.getElecmeterFactory());
        cv.setEventReason(CollectReasonEnum.getValueByName(cy.getEventReason()));
        cv.setWorkOrderStatus(WorkOrderStatusEnum.getValueByName(cy.getWorkOrderStatus()));
        cv.setEventType(CollectTypeEnum.getValueByName(cy.getEventType()));
        return cv;
    }





    @Override
    public Date SelectWoTime(int id) {
        return collectWorkOrderMapper.SelectWoTime(id);
    }

    @Override
    public List<CollectWorkOrder> selectByeleNum(String eleNum) {
        return collectWorkOrderMapper.selectByeleNum(eleNum);
    }

    @Override
    public int updateWorkCycle(String workOrderCycle, Integer id) {
        return collectWorkOrderMapper.updateWorkCycle(workOrderCycle,id);
    }

    @Override
    public List<CollectWorkOrder> selectList1(CollectWorkOrder c,String username,String s,String pageNo,String pageSize,List<String> orgNames,String status) {
         //= collectWorkOrderMapper.selectRole(username);
        if(s.equals("2")){//2是台区经理
            return collectWorkOrderMapper.selectList1(c,username,Integer.parseInt(pageNo),Integer.parseInt(pageSize),status);
        }else if(s.equals("1")){//1是所站长
            return collectWorkOrderMapper.selectList3(c,Integer.parseInt(pageNo),Integer.parseInt(pageSize),orgNames,status);//所站长查看的是工单预警为二级的
        }
        return collectWorkOrderMapper.selectList3(c,Integer.parseInt(pageNo),Integer.parseInt(pageSize),orgNames,status);
    }

    @Override
    public List<CollectWorkOrder> selectList2(List<String> readNames,String one, String username,Integer pageNo,Integer pageSize,String workOrderStatus,List<String> orgName,String role) {

        System.out.println("登录人"+username);
        if(role.equals("2")){//2是台区经理
            return collectWorkOrderMapper.selectList2(readNames,one,pageNo,pageSize,workOrderStatus,username);
        }else if(role.equals("1")){//1是所站长
            return collectWorkOrderMapper.selectList4(one,pageNo,pageSize,workOrderStatus,username,orgName);//所站长查看的是工单预警为二级的
        }
        return collectWorkOrderMapper.selectList4(one,pageNo,pageSize,workOrderStatus,username,orgName);
    }

    @Override
    public List<CollectWorkOrder> selectAllYWOapp() {
        return collectWorkOrderMapper.selectAllYWOapp();
    }

    @Override
    public CollectNotcon selectByPrimaryKeyn(Integer id) {
        return collectWorkOrderMapper.selectByPrimaryKeyn(id);
    }

    @Override
    public CollectInforma selectByPrimaryKeyi(Integer id) {
        return collectWorkOrderMapper.selectByPrimaryKeyi(id);
    }

    @Override
    public CollectFailure selectByPrimaryKeyf(Integer id) {
        return collectWorkOrderMapper.selectByPrimaryKeyf(id);
    }

    @Override
    public List<Map<String, Object>> nineCollWd(String username) {
        List<Map<String,Object>> list= Lists.newArrayList();
        String s = collectWorkOrderMapper.selectRole(username);
        if(s.equals("2")) {//2是台区经理
            Map<String, Object> map = new HashMap<>();
            long i1 = collectWorkOrderMapper.selectStatus1();
            long i2 = collectWorkOrderMapper.selectStatus2();
            long i3 = collectWorkOrderMapper.selectStatus3();
            long i4 = collectWorkOrderMapper.selectStatus4();
            long i5 = collectWorkOrderMapper.selectStatus5();
            long i6 = collectWorkOrderMapper.selectStatus6();
            map.put("collstatus1", i1);
            map.put("collstatus2", i2);
            map.put("collstatus3", i3);
            map.put("collstatus4", i4);
            map.put("collWarning1", i5);
            map.put("collWarning2", i6);
            list.add(map);
            return list;
        }else if(s.equals("1")){//1是所站长
            Map<String, Object> map = new HashMap<>();
            long i6 = collectWorkOrderMapper.selectStatus6();
            map.put("collWarning2", i6);
            list.add(map);
            return list;
        }
        return list;
    }

    @Override
    public void insertCollFail(List<CollectFailure> collFails) {
        for (CollectFailure collFail : collFails) {
            DateTime date = new DateTime();
            CollectWorkOrder collWo = new CollectWorkOrder();
            collWo.setMeterAssetNo(collFail.getMeterAssetNo());//电能表资产号
            collWo.setTerminalAddr(collFail.getTerminalAddr());//终端地址
            //判断研判原因
            String reason = FailTypeUtil.CollectFail(collFail.getTerminalState(),collectWorkOrderMapper.SelectCountterAdds(collFail.getTerminalAddr(),TimeUtil.getTodayTime()),collFail.getUserType());//collFail.getUserType()
//            if("0".equals(reason)){
//                break;//可能为H类用户，不生成工单
//            }
            List<CollectWorkOrder> collectWorkOrders = collectWorkOrderMapper.selectByeleNum(collFail.getMeterAssetNo());//获取到资产号一致的工单号
            int n = 0;
            CollectWorkOrder cWO = new CollectWorkOrder();
            if(collectWorkOrders.size()!=0) {
                cWO = collectWorkOrders.get(0);
                n = OrderWarnUtil.getWarning(cWO,date,"6");//判断是否是昨天的工单并标记预警
            }
            if(n==1){
                collectWorkOrderMapper.updateStatus1(cWO.getId());
                collectWorkOrderMapper.updateWorkCycle("2",cWO.getId());
    //            continue;
            }else if(n==2){
                collectWorkOrderMapper.updateStatus1(cWO.getId());
                collectWorkOrderMapper.updateWorkCycle("3",cWO.getId());
    //            continue;
            }else if(n==0) {
                collWo.setConsNo(collFail.getConsNo());
                collWo.setWorkOrderNo(TimeUtil.getTime(date) + "01" + OrderWarnUtil.OrderNum());//添加工单编号
                collWo.setFailDetailsId(collFail.getId());//采集失败关联id
                collWo.setEventReason(reason);//将研判原因传入到工单表中
                collWo.setConsName(collFail.getConsName());//将用户名传入到工单表中
                collWo.setElecAddr(collFail.getElecAddr());//将用户地址传入到工单中
                collWo.setMetManufacturer(collFail.getElecmeterFactory());//获取电能表厂家传入工单中
                collWo.setEventType("1");//工单表中事件类型为1 采集失败
                collWo.setWorkOrderStatus("1");//工单表中默认状态为1 待派单
                collWo.setWorkOrderCycle("0");
                collWo.setTgId(collFail.getTgId());//获取台区编号
                collWo.setTgName(collFail.getTgName());//获取台区名称
                collWo.setOrgName(collFail.getOrgName());//供电单位
                collWo.setPOrgName(collFail.getUpOrgName());//上级供电单位
                collWo.setMeterBarCode(collFail.getElecmeterCode());//电能表条码
                collWo.setWorkOrderCtime(date);
                collWo.setWorkOrderCtime1(TimeUtil.getTodayTime());
//                System.out.println("consNo"+collFail.getConsNo());
//                List<String> mobiles = aRcvblFlowMapper.selectMobiAddr(collFail.getConsNo());
//                if (mobiles.size()!=0) {
//                    String mobile = mobiles.get(0);
//                    collWo.setMobile(mobile);//获取用户联系方式,根据用户id
//                }
//                String mrsect = collectWorkOrderMapper.selectMrSectNo(collFail.getConsNo());//获取抄表段编号
//                String tgManagerid = collectWorkOrderMapper.selectOperator(mrsect);
                //collWo.setTgManager(collectWorkOrderMapper.selectTgManage1(collFail.getConsNo()));//根据台区编号关联出台区经理
                collectWorkOrderMapper.insertSelective(collWo);
                System.out.println("插入采集失败到工单表中******");
            }
        }
    }

    @Override
    public void insertCollNotc(CollectNotcon collNotc) {
        DateTime date = new DateTime();
        CollectWorkOrder collWo = new CollectWorkOrder();
        collWo.setMeterAssetNo(collNotc.getMeterAssetNo());//电能表资产号
        collWo.setNotConnectId(collNotc.getId());//采集未接入关联id
        collWo.setTerminalAddr(collNotc.getTerminalAddr());//终端地址
        List<CollectWorkOrder> collectWorkOrders = collectWorkOrderMapper.selectByeleNum(collNotc.getMeterAssetNo());//获取到资产号一致的工单号
        int n = 0;
        CollectWorkOrder cWO = new CollectWorkOrder();
        if(collectWorkOrders.size()!=0) {
            cWO = collectWorkOrders.get(0);
            n = OrderWarnUtil.getWarning(cWO,date,"6");//判断是否是昨天的工单并标记预警
        }
        if(n==1){
            collectWorkOrderMapper.updateStatus1(cWO.getId());
            collectWorkOrderMapper.updateWorkCycle("2",cWO.getId());
//            continue;
        }else if(n==2){
            collectWorkOrderMapper.updateStatus1(cWO.getId());
            collectWorkOrderMapper.updateWorkCycle("3",cWO.getId());
//            continue;
        }else if(n==0) {
            collWo.setConsNo(collNotc.getConsNo());
            collWo.setWorkOrderNo(TimeUtil.getTime(date) + "01" + OrderWarnUtil.OrderNum());//添加工单编号
            collWo.setEventReason("6");//将研判原因传入到工单表中
            collWo.setConsName(collNotc.getConsName());//将用户名传入到工单表中
            collWo.setElecAddr(collNotc.getElecAddr());//将用户地址传入到工单中
            collWo.setEventType("3");//工单表中事件类型为1 采集未接入
            collWo.setWorkOrderStatus("1");//工单表中默认状态为1 待派单
            collWo.setWorkOrderCycle("0");
            collWo.setTgId(collNotc.getTgId());//获取台区编号
            collWo.setTgName(collNotc.getTgName());//获取台区名称
            collWo.setOrgName(collNotc.getOrgName());//供电单位
            collWo.setMeterBarCode(collNotc.getElecmeterCode());//电能表条码
            collWo.setWorkOrderCtime(date);
            collWo.setWorkOrderCtime1(TimeUtil.getTodayTime());
//            List<String> mobiles = aRcvblFlowMapper.selectMobiAddr(collNotc.getConsNo());
//            if (mobiles.size()!=0){
//                collWo.setMobile(mobiles.get(0));//获取用户联系方式,根据用户id
//            }
            collWo.setTgManager(collNotc.getTgManager());
            collectWorkOrderMapper.insertSelective(collWo);
        }

    }

    @Override
    public void insertCollInfo(CollectInforma collInfo) {
        DateTime date = new DateTime();
        CollectWorkOrder collWo = new CollectWorkOrder();
        collWo.setMeterAssetNo(collInfo.getMeterAssetNo());//电能表资产号
        collWo.setColInforId(collInfo.getId());//采集未接入关联id
        collWo.setTerminalAddr(collInfo.getTerminalAddr());//终端地址
        List<CollectWorkOrder> collectWorkOrders = collectWorkOrderMapper.selectByeleNum(collInfo.getMeterAssetNo());//获取到资产号一致的工单号
        int n = 0;
        CollectWorkOrder cWO = new CollectWorkOrder();
        if(collectWorkOrders.size()!=0){
            cWO=collectWorkOrders.get(0);
            n = OrderWarnUtil.getWarning(cWO,date,"5");//判断是否是昨天的工单并标记预警
        }
        if(n==1){
            collectWorkOrderMapper.updateStatus1(cWO.getId());
            collectWorkOrderMapper.updateWorkCycle("2",cWO.getId());
        }else if(n==2){
            collectWorkOrderMapper.updateStatus1(cWO.getId());
            collectWorkOrderMapper.updateWorkCycle("3",cWO.getId());
        }else if(n==0) {
            collWo.setConsNo(collInfo.getConsNo().toString());
            collWo.setWorkOrderNo(TimeUtil.getTime(date) + "01" + OrderWarnUtil.OrderNum());//添加工单编号
            collWo.setEventReason("5");//将研判原因传入到工单表中
            collWo.setConsName(collInfo.getConsName());//将用户名传入到工单表中
            collWo.setElecAddr(collInfo.getElecAddr());//将用户地址传入到工单中
            collWo.setEventType("2");//工单表中事件类型为2 采集异常
            collWo.setWorkOrderStatus("1");//工单表中默认状态为1 待派单
            collWo.setWorkOrderCycle("0");
            collWo.setTgId(collInfo.getTgId().toString());//获取台区编号
            collWo.setTgName(collInfo.getTgName());//获取台区名称
            collWo.setOrgName(collInfo.getOrgName());//供电单位
            collWo.setMeterBarCode(collInfo.getElecmeterCode());//电能表条码
            collWo.setWorkOrderCtime(date);
            collWo.setWorkOrderCtime1(TimeUtil.getTodayTime());
//    List<String> mobiles = aRcvblFlowMapper.selectMobiAddr(collInfo.getConsNo());
//            if (mobiles.size()!=0){
//                collWo.setMobile(mobiles.get(0));//获取用户联系方式,根据用户id
//            }
            collWo.setTgManager(collInfo.getTgManager());//根据台区编号关联出台区经理
            collectWorkOrderMapper.insertSelective(collWo);
        }
    }
}
