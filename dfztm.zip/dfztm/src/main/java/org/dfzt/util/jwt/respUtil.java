package org.dfzt.util.jwt;

import com.alibaba.fastjson.JSON;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;

/**
 * @Author dyy
 * @Date 2022/7/22 11:18
 * @PackageName:org.dfzt.modules.dfzt.util.jwt
 * @ClassName: respUtil
 * @Description: TODO
 * @Version 1.0
 */
public class respUtil {
    public static void responseAppJSON(HttpServletResponse resp, Object obj) throws IOException {
        resp.setCharacterEncoding("utf-8");
        resp.setContentType("application/json;charset=utf-8");
        String jsonString = JSON.toJSONString(obj);
//        try(PrintWriter writer = resp.getWriter()){
//            writer.print(jsonString);
//            writer.flush();
//        }catch (Exception e){
//            e.printStackTrace();
//        }
/*        try{

        }catch (Exception e){
            e.printStackTrace();
        }

        OutputStream outputStream = resp.getOutputStream();
//        String json = new ObjectMapper().writeValueAsString(jsonString);
        outputStream.write(jsonString.getBytes());
        outputStream.flush();
        outputStream.close();*/

        try(OutputStream outputStream = resp.getOutputStream()){
            //        String json = new ObjectMapper().writeValueAsString(jsonString);
            outputStream.write(jsonString.getBytes());
            outputStream.close();
            outputStream.flush();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
