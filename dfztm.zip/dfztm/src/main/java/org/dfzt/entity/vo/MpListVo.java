package org.dfzt.entity.vo;

import lombok.Data;

import java.math.BigDecimal;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/9
 * @Version: 1.00
 */
@Data
public class MpListVo {
    private Integer Id;
    private String mpNo;//计量点编号
    private String voltCode;//电压等级
    private BigDecimal mpCap;//计量点容量
    private String calcMode;//计算方式
    private String frDeductFlag;//定比扣减方式
    private String measMode;//计量方式
    private String tlShareFlag;//变损分摊标志
    private String llBillFlag;//线损计费标志
    private String llShareFlag;//线损分摊标志
    private BigDecimal fqrValue;//定比定量值
    private String tlBillFlag;//变损计费标志
    private String llCalcMode;//线损计算方式
    private String statusCode;//计量点状态
    private String tgName;//台区名称
    private String tgNo;//台区编号
    private String lineNo;//线路编号
    private String lineName;//线路名称
    private String wiringMode;//接线方式
    private String marketType;//市场化类型
}
