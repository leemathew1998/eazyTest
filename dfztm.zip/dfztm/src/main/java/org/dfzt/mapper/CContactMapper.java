package org.dfzt.mapper;


import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.dfzt.entity.po.CCons;
import org.dfzt.entity.po.CContact;
import org.dfzt.entity.po.CInformation;

import java.math.BigDecimal;
import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Mapper
public interface CContactMapper extends BaseMapper<CContact> {
    //根据受电点查询用户号
    @Select("SELECT cons_no FROM c_information WHERE power_point_no = #{powerPointNo} ")
    CInformation selconsNo(String powerPointNo);

    //根据用户号查询用户信息
    @Select("SELECT contact_mode,contact_name,gender,title,office_tel,mobile,cons_no\n" +
            "FROM c_contact \n" +
            "WHERE cons_no = #{consNo}")
    List<CContact> selconsinfo(String consNo);

    @DS("mpg")
    List<CCons> selectCCons(String orgNo);

    Integer insertCCons(CCons cCons);

    Integer selectByconsId(BigDecimal consId);

    @DS("mpg")
    List<CContact> selectCConTact(BigDecimal custId);//查询用户联系方式的表
    List<BigDecimal> selectCustIdList();//查询tqwgh表已有的用户custid

    Integer insertCContact(CContact cContact);//将用户联系表新增到tqwgh中

//    Integer selectBycontactId(BigDecimal contactId);
}
