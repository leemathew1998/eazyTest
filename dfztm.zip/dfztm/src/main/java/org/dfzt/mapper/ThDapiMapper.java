package org.dfzt.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00 三维接口相关的mapper层
 */

@Repository
public interface ThDapiMapper {
    Integer selectUpcoming1(String orgName);//查询计量和采集的待办有多少工单数
    Integer selectUpWarning1(String orgName);//查询计量和采集的预警有多少工单数

    Integer selectUpcoming2(String workorderType,String orgName);//查询线损治理的待办和预警有多少工单数

    Integer selectUpcoming3(String workorderType,String orgName);//查询费控复电的待办和预警有多少工单数

    Integer selectUpcoming4(String workorderType,String orgName);//查询电费回收的待办和预警有多少工单数

    Integer selectUpcoming5(String workorderType,String orgName);//查询优质服务的待办和预警有多少工单数

    Integer selectUpcoming6(String orgName);//查询主动运维和抢修的待办有多少工单数
    Integer selectUpWarning6(String orgName);//查询主动运维和抢修的预警有多少工单数
}
