package com.exam.modules.mapper;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Constants;
import com.exam.modules.entity.ExamInfo;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

/**
 * 考试信息(ExamInfo)表数据库访问层
 *
 * @author makejava
 * @since 2022-11-09 15:05:39
 */
public interface ExamInfoMapper extends BaseMapper<ExamInfo> {


    @Update("UPDATE EXAM.EXAM_INFO \n" +
                    "SET IS_TRUE = 2 \n" +
                    "WHERE USER_ID = #{userId} AND EXAM_ID = #{examId}")
    boolean isTrue(Long userId,Long examId);

    @Select("SELECT COUNT(USER_ID)\n" +
            "FROM EXAM.EXAM_INFO \n" +
            "WHERE EXAM_ID = #{examId}")
    Long count(Long examId);
    @Select("SELECT COUNT(USER_ID)\n" +
            "FROM EXAM.EXAM_INFO \n" +
            "WHERE EXAM_ID = #{examId}" +
            "AND IS_TRUE = 2")
    Long count1(Long aLong);


    @Update("UPDATE EXAM.EXAM_INFO \n" +
            "SET ABNORMAL = #{abnormal} \n" +
            "WHERE USER_ID = #{userId} AND EXAM_ID = #{examId}")
    boolean abnormal(String abnormal,Long userId, Long examId);

    @Select("SELECT EXAM_NAME,SCORE_SUM,EXAM_ID,USER_ID,RANK() OVER(order by SCORE_SUM DESC ) as rank\n" +
            "FROM EXAM.EXAM_INFO\n" +
            "WHERE EXAM_ID = #{examId}")
    List<ExamInfo> ranks(Long examId);

    //各知识分类考试人数分布（1.前端 2.后端 3.设计 4.测试）
    @Select("SELECT COUNT(1)\n" +
            "FROM EXAM.EXAM_INFO EI\n" +
            "LEFT JOIN EXAM.EXAM_PAPER_INFO EPI ON EI.EXAM_PAPER_ID = EPI.EXAM_PAPER_ID\n" +
            "WHERE EPI.KNOW_GORY = #{knowGory}" +
            "AND EI.IS_TRUE = 2")
    Integer examPerCount(String knowGory);

    //各知识分类成绩人数分布
    @Select("SELECT COUNT(1)\n" +
            "FROM EXAM.EXAM_INFO EI\n" +
            "LEFT JOIN EXAM.EXAM_PAPER_INFO EPI ON EI.EXAM_PAPER_ID = EPI.EXAM_PAPER_ID\n" +
            "WHERE SCORE_SUM BETWEEN #{beginScore} AND #{endScore}\n" +
            "AND EPI.KNOW_GORY = #{knowGory}\n" +
            "AND EI.IS_TRUE = 2")
    Integer examScoreCount(int beginScore,int endScore,String knowGory);


    IPage<ExamInfo> selectExampage(IPage<ExamInfo> page,@Param(Constants.WRAPPER) Wrapper<ExamInfo> queryWrapper);

}


