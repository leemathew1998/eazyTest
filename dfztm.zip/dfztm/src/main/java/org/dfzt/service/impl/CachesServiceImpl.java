package org.dfzt.service.impl;

import org.dfzt.config.BaseCache;
import org.dfzt.config.CacheConstant;
import org.dfzt.entity.po.CaccheCons;
import org.dfzt.entity.po.consTgScm;
import org.dfzt.entity.vo.PropListVo;
import org.dfzt.service.CachesService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class CachesServiceImpl implements CachesService {
    @Override
    public List<String> getBusinessPlace() {
        List<consTgScm> consTgScms = (List<consTgScm>) BaseCache.get(CacheConstant.SYS_ORG_CACHE);
        List<String> collect = consTgScms.stream().filter(i -> i.getOrgType().equals("05")).map(i->i.getOrgNo())
                .collect(Collectors.toList());
        return collect;
    }

    @Override
    public String getOrgName(String orgNo) {
        List<consTgScm> orgList = (List<consTgScm>) BaseCache.get(CacheConstant.SYS_ORG_CACHE);
        Optional<consTgScm> opt = orgList.stream().filter(i -> i.getOrgNo().equals(orgNo)).findFirst();
        if (opt.isPresent()){
            return opt.get().getOrgName();
        }
        return "";
    }

    @Override
    @Cacheable(cacheNames= CacheConstant.SYS_ORG_CACHE_REDIS, key="#orgNo")
    public String getOrgNameRedis(String orgNo) {
        List<consTgScm> orgList = (List<consTgScm>) BaseCache.get(CacheConstant.SYS_ORG_CACHE);
        Optional<consTgScm> opt = orgList.stream().filter(i -> i.getOrgNo().equals(orgNo)).findFirst();
        if (opt.isPresent()){
            return opt.get().getOrgName();
        }
        return "";
    }

    @Override
    public String getPropName(String codeType, String value) {
        List<PropListVo> propListVos = (List<PropListVo>) BaseCache.get(CacheConstant.SYS_PROP_CACHE);
        Optional<PropListVo> first = propListVos.stream().filter(i -> i.getCodeType().equals(codeType))
                .filter(i -> i.getValue().equals(value)).findFirst();
        if (first.isPresent()){
            return first.get().getName();
        }
        return "";
    }

    @Override
    public String getConsName(String consNo) {
        List<CaccheCons> consList = (List<CaccheCons>) BaseCache.get(CacheConstant.SYS_CONS_CACHE);
        Optional<CaccheCons> first = consList.stream().filter(i -> i.getConsNo().equals(consNo)).findFirst();
        if (first.isPresent()){
            return first.get().getConsName();
        }
        return "";
    }
}
