package org.dfzt.entity.tdo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/30
 * @Version: 1.00
 * 统计列表实体类
 */
@Data
public class StatisticsList {
    //类型(1:低压用户数据 2:高压用户数量 3:0.4kV线路长度
    // 4:10kV线路长度 5:在运专变数量 6:在运公变数量 7:在运电能表数量 8:在运采集终端设备)
    private Number type;

    //类型名称(1:低压用户数据 2:高压用户数量 3:0.4kV线路长度
    // 4:10kV线路长度 5:在运专变数量 6:在运公变数量 7:在运电能表数量 8:在运采集终端设备)
    private String typeName;

    //值
    private Number value;

    //类型单位（户、千米、个）
    private String typeUnit;
}
