package org.dfzt.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.LinelossSynana;
import org.dfzt.entity.po.LinelossWorkOrder;
import org.dfzt.entity.vo.LinelossWorkOrderv;

import java.text.ParseException;
import java.util.List;
import java.util.Map;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/6/15
 * @Version: 1.00
 */
public interface LinelossWorkOrderService extends IService<LinelossWorkOrder> {
    int insertSelective(LinelossWorkOrder llwo);

    List<LinelossWorkOrder> selectAllLine();//查询线损工单表

    Integer updateTypeNum(String tgId, Integer comQuesNum, Integer elestealNum, Integer zeroFireNum, Integer currentNobalNum, Integer platOverloadNum, Integer userOverloadNum);

    LinelossWorkOrder selectOne(String tgId);

    Integer updateWoStatus2(String tgId);//根据工单id改变工单状态为2处理中
    Integer updateWoStatus3(String workOrderNo);//根据工单id改变工单状态为3待归档

    IPage<LinelossWorkOrder> selectAllLine1(Map<String,Object> map);//查询线损工单表--分页查询

    List<LinelossWorkOrder> selectList1(LinelossWorkOrder l,String username,String status,String orgName,String pageNo,String pageSize);//线损多条件查询

    List<LinelossWorkOrder> selectList2(List<String> readNames,String one,String username,Integer pageNo,Integer pageSize,String workOrderStatus,String role);//线损单个条件查询

    void insertLineloss(LinelossSynana lineloss) throws ParseException;

    Integer updatwWoStatus4(String tgId);//根据工单id改变状态为4已归档

}
