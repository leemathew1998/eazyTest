package org.dfzt.webservice;

import org.springframework.stereotype.Component;

import javax.jws.WebService;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/2/21
 * @Version: 1.00
 */
@Component
@WebService(targetNamespace="http://webservice.dfzt.org",endpointInterface = "org.dfzt.webservice.WebServiceGetValue")
public class WebServiceGetValueImpl implements WebServiceGetValue{
    @Override
    public String getKPIValue(String param) {
        System.out.println("进入接口");
        return "进入接口，获取数据";
    }
}
