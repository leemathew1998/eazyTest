package com.exam.modules.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.exam.modules.entity.SysLog;
import com.exam.modules.entity.SysUser;
import com.exam.modules.entity.vo.UserQueryVo;
import com.exam.modules.service.ISysLogService;
import com.exam.modules.service.ISysUserService;
import com.exam.modules.utils.Result;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * <p>
 * 登录日志 前端控制器
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@RestController
@RequestMapping("/api/log")
public class SysLogController {
    @Resource
    private ISysLogService sysLogService;
    @Resource
    private ISysUserService sysUserService;


    /**
     * 查询成功登录日志
     * @return
     */
    @PostMapping("/logSuccess")
    public Result logSuccess(@RequestBody UserQueryVo queryVo){
        //分页查询
        IPage<SysLog> page = new Page<>(queryVo.getPageNo(), queryVo.getPageSize());
        //构造条件
        QueryWrapper<SysLog> queryWrapper = new QueryWrapper<>();
        //根据登录时间查询
        if (queryVo.getStratTime()!=null && queryVo.getEndTime()!=null){
            queryWrapper.between("LOGIN_TIME",queryVo.getStratTime(),queryVo.getEndTime());
        }
        //登录成功日志
        queryWrapper.eq("STATUS",0);
        //排序
        queryWrapper.orderByAsc("LOGIN_TIME");
        //分页查询的数据
        IPage<SysLog> page1 = sysLogService.page(page, queryWrapper);
        //list集合存储分组字段
        List<SysLog> list = new ArrayList<>();
        for (SysLog record : page1.getRecords()) {
            SysLog log = new SysLog();
            //根据用户id查询分组
            List<String> theGroup = sysUserService.list()
                    .stream()
                    .filter(s -> Objects.equals(s.getUserId(), record.getUserId()))
                    .map(SysUser::getTheGroup)
                    .collect(Collectors.toList());
            //赋值
            for (String group : theGroup) {
                log.setTheGroup(group);
            }
            log.setUserId(record.getUserId());
            //存入集合
            list.add(log);
            //如果userId相等
            for (SysLog pageRecord : page1.getRecords()) {
                for (SysLog sysLog : list) {
                    if (sysLog.getUserId().equals(pageRecord.getUserId())){
                        //将查询的分组字段赋值返回
                        pageRecord.setTheGroup(sysLog.getTheGroup());
                    }
                }
            }
        }
        return Result.ok(page1);
    }

    /**
     * 查询失败登录日志
     * @return
     */
    @PostMapping("/loglFailure")
    public Result loglFailure(){
        return Result.ok(sysLogService.loglFailure());
    }
}
