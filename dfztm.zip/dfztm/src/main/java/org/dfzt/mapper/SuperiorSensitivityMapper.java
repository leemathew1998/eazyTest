package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.dfzt.entity.vo.SuperiorSensitivity;

import java.util.List;
import java.util.Map;

/**
 * (SuperiorSensitivity)表数据库访问层
 *
 * @author makejava
 * @since 2022-10-27 11:24:34
 */
@Mapper
public interface SuperiorSensitivityMapper extends BaseMapper<SuperiorSensitivity> {
    /**
     * 批量新增数据（MyBatis原生foreach方法）
     *
     * @param entities List<SuperiorSensitivity> 实例对象列表
     * @return 影响行数
     */
    int insertBatch(@Param("entities") List<SuperiorSensitivity> entities);

    /**
     * 批量新增或按主键更新数据（MyBatis原生foreach方法）
     *
     * @param entities List<SuperiorSensitivity> 实例对象列表
     * @return 影响行数
     * @throws org.springframework.jdbc.BadSqlGrammarException 入参是空List的时候会抛SQL语句错误的异常，请自行校验入参
     */
    int insertOrUpdateBatch(@Param("entities") List<SuperiorSensitivity> entities);

    List<SuperiorSensitivity> selectAll(Map map);

    int updateAll(Map map);

    String selectAdd(String dcounty);//所属的区县


}

