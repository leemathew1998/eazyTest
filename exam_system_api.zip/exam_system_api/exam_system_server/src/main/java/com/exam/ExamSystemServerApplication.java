package com.exam;


import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@Slf4j
@SpringBootApplication
//开启定时任务
@EnableScheduling
public class ExamSystemServerApplication{
    public static void main(String[] args) {
        SpringApplication.run(ExamSystemServerApplication.class, args);
    }
}

