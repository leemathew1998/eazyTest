package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import lombok.Data;

import java.util.List;

/**
 * @ClassName ReaLDemo
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/14 20:06
 */
@Data
@XStreamAlias("DBSET")
public class ReaLDemo {

    @XStreamImplicit
   /*注解使用当需要将collection或map类型的成员变量中数据转换成xml相同层次的元素时，
   可以在该成员变量使用该注解，
   会将添加注释的节点去掉 @XStreamImplicit(itemFieldName="real1List")*/
    private List<General> real1List;

}
