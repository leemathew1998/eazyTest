package org.dfzt.webservice;

import cn.hutool.core.util.XmlUtil;
import org.dom4j.*;
import org.dom4j.io.SAXReader;
import org.xml.sax.InputSource;
//import org.dom4j.Element;


import java.io.StringReader;
import java.util.Iterator;
import java.util.List;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/12/15
 * @Version: 1.00
 */
public class ReadXml {

    public static void main(String[] args){
//        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" + "<DBSET>"
//                + "<RETURN_STATUS>"
//                + "<C N=\"RLT_FLAG\">"+"1"+"</C>"
//                + "<C N=\"RLT_FLAG\">"+"XXXX"+"</C>"
//                + "</RETURN_STATUS>"
//                +

        String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<DATA_CONTENT>"
                + "<R>"
                    +"<C N=\"P_ORG_NAME\">上级单位1</C>"
                    +"<C N=\"ORG_NAME\">单位1</C>"
                    +"<C N=\"CONS_NO\">台区编号1</C>"
                + "</R>"
//                + "<R>"
//                    +"<C N=\"P_ORG_NAME\">上级单位2</C>"
//                    +"<C N=\"ORG_NAME\">单位2</C>"
//                    +"<C N=\"CONS_NO\">台区编号2</C>"
//                + "</R>"
                + "</DATA_CONTENT>"
                ;

    //    + "</DBSET>"
        Document doc = null;
        try {
            InputSource source = new InputSource(new StringReader(xml));
            SAXReader reader = new SAXReader();
            doc = reader.read(source);
            Element root = doc.getRootElement();
            System.out.println("P_ORG_NAME"+doc.elementByID("R").getTextTrim());
            System.out.println("P_ORG_NAME"+doc.elementByID("P_ORG_NAME").getTextTrim());
            System.out.println("P_ORG_NAME"+doc.elementByID("DATA_CONTANT").getTextTrim());
            System.out.println("P_ORG_NAME"+root.elementByID("P_ORG_NAME").getTextTrim());
//            doc = DocumentHelper.parseText(xml); // 将字符串转为XML

//            Element rootElt = doc.getRootElement(); // 获取根节点

//            System.out.println("根节点：" + rootElt.getName()); // 拿到根节点的名称 DATA
//            Iterator iter = rootElt.elementIterator("R"); // 获取根节点下的子节点R
//
//            Element datac = rootElt.element("R");
//            System.out.println("datac"+datac);
//            List<Element> r = datac.elements("R");
//            String text = r.get(0).getText();
//            System.out.println("text:"+text);
//            String c = r.get(0).attributeValue("C");
//            System.out.println("C"+c);
//
//
//
//            System.out.println("iter"+iter);
//            XmlUtil.getElements(rootElt,"C");
            // 遍历R节点
//            while (iter.hasNext()) {
//                Element recordEle = (Element) iter.next();
//                String C = recordEle.elementTextTrim("C"); // 拿到R节点下的子节点C值
//                System.out.println("C:" + C);
//                Iterator iterator = recordEle.elementIterator("N");
//                System.out.println("iterator : "+iterator);

//                String s = recordEle.element("C").attributeValue("P_ORG_NAME");
//                System.out.println("s:"+s);
//
//                Iterator iters = recordEle.elementIterator("C"); // 获取子节点head下的子节点script
//                System.out.println(iters);


                // 遍历Header节点下的Response节点
//                while (iters.hasNext()) {
//                    Element itemEle = (Element) iters.next();
//                    System.out.println(itemEle.attribute("P_ORG_NAME"));
//                    System.out.println(itemEle);
////
////                    String porgname = itemEle.elementTextTrim("P_ORG_NAME"); // 拿到head下的子节点script下的字节点username的值
////                    String orgname = itemEle.elementTextTrim("ORG_NAME");
////                    String consno = itemEle.elementTextTrim("CONS_NO");
////
////                    System.out.println("P_ORG_NAME:" + porgname);
////                    System.out.println("ORG_NAME:" + orgname);
////                    System.out.println("CONS_NO:" + consno);
//                }
          //  }
        }catch (DocumentException e){
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
