package com.exam.modules.entity.vo;

import com.exam.modules.entity.SysUser;
import lombok.Data;

import java.util.Date;

/**
 * @Author dyy
 * @Date 2022/11/4 17:44
 * @PackageName:com.exam.modules.entity.vo
 * @ClassName: UserQueryVo
 * @Description: TODO
 * @Version 1.0
 */
@Data
public class UserQueryVo extends SysUser {
    private Long pageNo = 1L;//当前页码
    private Long pageSize = 10L;//每页显示数量
    private Date stratTime;
    private Date endTime;
}
