package org.dfzt.entity.po;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 
 * </p>
 *
 * @author XingJunHao
 * @since 2022-07-11
 */
@Data
@EqualsAndHashCode(callSuper = false)
@ApiModel(value = "CContact对象", description = "")
public class CContact implements Serializable {
    @ApiModelProperty(value = "联系信息标识 本实体记录的唯一标识")
    @TableField("contact_id")
    private BigDecimal contactId;

    @ApiModelProperty(value = "客户标识  本实体记录的唯一标识，产生规则为流水号")
    @TableField("cust_id")
    private BigDecimal custId;

    @ApiModelProperty(value = "联系类型 联系信息的分类，区分其不同的用途 01 电气联系人、02 帐务联系人、03 停送电联系人")
    @TableField("contact_mode")
    private String contactMode;

    @ApiModelProperty(value = "联系信息来源 联系信息的产生来源，主要可以保证联系信息的正确使用和修改，如合同约定的联系信息95598业务不能修改。")
    @TableField("contact_source")
    private String contactSource;

    @ApiModelProperty(value = "联系优先级 ")
    @TableField("contact_prio")
    private BigDecimal contactPrio;

    @ApiModelProperty(value = "联系人 联系人的姓名")
    @TableField("contact_name")
    private String contactName;

    @ApiModelProperty(value = "性别 联系人的性别说明代码  01 男，02 女")
    private String gender;

    @ApiModelProperty(value = "部门编号 联系人所在单位的部门描述信息")
    @TableField("dept_no")
    private String deptNo;

    @ApiModelProperty(value = "联系人的职务/职称描述信息")
    private String title;

    @ApiModelProperty(value = "办公电话 可存储多个")
    @TableField("office_tel")
    private String officeTel;

    @ApiModelProperty(value = "住宅电话 可存储多个")
    private String homephone;

    @ApiModelProperty(value = "移动电话 可存储多个电话")
    private String mobile;

    @ApiModelProperty(value = "传真号码 可存储多个")
    @TableField("fax_no")
    private String faxNo;

    @ApiModelProperty(value = "联系地址 联系的通讯地址")
    private String addr;

    @ApiModelProperty(value = "邮编 联系地址的邮编")
    private String postalcode;

    @ApiModelProperty(value = "联系的电子邮箱 可存储多个")
    private String email;

    @ApiModelProperty(value = "联系人的家庭住址")
    @TableField("family_addr")
    private String familyAddr;

    @ApiModelProperty(value = "联系人的兴趣爱好")
    private String interest;

    @ApiModelProperty(value = "联系人的工作经历")
    private String work;

    @ApiModelProperty(value = "联系备注 联系的其他相关信息描述")
    @TableField("contact_remark")
    private String contactRemark;

    @DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss" ,timezone="GMT+8")
    @ApiModelProperty(value = "出生日期")
    private Date birthday;
    private int del_flag;

    @TableField(exist = false)
    private String consNo;
}
