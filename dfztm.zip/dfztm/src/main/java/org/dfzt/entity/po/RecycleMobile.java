package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/6/6
 * @Version: 1.00
 */
@Data
public class RecycleMobile implements Serializable {
    private String consNo;
    private String mobile;
}
