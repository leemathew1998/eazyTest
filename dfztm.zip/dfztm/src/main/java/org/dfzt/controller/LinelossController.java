package org.dfzt.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.api.ApiController;
import com.baomidou.mybatisplus.extension.api.R;
import com.google.common.collect.Maps;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.dfzt.annotation.CurrentUser;
import org.dfzt.entity.po.*;
import org.dfzt.entity.vo.LinelossWorkOrderv;
import org.dfzt.entity.vo.SplitTime;
import org.dfzt.entity.vo.SysUser;
import org.dfzt.eunm.WorkOrderStatusEnum;
import org.dfzt.mapper.CollectWorkOrderMapper;
import org.dfzt.mapper.LinelossSpqMapper;
import org.dfzt.mapper.LinelossWorkOrderMapper;
import org.dfzt.mapper.MeterCurrentMapper;
import org.dfzt.service.EventTypeService;
import org.dfzt.service.LinelossWorkOrderService;
import org.dfzt.service.WorkOrderInforService;
import org.dfzt.util.ExcelUtils;
import org.dfzt.util.PearsonUtil;
import org.dfzt.util.TimeUtil;
import org.dfzt.util.TwenfourPointUtil;
import org.dfzt.webservice.WebServiceSchedule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.security.Key;
import java.text.ParseException;
import java.util.*;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2022/7/11
 * @Version: 1.00
 * TODO 线损治理
 */

@RestController
@Slf4j
@CrossOrigin
@RequestMapping("/lineloss")
@Api(value = "线损治理")
public class LinelossController extends ApiController {

    @Resource
    private EventTypeService eventTypeService;

    @Resource
    private LinelossWorkOrderService linelossWorkOrderService;

    @Resource
    private WorkOrderInforService workOrderInforService;

    @Resource
    private MeterCurrentMapper meterCurrentMapper;

    @Resource
    private LinelossSpqMapper linelossSpqMapper;
    @Resource
    private CollectWorkOrderMapper collectWorkOrderMapper;
    @Resource
    private LinelossWorkOrderMapper linelossWorkOrderMapper;


    /**
     * TODO 查询线损工单表所有数据
     * @return
     */
    @ResponseBody
    @PostMapping("/list")
    @ApiOperation(value = "查询所有工单信息")
    public List<LinelossWorkOrder> LinelossList(){
        List<LinelossWorkOrder> linelosss = linelossWorkOrderService.selectAllLine();
        for (LinelossWorkOrder lineloss : linelosss) {
            lineloss.setWorkOrderStatus(WorkOrderStatusEnum.getValueByName(lineloss.getWorkOrderStatus()));
        }
        return linelosss;
    }

    /**
     * TODO 线损工单分页查询
     * @param map
     * @return
     */
    @ResponseBody
    @PostMapping("listp")
    public R<IPage<LinelossWorkOrder>> pageList(@RequestBody Map<String,Object> map){
        IPage<LinelossWorkOrder> iPage = linelossWorkOrderService.selectAllLine1(map);
        return success(iPage);
    }

    @RequestMapping("export")  //excel/export
    public void exportExcel2(HttpServletResponse response, @RequestParam String ids) throws IOException {
        List<LinelossWorkOrder> meterWorkOrders = collectWorkOrderMapper.selectExcel3(ids);
        ExcelUtils.exportExcel(meterWorkOrders, "线损治理工单列表", "线损治理", MeterWorkOrder.class, "线损治理工单文件", response);
    }

    @RequestMapping("exportAll")  //excel/export
    public void exportExcel2All(HttpServletResponse response, @RequestParam(required = false) String ids,LinelossWorkOrder l,
                                @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,
                                @RequestParam(required = false) String loName2) throws IOException {
        String orgName=null;
        List<LinelossWorkOrder> linelossWorkOrders = linelossWorkOrderService.selectList1(l,loName2,status,orgName,"1","999999999");
        ExcelUtils.exportExcel(linelossWorkOrders, "线损治理工单列表", "线损治理", LinelossWorkOrder.class, "线损治理工单文件", response);
    }

    /**
     * TODO 多条件查询查询线损工单表所有数据
     * @return
     */
    @ResponseBody
    @PostMapping("/list1")
    public R LinelossList1(LinelossWorkOrder l,@RequestParam(name = "pageNo",defaultValue = "1") String pageNo,
                                                 @RequestParam(name = "pageSize",defaultValue = "10") String pageSize,
                                                 @RequestParam(required = false) String status,@RequestParam(required = false) String orgNo,@RequestParam(required = false) String loName2){

        String orgName = null;
        if (orgNo !=null || "".equals(orgNo)) {
            orgName = collectWorkOrderMapper.selectOrgNo(orgNo);
        }
        List<LinelossWorkOrder> linelossWorkOrders = linelossWorkOrderService.selectList1(l,loName2,status,orgName,pageNo,pageSize);
        int size = linelossWorkOrderService.selectList1(l, loName2, status, orgName, "1", "999999999").size();
        Map<Integer,List<LinelossWorkOrder>> map = new HashMap<>();
        map.put(size,linelossWorkOrders);
        return success(map);
    }

//    /**
//     * TODO 多条件查询查询线损工单表所有数据
//     * @return
//     */
//    @ResponseBody
//    @PostMapping("/list1")
//    public List<LinelossWorkOrder> LinelossList1(LinelossWorkOrder l,@CurrentUser SysUser user){
//        List<LinelossWorkOrder> linelossWorkOrders = linelossWorkOrderService.selectList1(l,user.getLoginName());
//        return linelossWorkOrders;
//    }


    /**
     * TODO 单个条件查询线损工单表数据111 app
     * @return
     */
    @ResponseBody
    @PostMapping("/list2")
    public List<LinelossWorkOrder> LinelossList2(String one,@RequestParam(name = "pageNo",defaultValue = "0") String pageNo,
                                                 @RequestParam(name = "pageSize",defaultValue = "10") String pageSize,@RequestParam String loName2
            ,@RequestParam String workOrderStatus,@RequestParam(required = false) String role,@RequestParam(required = false) String loginName){
        List<String> readNames = collectWorkOrderMapper.selectReadNames(loginName);
        List<LinelossWorkOrder> linelossWorkOrders = linelossWorkOrderService.selectList2(readNames,one,loName2,Integer.parseInt(pageNo),Integer.parseInt(pageSize),workOrderStatus,role);
        return linelossWorkOrders;
    }




    /**
     * TODO 点击查询单个工单具体详情 工单状态改为2.处理中
     * @return
     */
    @ResponseBody
    @PostMapping("/selectOne")
    @ApiOperation(value = "查询单个工单信息")
    public LinelossWorkOrder selectOneLwo(String tgId){
        //传入台区经理，操作时间，存到处理信息表中
        //历史记录可以查询处理信息表
        Integer type1 = eventTypeService.selectType1Byplatid(tgId);
        Integer type2 = eventTypeService.selectType2Byplatid(tgId);
        Integer type3 = eventTypeService.selectType3Byplatid(tgId);
        Integer type4 = eventTypeService.selectType4Byplatid(tgId);
        Integer type5 = eventTypeService.selectType5Byplatid(tgId);
        Integer type6 = eventTypeService.selectType6Byplatid(tgId);
        Integer i = linelossWorkOrderService.updateTypeNum(tgId, type1, type2, type3, type4, type5, type6);
        log.info(i.toString());
        Integer integer2 = linelossWorkOrderService.updateWoStatus2(tgId);
        log.info("状态改为2处理中{}",integer2);
        log.info("数量更新记录为{}",tgId);
        LinelossWorkOrder llv = linelossWorkOrderService.selectOne(tgId);
        return llv;
    }


    /**
     * TODO 增加图片视频处理信息 工单状态改为3.待归档
     * @param colWOInfor
     * @return
     */
    @ResponseBody
    @PostMapping("/linelossinfor")
    @ApiOperation(value = "提交图片和视频")
    public int linelossinfor(WorkOrderInfor colWOInfor){
        int i = workOrderInforService.insertSelective(colWOInfor);//接收到图片视频等存放
        Integer integer3 = linelossWorkOrderService.updateWoStatus3(colWOInfor.getWorkOrderNo());
        log.info("状态改为3待归档,{}",integer3);
        log.info("i记录为:,{}",i);
        return i;
    }


    /**
     * TODO 回显工单处理表的图片和视频
     * @param workOrderNo 处理表中对应的工单id/
     * @return
     */
    @ResponseBody
    @PostMapping("/load")
    @ApiOperation(value = "回显图片和视频")
    public WorkOrderInfor loadInfovp(String workOrderNo){
        WorkOrderInfor collectWorkOrderInfor = workOrderInforService.SelectVandP(workOrderNo);
        log.info(String.valueOf(collectWorkOrderInfor));
        return collectWorkOrderInfor;
    }

    /**
     * TODO 点击查询采集通信问题详情
     * @return
     */
    @ResponseBody
    @PostMapping("/selectcom")
    @ApiOperation(value = "点击查询采集通信问题详情")
    public List<EventType> selectCom(String tgId){
        return eventTypeService.selectType1(tgId);
    }


    /**
     * TODO 点击查询可能存在窃电
     * @return
     */
    @ResponseBody
    @PostMapping("/selectele")
    @ApiOperation(value = "点击查询可能存在窃电")
    public List<EventType> selectEle(String tgId){
        return eventTypeService.selectType2(tgId);
    }


    /**
     * TODO 点击查询零线大于火线
     * @return
     */
    @ResponseBody
    @PostMapping("/selectzero")
    @ApiOperation(value = "点击查询零线大于火线")
    public List<EventType> selectZero(String tgId){
        return eventTypeService.selectType3(tgId);
    }

    /**
     * TODO 点击查询台电流不平衡超阈值
     * @return
     */
    @ResponseBody
    @PostMapping("/selectcnobal")
    @ApiOperation(value = "点击查询台电流不平衡超阈值")
    public List<EventType> selectCnobal(String tgId){
        return eventTypeService.selectType4(tgId);
    }


    /**
     * TODO 点击查询台区负荷超容
     * @return
     */
    @ResponseBody
    @PostMapping("/selectplat")
    @ApiOperation(value = "点击查询台区负荷超容")
    public List<EventType> selectPlat(String tgId){
        return eventTypeService.selectType5(tgId);
    }

    /**
     * TODO 点击查询用户负荷超容
     * @return
     */
    @ResponseBody
    @PostMapping("/selectuser")
    @ApiOperation(value = "点击查询用户负荷超容")
    public List<EventType> selectUser(String tgId) {
        return eventTypeService.selectType6(tgId);
    }


    /**
     * TODO 增加分时分相显示
     */
    @ResponseBody
    @PostMapping("/split")
    public List<SplitTime> Split(String tgId){
        ArrayList<SplitTime> list = new ArrayList<>();
        try {
//            /**
//             * TODO ppq表示供电量  spq表示售电量
//             */
//            //9.1 分时计算 取用户编号列、资产号列、综合倍率列、相别列及各时段示值（导出示值包含0-23时，需继续导出第二日0时数据）
//            String meterAssetNo = WebServiceSchedule.getTgppq1(tgId, TimeUtil.getStartTwoTime());
//            List<IndicationValue> indValues = WebServiceSchedule.getDayIndi(meterAssetNo);//示值曲线
//            BigDecimal spqA = new BigDecimal(0);//0-6售电量声明
//            BigDecimal spqB = new BigDecimal(0);//
//            BigDecimal spqC = new BigDecimal(0);
//            BigDecimal spqD = new BigDecimal(0);
//            BigDecimal ppqA = new BigDecimal(0);//0-6供电量声明
//            BigDecimal ppqB = new BigDecimal(0);
//            BigDecimal ppqC = new BigDecimal(0);
//            BigDecimal ppqD = new BigDecimal(0);
//
//            for (IndicationValue indValue : indValues) {
//                String eleAssetNum = indValue.getMeterAssetNo();//电能表资产号
//                Date sendTime = indValue.getRecTime();//获取上送时间
//                String tomorr = TimeUtil.getYesterday(sendTime);
////                        String userCode = indValue.getUserCode();//用户编号列
//                BigDecimal tFactor = indValue.getTFactor();//综合倍率列
//                //相别正向有功
////                String meterAssetNo = indValue.getMeterAssetNo();//电能表资产号
//                if (indValue.getUsageTypeCode().contains("售电侧结算")) {
//                    spqA = indValue.getR25().subtract(indValue.getR1()).multiply(indValue.getTFactor());//0-6的示值差值
//                    spqB = indValue.getR49().subtract(indValue.getR25()).multiply(indValue.getTFactor());//6-12电的示值差值
//                    spqC = indValue.getR73().subtract(indValue.getR49()).multiply(indValue.getTFactor());//12-18的示值差值
//                    //第二天0点的数值
//                    BigDecimal pointZero = meterCurrentMapper.selectTomorrZero(eleAssetNum, tomorr).getR1();
//                    spqD = pointZero.subtract(indValue.getR73()).multiply(indValue.getTFactor());//18-24的示值差值
//                }
//                if (indValue.getUsageTypeCode().contains("台区供电考核")) {
//                    ppqA = indValue.getR25().subtract(indValue.getR1());//0-6的示值差值 供电量
//                    ppqB = indValue.getR49().subtract(indValue.getR25());//6-12电的示值差值 供电量
//                    ppqC = indValue.getR73().subtract(indValue.getR49());//12-18的示值差值 供电量
//                    BigDecimal pointZero = meterCurrentMapper.selectTomorrZero(eleAssetNum, tomorr).getR1();
//                    ppqD = pointZero.subtract(indValue.getR73());//18-24的示值差值 供电量
//                }
//
//                ppqA = ppqA.add(ppqA);//0-6供电量
//                ppqB = ppqB.add(ppqB);//6-12供电量
//                ppqC = ppqC.add(ppqC);//12-18供电量
//                ppqD = ppqD.add(ppqD);//18-24供电量
//                spqA = spqA.add(spqA);//0-6售电量
//                spqB = spqB.add(spqB);//6-12售电量
//                spqC = spqC.add(spqC);//12-18售电量
//                spqD = spqD.add(spqD);//18-24售电量
//            }
//            BigDecimal lostA = ppqA.subtract(spqA);//0-6损耗电量
//            BigDecimal lostB = ppqB.subtract(spqB);//6-12损耗电量
//            BigDecimal lostC = ppqC.subtract(spqC);//12-18损耗电量
//            BigDecimal lostD = ppqD.subtract(spqD);//18-24损耗电量
//            BigDecimal lossrateA = lostA.divide(ppqA, BigDecimal.ROUND_HALF_UP);//0-6线损率
//            BigDecimal lossrateB = lostB.divide(ppqB, BigDecimal.ROUND_HALF_UP);//6-12线损率
//            BigDecimal lossrateC = lostC.divide(ppqC, BigDecimal.ROUND_HALF_UP);//12-18线损率
//            BigDecimal lossrateD = lostD.divide(ppqD, BigDecimal.ROUND_HALF_UP);//18-24线损率
//
//
//            BigDecimal Appq = new BigDecimal(0);//A相供电量声明
//            BigDecimal Bppq = new BigDecimal(0);//B相
//            BigDecimal Cppq = new BigDecimal(0);//C相
//            BigDecimal Aspq = new BigDecimal(0);//A相售电量声明
//            BigDecimal Bspq = new BigDecimal(0);//B相
//            BigDecimal Cspq = new BigDecimal(0);//C相
//
//            List<LinelossPower> linelossPowers = WebServiceSchedule.getDayPowers(meterAssetNo, TimeUtil.getStartTwoTime());//功率曲线
//            for (LinelossPower linelossPower : linelossPowers) {
//                String eleAssetNum = linelossPower.getMeterAssetNo();//电能表资产号
//                Date sendTime = linelossPower.getRecTime();//获取上送时间
////                String tomorr = TimeUtil.getYesterday(sendTime);
//                BigDecimal tFactor = linelossPower.getTFactor();//综合倍率
//                String usageTypeCode = linelossPower.getUsageTypeCode();//主用途类型
//                if (linelossPower.getPhaseFlag().contains("有功A相")) {//相别信息
//                    if (usageTypeCode.contains("售电侧结算")) {//售电量
//                        Aspq = Aspq.add(TwenfourPointUtil.getAddPower(linelossPower).multiply(tFactor));
//                    } else {//供电量
//                        Appq = Appq.add(TwenfourPointUtil.getAddPower(linelossPower).multiply(tFactor));
//                    }
//                } else if (linelossPower.getPhaseFlag().contains("有功B相")) {
//                    if (usageTypeCode.contains("售电侧结算")) {//售电量
//                        Bspq = Bspq.add(TwenfourPointUtil.getAddPower(linelossPower).multiply(tFactor));
//                    } else {//供电量
//                        Bppq = Bppq.add(TwenfourPointUtil.getAddPower(linelossPower).multiply(tFactor));
//                    }
//                } else if (linelossPower.getPhaseFlag().contains("有功C相")) {
//                    if (usageTypeCode.contains("售电侧结算")) {//售电量
//                        Cspq = Cspq.add(TwenfourPointUtil.getAddPower(linelossPower).multiply(tFactor));
//                    } else {//供电量
//                        Cppq = Cppq.add(TwenfourPointUtil.getAddPower(linelossPower).multiply(tFactor));
//                    }
//                }
//            }
////            WebServiceSchedule webSer = new WebServiceSchedule();
////            List<PhaseFlag> phaseFlags = webSer.PhaseFlag();//tgId
////            for (PhaseFlag phaseFlag : phaseFlags) {
////                if (phaseFlag.getPhaseCode().contains("A相")){
////                    if (phaseFlag.getUsageTypeCode().contains("售电侧结算")){
////                        Aspq = Aspq.add(phaseFlag.getSpq());
////                    }else {
////                        Appq = Appq.add(phaseFlag.getSpq());
////                    }
////                }else if(phaseFlag.getPhaseCode().contains("B相")){
////                    if (phaseFlag.getUsageTypeCode().contains("售电侧结算")){
////                        Bspq = Bspq.add(phaseFlag.getSpq());
////                    }else {
////                        Bppq = Bppq.add(phaseFlag.getSpq());
////                    }
////                }else if(phaseFlag.getPhaseCode().contains("C相")){
////                    if (phaseFlag.getUsageTypeCode().contains("售电侧结算")){
////                        Cspq = Cspq.add(phaseFlag.getSpq());
////                    }else {
////                        Cppq = Cppq.add(phaseFlag.getSpq());
////                    }
////                }
////            }
//            BigDecimal Alost = Appq.subtract(Aspq);//A相损耗电量
//            BigDecimal Blost = Bppq.subtract(Bspq);//B相损耗电量
//            BigDecimal Clost = Cppq.subtract(Cspq);//C相损耗电量
//            BigDecimal Alossrate = Alost.divide(Appq, BigDecimal.ROUND_HALF_UP);//A相线损率
//            BigDecimal Blossrate = Blost.divide(Bppq, BigDecimal.ROUND_HALF_UP);//B相线损率
//            BigDecimal Clossrate = Clost.divide(Cppq, BigDecimal.ROUND_HALF_UP);//C相线损率
//
//
//            //分时集合  分相集合
//
//            SplitTime splitTime1 = new SplitTime();
//            splitTime1.setTimeSlot("0-6时");
//            splitTime1.setPpq(ppqA.toString());
//            splitTime1.setTgSpq(spqA.toString());
//            splitTime1.setLossPq(lostA.toString());
//            splitTime1.setLinelossRate(lossrateA.toString() + "%");
//            list.add(splitTime1);
//            SplitTime splitTime2 = new SplitTime();
//            splitTime2.setTimeSlot("6-12时");
//            splitTime2.setPpq(ppqB.toString());
//            splitTime2.setTgSpq(spqB.toString());
//            splitTime2.setLossPq(lostB.toString());
//            splitTime2.setLinelossRate(lossrateB.toString() + "%");
//            list.add(splitTime2);
//            SplitTime splitTime3 = new SplitTime();
//            splitTime3.setTimeSlot("12-18时");
//            splitTime3.setPpq(ppqC.toString());
//            splitTime3.setTgSpq(spqC.toString());
//            splitTime3.setLossPq(lostC.toString());
//            splitTime3.setLinelossRate(lossrateC.toString() + "%");
//            list.add(splitTime3);
//            SplitTime splitTime4 = new SplitTime();
//            splitTime4.setTimeSlot("18-24时");
//            splitTime4.setPpq(ppqD.toString());
//            splitTime4.setTgSpq(spqD.toString());
//            splitTime4.setLossPq(lostD.toString());
//            splitTime4.setLinelossRate(lossrateD.toString() + "%");
//            list.add(splitTime4);
//
//            SplitTime splitTimea = new SplitTime();
//            splitTimea.setPhaseSlot("A相");
//            splitTimea.setPpq(Appq.toString());
//            splitTimea.setTgSpq(Aspq.toString());
//            splitTimea.setLossPq(Alost.toString());
//            splitTimea.setLinelossRate(Alossrate.toString());
//            list.add(splitTimea);
//
//            SplitTime splitTimeb = new SplitTime();
//            splitTimeb.setPhaseSlot("B相");
//            splitTimeb.setPpq(Bppq.toString());
//            splitTimeb.setTgSpq(Bspq.toString());
//            splitTimeb.setLossPq(Blost.toString());
//            splitTimeb.setLinelossRate(Blossrate.toString());
//            list.add(splitTimeb);
//
//            SplitTime splitTimec = new SplitTime();
//            splitTimec.setPhaseSlot("C相");
//            splitTimec.setPpq(Cppq.toString());
//            splitTimec.setTgSpq(Cspq.toString());
//            splitTimec.setLossPq(Clost.toString());
//            splitTimec.setLinelossRate(Clossrate.toString());
//            list.add(splitTimec);
        }catch (Exception e){
            e.printStackTrace();
            SplitTime splitTime1 = new SplitTime();
            splitTime1.setTimeSlot("0-6时");
            splitTime1.setPpq("0");
            splitTime1.setTgSpq("0");
            splitTime1.setLossPq("0");
            splitTime1.setLinelossRate("0");
            list.add(splitTime1);
            SplitTime splitTime2 = new SplitTime();
            splitTime2.setTimeSlot("6-12时");
            splitTime2.setPpq("0");
            splitTime2.setTgSpq("0");
            splitTime2.setLossPq("0");
            splitTime2.setLinelossRate("0");
            list.add(splitTime2);
            SplitTime splitTime3 = new SplitTime();
            splitTime3.setTimeSlot("12-18时");
            splitTime3.setPpq("0");
            splitTime3.setTgSpq("0");
            splitTime3.setLossPq("0");
            splitTime3.setLinelossRate("0");
            list.add(splitTime3);
            SplitTime splitTime4 = new SplitTime();
            splitTime4.setTimeSlot("18-24时");
            splitTime4.setPpq("0");
            splitTime4.setTgSpq("0");
            splitTime4.setLossPq("0");
            splitTime4.setLinelossRate("0");
            list.add(splitTime4);

            SplitTime splitTimea = new SplitTime();
            splitTimea.setPhaseSlot("A相");
            splitTimea.setPpq("0");
            splitTimea.setTgSpq("0");
            splitTimea.setLossPq("0");
            splitTimea.setLinelossRate("0");
            list.add(splitTimea);

            SplitTime splitTimeb = new SplitTime();
            splitTimeb.setPhaseSlot("B相");
            splitTimeb.setPpq("0");
            splitTimeb.setTgSpq("0");
            splitTimeb.setLossPq("0");
            splitTimeb.setLinelossRate("0");
            list.add(splitTimeb);

            SplitTime splitTimec = new SplitTime();
            splitTimec.setPhaseSlot("C相");
            splitTimec.setPpq("0");
            splitTimec.setTgSpq("0");
            splitTimec.setLossPq("0");
            splitTimec.setLinelossRate("0");
            return list;
        }
            return list;
    }

    /**
     * TODO 通过工单编号查询该工单下的皮尔逊系数前五的用户
     */
    @ResponseBody
    @RequestMapping("/pearson")
    public Map pearson(String tgId) throws ParseException {
        Map<String,BigDecimal> descOrderValueMap  = Maps.newLinkedHashMap();
        List<String> consNamelist = new ArrayList<>();
        //获取用户名称列表
        List<LinelossSpq> tgspq = WebServiceSchedule.getTgspq(tgId, TimeUtil.getStartTwoTime());//获取所有用户名称
        for (LinelossSpq linelossSpq : tgspq) {
            consNamelist.add(linelossSpq.getConsName());
        }
        try {
            Map<String,BigDecimal> map  =  Maps.newHashMap();
            //1-30号中的损耗电量作为一个BigDecimal的数组
            List<BigDecimal> lossPqlist = new ArrayList<>();
            //获取30天电量数据
            List<String> days = TimeUtil.get30days();//取近一个月的日期
            List<List<LinelossSpq>> maptimeCon = new ArrayList<>();  //List 售电量明细
            for (String day : days) {
                lossPqlist.add(WebServiceSchedule.getTgppq(tgId,day).get(0).getPapE());//1-30号损耗电量 后续从表中直接查询 需要更改
                maptimeCon.add(WebServiceSchedule.getTgspq(tgId,day));
            }
//            //获取用户名称列表
//            List<LinelossSpq> tgspq = WebServiceSchedule.getTgspq(tgId, TimeUtil.getStartTwoTime());//获取所有用户名称
//            for (LinelossSpq linelossSpq : tgspq) {
//                consNamelist.add(linelossSpq.getConsName());
//            }
            Map<String,List<BigDecimal>> mapSpq = Maps.newHashMap();//key用户名称 List<用户30天电量>
            for(int i=0;i<consNamelist.size();i++){
                List<BigDecimal> sqp30 = new ArrayList<>();
                for (int j=0;j<days.size();j++) {
                    sqp30.add(maptimeCon.get(j).get(i).getPapE());
                }
                mapSpq.put(consNamelist.get(i),sqp30);
            }
            BigDecimal[] yData = new BigDecimal[lossPqlist.size()];
            BigDecimal[] xData = new BigDecimal[lossPqlist.size()];//获取当月损耗电量，由集合转化为数组
            lossPqlist.toArray(xData);
            for (String conName : consNamelist) {
                List<BigDecimal> linelossSpqs = mapSpq.get(conName);
                linelossSpqs.toArray(yData);
                //皮尔逊公式机算
                BigDecimal pearsonScore = PearsonUtil.getPearsonCorrelationScore(xData, yData);
                //机算结果存value，用户名存key
                map.put(conName,pearsonScore.abs());
            }
            //采用linedkhashmap的形式取前五用户

            map.entrySet().stream().sorted(Map.Entry.<String, BigDecimal>comparingByValue().reversed()).forEachOrdered(e->descOrderValueMap.put(e.getKey(),e.getValue()));
        }catch (Exception e){
            e.printStackTrace();
            descOrderValueMap.put(consNamelist.get(0),new BigDecimal("0.00"));
            descOrderValueMap.put(consNamelist.get(1),new BigDecimal("0.00"));
            descOrderValueMap.put(consNamelist.get(2),new BigDecimal("0.00"));
            descOrderValueMap.put(consNamelist.get(3),new BigDecimal("0.00"));
            descOrderValueMap.put(consNamelist.get(4),new BigDecimal("0.00"));
            return descOrderValueMap;
        }
        return descOrderValueMap;
    }

    /**
     * TODO 通过工单编号查询该工单下的皮尔逊系数前五的用户
     */
    @ResponseBody
    @PostMapping("/pearson1")
    public Map pearson1(String tgId){
        Map<String,BigDecimal> map  =  Maps.newHashMap();
        //1-30号中的损耗电量作为一个BigDecimal的数组
        List<LinelossSynana> llSys = linelossSpqMapper.selectLineloss(tgId, TimeUtil.getStartMon());
        List<BigDecimal> lossPqlist = new ArrayList<>();
        for (LinelossSynana llSy : llSys) {
            lossPqlist.add(llSy.getLossPq());
        }
        BigDecimal[] xData = new BigDecimal[lossPqlist.size()];//获取当月损耗电量，由集合转化为数组
        lossPqlist.toArray(xData);

        //获取所有用户的用户名
        List<String> consNamelist = linelossSpqMapper.selectConsName(tgId, TimeUtil.getStartMon());
        for (String conName : consNamelist) {
            BigDecimal[] yData = new BigDecimal[lossPqlist.size()];//定义每个用户的数组
            //根据用户名查询每天的电量并存为数组
            List<BigDecimal> linelossSpqs = linelossSpqMapper.selectlineSpq(TimeUtil.getStartMon(),conName);
            linelossSpqs.toArray(yData);
            //皮尔逊公式机算
            BigDecimal pearsonScore = PearsonUtil.getPearsonCorrelationScore(xData, yData);
            //机算结果存value，用户名存key
            map.put(conName,pearsonScore.abs());
        }
        //采用linedkhashmap的形式取前五用户
        Map<String,BigDecimal> descOrderValueMap  = Maps.newLinkedHashMap();
        map.entrySet().stream().sorted(Map.Entry.<String, BigDecimal>comparingByValue().reversed()).forEachOrdered(e->descOrderValueMap.put(e.getKey(),e.getValue()));
        return descOrderValueMap;
    }



    /**
     * TODO 线损工单定时归档
     */
    @ResponseBody
    @PostMapping("/linelossfile")
    public void linelossfile(){
        List<String> stringsyesd = linelossWorkOrderMapper.selectYesdayLineWo(TimeUtil.getStartTime());//昨天工单
        List<String> stringsday = linelossWorkOrderMapper.selectYesdayLineWo(TimeUtil.getStart5Time());//今天工单
        for (String ys : stringsyesd) {
            if(!stringsday.contains(ys)){
                linelossWorkOrderMapper.updateLineloss(ys,TimeUtil.getStartTime());
            }
        }
    }

    /**
     * TODO 模拟召测,手动归档
     */
    @ResponseBody
    @PostMapping("/over")
    public int WorkOrderOver(@RequestParam String tgId){
        Integer integer = linelossWorkOrderService.updatwWoStatus4(tgId);
        return integer;
    }
}
