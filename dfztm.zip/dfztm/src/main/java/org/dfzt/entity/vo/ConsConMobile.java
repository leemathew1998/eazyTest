package org.dfzt.entity.vo;

import lombok.Data;

/**
 * @Author: 14259 zhangsheng
 * @Date: 2023/4/8
 * @Version: 1.00
 */
@Data
public class ConsConMobile {
    private String contactMode;//联系类型
    private String contactName;//联系人
    private String mobile;//移动电话
}
