package org.dfzt.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.dfzt.entity.po.DMeter;

/**
* @author 李木
* @description 针对表【d_meter(电能表信息)】的数据库操作Mapper
* @createDate 2023-02-25 18:01:28
* @Entity org.afzt.entity.po.DMeter
*/
public interface DMeterMapper extends BaseMapper<DMeter> {

}




