package org.dfzt.service;

import com.baomidou.mybatisplus.extension.service.IService;
import org.dfzt.entity.po.CollectInforma;
import org.dfzt.entity.po.MeterCurr;
import org.dfzt.entity.po.MeterVoltage;
import org.dfzt.entity.po.MeterWorkOrder;

import java.util.List;

/**
* @author 李木
* @description 针对表【collect_informa】的数据库操作Service
* @createDate 2023-02-25 11:07:08
*/
public interface CollectInformaService extends IService<CollectInforma> {

    void meterWorkOrder(List<CollectInforma> collectInformas);
    MeterWorkOrder meterWorkOrderUser(CollectInforma collectInforma, List<MeterVoltage> meterVs,List<MeterCurr> meterCurrs);

    void solveOrder();

}
