package org.dfzt.entity.po;


import cn.afterturn.easypoi.excel.annotation.Excel;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.dfzt.eunm.WorkOrderStatusEnum;

import java.math.BigDecimal;
import java.util.Date;

/**
 * (RecycleWorkOrder)表实体类
 *
 * @author makejava
 * @since 2022-07-11 15:38:15
 */
@SuppressWarnings("serial")

@TableName("recycle_work_order")
@Data
public class RecycleWorkOrder extends Model<RecycleWorkOrder> {
    private Integer id;

    private BigDecimal rcvblAmtId;
    //工单编号
    @Excel(name = "工单编号",orderNum = "1",width = 20)
    private String workOrderNo;
    //台区经理
    @Excel(name = "台区经理",orderNum = "2",width = 20)
    private String tgManager;
    //台区编号
    @Excel(name = "台区编号",orderNum = "3",width = 20)
    private String tgId;
    //台区名称
    @Excel(name = "台区名称",orderNum = "4",width = 20)
    private String tgName;
    //供电单位
    @Excel(name = "供电单位编号",orderNum = "5",width = 20)
    private String orgNo;
    //供电单位
    @Excel(name = "供电单位名称",orderNum = "6",width = 20)
    private String orgName;
    //用户名称
    @Excel(name = "用户名称",orderNum = "7",width = 20)
    private String consName;
    //用户编号
    @Excel(name = "用户编号",orderNum = "8",width = 20)
    private String consNo;
    //用户地址
    @Excel(name = "用户地址",orderNum = "9",width = 20)
    private String elecAddr;
    //用户电话
    @Excel(name = "用户电话",orderNum = "10",width = 20)
    private String mobile;
    //用电类别
    @Excel(name = "用电类别",orderNum = "11",width = 20)
    private String elecTypeCode;
    //电度电费
    @Excel(name = "电度电费",orderNum = "12",width = 20)
    private BigDecimal oweAmt;

    //实收金额
    @Excel(name = "实收金额",orderNum = "13",width = 20)
    private BigDecimal rcvedAmt;
    //应收金额
    @Excel(name = "应收金额",orderNum = "14",width = 20)
    private BigDecimal rcvblAmt;
    //应收违约金
    @Excel(name = "应收违约金",orderNum = "15",width = 20)
    private BigDecimal rcvblPenalty;
    //实收违约金
    @Excel(name = "实收违约金",orderNum = "16",width = 20)
    private BigDecimal rcvedPenalty;
    //电费年月
    @Excel(name = "电费年月",orderNum = "17",width = 20)
    private String rcvblYm;
    //差价收益
    @Excel(name = "差价收益",orderNum = "18",width = 20)
    private BigDecimal differenceEarnings;
    //偏差考核
    @Excel(name = "偏差考核",orderNum = "19",width = 20)
    private BigDecimal deviationAssess;
    //工单状态，1.待处理，2.处理中，3.待归档，4.已归档
    @ApiModelProperty("状态")
    private String workOrderStatus;
    //工单创建人
    private String workOrderCreator;
    //工单生成时间
    private Date workOrderTime;
    @Excel(name = "工单生成时间",orderNum = "20",width = 20)
    private String workOrderCtime1;
    //工单耗时
    private String workOrderUtime;
    //工单解决时间
    private Date workOrderStime;
    //工单归档时间
    private Date workOrderFtime;
    //处理人
    private String handler;
    //处理人接收时间
    private Date handlerRtime;
    //是连续几天的工单
    private Integer workOrderCycle;
    //工单描述
    private String workOrderDes;

//    public void setWorkOrderStatus(String workOrderStatus) {
//        this.workOrderStatus = WorkOrderStatusEnum.getValueByName(workOrderStatus);
//    }
}
