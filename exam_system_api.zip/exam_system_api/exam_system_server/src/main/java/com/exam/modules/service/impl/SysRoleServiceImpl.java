package com.exam.modules.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.exam.modules.entity.SysRole;
import com.exam.modules.entity.SysRoleMenu;
import com.exam.modules.entity.SysUser;
import com.exam.modules.entity.dto.RoleMenuDTO;
import com.exam.modules.entity.vo.RoleQueryVo;
import com.exam.modules.mapper.SysRoleMapper;
import com.exam.modules.mapper.SysUserMapper;
import com.exam.modules.service.ISysRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.RequestBody;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * <p>
 * 角色表 服务实现类
 * </p>
 *
 * @author dyy
 * @since 2022-10-27
 */
@Service
@Transactional
public class SysRoleServiceImpl extends ServiceImpl<SysRoleMapper, SysRole> implements ISysRoleService {
    @Resource
    private SysUserMapper userMapper;

    /**
     * 根据用户查询角色列表
     *
     * @param page
     * @param roleQueryVo
     * @return
     */
    @Override
    public IPage<SysRole> findRoleListByUserId(IPage<SysRole> page, RoleQueryVo roleQueryVo) {
        //创建条件构造器
        QueryWrapper<SysRole> queryWrapper = new QueryWrapper<SysRole>();
        //角色名称
        queryWrapper.like(!ObjectUtils.isEmpty(roleQueryVo.getRoleName()),
                "ROLE_NAME",roleQueryVo.getRoleName());
        //排序
        queryWrapper.orderByAsc("ROLE_ID");
        //根据用户ID查询用户信息
        SysUser user = userMapper.selectById(roleQueryVo.getUserId());
        //如果用户不为空、且不是管理员，则只能查询自己创建的角色
        if(user!=null && !ObjectUtils.isEmpty(user.getIsAdmin()) && !user.getIsAdmin().equals("1")){
            queryWrapper.eq("CREATE_BY",roleQueryVo.getUserId());
        }
        return baseMapper.selectPage(page,queryWrapper);
    }

    /**
     * 检查角色是否被使用
     * @param id
     * @return
     */
    @Override
    public boolean hashRoleCount(Long id) {
        return baseMapper.getRoleCountByRoleId(id)>0;
    }

    /**
     * 删除角色
     * @param id
     * @return
     */
    @Override
    public boolean deletRoleById(Long id) {
        //删除角色权限关系
        baseMapper.deleteRoleMenuByRoleId(id);
        //删除角色
        return baseMapper.deleteById(id)>0;
    }

    /**
     * 保存角色权限关系
     * @param roleMenuDTO
     * @return
     */
    @Override
    //发生运行时异常，进行回滚
    @Transactional(rollbackFor = RuntimeException.class)
    public boolean saveRoleMenu(RoleMenuDTO roleMenuDTO) {
        //删除该角色对应的权限信息
        baseMapper.deleteRoleMenuByRoleId(roleMenuDTO.getRoleId());

        if (!roleMenuDTO.getList().isEmpty()){
            //保存角色权限
            return baseMapper.saveRoleMenu(roleMenuDTO.getRoleId(),roleMenuDTO.getList())>0;
        }
        return true;
    }

    /**
     * 根据用户ID查询该用户拥有的角色ID
     * @param userId
     * @return
     */
    @Override
    public List<Long> findRoleIdByUserId(Long userId) {
        return baseMapper.findRoleIdByUserId(userId);
    }
}
