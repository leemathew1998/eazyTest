package com.exam.config.security;

import com.exam.modules.entity.SysMenu;
import com.exam.modules.entity.SysUser;
import com.exam.modules.mapper.SysUserMapper;
import com.exam.modules.service.ISysMenuService;
import com.exam.modules.service.ISysUserService;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @Author dyy
 * @Date 2022/10/28 9:57
 * @PackageName:com.exam.config.security
 * @ClassName: CustomerUserDetailsService
 * @Description: TODO 用户认证处理器类
 * @Version 1.0
 */
@Component
public class CustomerUserDetailsService implements UserDetailsService {

    @Resource
    private ISysUserService sysUserService;
    @Resource
    private SysUserMapper sysUserMapper;
    @Resource
    private ISysMenuService sysMenuService;

    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        //调用根据用户名查询用户信息的方法
        SysUser user = sysUserService.findUserByUserName(userName);
        //判断对象是否为空，如果对象为空，则登录失败
        if (user == null) {
            throw new UsernameNotFoundException("用户名密码错误！");
        }
        //查询用户的拥有的权限列表
        List<SysMenu> menuList = sysMenuService.findSysMenuListByUserId(user.getUserId());
        //获取权限编码
        List<String> collect = menuList.stream()
                .filter(Objects::nonNull)
                .map(SysMenu::getCode)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
        //转换成数组
        String[] strings = collect.toArray(new String[collect.size()]);
        //设置权限列表
        List<GrantedAuthority> authorityList = AuthorityUtils.createAuthorityList(strings);
        user.setAuthorities(authorityList);
        //设置菜单列表
        user.setSysMenusList(menuList);
        //查询成功
        return user;
    }
}
