package org.dfzt.entity.po;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @Author: 14259 zhangsheng 关联95598用户相关信息表
 * @Date: 2023/2/26
 * @Version: 1.00
 */
@Data
public class SSrvReq implements Serializable {
    private Long reqId;//服务请求标识
    private Long channelId;//服务渠道标识
    private String srvMode;//服务渠道编号
    private String busiTypeCode;//业务类型
    private String srvEmpNo;//为客户服务人员 记录人员系统用户名
    private String custNo;//客户标识
    private String contactName;//服务人员联系当事人名字
    private String orderId;//各业务工单申请编号
    private String callingNo;//主叫号码
    private String tel;//客户联系电话
    private String mobile;//客户联系手机号
    private String faxNo;//客户传真电话
    private String email;//客户邮箱
    private String addr;//客户联系地址
    private Date reqDate;//服务请求时间
    private String commId;//增加服务请求和通讯记录关联
    private String custName;//客户名称
    private String orgNo;//供电单位编号
}
