package org.dfzt.entity.xmlDemoReal;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import com.thoughtworks.xstream.security.AnyTypePermission;
import org.dfzt.util.XStreamUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName RunDemo1
 * @Description TODO
 * @Author 邢俊豪
 * @Date 2022/12/15 18:42
 */
public class RunDemo1 {


    public static void main(String[] args) {
        Demo1 demo1 = new Demo1();
        Demo2 demo2 =new Demo2();
        List<General> generals =new ArrayList<>();
        General general5 = new General();
        general5.setN("setRLT_FLAG");
        general5.setValue("false");
        generals.add(general5);
        General general6 = new General();
        general6.setN("setRLT_MEMO");
        general6.setValue("111");
        generals.add(general6);
        demo2.setGeneral(generals);
        demo1.setDemo2(demo2);


        Demo3 demo3 =new Demo3();
        demo1.setDemo2(demo2);

        List<General> list =new ArrayList<>();
        General general = new General("abc", "cvb");
        General general1 = new General("xyz", "jkl");
        list.add(general);
        list.add(general1);
        //demo3.setGeneral(list);
        demo1.setDemo3(demo3);



        XStream xstream = new XStream();
        xstream.registerConverter(new DemoConverter());
        xstream.autodetectAnnotations(true);
        xstream.addPermission(AnyTypePermission.ANY);
        /*起别名*/
        xstream.alias("demo1", Demo1.class);
        xstream.alias("demo2", Demo2.class);
//        xstream.alias("DATA_CONTENT", Demo3.class);
        xstream.alias("general", General.class);

        //xstream使用注解转换
        xstream.processAnnotations(Demo1.class);
        xstream.setClassLoader((Demo1.class.getClassLoader()));
        String s = xstream.toXML(demo1);
        String s1 = s.replaceAll("__", "_");
        s1="<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"+s1;
        System.out.println(s1);
       // Demo1 demo11 =(Demo1)xstream.fromXML(s1);
        Demo1 demo11 =(Demo1) XStreamUtils.xmlToObject(s1,Demo1.class,new DemoConverter());
        System.out.println(demo11);



    }
}
